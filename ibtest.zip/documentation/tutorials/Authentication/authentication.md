*Urls*
{@link http://localhost:3000/account-opening/authentication}
{@link http://localhost:3000/account-opening/login}

## Solution Designs
- {@link https://abouthere.atlassian.net/wiki/display/DYB/User+Authentication API: User Authentication}

## Enviroments
- {@link https://abouthere.atlassian.net/wiki/display/DYB/Environments+-+Developer+1 Environments - Developer 1}
- {@link https://abouthere.atlassian.net/wiki/display/DYB/Environment+Specifications Environment Specifications}
- {@link https://abouthere.atlassian.net/wiki/display/DYB/Environment+Specifications Environment Routing/Access}
- {@link https://abouthere.atlassian.net/wiki/display/DYB/Environment+access Environment Staff Access}
- {@link https://abouthere.atlassian.net/wiki/display/DYB/Environment+Specifications Environment Routing/Access}

## User API Flow
- {@link https://abouthere.atlassian.net/wiki/display/DYB/API+Journey+Summary API Journey Flows Summary}
