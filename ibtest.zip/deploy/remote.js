const { remote } = require('web-ui-tools').deploy.v1;

remote({
	WEB_APP_NAME: 'web-app',
	WEB_APP_CONFIG: 'web-app-config',
	WEB_APP_BUILDS: 'web-app-builds',
});
