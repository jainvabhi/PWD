const { test } = require('web-ui-tools').deploy.v1;

test({
	jestOptions: require('../package.json').jest,
	repo: 'web-app',
});
