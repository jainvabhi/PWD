const { local } = require('web-ui-tools').deploy.v1;

local({
	jenkinsJob: 'account-opening-deploy',
	deployEnv: {
		choices: ['int3', 'sit6', 'dev1', 'fat1'],
		default: 'int3',
	},
});
