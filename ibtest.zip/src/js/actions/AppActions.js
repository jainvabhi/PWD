/**
 * @module AppActions
 * @requires AppConstants
 * @requires AppDispatcher
 */

const AppConstants = require('../constants/AppConstants');
const AppDispatcher = require('../dispatcher/AppDispatcher');
const ErrorHandlers = require('../utils/ErrorHandlers');
const { logError } = require('../utils/ErrorHandlers/helpers');

/**
 * @class AppActions
 */
const AppActions = {

	/**
	 * Log that an API call has begun.
	 *
	 * @param  {String} url
	 */
	trackApiCallStarted(url) {
		AppDispatcher.handleViewAction({
			actionType: AppConstants.TRACK_API_CALL_STARTED,
			data: { url },
		});
	},

	/**
	 * Log that an API call has finished.
	 *
	 * @param  {String} url
	 */
	trackApiCallComplete(url) {
		AppDispatcher.handleViewAction({
			actionType: AppConstants.TRACK_API_CALL_COMPLETE,
			data: { url },
		});
	},

	/**
	 * Notify the app that a stepup authentication is now happening
	 *
	 * @param  {Function} callback
	 */
	requireStepupAuthentication(callback) {
		AppDispatcher.handleViewAction({
			actionType: AppConstants.REQUEST_STEPUP_AUTHENTICATION,
			callback,
		});
	},

	/**
	 * Execute the callback (e.g. - continue what we were trying to do before stepup)
	 */
	callStepupAuthenticationCallback() {
		AppDispatcher.handleViewAction({
			actionType: AppConstants.REQUEST_STEPUP_AUTHENTICATION_CALLBACK,
		});
	},

	handleError(error) {
		ErrorHandlers.handle(error, logError(this.navigateToError));
	},

	navigateToError(error) {
		const taskId = 'WEB-ERROR';
		AppDispatcher.handleViewAction({
			actionType: AppConstants.NAVIGATE_TO_WEB_TASK,
			data: { taskId, data: error },
		});
	},

	/**
	 * Resets all data accrewed by a user during session
	 */
	reset() {
		AppDispatcher.handleViewAction({
			actionType: AppConstants.RESET,
		});
	},

	/**
	 * Remove unload warning
	 */
	removeUnloadWarning() {
		AppDispatcher.handleViewAction({
			actionType: AppConstants.REMOVE_UNLOAD_WARNING,
		});
	},
};

module.exports = AppActions;
