const AppDispatcher = require('../dispatcher/AppDispatcher');
const PageSessionConstants = require('../constants/PageSessionConstants');

const PageSessionActions = {
	clearPageSession() {
		AppDispatcher.handleServerAction({
			actionType: PageSessionConstants.CLEAR_PAGE_SESSION,
		});
	},

	setPageSession(data) {
		AppDispatcher.handleServerAction({
			actionType: PageSessionConstants.SET_PAGE_SESSION,
			data,
		});
	},
};

module.exports = PageSessionActions;
