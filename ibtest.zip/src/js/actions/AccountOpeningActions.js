/**
 * @module AccountOpeningActions
 * @requires AccountOpeningConstants
 * @requires AppDispatcher
 * @requires appConstants
 */

const AccountOpeningConstants = require('../constants/AccountOpeningConstants');
const AppDispatcher = require('../dispatcher/AppDispatcher');
const AppConstants = require('../constants/AppConstants');

/**
 * @class AccountOpeningActions
 */
const AccountOpeningActions = {

	/**
	 * Setts the product code
	 *
	 * @param {String} productCode Product code to set
	 *
	 */
	setProductCode(productCode) {
		AccountOpeningActions.raise(AccountOpeningConstants.SET_PRODUCT_CODE, { productCode });
	},

	raise(actionType, data) {
		AppDispatcher.handleViewAction({
			actionType,
			data,
		});
	},

	/**
	 * User has been given an offer and we need to retrieve the details.
	 *
	 * @param {String} caseId 			The caseId for the application.
	 */
	requestProductOffer(caseId) {
		AccountOpeningActions.raise(AccountOpeningConstants.REQUEST_PRODUCT_OFFER, { caseId });
	},

	/**
	 * Accept/decline a product offer.
	 * When multiple products are offered in future, this should
	 * be extended to take arrays of yes / no.
	 *
	 * @param  {String} productId 			Product to accept.
	 * @param  {Boolean} isDecline 			decline offer.
	 * @param  {String} offerProductCode 	code of chosen product offer
	 * @param  {Array} documents 			audit documents
	 */
	respondToProductOffer(offerId, isDecline, offerProductCode, docs) {
		AccountOpeningActions.raise(AccountOpeningConstants.RESPOND_TO_PRODUCT_OFFER, { offerId, isDecline, offerProductCode, docs });
	},

	/**
	 * Update credit limit on a product offer.
	 *
	 * @param  {String} offerId 			Product to accept.
	 * @param  {String} amount 				credit limit
	 * @param	 {String} acceptAfterUpdate			set flag to indicate
	 */
	updateProductOffer(offerId, amount, acceptAfterUpdate) {
		AccountOpeningActions.raise(AccountOpeningConstants.UPDATE_PRODUCT_OFFER, { offerId, amount, acceptAfterUpdate });
	},

	/**
	 * User has changed a value in the form.
	 *
	 * @param  {String} key   		Which value was changed?
	 * @param  {Any} value 			What is the new value?
	 * @param  {String} arrayName 	Optional value, used if the value should be stored in an array
	 * @param  {String}  arrayIndex	Optional value, specifies the index within the array to update
	 */
	updateFormValue(key, value, arrayName, arrayIndex) {
		AccountOpeningActions.raise(AccountOpeningConstants.UPDATE_FORM_VALUE, {
			key,
			value,
			arrayName,
			arrayIndex,
		}
		);
	},

	/**
	 * User has changed a value in the form.
	 *
	 * @param  {Array} data 	List of objects, each with a "key" and "value" pair.
	 */
	updateFormValues(data) {
		AccountOpeningActions.raise(AccountOpeningConstants.UPDATE_FORM_VALUES, data);
	},

	/**
	 * Responsible for raising the action to clear supplied addresses
	 *
	 * @param  {Array} addressIndexes 	Array of address indexes to be removed
	 *
	 */
	clearAddress(addressIndexes) {
		AccountOpeningActions.raise(AccountOpeningConstants.CLEAR_ADDRESS, { addressIndexes });
	},

	/**
	 * Responsible for raising the action to reset supplied address
	 *
	 * @param  {Array} addressIndex Index of the address to reset
	 *
	 */
	resetAddress(addressIndex) {
		AccountOpeningActions.raise(AccountOpeningConstants.RESET_ADDRESS, { addressIndex });
	},

	/**
	 * User has entered a new value Is it valid?
	 *
	 * @param  {String}  group   	Inputs are grouped by form.
	 * @param  {String}  key     	Name of the input.
	 * @param  {Boolean} isValid 	True if the value passes validation.
	 */
	updateValidation(group, key, isValid) {
		AccountOpeningActions.raise(AccountOpeningConstants.UPDATE_VALIDATION, {
			group,
			key,
			isValid,
		});
	},

	/**
	 * User removed a question. Is the form valid?
	 *
	 * @param  {String}  group   	Inputs are grouped by form.
	 * @param  {String}  key     	Name of the input.
	 */
	removeValidation(group, key) {
		AccountOpeningActions.raise(AccountOpeningConstants.REMOVE_VALIDATION, {
			group,
			key,
		});
	},

	/**
	 * The given field can now be visibly validated (i.e. show error messages)
	 *
	 * @param  {String}  group   	Inputs are grouped by form.
	 * @param  {String}  key     	Name of the input.
	 */
	enableValidation(group, key) {
		AccountOpeningActions.raise(AccountOpeningConstants.ENABLE_VALIDATION, {
			group,
			key,
		});
	},

	/**
	 * The given field whilst visible will have its validation state reset
	 *
	 * @param  {String}  group   	Inputs are grouped by form.
	 * @param  {String}  key     	Name of the input.
	 */
	disableValidation(group, key) {
		AccountOpeningActions.raise(AccountOpeningConstants.DISABLE_VALIDATION, {
			group,
			key,
		});
	},

	/**
	 * Send all data captured in the "data capture" phase of account opening.
	 *
	 * @param {Boolean} formComplete		Has the user finished the form now?
	 */
	sendFormData(formComplete, onSuccess) {
		AccountOpeningActions.raise(AccountOpeningConstants.SEND_FORM_DATA, {
			formComplete: !!formComplete,
			onSuccess,
		});
	},

	/**
	 * Fetch the user's form data, including account numbers if the account
	 * has now been setup.
	 *
	 * @param {String} caseId 		Id of the case to fetch.
	 * @param {String} productType 		Type of product we are fetching
	 */
	getCase(caseId, productType) {
		AccountOpeningActions.raise(AccountOpeningConstants.GET_CASE, { caseId, productType });
	},

	/**
	 * Fetch the user's account numbers if the account
	 * has now been setup.
	 *
	 * @param {String} caseId 		Id of the case to fetch.
	 * @param {String} productType 		Type of product we are fetching
	 */
	getCompletedCase(caseId, productType) {
		AccountOpeningActions.raise(AccountOpeningConstants.GET_COMPLETED_CASE, { caseId, productType });
	},

	/**
	 * What screen should the user be on?
	 *
	 * @param {String} caseId 		User case ID.
	 */
	getNextTask(caseId) {
		AccountOpeningActions.raise(AppConstants.GET_NEXT_TASK, { caseId });
	},

	/**
	 * Take the user to the URL represented by the given task ID.
	 *
	 * This should never be called with CSAP tasks. They should be fetched
	 * only from the API (via AccountOpeningActions.getNextTask) so that
	 * we are never out of sync with CSAP.
	 */
	navigateToWebTask(taskId) {
		AccountOpeningActions.raise(AppConstants.NAVIGATE_TO_WEB_TASK, { taskId });
	},

	/**
	 * Clear stored task IDs.
	 */
	clearTasks() {
		AccountOpeningActions.raise(AppConstants.CLEAR_TASKS);
	},

	/**
	 * Clear stored web task ID.
	 */
	clearWebTask() {
		AccountOpeningActions.raise(AppConstants.CLEAR_WEB_TASK);
	},

	/**
	 * Track when the user is/isn't editing a field in the form.
	 *
	 * @param {Boolean} isEditing Are they currently editing a field?
	 */
	setUserIsEditingField(isEditing) {
		AccountOpeningActions.raise(AccountOpeningConstants.SET_USER_IS_EDITING_FIELD, { isEditing });
	},

	/**
	 * Submit a CAS application.
	 */
	submitSwitchingApplication() {
		AccountOpeningActions.raise(AccountOpeningConstants.SUBMIT_SWITCHING_APPLICATION);
	},

	/**
	 * Submit the registration page.
	 *
	 * @param {String} publicKey 		For encryption.
	 * @param {String} keyDatetime 		Timestamp when the key was generated.
	 * @param {String} nextWebTask 		Next web task based on product post registration task
	 */
	submitRegistrationPage(publicKey, keyDatetime, nextWebTask) {
		AccountOpeningActions.raise(AccountOpeningConstants.SUBMIT_REGISTRATION_PAGE, {
			publicKey,
			keyDatetime,
			nextWebTask,
		});
	},

	/**
	 * Force autosaving of the user's data to start.
	 * Successful save calls automatically trigger the next autosave timer, so this
	 * is only needed for the initial kick-off.
	 */
	startAutosaveTimer() {
		AccountOpeningActions.raise(AccountOpeningConstants.START_AUTOSAVE_TIMER);
	},

	/**
	 * Update offer status.
	 * @param  {Event} isAltProduct is offer downgraded or not
	 */
	updateOfferStatus(isAltProduct) {
		AccountOpeningActions.raise(AccountOpeningConstants.UPDATE_OFFER_STATUS, { isAltProduct });
	},

	/**
	 * Update username
	 * @param  {username}
	 */
	updateUserName(userName) {
		AccountOpeningActions.raise(AccountOpeningConstants.UPDATE_USERNAME, { userName });
	},

	/**
	 * Bank ID may or may not be present in the data store from app start
	 * @param  {bankId}
	 */
	setBankId(bankID) {
		AccountOpeningActions.raise(AccountOpeningConstants.SET_BANK_ID, { bankID });
	},

	/**
	 * Clear any bankID that has been set
	 */
	resetBankId() {
		AccountOpeningActions.raise(AccountOpeningConstants.RESET_BANK_ID);
	},

	/**
	 * Clear any username that has been set
	 */
	resetUsername() {
		AccountOpeningActions.raise(AccountOpeningConstants.CLEAR_USERNAME);
	},

	/**
	 * Clear any userInfo that has been set
	 */
	resetUserInfo(userInfo) {
		AccountOpeningActions.raise(AccountOpeningConstants.CLEAR_USERINFO, { userInfo });
	},

	/**
	 * Receives Http get response body
	 * @param  {object} result Http response body
	 */
	receiveGetResult(result) {
		AccountOpeningActions.raise(AccountOpeningConstants.RECEIVE_GET_RESULT, { result });
	},

	/**
	 * Receives Http get response data for competed case
	 * @param  {object} result Http response body
	 */
	receiveCompletedGetResult(result) {
		AccountOpeningActions.raise(AccountOpeningConstants.RECEIVE_GET_COMPLETED_RESULT, { result });
	},

	/**
	 * Records that a task has been completed
	 * @param  {string} taskId Id of the task that has just been completed
	 */
	recordTaskComplete(taskId) {
		AccountOpeningActions.raise(AccountOpeningConstants.RECORD_TASK_COMPLETE, { taskId });
	},

	setCaseId(caseId) {
		AccountOpeningActions.raise(AccountOpeningConstants.SET_CASE_ID, { caseId });
	},

	/**
	 * submitLetterCode
	 * @param  {string} letter code Id
	 */
	submitLetterCode(letterCode) {
		AccountOpeningActions.raise(AccountOpeningConstants.SUBMIT_LETTER_CODE, { letterCode });
	},


	/**
	 * call off to see if the case has a joint link code
	 */
	hasLinkCode() {
		AccountOpeningActions.raise(AccountOpeningConstants.HAS_LINK_CODE);
	},

	/**
	 * Sets joint account link code
	 *
	 */
	setLinkCode(jointLinkCode) {
		AccountOpeningActions.raise(AccountOpeningConstants.SET_LINK_CODE, { jointLinkCode });
	},


	/**
	 * Sets sub type
	 *
	 */
	setSubType(subType) {
		AccountOpeningActions.raise(AccountOpeningConstants.SET_SUB_TYPE, { subType });
	},

	/**
	 * Resets the errors received upon inital form submission
	 */
	resetFormErrors() {
		AccountOpeningActions.raise(AccountOpeningConstants.RESET_FORM_ERRORS);
	},

	/**
	 * Resets the errors received upon inital form submission
	 */
	resetNIFields() {
		AccountOpeningActions.raise(AccountOpeningConstants.RESET_NI_FIELDS);
	},

	setVariantCode(productVariant) {
		AccountOpeningActions.raise(AccountOpeningConstants.SET_VARIANT_CODE, { productVariant });
	},
};

module.exports = AccountOpeningActions;
