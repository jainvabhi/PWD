const AppDispatcher = require('../dispatcher/AppDispatcher');
const CMSApiUtils = require('../api/CMSApiUtils');
const CMSConstants = require('../constants/CMSConstants');
const moment = require('moment');

const handleError = () => {
	AppDispatcher.handleServerAction({
		actionType: CMSConstants.REQUEST_CMS_FAILURE,
	});
};

const CMSActions = {

	getCMS() {
		CMSApiUtils.fetchLocator()
			.then(res => {
				const { body } = res;
				AppDispatcher.handleServerAction({
					actionType: CMSConstants.REQUEST_CMS_LOCATOR_SUCCESS,
					data: {
						date: moment(),
						body,
					},
				});
			}, handleError);
	},

	getCMSFile(file) {
		CMSApiUtils.fetchDocument(file)
			.then(res => {
				const { body } = res;
				AppDispatcher.handleServerAction({
					actionType: CMSConstants.REQUEST_CMS_SUCCESS,
					data: {
						body,
					},
				});
			}, handleError);
	},
};

module.exports = CMSActions;
