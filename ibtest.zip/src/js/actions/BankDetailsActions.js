/**
 * @module BankDetailsActions
 */

const AccountOpeningServerActionCreator = require('../actions/AccountOpeningServerActionCreator');
const BankDetailsApiUtils = require('../api/BankDetailsApiUtils');
/**
 * @class BankDetailsActions
 */
const BankDetailsActions = {

	getBankDetails(type, accountNumber, sortCode) {
		BankDetailsApiUtils.search({
				account_number: accountNumber,
				sort_code: sortCode,
			})
			.then(res => {
				const { body } = res;
				AccountOpeningServerActionCreator.handleBankSearchSuccess(type, body);
			}, res => {
				AccountOpeningServerActionCreator.handleBankSearchError(type, res);
			});
	},

	resetBankDetails(type) {
		AccountOpeningServerActionCreator.handleBankClear(type);
	},
};

module.exports = BankDetailsActions;
