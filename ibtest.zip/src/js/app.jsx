const startAnalytics = () => {
	if (window._satellite) {
		const AnalyticsActionCreator = require('actions/AnalyticsActionCreator');
		AnalyticsActionCreator.setAdobe(window._satellite, window.adobeDataLayer);
	} else {
		setTimeout(startAnalytics, 50);
	}
};

// Kick off app via routing, when config + content are loaded.
const startApp = () => {
	if (global.envConfig && global.appContent) {
		const envConfig = require('../static/config');
		envConfig.setContent(envConfig, global.appContent);
		const config = require('./config');
		config.setBankId(envConfig.bankId);
		const AppRouter = require('./router/AppRouter.jsx');
		AppRouter.init();
		const Preload = require('./utils/Preload');
		Preload.images();
		setTimeout(startAnalytics, 50);
	} else {
		setTimeout(startApp, 50);
	}
};

setTimeout(startApp, 50);
