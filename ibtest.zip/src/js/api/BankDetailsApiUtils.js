/**
 * @module BankDetailsApiUtils
 */

const envConfig = require('../../static/config');
const config = require('../config');

// TODO move to API folder
const Api = require('./Api');

const _endpointSearch = '/ref/bank/search';

module.exports = {
	apiVersion: config.apiVersions.referenceServices,

	/**
	 * Search bank details API
	 *
	 * @param {String} accountNo 		Account number
	 * @param {String} sortCode 		Sort Code
	 */
	search(data) {
		const { apiVersion } = this;

		const url = [envConfig.apiBaseUrl, _endpointSearch].join('');

		return Api.post(url, data).setupWith({ apiVersion, requireAuth: true });
	},


};
