const Api = require('./Api');

module.exports = {
	Api,
};
