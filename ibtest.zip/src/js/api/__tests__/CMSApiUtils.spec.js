jest.disableAutomock();

const Api = require('../Api');
const CMSApiUtils = require('../CMSApiUtils');

describe('CMSApiUtils', () => {

    beforeEach(() => {
        Api.get = jest.fn(() => {
            return {
                setupWith: jest.fn(),
            }
        });
    });

    describe('fetchLocator', () => {
        it('gets the document-list-locator.json', () => {
            CMSApiUtils.fetchLocator();
            expect(Api.get).toHaveBeenCalledWith('undefined/static/product/config/document-list-locator.json');
        });
    });

    describe('fetchDocument', () => {
        it('gets a cmsFile', () => {
            const cmsFile = 'document-list-accountopening-version1.json';
            CMSApiUtils.fetchDocument(cmsFile);
            expect(Api.get).toHaveBeenCalledWith(`undefined/static/product/config/${cmsFile}`);
        });
    });
});
