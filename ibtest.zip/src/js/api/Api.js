const request = require('superagent-promise')(require('superagent'), require('promise'));

const config = require('../config');

const _ = require('lodash');

const AccountOpeningContentStore = require('stores/AccountOpeningContentStore');
const AppStore = require('stores/AppStore');

const BrowserUtils = require('utils/BrowserUtils');
const GenericMapper = require('utils/GenericMapperUtils');

const Api = {
	options: {
		apiVersion: '0.8',
		contentType: 'application/json',
	},

	get(url) {
		const req = request.get(url);

		return _.extend({}, req, { setupWith: options => req.use(this.setupApi(options)) });
	},

	post(url, data) {
		const req = request.post(url, data);

		return _.extend({}, req, { setupWith: options => req.use(this.setupApi(options)) });
	},

	setupApi(options) {
		const opts = _.extend({}, this.options, options);
		let authHeaders = {};

		return req => {
			const SessionStore = require('../stores/SessionStore');
			const authToken = SessionStore.getToken()['access_token'];

			if (opts.requireAuth && authToken) {
				authHeaders = {
					'Authorization': `Bearer ${authToken}`,
				};
			}

			const headers = {
				'Accept': 'application/json',
				'Content-Type': opts.contentType,
				'x-bpi-version': opts.apiVersion,
				'x-bpi-client-context': this.clientContext(),
				'x-bpi-service-context': config.authentication.context,
				...authHeaders,
			};


			return req.set(headers);
		};
	},

	clientContext() {
		const clientContext = {
			client: {
				userTrackingId: AppStore.getValue('sessionId'),
				appTitle: AccountOpeningContentStore.get('documentTitle'),
				appPackageName: config.analytics.channelID,
				appVersionCode: config.version,
				appVersionName: config.versionName,
			},
			env: {
				platformVersion: BrowserUtils.getBrowserVersion(),
				make: BrowserUtils.getPlatform(),
				locale: BrowserUtils.getUserLocale(),
				platform: config.platform,
			},
		};

		return JSON.stringify(GenericMapper.mapObject(clientContext, {}));
	},
};

module.exports = Api;
