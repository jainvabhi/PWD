/**
 * @module CMSApiUtils
 */

const envConfig = require('../../static/config');

const Api = require('./Api');
const root = '/static/product/config/';
const _endpointCMSLocator = 'document-list-locator.json';

module.exports = {
	/**
	 * Search fetch document locator
	 *
	 */
	fetchLocator() {
		const url = `${envConfig.AOBaseUrl}${root}${_endpointCMSLocator}`;

		return Api.get(url).setupWith();
	},

	/**
	 * Search fetch document file
	 *
	 * @param {String} cmsFile 	cms file name
	 */
	fetchDocument(cmsFile) {
		const url = `${envConfig.AOBaseUrl}${root}${cmsFile}`;

		return Api.get(url).setupWith();
	},
};

