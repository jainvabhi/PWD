jest.autoMockOff();

jest.mock('../../actions/AccountOpeningActions');

const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');

const RefreshHandler = require('../RefreshHandler');
const AccountOpeningActions = require('../../actions/AccountOpeningActions');

const WrappedComponent = props => <h1>WrappedComponent</h1>;

const render = (overrideProps = {}) => {
	const props = {
		data: {},
		pageSession: {},
		...overrideProps,
	};
	const HOC = RefreshHandler(WrappedComponent);
	const container = document.createElement('div');
	const instance = TestUtils.renderIntoDocument(<HOC {...props} />, container);
	return { props, instance };
};

describe('RefreshHandler', () => {
	beforeEach(() => {
		AccountOpeningActions.updateFormValues.mockClear();
		AccountOpeningActions.navigateToWebTask.mockClear();
	});

	describe('when not refreshed', () => {
		it('does NOT redirect', () => {
			const { instance } = render({
				productCode: 'IM135',
			});
			expect(AccountOpeningActions.updateFormValues).not.toHaveBeenCalled();
			expect(AccountOpeningActions.navigateToWebTask).not.toHaveBeenCalled();
		});
	});

	describe('when has refreshed', () => {
		describe('user is saved', () => {
			it('redirects to WEB-LOGIN', () => {
				const productCode = 'IM135';
				const { instance } = render({
					pageSession: {
						persisted: 'true',
						productCode,
					},
				});
				expect(AccountOpeningActions.updateFormValues).not.toHaveBeenCalled();
				expect(AccountOpeningActions.navigateToWebTask).toHaveBeenCalledWith(
					'WEB-LOGIN'
				);
			});
		});

		describe('when user is NOT saved', () => {
			describe('with productCode', () => {
				it('redirects to WEB-ELIGIBILITY-PAGE', () => {
					const productCode = 'IM135';
					const { instance } = render({
						pageSession: {
							productCode,
							productVariant: null,
						},
					});
					expect(AccountOpeningActions.updateFormValues).toHaveBeenCalledWith([
						{
							key: 'productCode',
							value: productCode,
						},
					]);
					expect(AccountOpeningActions.navigateToWebTask).toHaveBeenCalledWith(
						'WEB-ELIGIBILITY-PAGE'
					);
				});
			});

			describe('without productCode', () => {
				it('does NOT redirect', () => {
					const { instance } = render({
						pageSession: {},
					});
					expect(AccountOpeningActions.updateFormValues).not.toHaveBeenCalled();
					expect(
						AccountOpeningActions.navigateToWebTask
					).not.toHaveBeenCalled();
				});
			});
		});
	});
});
