jest.unmock('../RequiresIDandV');
jest.unmock('react-bootstrap-datetimepicker');

const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');
const Router = require('react-router');
const Route = Router.Route;

let RequiresIDandV = require('../RequiresIDandV');
const LoadingSpinner = require('../LoadingSpinner');
const AccountOpeningActions = require('../../actions/AccountOpeningActions');
const AppActions = require('../../actions/AppActions');
const SessionServerActionCreator = require('../../actions/SessionServerActionCreator');
const SessionActionCreator = require('../../actions/SessionActionCreator');
const UrlUtils = require('../../utils/UrlUtils');

const container = document.createElement('div');
const render = (comp, el) => ReactDOM.render(comp, el);

describe('RequiresIDandV', () => {

	beforeEach(() => {
		AppActions.handleError.mockClear();
	});
	const WrappedComponent = props => {
		return (<h1>WrappedComponent</h1>);
	};

	const HOC = RequiresIDandV(WrappedComponent);

	const defaultProps = {
		appData: {},
		envConfig: {
			targetScope: 30,
		},
		data: {
		},
		session: {
			authenticated: false,
		},
		location: {
			query: {
				applyfor: "",
			},
			pathname: 'test',
			hash: '',
			search: '',
			action: 'push',
		},
	};

	let instance, result, props;
	const shallowRender = (props, div = document.createElement('div')) => {
		const shallowRenderer = TestUtils.createRenderer();
		const newProps = {
			...defaultProps,
			...props,
		};

		shallowRenderer.render(
			<HOC {...newProps} />
		);
		instance = render(<HOC {...newProps} />, div);
		return shallowRenderer.getRenderOutput();
	};

	it('should fire an error is returned in hash', () => {
		result = shallowRender({
			session: {
				authenticated: false,
			},
			location: {
				query: {
					applyfor: "",
				},
				pathname: 'test',
				hash: '#error=something',
				search: '',
				action: 'push',
			},
		}, document.createElement('div'));
		expect(AppActions.handleError).toBeCalled();
	});

	it('should NOT fire an error of access denied is returned in hash', () => {
		result = shallowRender({
			session: {
				authenticated: false,
			},
			location: {
				query: {
					applyfor: "",
				},
				pathname: 'test',
				hash: '#error=access_denied',
				search: '',
				action: 'push',
			},
		}, document.createElement('div'));
		expect(AppActions.handleError).not.toBeCalled();
	});

	it('should set the token when we have one in hash', () => {
		result = shallowRender({
			session: {
				authenticated: false,
			},
			location: {
				query: {
					scope: "30",
				},
				pathname: 'test',
				hash: '#access_token=testToken',
				search: '',
				action: 'push',
			},
		}, document.createElement('div'));
		expect(SessionServerActionCreator.setAccessToken).toBeCalledWith({
			scope: '30',
			access_token: 'testToken',
		});
	});

	it('should fetch current user when we have the access token prop', () => {
		let div = document.createElement('div');
		result = shallowRender(null, div);
		result = shallowRender({
			session: {
				authenticated: false,
				accessToken: 'test',
			},
			location: {
				query: {
					scope: "30",
				},
				pathname: 'test',
				hash: '#access_token=testToken',
				search: '',
				action: 'push',
			},
		}, div);
		expect(SessionActionCreator.getCurrentUser).toBeCalled();
	});

	it('should get bank id when we have username and access token', () => {
		let div = document.createElement('div');
		result = shallowRender(null, div);
		result = shallowRender({
			data: {
				username: 'testuser',
			},
			session: {
				authenticated: true,
				accessToken: 'test',
			},
			location: {
				query: {
					scope: "30",
				},
				pathname: 'test',
				hash: '#access_token=testToken',
				search: '',
				action: 'push',
			},
		}, div);
		result = shallowRender(null, div);
		expect(SessionActionCreator.requestBankId).toBeCalledWith('testuser');
	});

	describe('render', () => {
		it('should render a loading spinner when NOT authenticated', () => {
			result = shallowRender();

			expect(result).toEqualJSX(
				<div className="account-opening authentication-page container-fluid">
					<div className="row main-container">
						<LoadingSpinner centerAlign />
					</div>
				</div>
			);
		});

		it('should NOT render a loading spinner when authenticated', () => {
			result = shallowRender({
				session: {
					authenticated: true,
				}
			});

			expect(result).toEqualJSX(
				<WrappedComponent {...result.props} />
			);
		});
	});
});
