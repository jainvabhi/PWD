jest.autoMockOff();

jest.mock('../../actions/AccountOpeningActions');
jest.mock('../../actions/AppActions');

const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');

const RedirectErrorOnBack = require('../RedirectErrorOnBack');
const AccountOpeningActions = require('../../actions/AccountOpeningActions');
const AppActions = require('../../actions/AppActions');

const WrappedComponent = () => <h1>WrappedComponent</h1>;

const render = (authenticated = true) => {
	const props = {
		session: {
			authenticated,
		},
		customer: {
			customerNumber: '1234567890',
		},
	};

	const HOC = RedirectErrorOnBack(WrappedComponent);
	const container = document.createElement('div');
	TestUtils.renderIntoDocument(<HOC {...props} />, container);
};

describe('RedirectErrorOnBack', () => {
	let onPopState;
	beforeEach(() => {
		window.addEventListener = jest.fn((event, fn) => {
			onPopState = fn;
		});
	});

	describe('when onPopState called', () => {
		describe('with session.authenticated', () => {
			it('does not call clearWebTask or handleError', () => {
				render();
				onPopState();
				expect(AccountOpeningActions.clearWebTask).not.toHaveBeenCalled();
				expect(AppActions.handleError).not.toHaveBeenCalled();
			});
		});

		describe('without session.authenticated', () => {
			it('calls clearWebTask and handleError', () => {
				render(false);
				onPopState();
				expect(AccountOpeningActions.clearWebTask).toHaveBeenCalled();
				expect(AppActions.handleError).toHaveBeenCalledWith({
					source: 'RedirectErrorOnBack',
					type: 'ui',
				});
			});
		});
	});
});
