jest.autoMockOff();

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const WithSourceId = require('../WithSourceId');

const AccountOpeningActions = require('../../actions/AccountOpeningActions');

const WrappedComponent = props => {
	return (<h1>WrappedComponent</h1>);
};

const HOC = WithSourceId(WrappedComponent);

const shallowRenderer = props => {
	const renderer = TestUtils.createRenderer();
	renderer.render(<HOC {...props} />)
	return renderer.getRenderOutput();
};

const getProps = id => {
	return {
		location: {
			query: {
				sourceId: id,
			},
		},
        data: {
            product: {
                productType: {
                    name: 'credit-card',
                },
            },
        },
	};
};

describe('WithSourceId', () => {
	let component;

	beforeEach(() => {
		AccountOpeningActions.updateFormValue = jasmine.createSpy();
	});

	describe('when an aggregator id is supplied', () => {
		const id = 'testid123';

		beforeEach(() => {
			component = shallowRenderer(getProps(id));
		});

		it('should update store with id', () => {
			expect(AccountOpeningActions.updateFormValue).toBeCalledWith('sourceId', id);
		});
	});

	describe('when an aggregator is not supplied', () => {
		beforeEach(() => {
			component = shallowRenderer(getProps(null));
		});

		it('should not update store', () => {
			expect(AccountOpeningActions.updateFormValue).not.toHaveBeenCalled();
		});
	});

    describe('when an product does NOT support aggregator IDs', () => {
		beforeEach(() => {
			component = shallowRenderer({
        		location: {
        			query: {
        				sourceId: 'test',
        			},
        		},
                data: {
                    product: {
                        productType: {
                            name: 'current',
                        },
                    },
                },
        	});
		});

		it('should not update store', () => {
			expect(AccountOpeningActions.updateFormValue).not.toHaveBeenCalled();
		});
	});
});
