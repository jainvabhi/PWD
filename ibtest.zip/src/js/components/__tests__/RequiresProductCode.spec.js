jest.unmock('../RequiresProductCode');
jest.unmock('react-bootstrap-datetimepicker');

const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');
const Router = require('react-router');
const Route = Router.Route;

const RequiresProductCode = require('../RequiresProductCode');

const AccountOpeningActions = require('../../actions/AccountOpeningActions');
const AppActions = require('../../actions/AppActions');
const UrlUtils = require('../../utils/UrlUtils');

describe('RequiresProductCode', () => {

	const WrappedComponent = props => {
		return (<h1>WrappedComponent</h1>);
	};

	const HOC = RequiresProductCode(WrappedComponent);

	describe('action tests', () => {

		const container = document.createElement('div');

		const executeActionTest = (testCase) => {

			it(testCase.desc, () => {
				testCase.before();

				const props = {
					data: {
						productCode: undefined,
					},
					location: {
						query: {
							applyFor: testCase.productCode,
						},
						pathname: 'test',
						search: '',
						action: 'PUSH',
					},
				};

				const instance = TestUtils.renderIntoDocument(<HOC {...props} />, container)
				testCase.expected();
			});
		};

		const actionTestCases = [{
			desc: 'when no product code is present and not in URL then should raise an error',
			productCode: null,
			before: () => AppActions.handleError.mockClear(),
			expected: () => expect(AppActions.handleError).toBeCalled(),
		},];

		actionTestCases.forEach(executeActionTest);
	});

	describe('render tests', () => {
		const executeRenderTest = (testCase) => {
			it(testCase.desc, () => {
				const renderer = TestUtils.createRenderer();
				const props = {
					data: {
						productCode: testCase.productCode,
						product: testCase.product,
					},
					location: {
						query: {
							applyFor: testCase.productCode,
						},
						pathname: 'test',
						search: '',
						action: 'PUSH',
					}
				};

				renderer.render(
					<HOC {...props} />
				);

				expect(renderer.getRenderOutput()).toEqual(testCase.expected(props));
			});
		};

		const renderTestCases = [{
			desc: 'when a product is available then should render WrappedComponent',
			productCode: 'IM803',
			product: {
				productType: {
					name: 'current',
				},
			},
			expected: (props) => (<WrappedComponent {...props} />),
		}, {
			desc: 'when no product available then should render null',
			productCode: null,
			product: null,
			expected: () => null,
		}, {
			desc: 'when no product available then should render null',
			productCode: null,
			product: {
				productType: {
					name: 'empty',
				},
			},
			expected: () => null,
		},];

		renderTestCases.forEach(executeRenderTest);
	});
});
