jest.autoMockOff();

jest.mock('../../actions/AccountOpeningActions');

const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');

const ResetTasksOnBackButton = require('../ResetTasksOnBackButton');
const AccountOpeningActions = require('../../actions/AccountOpeningActions');

const WrappedComponent = () => <h1>WrappedComponent</h1>;

const render = webTaskId => {
	const props = {
		appData: {
			webTaskId,
		},
	};
	const HOC = ResetTasksOnBackButton(WrappedComponent);
	const container = document.createElement('div');
	TestUtils.renderIntoDocument(<HOC {...props} />, container);
};

describe('ResetTasksOnBackButton', () => {
	let onPopState;
	beforeEach(() => {
		window.addEventListener = jest.fn((event, fn) => {
			onPopState = fn;
		});
	});

	describe('when onPopState called', () => {
		describe('without appData.webTaskId', () => {
			it('does not call clearWebTask', () => {
				render();
				onPopState();
				expect(AccountOpeningActions.clearWebTask).not.toHaveBeenCalled();
			});
		});

		describe('with appData.webTaskId', () => {
			it('calls clearWebTask', () => {
				render('WEB-SUBMIT-FORM');
				onPopState();
				expect(AccountOpeningActions.clearWebTask).toHaveBeenCalled();
			});
		});
	});
});
