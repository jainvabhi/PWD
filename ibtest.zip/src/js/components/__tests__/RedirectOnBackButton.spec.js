jest.autoMockOff();

jest.mock('../../actions/AccountOpeningActions');

const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');

const RedirectOnBackButton = require('../RedirectOnBackButton');
const AccountOpeningActions = require('../../actions/AccountOpeningActions');

const WrappedComponent = () => <h1>WrappedComponent</h1>;

const render = () => {
	const HOC = RedirectOnBackButton(WrappedComponent);
	const container = document.createElement('div');
	TestUtils.renderIntoDocument(<HOC />, container);
};

describe('RedirectOnBackButton', () => {
	let onPopState;
	beforeEach(() => {
		window.addEventListener = jest.fn((event, fn) => {
			onPopState = fn;
		});
	});

	describe('when onPopState called', () => {
		it('redirects to WEB-LOGIN', () => {
			render();
			onPopState();
			expect(AccountOpeningActions.navigateToWebTask).toHaveBeenCalledWith('WEB-SUBMIT-FORM');
		});
	});
});
