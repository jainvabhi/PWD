jest.unmock('../WithJointAccountCode');

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const WithJointAccountCode = require('../WithJointAccountCode');

const AccountOpeningActions = require('../../actions/AccountOpeningActions');

const WrappedComponent = () => <h1>WrappedComponent</h1>;

const HOC = WithJointAccountCode(WrappedComponent);

const shallowRenderer = props => {
	const renderer = TestUtils.createRenderer();
	renderer.render(<HOC {...props} />)
	return renderer.getRenderOutput();
};

const getProps = code => {
	return {
		location: {
			query: {
				code: code,
			},
		},
		data: {
			jointLinkCode: '',
		},
	};
};

describe('WithJointAccountCode', () => {
	let component;

	beforeEach(() => {
		AccountOpeningActions.setLinkCode = jasmine.createSpy();
	});

	describe('when joint code supplied', () => {
		const code = '123456';

		beforeEach(() => {
			component = shallowRenderer(getProps(code));
		});

		it('should update store with link code', () => {
			expect(AccountOpeningActions.setLinkCode).toBeCalledWith(code);
		});
	});

	describe('when a joint code is not supplied', () => {
		const code = '';

		beforeEach(() => {
			component = shallowRenderer(getProps(code));
		});

		it('should not update store with link code', () => {
			expect(AccountOpeningActions.setLinkCode).not.toHaveBeenCalled();
		});
	});
});
