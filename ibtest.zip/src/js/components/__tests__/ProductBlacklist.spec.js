jest.unmock('../ProductBlacklist');

const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');
const Router = require('react-router');
const Route = Router.Route;
const ProductBlacklist = require('../ProductBlacklist');
const AppActions = require('../../actions/AppActions');

const getProps = testCase => {
	return {
		product: {
			existingCustomersOnly: testCase.existingCustomersOnly,
			blackListedProduct: testCase.blackListedProduct,
			allowedOnJointApplication: testCase.allowedOnJointApplication,
			productType: testCase.productType || { name: 'current' }
		},
		...testCase
	};
};

const WrappedComponent = props => {
	return (<h1>WrappedComponent</h1>);
};

const HOC = ProductBlacklist(WrappedComponent);

const container = document.createElement('div');

const renderComponent = (data, pathname, query) => {
	return TestUtils.renderIntoDocument(<HOC data={data} location={{query: query, pathname: pathname}} />, container)
};

describe('when using ProductBlacklist', () => {
	let routes;
	let location;
	let instance;

	const testCases = [{
		description: 'should raise error when a product is blacklisted',
		productCode: 'IM800',
		blackListedProduct: true,
		isExstingCustomer: 'No',
		location: '/',
		expected: method => method.toBeCalled(),
	},
	{
		description: 'should not raise error when a product is blacklisted and isAltProduct',
		productCode: 'IM800',
		blackListedProduct: true,
		isAltProduct: true,
		location: '/registration',
		expected: method => method.not.toBeCalled(),
	},
	{
		description: 'should raise error when a product cannot be applied for directly',
		productCode: 'IM803',
		existingCustomersOnly: true,
		location: '/',
		expected: method => method.toBeCalled(),
	}, {
		description: 'should not raise an error when a product is not blacklisted',
		productCode: 'IM136',
		isExstingCustomer: 'Yes',
		location: '/',
		expected: method => method.not.toBeCalled(),
	}, {
		description: 'should not raise an error when a product is blacklisted but allowed through authentication route',
		productCode: 'IM803',
		existingCustomersOnly: true,
		isExstingCustomer: 'Yes',
		location: '/authentication',
		expected: method => method.not.toBeCalled(),
	}, {
		description: 'should not allow a savings account to be opened as a joint account',
		productCode: 'IM803',
		subType: 'JOINT',
		location: '/',
		productType: { name: 'savings' },
		expected: method => method.toBeCalled(),
	}, {
		description: 'should not raise an error when a product is blacklisted but allowed through joint route',
		productCode: 'IM800',
		allowedOnJointApplication: true,
		blackListedProduct: true,
		subType: 'JOINT',
		location: '/',
		expected: method => method.not.toBeCalled(),
	}];

	const executeTests = (testCase) => {
		it(testCase.description, () => {
			AppActions.handleError.mockClear();
			const data = getProps(testCase);
			renderComponent(data, testCase.location, {applyFor: testCase.productCode});
			testCase.expected(expect(AppActions.handleError));
		});
	};

	testCases.forEach(executeTests);
});
