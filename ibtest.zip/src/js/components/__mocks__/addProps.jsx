module.exports = WrappedComponent => WrappedComponent;
