/**
 * @module DobChallenge
 * @tutorial authentication
 */

const React = require('react');
const { PropTypes } = React;

const AccountOpeningConstants = require('../../../../constants/AccountOpeningConstants');
const DatePickerQuestion = require('../../../common/questionsets/DatePickerQuestion');
const DateUtils = require('../../../../utils/DateUtils');

/**
 * Requests update to auth header
 *
 * @param {String} name of auth field within challenge
 * @param {String} value of auth field within challenge
 * @param {Object} props containing action of take onChange
 *
 */
function onChange(name, value, props) {
	const date = DateUtils.getAPIDateString(value).replace(/-/g, ''); // DGW2CC-855

	props.requestAuthenticationUpdate({
		authType: name,
		authData: props.encryptAnswer(date),
	});
}

const DobChallenge = props => {
	return (
		<div>
			<DatePickerQuestion
				name="date_of_birth"
				key="dob"
				columnSize="12"
				mainColumnSize="12"
				validationText={props.content.dobChallengeValidationMessage}
				helpText={props.content.dobChallengeHelpMessage}
				required
				onChange={(name, value) => onChange(name, value, props)}
				{...props}
			>
				{props.content.dobChallengeQuestion}
			</DatePickerQuestion>

		</div>
	);
};

DobChallenge.defaultProps = {
	group: AccountOpeningConstants.GROUP_LOGIN,
};

DobChallenge.propTypes = {
	content: PropTypes.object.isRequired,
	group: PropTypes.string.isRequired,
};

module.exports = DobChallenge;
