jest.autoMockOff();

const React = require('react');
const TestUtils = require('react-addons-test-utils');

const SessionActionCreator = require('../../../../../actions/SessionActionCreator');

const TextQuestion = require('../../../../common/questionsets/TextQuestion');
const CreditCardChallenge = require('../CreditCardChallenge');

const shallowRender = props => {
	const shallowRenderer = TestUtils.createRenderer();
	shallowRenderer.render(
		<CreditCardChallenge {...props}/>
	);
	return shallowRenderer.getRenderOutput();
};

describe('when a user has a credit card challenge', () => {

	let component;
	let props;

	beforeEach(() => {
		props = {
			content: {
				ccPanChallengeQuestion: 'ccPanChallengeQuestion',
				ccPanChallengeValidationMessage: 'ccPanChallengeValidationMessage',
				ccPanChallengeHelpMessage: 'ccPanChallengeHelpMessage',
				creditLimitChallengeQuestion: 'creditLimitChallengeQuestion',
				creditLimitChallengeValidationMessage: 'creditLimitChallengeValidationMessage',
				creditLimitChallengeHelpMessage: 'creditLimitChallengeHelpMessage',
			},
			session: {
				challenge: {
					auth_scheme: {
						challenges: {
							credit_card: {
							},
						}
					},
					auth_session_id: {
					},
					public_key: {
					}
				}
			},
			encryptAnswer: jest.fn(),
			requestAuthenticationUpdate: jest.fn(),
		};

		component = shallowRender(props);
	});

	it('should render multiple TextQuestion', () => {

		expect(component).toEqualJSX(
			<span>
				<TextQuestion
					name="pan"
					key="pan"
					group="GROUP_LOGIN"
					mainColumnSize={12}
					mainColumnSizeMD={12}
					minLength={16}
					maxLength={16}
					validateType="number"
					validationText="ccPanChallengeValidationMessage"
					helpText="ccPanChallengeHelpMessage"
					onChange={() => {}}
					dataAnchor="auth-challenge-ccpan-input"
					required
				>
					ccPanChallengeQuestion
				</TextQuestion>
				<TextQuestion
					name="credit_limit"
					key="credit_limit"
					group="GROUP_LOGIN"
					mainColumnSize={12}
					mainColumnSizeMD={12}
					minLength={1}
					validateType="number"
					validationText="creditLimitChallengeValidationMessage"
					helpText="creditLimitChallengeHelpMessage"
					onChange={() => {}}
					dataAnchor="auth-challenge-credit-limit-input"
					required
				>
					creditLimitChallengeQuestion
				</TextQuestion>
			</span>
		);
	});

	describe('and answering the security question', () => {
		const encryptValues = [0,3,5];

		beforeEach(() => {
			component.props.children[0].props.onChange('test', encryptValues);
		});

		it('should create authentication answers update', () => {
			expect(props.encryptAnswer.mock.calls[0][0]).toEqual(encryptValues);
			expect(props.requestAuthenticationUpdate.mock.calls.length).toBe(1);
		});
	});
});
