jest.autoMockOff();
const React = require('react');
const TestUtils = require('react-addons-test-utils');

const SessionActionCreator = require('../../../../../actions/SessionActionCreator');

const DatePickerQuestion = require('../../../../common/questionsets/DatePickerQuestion');
const DobChallenge = require('../DobChallenge');

const shallowRender = props => {
	const shallowRenderer = TestUtils.createRenderer();
	shallowRenderer.render(
		<DobChallenge
			{...props}
		/>
	 );
	return shallowRenderer.getRenderOutput();
};

describe('when a user has an DobChallenge', () => {

	let component;
	let props;

	beforeEach(() => {
		props = {
			data: {
				phoneNumber: '121212',
			},
			content: {
				dobChallengeQuestion: 'dobChallengeQuestion',
				dobChallengeValidationMessage: 'dobChallengeValidationMessage',
				dobChallengeHelpMessage: 'dobChallengeHelpMessage',
			},
			session: {
				isStepupAuthenticationComplete: false,
				challenge: {
					auth_scheme: {
						challenges: {
							date_of_bith: {
							},
						},
					},
					auth_session_id: {
					},
					public_key: {
					},
				},
			},
			encryptAnswer: jest.fn(),
			requestAuthenticationUpdate: jest.fn(),
		};

		component = shallowRender(props);
	});

	it('should render DatePickerQuestion', () => {
		expect(component).toEqualJSX(
			<div>
				<DatePickerQuestion
					name="date_of_birth"
					key="dob"
					columnSize="12"
					mainColumnSize="12"
					group="GROUP_LOGIN"
					validationText={'dobChallengeValidationMessage'}
					helpText={'dobChallengeHelpMessage'}
					onChange={() => {}}
				    encryptAnswer={() => {}}
					{...props}
					required>
					dobChallengeQuestion
				</DatePickerQuestion>
			</div>
		);
	});

	describe('and answering the security question', () => {

		beforeEach(() => {
			component.props.children.props.onChange('test', '18-12-1960');
		});

		it('should create authentication answers update', () => {
			expect(props.requestAuthenticationUpdate.mock.calls.length).toBe(1);
		});
	});


});
