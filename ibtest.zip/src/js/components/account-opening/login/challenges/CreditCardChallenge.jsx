/**
 * @module CreditCardChallenge
 * @tutorial authentication
 */

const React = require('react');
const { PropTypes } = React;

const TextQuestion = require('../../../common/questionsets/TextQuestion');
const AccountOpeningConstants = require('../../../../constants/AccountOpeningConstants');

/**
 * Requests update to auth header
 *
 * @param {String} name of auth field within challenge
 * @param {String} value of auth field within challenge
 * @param {Object} props containing action of take onChange
 *
 */
function onChange(name, value, props) {
	props.requestAuthenticationUpdate({
		authType: 'credit_card',
		authData: props.encryptAnswer(value),
		authIndex: name,
	});
}

const CreditCardChallenge = props => {
	return (
		<span>
			<TextQuestion
				name="pan"
				key="pan"
				group={props.group}
				mainColumnSize={12}
				mainColumnSizeMD={12}
				minLength={16}
				maxLength={16}
				validateType="number"
				validationText={props.content.ccPanChallengeValidationMessage}
				helpText={props.content.ccPanChallengeHelpMessage}
				onChange={(name, value) => onChange(name, value, props)}
				dataAnchor="auth-challenge-ccpan-input"
				required
			>
				{props.content.ccPanChallengeQuestion}
			</TextQuestion>
			<TextQuestion
				name="credit_limit"
				key="credit_limit"
				group={props.group}
				mainColumnSize={12}
				mainColumnSizeMD={12}
				minLength={1}
				validateType="number"
				validationText={props.content.creditLimitChallengeValidationMessage}
				helpText={props.content.creditLimitChallengeHelpMessage}

				onChange={(name, value) => onChange(name, value, props)}
				dataAnchor="auth-challenge-credit-limit-input"
				required
			>
				{props.content.creditLimitChallengeQuestion}
			</TextQuestion>

		</span>
	);
};

CreditCardChallenge.defaultProps = {
	group: AccountOpeningConstants.GROUP_LOGIN,
};

CreditCardChallenge.propTypes = {
	session: PropTypes.object.isRequired,
	content: PropTypes.object.isRequired,
	group: PropTypes.string.isRequired,
	encryptAnswer: PropTypes.func.isRequired,
	requestAuthenticationUpdate: PropTypes.func.isRequired,
};

module.exports = CreditCardChallenge;
