/**
 * @module DeferredPage
 */

const React = require('react');
const { PropTypes } = React;
const Helmet = require('react-helmet');
const _ = require('lodash');

const ResultSection = require('../common/sections/ResultSection');
const PageHeader = require('../common/PageHeader');

const BrandUtils = require('../../utils/BrandUtils');
const ContentUtils = require('../../utils/ContentUtils');

const DeferredPage = React.createClass({
	propTypes: {
		data: PropTypes.object,
		validations: PropTypes.object,
		content: PropTypes.object,

	},

	/**
	 * Get a JSX element for each deferred item.
	 *
	 * @return {Array} Of JSX elements.
	 */
	getDeferredElements() {
		const deferredElements = this.props.content.deferredPageNextStepsItems;

		return _.map(deferredElements, name => {
			return (
				<li name={name} key={name}>{name}</li>
			);
		});
	},

	render() {
		const link = this.props.content.idDeferredLinkUrl ? (<p><a href={this.props.content.idDeferredLinkUrl} aria-label={ContentUtils.getProductContent('idDeferredLinkText', this.props.content, this.props.data.productCode)} target="_blank" title={this.props.content.idDeferredLinkTitle}>{ContentUtils.getProductContent('idDeferredLinkText', this.props.content, this.props.data.productCode)} <span className="screenreader">{this.props.content.newBrowserWindowTitle}</span></a></p>) : (<p dangerouslySetInnerHTML={{ __html: ContentUtils.getProductContent('idDeferredLinkText', this.props.content, this.props.data.productCode) }} />
);
		return (
			<div className="account-opening result-page-wrapper deferred-page-wrapper container-fluid">
				<Helmet title={this.props.content.idDeferredPageHeader} />
				<PageHeader visible={BrandUtils.isAbleToDisplay('result-pages-header')}
							title={`${this.props.content.landingPageTitle}${this.props.data.product.name}${this.props.data.product.nameSuffix}`}
							content={this.props.content}
				/>
				<div className="result-page deferred-page container" role="main">
					<div className="row text-center">
						<div className="col-xs-12">
							<ResultSection
								imgSrc={BrandUtils.getResultImage('id-deferred-page-with-image', 'bank-illustration.png')}
								imgAlt="Deferred Result"
								title={ContentUtils.getProductContent('idDeferredPageTitle', this.props.content, this.props.data.productCode)}
							>
								<div className="white-board">
									<p dangerouslySetInnerHTML={{ __html: ContentUtils.getProductContent('idDeferredPageExplanation', this.props.content, this.props.data.productCode) }} />

									{link}

									{!!this.getDeferredElements().length && <ul>
										{this.getDeferredElements()}
									</ul>}

									{ContentUtils.getProductContent('idDeferredPageFooter', this.props.content, this.props.data.productCode) && <p>{ContentUtils.getProductContent('idDeferredPageFooter', this.props.content, this.props.data.productCode)}</p>}
								</div>
							</ResultSection>
						</div>
					</div>
				</div>
			</div>
		);
	},
});

module.exports = DeferredPage;
