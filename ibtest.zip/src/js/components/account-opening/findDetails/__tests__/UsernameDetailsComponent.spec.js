jest.unmock('../UsernameDetailsComponent');
jest.unmock('react-bootstrap-datetimepicker');
jest.unmock('../../../../utils/ChallengeUtils');

const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');
const _ = require('lodash');

const UsernameDetailsComponent = require('../UsernameDetailsComponent');

const ChallengeUtils = require('../../../../utils/ChallengeUtils');

const { buildFindMockByNameFilter } = require('../../../../__helpers__/TestHelpers');

// Mocks
const { TextQuestion, DatePickerQuestion, DropdownQuestion, RadioQuestion } = require('../../../common/questionsets');
const BottomNavigationBox = require('../../../common/BottomNavigationBox');
const SessionActionCreator = require('../../../../actions/SessionActionCreator');
const ErrorMessage = require('../../../common/ErrorMessage');
const AccountOpeningActions = require('../../../../actions/AccountOpeningActions');
const ChallengeComponent = require('../../login/ChallengeComponent');
let instance;

const getData = props => {
	return {
		product: {
			productType: {
				name: 'current',
			},
		},
		completedTasks: {},
		...props,
	};
};

const content = {
	titleQuestion: 'test',
	firstNameQuestion: 'test',
	lastNameQuestion:  'test',
	middleNameQuestion:  'test',
	dateOfBirthQuestion: 'test',
	phoneNumberQuestion: 'test',
	emailAddressQuestion: 'test',
	emailAddressConfirmationQuestion: 'test',
};

const data = {
	productCode: 'IM540',
};

describe('UsernameDetailsComponent', () => {
	describe('canEditUsername', () => {
		describe('when no username has been set', () => {
			beforeEach(() => {
				instance = TestUtils.renderIntoDocument(<UsernameDetailsComponent
					envConfig={{}}
					data={getData()}
					content={content}
					appData={{}} />
				);
			});

			it('should not be possible to edit username', () => {
				expect(instance.canEditUsername(false)).toBe(true);
			});
		});

		describe('when username has been set', () => {
			beforeEach(() => {
				instance = TestUtils.renderIntoDocument(<UsernameDetailsComponent
					envConfig={{}}
					data={getData({username: 'asdadasd',})}
					content={content}
					appData={{}} />
				);
			});

			it('should be possible to edit username', () => {
				expect(instance.canEditUsername(false)).toBe(true);
			});
		});

		describe('when case has been set', () => {
			beforeEach(() => {
				instance = TestUtils.renderIntoDocument(<UsernameDetailsComponent
					envConfig={{}}
					data={getData({caseId: 'asdadasd',})}
					content={content}
					appData={{}} />
				);
			});

			it('should be possible to edit username', () => {
				expect(instance.canEditUsername(false)).toBe(true);
			});
		});

		describe('when user is existing customer', () => {
			beforeEach(() => {
				instance = TestUtils.renderIntoDocument(<UsernameDetailsComponent
					envConfig={{}}
					data={getData()}
					content={content}
					appData={{}} />
				);
			});

			it('should be possible to edit username', () => {
				expect(instance.canEditUsername(true)).toBe(false);
			});
		});
	});

	describe('canEditPassword', () => {
		describe('when no credentials or password are present', () => {
			beforeEach(() => {
				instance = TestUtils.renderIntoDocument(<UsernameDetailsComponent
					envConfig={{}}
					data={getData()}
					content={content}
					appData={{}} />
				);
			});

			it('should not be possible to edit password', () => {
				expect(instance.canEditPassword(false, false)).toBe(true);
			});
		});

		describe('when credentials are present and no password is present', () => {
			beforeEach(() => {
				instance = TestUtils.renderIntoDocument(<UsernameDetailsComponent
					envConfig={{}}
					data={getData({credentials: {}})}
					content={content}
					appData={{}} />
				);
			});

			it('should be possible to edit password', () => {
				expect(instance.canEditPassword(false, false)).toBe(true);
			});
		});

		describe('when credentials and password are present', () => {
			beforeEach(() => {
				instance = TestUtils.renderIntoDocument(<UsernameDetailsComponent
					envConfig={{}}
					data={getData({
						credentials: {
							password: 'password'
						}})
					}
					content={content}
					appData={{}} />
				);
			});

			it('should be possible to edit password', () => {
				expect(instance.canEditPassword(false, false)).toBe(false);
			});
		});

		describe('when user is existing RIB customer', () => {
			beforeEach(() => {
				instance = TestUtils.renderIntoDocument(<UsernameDetailsComponent
					envConfig={{}}
					data={getData()}
					content={content}
					appData={{}} />
				);
			});

			it('should not be possible to edit password', () => {
				expect(instance.canEditPassword(true, true)).toBe(false);
			});
		});

		describe('when user is existing not RIB customer', () => {
			beforeEach(() => {
				instance = TestUtils.renderIntoDocument(<UsernameDetailsComponent
					envConfig={{}}
					data={getData()}
					content={content}
					appData={{}} />
				);
			});

			it('should be possible to edit password', () => {
				expect(instance.canEditPassword(true, false)).toBe(true);
			});
		});
	});
});
