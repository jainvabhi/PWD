/**
 * @module PersonalDetailsFoundError
 */

const React = require('react');
const { PropTypes } = React;
const envConfig = require('../../../../static/config');
const _ = require('lodash');

const ErrorMessage = require('../../common/ErrorMessage');

const PersonalDetailsFoundError = React.createClass({
	propTypes: {
		data: PropTypes.object.isRequired,
		content: PropTypes.object.isRequired,
	},

	render() {
		const errorMessages = [
			{
				dataKey: 'personalDetailsFound',
				contentKey: 'personalDetailsFoundValidationMessage',
			},
			{
				dataKey: 'inFlightCustomer',
				contentKey: 'loginCSAPErrorMessage',
			},
			{
				dataKey: 'NotInFlightCustomer',
				contentKey: 'authCSAPErrorMessage',
			},
			{
				dataKey: 'NotInFlightCustomerNoCreds',
				contentKey: 'contactBankCSAPErrorMessage',
			},
		];

		const doesErrorExist = ({ dataKey }) => this.props.data[dataKey];
		const message = _.find(errorMessages, doesErrorExist);

		if (!message || !this.props.content[message.contentKey]) {
			return null;
		}

		const productVariant = this.props.data.productVariant ? `&issue=${this.props.data.productVariant}` : '';

		const content = this.props.content[message.contentKey]
				.replace('{websiteBaseDirectory}', envConfig.websiteBaseDirectory)
				.replace('{productCode}', this.props.data.productCode)
				.replace('{productVariant}', productVariant);

		return (
			<div className="row padding-bottom" role="alert" aria-live="assertive">
				<ErrorMessage text={content} extraClasses="found-user help" />
			</div>
		);
	},
});

module.exports = PersonalDetailsFoundError;
