const React = require('react');
const { PropTypes } = React;

const SectionFullWidth = require('../../common/SectionFullWidth');
const ComponentHeader = require('../../common/ComponentHeader');
const TextQuestion = require('../../common/questionsets/TextQuestion');
const StaticParagraphQuestion = require('../../common/questionsets/StaticParagraphQuestion');
const ErrorMessage = require('../../common/ErrorMessage');

const PersonalDetailsFoundError = require('./PersonalDetailsFoundError');

const ContentUtils = require('../../../utils/ContentUtils');

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');

const UsernameDetailsComponent = React.createClass({
	propTypes: {
		data: PropTypes.shape({
			isExistingCustomer: PropTypes.string,
			isRibCustomer: PropTypes.string,
			password1: PropTypes.string,
			password2: PropTypes.string,
			usernameAlreadyInUse: PropTypes.bool,
			username: PropTypes.string,
			caseId: PropTypes.string,
			credentials: PropTypes.object,
			completedTasks: PropTypes.object,
		}),
		content: PropTypes.shape({
			passwordLastWarning: PropTypes.string,
			setPasswordTitle: PropTypes.string,
			password1Question: PropTypes.string,
			password1QuestionExisting: PropTypes.string,
			password2Question: PropTypes.string,
			passwordDisclaimer: PropTypes.string,
			usernameAlreadyInUseValidationMessage: PropTypes.string,
			usernameQuestion: PropTypes.string,
			usernameQuestionExisting: PropTypes.string,
			usernameInfo: PropTypes.string,
			usernameAdditionalInfo: PropTypes.string,
		}),
		group: PropTypes.string,
	},

	getInitialState() {
		return {
			isLoadingCredentials: false,
			usernameAlreadyInUse: this.props.data.usernameAlreadyInUse,
			previousUserName: this.props.data.unsavedUsername,
		};
	},

	componentWillMount() {
		console.log(this.state);
		console.log(this.props);
	},

	componentDidMount() {
		console.log(this.state);
		console.log(this.props);
	},

	componentWillReceiveProps(nextProps) {
		console.log(nextProps.data);
		console.log(this.state);
	},

	/**
	 * Error is displayed when user details have been found
	 * @return {ReactElement} Error message
	 */
	getPersonaDetailsFoundError() {
		return (
			<PersonalDetailsFoundError
			{...this.props}
			/>
		);
	},

	/**
	 * Password input field
	 * @return {ReactElement}
	 */
	getPasswordQuestion() {
		// If loading credentials, we don't know what fields to display yet.
		if (this.state.isLoadingCredentials) {
			return;
		}

		const passwordFields = [];
		const passwordAlreadySetLabel = 'Password';
		const isExistingCustomer = (this.props.data.isExistingCustomer === 'Yes') ? true : false;
		const isExistingRibCustomer = isExistingCustomer && this.props.data.isRibCustomer;

		if (!this.canEditPassword(isExistingCustomer, isExistingRibCustomer)) {
			const label = this.props.content.password1QuestionExisting || this.props.content.password1Question;
			passwordFields.push(
				<StaticParagraphQuestion
					key="passwordSet"
					label={label}
					name="passwordAlreadySet"
					defaultValue="*******"
					className="credentials-disabled"
					required
				/>
			);
		} else {
			passwordFields.push(
				<TextQuestion
					key="password1"
					name="password1"
					defaultValue={this.props.data.password1}
					group={this.props.group}
					label={passwordAlreadySetLabel}
					inputType="password"
					onChange={AccountOpeningActions.updateFormValue}
					dataAnchor="password"
					validateType="password"
					required
				>
					{this.props.content.password1Question}
				</TextQuestion>
			);

			passwordFields.push(
				<TextQuestion
					key="password2"
					name="password2"
					defaultValue={this.props.data.password2}
					group={this.props.group}
					label="Password (confirm)"
					inputType="password"
					onChange={AccountOpeningActions.updateFormValue}
					dataAnchor="password-confirm"
					validateEqualTo={this.props.data.password1}
					required
				>
					{this.props.content.password2Question}
				</TextQuestion>
			);
		}

		if (isExistingCustomer) {
			passwordFields.push(
				<p key="passwordDisclaimer">{this.props.content.passwordDisclaimer}</p>
			);
		}

		return passwordFields;
	},

	/**
	 * Error is displayed when username is taken
	 * @return {ReactElement} Error message
	 */
	getUsernameIsTakenError() {
		if (this.state.usernameAlreadyInUse) {
			return <ErrorMessage text={this.props.content.usernameAlreadyInUseValidationMessage} extraClasses="taken-username error" />;
		}
	},
	
	/**
	 * username input field
	 *
	 * @return {ReactElement}
	 */
	getUsernameQuestion() {
		let usernameField;
		const usernameFieldLabel = this.props.content.usernameQuestionExisting || this.props.content.usernameQuestion || 'Username';
		const isExistingCustomer = (this.props.data.isExistingCustomer === 'Yes') ? true : false;

		if (!this.canEditUsername(isExistingCustomer)) {
			usernameField = (<StaticParagraphQuestion
				label={usernameFieldLabel}
				name="username"
				defaultValue={this.props.data.username || '*****'}
				className="credentials-disabled"
				required
			/>);
		} else {
			usernameField = [];

			usernameField.push(<p key="username-intro" className="intro-paragraph">{this.props.content.usernameInfo}</p>);

			usernameField.push(
				<ul key="username-intro-list-items" className="username-intro-list-items">
					{[ContentUtils.getContentListElements('usernameImportantInfo', this.props.content)]}
				</ul>
			);

			usernameField.push(<p key="username-intro-additional" className="intro-paragraph">{this.props.content.usernameAdditionalInfo}</p>);

			usernameField.push(
				<TextQuestion
					key="unsavedUsername"
					name="unsavedUsername"
					group={this.props.group}
					onChange={AccountOpeningActions.updateFormValue}
					minLength={6}
					maxLength={16}
					dataAnchor="unsaved-username"
					validateType="ntbusername"
					required
				>
					{usernameFieldLabel}
				</TextQuestion>
			);
		}

		return usernameField;
	},

	/**
	 * Responsible for deciding if the username can be edited
	 *
	 * @param {Boolean} isExistingCustomer Define if we are working with an existing customer
	 *
	 * @return {Boolean} True if username can be edited
	 */
	canEditUsername(isExistingCustomer) {
		return !((this.props.data.username && this.props.data.completedTasks['SAVE_AND_RESUME']) || isExistingCustomer);
	},

	/**
	 * Responsible for deciding it the password can be edited
	 *
	 * @param {Boolean} isExistingCustomer Define if we are working with an existing customer
	 * @param {Boolean} isExistingRibCustomer Define if we are working with an existing RIB customer
	 *
	 * @return {Boolean} True if password can be edited
	 */
	canEditPassword(isExistingCustomer, isExistingRibCustomer) {
		return !((this.props.data.credentials && this.props.data.credentials.password) || (isExistingCustomer && isExistingRibCustomer));
	},

	render() {
		return (
			<SectionFullWidth className="padding-top">
				<ComponentHeader
					title={this.props.content.setPasswordTitle}
					titleLevel={2}
				>
					{this.getUsernameQuestion()}
					<div className="row" role="alert" aria-live="assertive">
						{this.getUsernameIsTakenError()}
					</div>

					{this.getPasswordQuestion()}

					{this.props.content.passwordLastWarning ? <p className="security-info">{this.props.content.passwordLastWarning}</p> : false}

				</ComponentHeader>
				{this.getPersonaDetailsFoundError()}
				<hr />
			</SectionFullWidth>
		);
	},
});

module.exports = UsernameDetailsComponent;
