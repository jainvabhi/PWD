/**
 * @module HasCustomerNumber
 * @ticket DYB-12247
 *
 */

const React = require('react');
const PropTypes = React.PropTypes;
const { RadioQuestion } = require('../../common/questionsets');
const AccountOpeningActions = require('../../../actions/AccountOpeningActions');
const AccountOpeningConstants = require('../../../constants/AccountOpeningConstants');
const BrandUtils = require('../../../utils/BrandUtils');
const { GROUP_EXISTING_CUSTOMER_WITHOUT_CUSTOMERID: groupExistingCustomer } = AccountOpeningConstants;

const HasCustomerNumber = props => {
	return (<RadioQuestion
		defaultValue={props.data.hasCustomerName}
		group={groupExistingCustomer}
		labelText={props.content.hasCustomerName}
		mainColumnSize={BrandUtils.defaultColumnSize() === 12 ? 12 : 6}
		mainColumnSizeMD={BrandUtils.defaultColumnSize() === 12 ? 12 : 6}
		name="hasCustomerName"
		onChange={AccountOpeningActions.updateFormValue}
		options={[{ value: 'No' }, { value: 'Yes' }]}
		required
	/>);
};

HasCustomerNumber.propTypes = {
	data: PropTypes.object,
	content: PropTypes.object,
};

module.exports = HasCustomerNumber;
