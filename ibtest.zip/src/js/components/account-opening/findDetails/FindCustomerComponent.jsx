const React = require('react');
const { PropTypes } = React;

const LoginComponent = require('../login/LoginComponent');
const FindDetailsComponent = require('./FindDetailsComponent');
const HasCustomerNumber = require('./HasCustomerNumber');

const LoadingMessage = props => {
	return (<p>{props.content.authPageLoadingMessage}</p>);
};

LoadingMessage.propTypes = {
	content: PropTypes.object.isRequired,
};

const FindCustomerComponent = React.createClass({
	propTypes: {
		data: PropTypes.shape({
			hasCustomerName: PropTypes.string,
		}),
		content: PropTypes.shape({
			authCheckDetailsError: PropTypes.string,
		}),
		session: PropTypes.shape({
			authenticated: PropTypes.bool,
		}),
		targetScope: PropTypes.number.isRequired,
		onSuccess: PropTypes.func.isRequired,
	},

	/**
	 * switch different forms if customer [has|doesn't have] a username
	 * @return {ReactElement}
	 */
	getCustomerInformation() {
		// ternary is not an option here as there are 3 cases [Yes|No|underfined]
		switch (this.props.data.hasCustomerName) {
			case 'Yes':
				return this.getUsernameQuestion();
			case 'No':
				return this.getAlternateAuthenticationQuestions();
		}
	},

	/**
	 * A form for exisiting customer with a username
	 * @return {ReactElement}
	 */
	getUsernameQuestion() {
		return (
			<div className="padding-bottom">
				<LoginComponent
					{...this.props}
					targetScope={this.props.targetScope}
					isNotAbleToShowUsername
					errorMessage={this.props.content.authCheckDetailsError}
					onSuccess={this.props.onSuccess}
				/>
			</div>
		);
	},

	/**
	* A form for existing customer without a username
	* @return {ReactElement}
	*/
	getAlternateAuthenticationQuestions() {
		return (<div className="padding-bottom">
			<FindDetailsComponent
				{...this.props}
				targetScope={this.props.targetScope}
				onSuccess={this.props.onSuccess}
			/>
			</div>
		);
	},

	shouldShowForm() {
		return !this.props.session.authenticated;
	},

	render() {
		return (
			<span>
				{this.shouldShowForm() && <HasCustomerNumber {...this.props} /> || <LoadingMessage {...this.props} />}
				{this.getCustomerInformation()}
			</span>
		);
	},
});

module.exports = FindCustomerComponent;
