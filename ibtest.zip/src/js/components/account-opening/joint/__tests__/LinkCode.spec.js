jest.unmock('../LinkCode');
jest.unmock('../../../../utils/RegexUtils');

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const Helmet = require('react-helmet');

const AccountOpeningConstants = require('../../../../constants/AccountOpeningConstants');
const ValidationUtils = require('../../../../utils/ValidationUtils');

const SectionFullWidth = require('../../../common/SectionFullWidth');
const BottomNavigationBox = require('../../../common/BottomNavigationBox');
const { TextQuestion } = require('../../../common/questionsets');
const ErrorMessage = require('../../../common/ErrorMessage');

const LinkCode = require('../LinkCode');

const shallowRender = props => {
	const shallowRenderer = TestUtils.createRenderer();
	shallowRenderer.render(<LinkCode
		{...props}
	/>);

	return shallowRenderer.getRenderOutput();
};

const getProps = ({ validations, data, }) => {
	return {
		appData: {},
		content: {
			jointAccountPagePartyTitle: '',
			jointAccountLinkCodeValidationMessage: '',
			jointAccountButtonLabel: '',
			jointAccountInvalidResponse: 'invalid',
			jointAccountInputHelpText: '',
			jointAccountLinkCodeTextQuestionLabel: '',
			jointAccountLinkCodeViewNextLabel: 'Proceed',
		},
		data: {
			jointLinkCode: '',
			linkCaseRequestInvalid: false,
			...data
		},
		validations: validations,
		nextTaskId: '',
		onClickNext: () => {},
		additionalLabelClasses: '',
		additionalInputContainerClasses: '',
	};
};

describe('LinkCode', () => {
	let component;

	describe('when initially loaded', () => {
		beforeEach(() => {
			ValidationUtils.isGroupValid.mockReturnValueOnce(false);
			component = shallowRender(getProps({}));
		});

		it('should render', () => {
			expect(component).toEqualJSX(
				<span>
					<TextQuestion
						containerClassName=""
						defaultValue=""
						group="GROUP_JOINT_ACCOUNT"
						inputContainerClassName=""
						inputType="text"
						labelClassName=""
						labelContainerClassName=""
						mainColumnSize={6}
						mainColumnSizeMD={6}
						maxLength={6}
						minLength={6}
						name="jointLinkCode"
						onBlur={function noRefCheck() {}}
						onChange={function noRefCheck() {}}
						required={true}
						validateRegex={/^[0-9]+$/}
						validationText=""
						helpText=""
						valueFormatter={function noRefCheck() {}}
					/>
					<SectionFullWidth>
						<BottomNavigationBox
							disabled={true}
							isLoading={undefined}
							nextButtonLabel="Proceed"
							nextTaskId=""
							onClickNext={function noRefCheck() {}}
						/>
					</SectionFullWidth>
				</span>
			);
		});
	});

	describe('when input validation fails', () => {
		beforeEach(() => {
			ValidationUtils.isGroupValid.mockReturnValueOnce(false);

			component = shallowRender(getProps({}));
		});

		it('should disable proceed button', () => {
			expect(component).toIncludeJSX(
				<BottomNavigationBox
					disabled={true}
					isLoading={undefined}
					nextButtonLabel="Proceed"
					nextTaskId=""
					onClickNext={function noRefCheck() {}}
				/>
			);
		});
	});

	describe('when input validation succeeds', () => {
		beforeEach(() => {
			ValidationUtils.isGroupValid.mockReturnValueOnce(true);

			component = shallowRender(getProps({}));
		});

		it('should enable proceed button', () => {
			expect(component).toIncludeJSX(
				<BottomNavigationBox
					disabled={false}
					isLoading={undefined}
					nextButtonLabel="Proceed"
					nextTaskId=""
					onClickNext={function noRefCheck() {}}
				/>
			);
		});
	});

	describe('when API returns invalid code', () => {
		beforeEach(() => {
			component = shallowRender(getProps({
				data: {
					linkCaseRequestInvalid: true
				},
				appData: {
					isApiCallInProgress: false,
				}
			}));
		});

		it('should render error message', () => {
			expect(component).toIncludeJSX(
				<ErrorMessage text="invalid" extraClasses="error ja-link-code-info-message" />
			);
		});
	});
});
