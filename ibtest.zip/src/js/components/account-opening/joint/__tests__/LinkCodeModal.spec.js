jest.unmock('../LinkCodeModal');
jest.unmock('../../../common/modals/Modal');

const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');

const render = (comp, el) => ReactDOM.render(comp, el || container);

let container = document.createElement('div');

const LinkCodeModal = require('../LinkCodeModal');

const getProps = props => {
	return {
		onClickNext: jest.fn(),
		getNextButtonLabel: () => {},
		content: {
			jointAccountModalTitle: '',
		},
		data: {
			linkCaseRequestInvalid: false,
		},
		appData: {
			isApiCallInProgress: false,
		},
		...props,
	};
};

describe('LinkCodeModal', () => {
	let component;
	let props;
	let node;

	describe('initial render', () => {
		beforeEach(() => {
			props = getProps({});
			component = render(<LinkCodeModal {...props} />, container);
			node = ReactDOM.findDOMNode(component);
		});

		it('should render null', () => {
			expect(node).toEqual(null);
		});
	});

	describe('and when link code is invalid', () => {
		beforeEach(() => {
			props = getProps({});
			component = render(<LinkCodeModal {...props} />, container);
			props = getProps({
				data: {
					linkCaseRequestInvalid: true,
				},
			});
			component = render(<LinkCodeModal {...props} />, container);
			node = ReactDOM.findDOMNode(component);
		});

		it('should render modal', () => {
			expect(node).not.toEqual(null);
		});

		describe('and when next button clicked', () => {
			beforeEach(() => {
				props = getProps({
					data: {
						linkCaseRequestInvalid: true,
					},
				});
				component.onClickNext();
				node = ReactDOM.findDOMNode(component);
			});

			it('should invoke passed click handler', () => {
				expect(component.props.onClickNext.mock.calls.length).toBe(1);
			});

			describe('and when link code is still invalid', () => {
				beforeEach(() => {
					props = getProps({
						data: {
							linkCaseRequestInvalid: true,
						},
					});
					component = render(<LinkCodeModal {...props} />, container);
					node = ReactDOM.findDOMNode(component);
				});

				it('should render modal', () => {
					expect(node).not.toEqual(null);
				});
			});
		});
	});
});
