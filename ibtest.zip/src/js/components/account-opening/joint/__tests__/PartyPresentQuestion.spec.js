jest.disableAutomock();
jest.unmock('../PartyPresentQuestion');
jest.unmock('../../../common/questionsets/RadioQuestion');

const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');
const Helmet = require('react-helmet');

const PageHeader = require('../../../common/PageHeader');
const PageColumnWrapper = require('../../../common/PageColumnWrapper');
const SideBarColumnWrapper = require('../../../common/SideBarColumnWrapper');
const SectionCentered = require('../../../common/SectionCentered');
const ComponentHeader = require('../../../common/ComponentHeader');
const RadioQuestion = require('../../../common/questionsets/RadioQuestion');

const PartyPresentQuestion = require('../PartyPresentQuestion');

const container = document.createElement('div');

const render = (comp, el) => ReactDOM.render(comp, el);

const getProps = props => {
	return {
		content: props.content,
	};
};

const getContent = () => {
	return {
		jointAccountPartyTwoAbsentTitle: '',
		jointAccountPartyTwoPresentTitle: '',
		jointAccountMultiPartyRadioQuestionTitle: 'radioQuestionLabel',
		jointAccountPartyPresentNextLabel: '',
		jointAccountIsSecondPartyPresent: '',
		jointAccountLetterCodeIntro: 'jointAccountLetterCodeIntro',
	};
};

describe('JointAccountHoldingPage', () => {
	let content;
	let props;


	describe('when party two is present', () => {
		let instance;

		beforeEach(() => {
			content = getContent();
			props = getProps({
				content: content,
			});

			instance = render(
				<PartyPresentQuestion
					{...props}
				/>, container)

			instance.onChange('isExistingCustomer', 'Yes');

			instance = render(
				<PartyPresentQuestion
					{...props}
				/>, container)
		});

		it('should render proceed with appliction button', () => {
			expect(instance.state.isPartyTwoPresent).toBe('Yes');
		});
	})
});
