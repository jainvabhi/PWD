const React = require('react');
const { PropTypes } = React;

const PartyTwoAbsent = props => {
	return (
		<span className="ja-party-two-absent">
			<p>{props.content.jointAccountPartyTwoAbsentTitle}</p>
		</span>
	);
};

PartyTwoAbsent.propTypes = {
	content: PropTypes.shape({
		jointAccountPartyTwoAbsentTitle: PropTypes.string.isRequired,
	}),
};

module.exports = PartyTwoAbsent;
