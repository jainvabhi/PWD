const React = require('react');
const { PropTypes } = React;
const SectionFullWidth = require('../../common/SectionFullWidth');
const BottomNavigationBox = require('../../common/BottomNavigationBox');

const PartyTwoPresent = props => {
	return (
		<SectionFullWidth>
			<p>{props.content.jointAccountPartyTwoPresentTitle}</p>
			<BottomNavigationBox
				onClickNext={props.onClickNext}
				nextButtonLabel={props.content.jointAccountPartyPresentNextLabel}
			/>
		</SectionFullWidth>
	);
};

PartyTwoPresent.propTypes = {
	content: PropTypes.shape({
		jointAccountPartyPresentNextLabel: PropTypes.string.isRequired,
		jointAccountPartyTwoPresentTitle: PropTypes.string.isRequired,
	}),
	onClickNext: PropTypes.func.isRequired,
};

module.exports = PartyTwoPresent;
