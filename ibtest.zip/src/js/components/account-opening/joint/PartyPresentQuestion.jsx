const React = require('react');
const { PropTypes } = React;

const ComponentHeader = require('../../common/ComponentHeader');
const SectionCentered = require('../../common/SectionCentered');
const RadioQuestion = require('../../common/questionsets/RadioQuestion');
const BrandUtils = require('../../../utils/BrandUtils');
const AccountOpeningConstants = require('../../../constants/AccountOpeningConstants');

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');
const PageSessionActions = require('../../../actions/PageSessionActions');

const PartyTwoAbsent = require('./PartyTwoAbsent');
const PartyTwoPresent = require('./PartyTwoPresent');

const PartyPresentQuestion = React.createClass({
	propTypes: {
		content: PropTypes.shape({
			jointAccountMultiPartyRadioQuestionTitle: PropTypes.string.isRequired,
			jointAccountIsSecondPartyPresent: PropTypes.string.isRequired,
			jointAccountLetterCodeIntro: PropTypes.string.isRequired,
		}),
	},

	getInitialState() {
		return {
			isPartyTwoPresent: undefined,
		};
	},

	onChange(name, value) {
		this.setState({
			isPartyTwoPresent: value,
		});
	},

	onPartyTwoPresentClickNext() {
		PageSessionActions.setPageSession({
			persisted: false,
		});
		AccountOpeningActions.navigateToWebTask('WEB-JOINT-ACCOUNT');
	},

	render() {
		return (
			<span>
				<SectionCentered centredColumnSize={12}>
					<ComponentHeader
						title=""
						titleLevel={2}
					>
					<p>{this.props.content.jointAccountLetterCodeIntro}</p>
					<RadioQuestion
						group={AccountOpeningConstants.GROUP_JOINT_ACCOUNT}
						align={BrandUtils.isAbleToDisplay('page-full-width') ? 'left' : 'right'}
						labelText={this.props.content.jointAccountMultiPartyRadioQuestionTitle}
						helpText={this.props.content.jointAccountIsSecondPartyPresent}
						classNameLabelDiv="ja-customer-present-question"
						onChange={this.onChange}
						mainColumnSize={BrandUtils.isAbleToDisplay('page-full-width') ? 12 : 6}
						mainColumnSizeMD={BrandUtils.isAbleToDisplay('page-full-width') ? 12 : 6}
						name="isSecondPartyPresent"
						options={[{ anchor: 'second-party-no', value: 'No' }, { anchor: 'second-party-yes', value: 'Yes' }]}
						required
					/>
					</ComponentHeader>
				</SectionCentered>
				{this.state.isPartyTwoPresent === 'No' && <PartyTwoAbsent {...this.props} /> }
				{this.state.isPartyTwoPresent === 'Yes' &&
					<PartyTwoPresent
						onClickNext={this.onPartyTwoPresentClickNext}
						{...this.props}
					/>}
			</span>
		);
	},
});

module.exports = PartyPresentQuestion;
