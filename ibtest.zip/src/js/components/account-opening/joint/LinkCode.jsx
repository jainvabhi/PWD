const React = require('react');
const { PropTypes } = React;

const BottomNavigationBox = require('../../common/BottomNavigationBox');
const { TextQuestion } = require('../../common/questionsets');
const ErrorMessage = require('../../common/ErrorMessage');
const SectionFullWidth = require('../../common/SectionFullWidth');
const AccountOpeningActions = require('../../../actions/AccountOpeningActions');
const AccountOpeningConstants = require('../../../constants/AccountOpeningConstants');
const ValidationUtils = require('../../../utils/ValidationUtils');
const RegexUtils = require('../../../utils/RegexUtils');
const BrandUtils = require('../../../utils/BrandUtils');

const onJointAccountLinkCodeChange = (name, value) => AccountOpeningActions.updateFormValue(name, value);

const LinkCode = props => {
	const isValid = ValidationUtils.isGroupValid(props.validations, AccountOpeningConstants.GROUP_JOINT_ACCOUNT);

	return (
		<span>
			<TextQuestion
				group={AccountOpeningConstants.GROUP_JOINT_ACCOUNT}
				mainColumnSize={BrandUtils.defaultColumnSize() === 12 ? 12 : 6}
				mainColumnSizeMD={BrandUtils.defaultColumnSize() === 12 ? 12 : 6}
				labelClassName={props.additionalLabelClasses}
				onChange={onJointAccountLinkCodeChange}
				maxLength={6}
				minLength={6}
				name="jointLinkCode"
				defaultValue={props.data.jointLinkCode}
				validateRegex={RegexUtils.regexes.number}
				validationText={props.content.jointAccountLinkCodeValidationMessage}
				helpText={props.content.jointAccountInputHelpText}
				required
			>
				{props.content.jointAccountLinkCodeTextQuestionLabel}
			</TextQuestion>
			{props.data.linkCaseRequestInvalid && <ErrorMessage text={props.content.jointAccountInvalidResponse} extraClasses="error ja-link-code-info-message" />}
			<SectionFullWidth>
				<BottomNavigationBox
					nextTaskId={props.nextTaskId}
					disabled={!isValid}
					nextButtonLabel={props.content.jointAccountLinkCodeViewNextLabel}
					isLoading={props.appData.isApiCallInProgress}
					onClickNext={props.onClickNext}
				/>
			</SectionFullWidth>
		</span>
	);
};

LinkCode.propTypes = {
	appData: PropTypes.object,
	content: PropTypes.shape({
		jointAccountLinkCodeTextQuestionLabel: PropTypes.string.isRequired,
		jointAccountLinkCodeValidationMessage: PropTypes.string.isRequired,
		jointAccountInvalidResponse: PropTypes.string.isRequired,
		jointAccountInputHelpText: PropTypes.string.isRequired,
		jointAccountLinkCodeViewNextLabel: PropTypes.string.isRequired,
	}),
	data: PropTypes.shape({
		jointLinkCode: PropTypes.string,
		linkCaseRequestInvalid: PropTypes.bool,
	}),
	validations: PropTypes.object,
	nextTaskId: PropTypes.string,
	onClickNext: PropTypes.func,
	additionalLabelClasses: PropTypes.string,
};

module.exports = LinkCode;
