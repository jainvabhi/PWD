const React = require('react');
const { PropTypes } = React;

const Modal = require('../../common/modals/Modal');
const LinkCode = require('./LinkCode');

const LinkCodeModal = React.createClass({
	propTypes: {
		data: PropTypes.shape({
			linkCaseRequestInvalid: PropTypes.bool,
		}),
		content: PropTypes.shape({
			jointAccountModalTitle: PropTypes.string.isRequired,
		}),
		onClickNext: PropTypes.func.isRequired,
		getNextButtonLabel: PropTypes.func.isRequired,
	},

	getInitialState() {
		return {
			visible: false,
		};
	},

	componentWillReceiveProps(nextProps) {
		if (!this.state.visible && nextProps.data.linkCaseRequestInvalid) {
			this.setState({
				visible: true,
			});
		}
	},

	onClickNext(e) {
		this.props.onClickNext(e);
	},

	render() {
		if (!this.state.visible) {
			return null;
		}

		return (
			<div className="ja-link-code-modal">
				<Modal
					title={this.props.content.jointAccountModalTitle}
					titleLevel={2}
				>
					<LinkCode
						{...this.props}
						onClickNext={this.onClickNext}
						nextButtonLabel={this.props.getNextButtonLabel()}
					/>
				</Modal>
			</div>
		);
	},
});

module.exports = LinkCodeModal;
