/**
 * @module TransferContainer
 */

const React = require('react');
const _ = require('lodash');
const { PropTypes } = React;

const SessionActionCreator = require('../../../actions/SessionActionCreator');
const AppActions = require('../../../actions/AppActions');
const BrandUtils = require('../../../utils/BrandUtils');
const envConfig = require('../../../../static/config');

const canTransfer = props => BrandUtils.isAbleToDisplay(`transfer-${props.data.product.productType.name}`)
		&& props.data.product.canTransfer
		&& (!props.data.hasTransfered || props.data.product.allowMultipleTransfers);
const wantsToTransfer = props => canTransfer(props) && (props.data.wantToTranfer === 'Yes' || !props.data.wantToTranfer);

const transferAppEntry = props => {
	const buildParams = params => _.map(params, (v, k) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&');
	const entryParams = {
		applyFor: props.data.productCode,
		bankId: props.data.bankID,
		accountId: _.head(props.data.completedBankInfo.accounts).accountId,
	};

	if (props.data.productVariant) {
		entryParams.issue = props.data.productVariant;
	}

	const returnUrl = `${envConfig.AOBaseUrl}${'/continue'}${props.data
		.isExistingCustomer === 'Yes'
		? '/existing'
		: ''}?${buildParams(entryParams)}#${buildParams({ case_id: props.data.caseId })}`;

	const exitParams = {
		...entryParams,
		returnUrl,
	};
	const bankId = envConfig.bankId === 'DYB' ? 'B' : envConfig.bankId;
	return `${envConfig.appsBaseUrl}/${props.data.product.transferRoute}/${bankId}?${buildParams(exitParams)}#${buildParams({ id_token: props.session.accessToken })}`;
};

const removeAppUnloadWarningAndNavigate = _.once(props => {
	AppActions.removeUnloadWarning();
	setTimeout(() => {
		window.location = transferAppEntry(props);
	}, props.data.product.productType.name === 'cashISA' ? 25000 : 50);
});
const btRequiredScope = 30;
const otpRequiredScope = 40;

const TransferContainer = WrappedComponent => React.createClass({
	propTypes: {
		data: PropTypes.object,
		session: PropTypes.object,
	},

	getInitialState() {
		return {
			stepupRequested: false,
			awaitingHandoff: false,
		};
	},

	componentWillMount() {
	},

	componentWillReceiveProps(newProps) {
		if (this.state.stepupRequested) {
			this.navigateToBtApp(newProps);
		}
	},

	requiresStepUp(props) {
		return !this.stepupRequested && props.data.isExistingCustomer === 'No' && props.session.scope < btRequiredScope;
	},

	transferUser(props) {
		if (this.requiresStepUp(props)) {
			this.setState({
				stepupRequested: true,
			}, () => {
				const requireStepupCallback = () => {
					AppActions.requireStepupAuthentication(() => {
						this.navigateToBtApp(props);
					});
				};
				SessionActionCreator.prepareForStepupAuthentication();
				SessionActionCreator.requestAccessChallengeCreate(props.data.username, otpRequiredScope, requireStepupCallback);
			});
			return;
		}

		this.navigateToBtApp(props);
	},

	navigateToBtApp(props) {
		if (props.session.scope < btRequiredScope) {
			return;
		}

		this.setState({
			awaitingHandoff: true,
		}, () => {
			removeAppUnloadWarningAndNavigate(props);
		});
	},

	render() {
		return (
			<WrappedComponent
				transferUser={this.transferUser}
				canTransfer={canTransfer}
				wantsToTransfer={wantsToTransfer}
				{...this.props}
				{...this.state}
			/>
		);
	},

});

module.exports = TransferContainer;
module.exports.transferAppEntry = transferAppEntry;
