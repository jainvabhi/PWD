/**
 * @module Transfer
 */

const React = require('react');
const { PropTypes } = React;

const RegistrationContainer = require('./RegistrationContainer');

const RadioQuestion = require('../../common/questionsets/RadioQuestion');
const AccountOpeningActions = require('../../../actions/AccountOpeningActions');

const BrandUtils = require('../../../utils/BrandUtils');

const LoadingSpinner = require('../../LoadingSpinner');

const Transfer = props => (
	<div className="transfer-box padding-bottom row">
		{props.content.transferHeader && <h2>{props.content.transferHeader}</h2>}
		<div className="col-md-12">
			{props.awaitingHandoff && <LoadingSpinner />}
			{!props.awaitingHandoff && <RadioQuestion
				align="left"
				defaultValue={null}
				mainColumnSize={BrandUtils.defaultColumnSize() === 12 ? 12 : 6}
				mainColumnSizeMD={BrandUtils.defaultColumnSize() === 12 ? 12 : 6}
				group={props.group}
				helpText={props.content.wantToTransferHelpMessage}
				labelText={props.label}
				name="wantToTranfer"
				onChange={AccountOpeningActions.updateFormValue}
				options={[{
					anchor: 'transfer-no',
					value: 'No',
				}, {
					anchor: 'transfer-yes',
					value: 'Yes',
				}]}
				required
			/>}
		</div>
	</div>
);

Transfer.propTypes = {
	content: PropTypes.object,
	appData: PropTypes.object,
	validations: PropTypes.object,
	selectContentBasedOnDowngrade: PropTypes.func,
	onSubmit: PropTypes.func,
	showDigitalRegistration: PropTypes.bool,
	data: PropTypes.object,
	group: PropTypes.string,
	label: PropTypes.string.isRequired,
	awaitingHandoff: PropTypes.bool,
};

module.exports = RegistrationContainer(Transfer);
