/**
 * @module RegistrationContainer
 */

const React = require('react');
const { PropTypes } = React;

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');
const AnalyticsActionCreator = require('../../../actions/AnalyticsActionCreator');
const CredentialsActions = require('../../../actions/CredentialsActions');
const SessionActionCreator = require('../../../actions/SessionActionCreator');

const UserServicesApiUtils = require('../../../utils/UserServicesApiUtils');

function supportsRegistration(props) {
	const { data: { product, isExistingCustomer } } = props;
	if (isExistingCustomer === 'Yes') {
		return product.registrationSupport.existing;
	} else {
		return product.registrationSupport.ntb;
	}
}


const RegistrationContainer = WrappedComponent => React.createClass({
	propTypes: {
		appData: PropTypes.object,
		data: PropTypes.object,
		validations: PropTypes.object,
		session: PropTypes.object,
		content: PropTypes.object,
		selectContentBasedOnDowngrade: PropTypes.func,
	},

	getInitialState() {
		return {
			requestedSecurityQuestions: false,
		};
	},

	componentWillMount() {
		AccountOpeningActions.getCompletedCase(this.props.data.caseId, this.props.data.product.productType);
		if (supportsRegistration(this.props)) {
			CredentialsActions.getCredentials();
		}

		// Record an analytics user event.
		AnalyticsActionCreator.track({
			path: '/user/experience/view',
			action: 'Appeared',
		}, {
			description: 'PageLoaded',
		});
	},

	componentDidUpdate() {
		// Do we need to download security questions?
		if (this.showDigitalRegistration() && this.props.data.credentials && !this.state.requestedSecurityQuestions && this.shouldShowRib()) {
			this.setState({
				requestedSecurityQuestions: true,
			}, () => {
				UserServicesApiUtils.requestSecurityQuestions();
			});
		}
	},

	/**
	 * Get and format the error message if the form submit is not successful
	 */
	getCredentialErrorMessage() {
		if (this.props.data.registrationPageErrorCallbackMessage && this.props.data.registrationPageErrorCallbackCredential) {
			return this.props.content.registrationPageErrorMessage
				.replace('{0}', this.props.data.registrationPageErrorCallbackCredential)
				.replace('{1}', this.props.data.registrationPageErrorCallbackMessage);
		}
	},

	/**
	 * User attempting to submit the form.
	 * Do we need to trigger an OTP popup?
	 *
	 * @param  {Event} e 	Click event.
	 */
	_onSubmitClick(e) {
		e.preventDefault();

		AnalyticsActionCreator.track({
			path: '/user/experience/activity',
			action: 'Interacted',
		}, {
			description: 'RegistrationSubmitted',
			event: 'created',
		});

		const submitForm = product => (publicKey, publicKeyDateTime) => {
			// Got key, need to send the user's answers now.
			AccountOpeningActions.submitRegistrationPage(publicKey, publicKeyDateTime, product.postRegistrationTask);
		};
		// Is this a form submission, or simply navigating?
		if (this.showDigitalRegistration()) {
			const publicKey = this.props.session.genericPublicKey;
			const publicKeyDateTime = this.props.session.genericPublicKeyDatetime;
			// If we don't have a key get one and then submit the form
			if (!publicKey && !publicKeyDateTime) {
				SessionActionCreator.requestPublicKey(submitForm(this.props.data.product));
			} else if (publicKey && publicKeyDateTime) {
				// Looks like we have a key so let's go ahead and submit
				submitForm(this.props.data.product)(publicKey, publicKeyDateTime);
			}
		} else {
			AccountOpeningActions.navigateToWebTask(this.props.data.product.postRegistrationTask);
		}
	},

	/**
	 * Should password offered?
	 *
	 * @return {Boolean}
	 */
	shouldShowPassword() {
		return !!(this.props.data.credentials && !this.props.data.credentials.password);
	},

	/**
	 * Should sign-up for RIB be offered?
	 *
	 * @return {Boolean}
	 */
	shouldShowRib() {
		return !!(this.props.data.credentials && !this.props.data.credentials['security_questions']);
	},

	/**
	 * Should sign-up for telephone banking be offered?
	 *
	 * @return {Boolean}
	 */
	shouldShowTB() {
		return !!(this.props.data.credentials && !this.props.data.credentials.acn);
	},

	showDigitalRegistration() {
		return supportsRegistration(this.props) && (this.shouldShowRib() || this.shouldShowTB() || this.shouldShowPassword());
	},

	render() {
		return (
			<WrappedComponent
				showDigitalRegistration={this.showDigitalRegistration()}
				credentialErrorMessage={this.getCredentialErrorMessage()}
				shouldShowPassword={this.shouldShowPassword}
				onSubmit={this._onSubmitClick}
				onChange={AccountOpeningActions.updateFormValue}
				{...this.props}
			/>
		);
	},

});

module.exports = RegistrationContainer;
