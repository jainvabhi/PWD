jest.unmock('../RegistrationContainer');

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const ReactDOM = require('react-dom');

const CredentialsActions = require('../../../../actions/CredentialsActions');
const AccountOpeningActions = require('../../../../actions/AccountOpeningActions');

const container = document.createElement('div');
const render = (comp, el) => ReactDOM.render(comp, el || container);
const shallowRenderer = TestUtils.createRenderer();

const RegistrationContainer = require('../RegistrationContainer');

const ChildComponent = props => {
	return (<h1>Child Component</h1>);
};

const RegistrationContainerInstance = RegistrationContainer(ChildComponent);

const shallowRender = props => {
	const shallowRenderer = TestUtils.createRenderer();
	shallowRenderer.render(<RegistrationContainerInstance {...props}/>);
	return shallowRenderer.getRenderOutput();
};

describe('RegistrationContainer', () => {
	let e;

	beforeEach(() => {
		CredentialsActions.getCredentials.mockClear();
		AccountOpeningActions.submitRegistrationPage.mockClear();
		AccountOpeningActions.getCase.mockClear();
		e = {
			preventDefault: jest.fn()
		};
	});

	describe('when a NTB customer is applying', () => {
		describe('for a product that allows for Digital Registration', () => {
			let instance, props;

			beforeEach(() => {
				props = {
					canTransfer: ()=>{},
					shouldShowPassword: () => true,
					data: {
						credentials:{
							acn: false,
							password: false,
							"security_questions": false,
						},
						isExistingCustomer: 'No',
						product: {
							productType: {
							},
							registrationSupport: {
								ntb: true,
							}
						}
					}
				};
				instance = shallowRender(props);
			});

			it('should show digital registration', () => {
				expect(instance.props.showDigitalRegistration).toBe(true);
			});

			it('should call the credentials api', () => {
				expect(CredentialsActions.getCredentials).toBeCalled();
			});

			it('should render the UI component when we get data back', () => {
				expect(instance).toEqualJSX(
					<ChildComponent
						showDigitalRegistration={true}
						credentialErrorMessage={undefined}
						canTransfer={() => {}}
						shouldShowPassword={() => {}}
						onSubmit={()=>{}}
						onChange={()=>{}}
						{...props}
					/>);
			});

			it('should submit the registration details when they submit', () => {
				props = Object.assign({}, props, {
							session:{
								genericPublicKey: '1',
								genericPublicKeyDatetime: '2016-11-11 12:00:00'
							}
				});
				props.data = Object.assign({}, props.data, {
								credentials:{
										security_questions:null
								},
								caseId: null
							});
				instance  = shallowRender(props);

				instance.props.onSubmit(e);
				expect(AccountOpeningActions.submitRegistrationPage).toBeCalled();
			});

		});

		describe('for a product that does not allow Digital Registration', () => {
			let instance;

			beforeEach(() => {
				instance = shallowRender({
					canTransfer: ()=>{},
					data: {
						isExistingCustomer: 'Yes',
						product: {
							productType: {
							},
							registrationSupport: {
								ntb: false,
							}
						}
					}
				});
			});

			it('should not call the credentials api', () => {
				expect(CredentialsActions.getCredentials).not.toBeCalled();
			});

			it('should not submit the registration details when they submit', () => {
				instance.props.onSubmit(e);
				expect(AccountOpeningActions.submitRegistrationPage).not.toBeCalled();
			});
		});
	});

	describe('when an existing customer is applying', () => {
		describe('for a product that allows for Digital Registration', () => {
			let props, instance;

			beforeEach(() => {
				props = {
					canTransfer: ()=>{},
					data: {
						isExistingCustomer: 'Yes',
						product: {
							productType: {
							},
							registrationSupport: {
								existing: true,
							}
						}
					}
				};
				instance = shallowRender(props);
			});

			it('should call the credentials api', () => {
				expect(CredentialsActions.getCredentials).toBeCalled();
			});

			it('should render the UI component when we get data back', () => {
				expect(instance).toEqualJSX(
					<ChildComponent
						showDigitalRegistration={false}
						credentialErrorMessage={undefined}
						onSubmit={()=>{}}
						canTransfer={() => {}}
						shouldShowPassword={() => {}}
						onChange={()=>{}}
						{...props}
					/>);
			});

			it('should submit the registration details when they submit', () => {
				props = Object.assign({}, props, {
							session:{
								genericPublicKey: '1',
								genericPublicKeyDatetime: '2016-11-11 12:00:00'
							}
				});
				props.data = Object.assign({}, props.data, {
								credentials:{
										security_questions:null
								},
								caseId: null
							});
				instance  = shallowRender(props);

				instance.props.onSubmit(e);
				expect(AccountOpeningActions.submitRegistrationPage).toBeCalled();
			});
		});

		describe('for a product that does not allow Digital Registration', () => {
			let instance;

			beforeEach(() => {
				instance = shallowRender({
					canTransfer: ()=>{},
					data: {
						isExistingCustomer: 'Yes',
						product: {
							productType: {
							},
							registrationSupport: {
								existing: false,
							},
							postRegistrationTask: 'redirect',
						}
					}
				});
			});

			it('should not call the credent api', () => {
				expect(CredentialsActions.getCredentials).not.toBeCalled();
			});

			it('should not submit the registration details when they submit', () => {
				instance.props.onSubmit(e);
				expect(AccountOpeningActions.submitRegistrationPage).not.toBeCalled();
			});

			it('should redirect to the correct page', () => {
				instance.props.onSubmit(e);
				expect(AccountOpeningActions.navigateToWebTask).toBeCalledWith('redirect');
			});

			it('should not show digital registration', () => {
				expect(instance.props.showDigitalRegistration).toBe(false);
			});

		});

	});
});
