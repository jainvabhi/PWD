jest.autoMockOff();

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const ReactDOM = require('react-dom');

const container = document.createElement('div');
const render = (comp, el) => ReactDOM.render(comp, el || container);
const shallowRenderer = TestUtils.createRenderer();

const {
	DYBInfo,
	CYBInfo,
	GenericAccountInfo,
	CashISAAccountInfo,
	RibTbIntro,
	CashISARegistrationIntro,
	Transfer,
} = require('../RegistrationTypes');
const { buildContent } = require('../../../../__helpers__/TestHelpers');

let instance, result, props;
const shallowRender = props => {
	const shallowRenderer = TestUtils.createRenderer();
	shallowRenderer.render(
		<CYBInfo {...props} />
	);
	instance = TestUtils.renderIntoDocument(
		<CYBInfo {...props} />,
		document.createElement('div')
	);
	return shallowRenderer.getRenderOutput();
};

const content = buildContent([
	'cashISAHowToRegisterTitle',
	'cashISARegistrationFooter1',
	'cashISARegistrationFooter2',
	'cashISARegistrationIntro',
	'cashISARegistrationTitle',
	'cashISARequirements1',
	'cashISARequirements2',
	'cashISARequirements3',
]);

describe('RegistrationTypes', () => {
	describe('credit card', () => {
		beforeEach(() => {
			props = {
				canTransfer: () => true,
				shouldShowPassword: () => true,
				showDigitalRegistration: true,
				content,
				getProductContent: content => content,
				selectContentBasedOnDowngrade: content => content,
				wantsToTransfer: () => true,
				group: 'test',
				data: {
					wantToTranfer: 'No',
					product: {
						productType: {
							name: 'credit-card',
						},
						registrationSupport: {

						},
					},

					completedBankInfo: {
						account_type: 'Credit Card',
						account_number: '10012212',
						account_id: 'f6a73fed-a0ff-4a03-a665-39433e2bab80',
						customer_number: '1097736805',
						sort_code: '824000',
						pan: null,
						'accounts': [{
							'sort_code': null,
							'account_number': null,
							'account_type': 'CREDIT CARD',
							'account_name': null,
							'bank': null,
							'time_with_bank': null,
						}],
						account_type: 'Credit Card',
						caseId: 'CS-123',
						sortCode: '503939',
						account_number: '49893829',
						customer_number: '9387239874',
						offer: {
							product: {
								code: '001',
								name: 'Credit Card',
								description: 'Gold 99 Credit Card',
							},
							features: {
								creditLimit: {
									offerLimit: 4000,
								},
							},
						},
					},
				},
			};
			result = shallowRender(props);
		});

		it('should render the Generic Account Info', () => {
			expect(result).toIncludeJSX(<GenericAccountInfo {...props} />)
		});

		it('should render the rib/tb intro', () => {
			expect(result).toIncludeJSX(<RibTbIntro {...props} />)
		});

		it('should NOT render the Cash ISA Account Info', () => {
			expect(result).not.toIncludeJSX(<CashISAAccountInfo {...props} />)
		});

		it('should NOT render the Cash ISA Reg  Info', () => {
			expect(result).not.toIncludeJSX(<CashISARegistrationIntro {...props} />)
		});
	});
});
