jest.unmock('../TransferContainer');

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const ReactDOM = require('react-dom');

const SessionActionCreator = require('../../../../actions/SessionActionCreator');
const AccountOpeningActions = require('../../../../actions/AccountOpeningActions');
const AppActions = require('../../../../actions/AppActions');
const envConfig = require('../../../../../static/config');

const container = document.createElement('div');
const render = (comp, el) => ReactDOM.render(comp, el || container);
const shallowRenderer = TestUtils.createRenderer();

const TransferContainer = require('../TransferContainer');
const { transferAppEntry } = require('../TransferContainer');

const ChildComponent = props => <h1>Child Component</h1>;

const TestPage = TransferContainer(ChildComponent);
let instance, result, props;
const shallowRender = props => {
	const shallowRenderer = TestUtils.createRenderer();
	shallowRenderer.render(
		<TestPage {...props} />
	);
	instance = TestUtils.renderIntoDocument(<TestPage {...props} />, document.createElement('div'));
	return shallowRenderer.getRenderOutput();
};

describe('TransferContainer', () => {

	beforeEach(() => {
		SessionActionCreator.prepareForStepupAuthentication.mockClear();
		SessionActionCreator.requestAccessChallengeCreate.mockClear();
	});

	describe('when a NTB customer is applying', () => {
		describe('with a lower scope than required', () => {
			beforeEach(() => {
				props = {
					canTransfer: ()=>{},
					appData: {
						disableUnload: true,
					},
					data: {
						isExistingCustomer: 'No',
						product: {
							canTransfer: true,
							transferRoute: 'test',
							productType: {
							},
						}
					},
					session: {
						scope: 20
					},
				};
				result = shallowRender(props);
				instance.transferUser(props);

			});

			it('should set state to flag request to setup has been made', () => {
				expect(instance.state.stepupRequested).toBeTruthy();
			});

			it('should fire the required stepup actions', () => {
				expect(SessionActionCreator.prepareForStepupAuthentication).toBeCalled();
				expect(SessionActionCreator.requestAccessChallengeCreate).toBeCalled();
			});

			it('should render the UI component when we get data back', () => {
				expect(result).toEqualJSX(
					<ChildComponent
						canTransfer={() => {}}
						transferUser={()=>{}}
						wantsToTransfer={()=>{}}
						awaitingHandoff={false}
						stepupRequested={false}
						{...props}
					/>);
			});
		});

		describe('when a existing customer is applying', () => {
			describe('with the correct scope', () => {
				beforeEach(() => {

					props ={
						canTransfer: ()=>{},
						appData: {
							disableUnload: true,
						},
						data: {
							isExistingCustomer: 'Yes',
							product: {
								canTransfer: true,
								transferRoute: 'test',
								productType: {
								},
							}
						},
						session: {
							scope: 30
						},
					};
					result = shallowRender(props);
					instance.transferUser(props);
				});

				it('should not update state', () => {
					expect(instance.state.stepupRequested).not.toBeTruthy();
				});

				it('should NOT fire the required stepup actions', () => {
					expect(SessionActionCreator.prepareForStepupAuthentication).not.toBeCalled();
					expect(SessionActionCreator.requestAccessChallengeCreate).not.toBeCalled();
				});
			});
		});
	});

	describe('with a correct scope', () => {
		beforeEach(() => {
			props = {
				canTransfer: ()=>{},
				appData: {
					disableUnload: true,
				},
				data: {
					isExistingCustomer: 'No',
					product: {
						canTransfer: true,
						transferRoute: 'test',
						productType: {
						},
					}
				},
				session: {
					scope: 30
				},
			};
			result = shallowRender(props);
			instance.transferUser(props);
		});

		it('should fire navigation calls only once', () => {
			expect(AppActions.removeUnloadWarning.mock.calls.length).toBe(1);
			instance.transferUser(props);
			instance.transferUser(props);
			instance.transferUser(props);
			expect(AppActions.removeUnloadWarning.mock.calls.length).toBe(1);
		});
	});

	describe('transferAppEntry', () => {
		it('should construct the url', () => {
			const accountId = '123';
			const productCode = 'G99';
			const transferRoute = 'route';
			const accessToken = 'topsecret';
			const bankID = 'CB'

			expect(
				transferAppEntry({
					data: {
						bankID,
						completedBankInfo: {
							accounts: [{
								accountId,
							}]
						},
						productCode,
						product: {
							transferRoute,
						},
					},
					session: {
						accessToken,
					},
				})
			).toEqual(
				`undefined/${transferRoute}/${bankID}` +
					`?applyFor=${productCode}&bankId=${bankID}&accountId=${accountId}` +
					`&returnUrl=undefined%2Fcontinue%3FapplyFor%3D${productCode}` +
					`%26bankId%3D${bankID}%26accountId%3D${accountId}%23case_id%3Dundefined#id_token=${accessToken}`
			);
		});
	});
});
