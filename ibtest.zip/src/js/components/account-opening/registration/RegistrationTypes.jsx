/**
 * @module RegistrationTypes
 */

const React = require('react');
const { PropTypes } = React;
const _ = require('lodash');
const cx = require('classnames');

const SectionFullWidth = require('../../common/SectionFullWidth');
const ListSection = require('../../common/sections/ListSection');
const Transfer = require('./Transfer');

const isCashISA = props => props.data.product.productType.name === 'cashISA';
const isCreditCard = props => props.data.product.productType.name === 'credit-card';
const { formatSortCode } = require('../../../utils/NumberUtils');

const mapBankAccountInformation = props => {
	if (isCreditCard(props)) {
		return null;
	}

	const getDataAnchor = (accountType, numberType) => (`${_.kebabCase(accountType)}-${numberType}`);
	const { completedBankInfo } = props.data;
	return completedBankInfo && _.map(completedBankInfo.accounts, (account, i) => (
		<div key={i}>
			<div className="col-xs-12 text-center">
				<h3>{_.startCase(account.accountType)}</h3>
			</div>
			<div className="col-xs-6 text-right">
				Sort code:
			</div>
			<div className="col-xs-6 text-left min-height-25">
				<span data-anchor={getDataAnchor(account, 'sort-code')}>{account.sortCode}</span>
			</div>
			<div className="col-xs-6 text-right">
				Account number:
			</div>
			<div className="col-xs-6 text-left min-height-25">
				<span data-anchor={getDataAnchor(account, 'account-number')}>{account.accountNumber}</span>
			</div>
		</div>
	));
};

mapBankAccountInformation.propTypes = {
	data: PropTypes.shape({
		completedBankInfo: PropTypes.object,
	}),
};

const RibTbIntro = props => {
	if (!props.showDigitalRegistration) {
		return null;
	}

	return (
		<div className={cx('col-xs-12 text-left padding-top padding-bottom', { 'transfer-cust-info': (props.canTransfer(props) || props.data.hasTransfered) })}>
			{props.content.registrationPageRibHeader && <h2>{props.content.registrationPageRibHeader}</h2>}
			{(props.data.wantToTranfer === 'No' || props.data.hasTransfered) && props.content.registrationPageRibIntro && (<p className="large  padding-top">{props.content.registrationPageRibIntro}</p>)}
			<p className="large padding-top">{props.selectContentBasedOnDowngrade('registrationPageParagraph1')}</p>
			<ul>
				{props.selectContentBasedOnDowngrade('registrationPageBullet1') && <li key="1"><p>{props.selectContentBasedOnDowngrade('registrationPageBullet1')}</p></li>}
				{!props.shouldShowPassword() && props.selectContentBasedOnDowngrade('registrationPageBullet2') && <li key="2"><p>{props.selectContentBasedOnDowngrade('registrationPageBullet2')}</p></li>}
				{props.selectContentBasedOnDowngrade('registrationPageBullet3') && <li key="3"><p>{props.selectContentBasedOnDowngrade('registrationPageBullet3')}</p></li>}
			</ul>
			<p>{props.selectContentBasedOnDowngrade('registrationPageParagraph2')}</p>
		</div>
	);
};

RibTbIntro.propTypes = {
	selectContentBasedOnDowngrade: PropTypes.func,
	shouldShowPassword: PropTypes.func,
	data: PropTypes.object,
	content: PropTypes.object,
	showDigitalRegistration: PropTypes.bool.isRequired,
	canTransfer: PropTypes.func,
};

const getContentItems = (content, prefix) => {
	return _.chain(content)
	.keys()
	.filter(key => key.startsWith(prefix))
	.map(key => {
		return content[`${key}`];
	})
	.value();
};

const GenericAccountInfo = props => {
	const { completedBankInfo } = props.data;
	return (
		<div className="row result-header-account-details">
			<div>
				{props.selectContentBasedOnDowngrade('registrationPageSubTitle') && <div className="col-xs-12 padding-bottom text-center">
					<h2>{props.selectContentBasedOnDowngrade('registrationPageSubTitle')}</h2>
				</div>}
				<div className="row">
					{props.content.registrationPageCustNoTitle && <div className="col-xs-12 text-center">
						<h3>{props.content.registrationPageCustNoTitle}</h3>
					</div>}
					<div className={cx('cust-no-section', { transfer: (props.canTransfer(props) || props.data.hasTransfered) })}>
						<div className="col-xs-6 text-right">
							<p>{props.content.registrationPageCustNoPara1}</p>
						</div>
						<div className="col-xs-6 text-left min-height-25">
							<p><span data-anchor="customer-number" className="customer-number">{completedBankInfo && completedBankInfo.customerNumber}</span></p>
						</div>
					</div>
					{props.content.registrationPageCustNoPara2 && <h3 className="cust-no-section__header">{props.content.registrationPageCustNoPara2}</h3>}
				</div>
				{mapBankAccountInformation(props)}
				{props.data.product.showBondDepositInstructions &&
					<SectionFullWidth className="seperator bond-deposit-instructions">
						<h2 className="component-title">{ props.content.accountOpenedSection13Title }</h2>
						<ListSection
							items={getContentItems(props.content, 'accountOpenedSection13Bullet')}
						/>
					</SectionFullWidth>
				}
				{!isCreditCard(props) && <RibTbIntro {...props} />}
			</div>
		</div>
	);
};

GenericAccountInfo.propTypes = {
	selectContentBasedOnDowngrade: PropTypes.func,
	showDigitalRegistration: PropTypes.bool.isRequired,
	data: PropTypes.shape({
		customerNumber: PropTypes.string,
		hasTransfered: PropTypes.bool,
		product: PropTypes.shape({
			showBondDepositInstructions: PropTypes.bool,
		}),
	}),
	content: PropTypes.object,
	canTransfer: PropTypes.func,
};

const MapCashISABankInfo = props => {
	const { completedBankInfo } = props.data;
	return _.map(completedBankInfo.accounts, (account, i) => {
		return (
			<div className="col-xs-12 text-center padding-top padding-bottom" key={i}>
				<h4 className="text-center">{props.data.product.name}</h4>
				<div className="account-info">
					<div className="account-info__group">
						<p className="group-label text-right">Sort code:</p><p className="group-value text-left">{formatSortCode(account.sortCode)}</p>
					</div>
					<div className="account-info__group">
						<p className="group-label text-right">Account number:</p><p className="group-value text-left">{account.accountNumber}</p>
					</div>
				</div>
			</div>
		);
	});
};

MapCashISABankInfo.propTypes = {
	data: {
		completedBankInfo: PropTypes.object,
	},
};

const CashISAAccountInfo = props => {
	return (
		<div className="row result-header-account-details cash-isa">
			<div>
				<div className="col-xs-12 padding-bottom">
					<h2>{props.selectContentBasedOnDowngrade('registrationPageSubTitle')}</h2>
				</div>
				<div className="row">
					<div className="col-xs-12 text-center">
						<h3>Customer number</h3>
					</div>
					<div className="col-xs-12 text-center min-height-25">
						<p><span className="customer-number" data-anchor="customer-number">{props.data.completedBankInfo.customerNumber}</span></p>
					</div>
				</div>
				{MapCashISABankInfo(props)}
			</div>
		</div>
	);
};

CashISAAccountInfo.propTypes = {
	selectContentBasedOnDowngrade: PropTypes.func,
	data: PropTypes.shape({
		customerNumber: PropTypes.string,
		completedBankInfo: PropTypes.object,
	}),
};

const CashISARegistrationIntro = props => {
	return (
		<div className="row cash-isa text-left register-info-container">
			<div>
				<h2 className="text-left">{props.content.cashISARegistrationTitle}</h2>
				<p>{props.content.cashISARegistrationIntro}</p>
				<h3>{props.content.cashISAHowToRegisterTitle}</h3>
				<ul>
					<li><p className="customer-number-reminder" dangerouslySetInnerHTML={{ __html: props.content.cashISARequirements1.replace('{customerNumber}', props.data.completedBankInfo.customerNumber) }}></p></li>
					<li><p>{props.content.cashISARequirements2}</p></li>
					<li><p>{props.content.cashISARequirements3}</p></li>
				</ul>
				<p>{props.content.cashISARegistrationFooter1}</p>
				<p>{props.content.cashISARegistrationFooter2}</p>
			</div>
		</div>
	);
};

CashISARegistrationIntro.propTypes = {
	data: PropTypes.shape({
		completedBankInfo: PropTypes.shape({
			customerNumber: PropTypes.string,
		}),
	}),
	content: PropTypes.shape({
		cashISARegistrationTitle: PropTypes.string.isRequired,
		cashISARegistrationIntro: PropTypes.string.isRequired,
		cashISAHowToRegisterTitle: PropTypes.string.isRequired,
		cashISARequirements1: PropTypes.string.isRequired,
		cashISARequirements2: PropTypes.string.isRequired,
		cashISARequirements3: PropTypes.string.isRequired,
		cashISARegistrationFooter1: PropTypes.string.isRequired,
		cashISARegistrationFooter2: PropTypes.string.isRequired,
	}),
};


const CybRegistration = props => {
	if (!props.data.completedBankInfo) {
		return null;
	}

	const transferQuestionLabel = props.data.hasTransfered ? props.getProductContent('transferAnotherQuestion')
		&& props.getProductContent('transferAnotherQuestion')
		.replace('{productName}', props.data.product.name) : props.getProductContent('transferQuestion')
		&& props.getProductContent('transferQuestion')
		.replace('{productName}', props.data.product.name);

	return (
		<div>
			{!isCashISA(props) && <GenericAccountInfo {...props} />}
			{isCashISA(props) && <CashISAAccountInfo {...props} />}
			{props.canTransfer(props) && <Transfer
				{...props}
				group={props.group}
				label={transferQuestionLabel}
			/>}
			{isCreditCard(props) && props.showDigitalRegistration &&
					(props.data.wantToTranfer === 'No' || props.data.hasTransfered) &&
					<RibTbIntro {...props} />
			}
			{isCashISA(props) &&
					props.showDigitalRegistration &&
					!props.wantsToTransfer(props) &&
					<CashISARegistrationIntro {...props} />
			}
		</div>
	);
};

CybRegistration.propTypes = {
	data: PropTypes.shape({
		showDigitalRegistration: PropTypes.bool,
		wantToTranfer: PropTypes.string,
		hasTransfered: PropTypes.bool,
		completedBankInfo: PropTypes.object,
		product: PropTypes.object,
	}),
	canTransfer: PropTypes.func,
	group: PropTypes.string,
	wantsToTransfer: PropTypes.func,
	showDigitalRegistration: PropTypes.bool,
	getProductContent: PropTypes.func,
};

const DybRegistration = props => {
	if (!props.data.completedBankInfo) {
		return null;
	}

	const transferQuestionLabel = props.getProductContent('transferQuestion') && props.getProductContent('transferQuestion')
		.replace('{productName}', props.data.product.name);

	return (
		<div>
			<GenericAccountInfo {...props} />
			{props.canTransfer(props) && <Transfer
				{...props}
				group={props.group}
				label={transferQuestionLabel}
			/>}
			{isCreditCard(props) && props.showDigitalRegistration &&
					(props.data.wantToTranfer === 'No' || props.data.hasTransfered) &&
					<RibTbIntro {...props} />
			}
		</div>
	);
};

DybRegistration.propTypes = {
	data: PropTypes.shape({
		showDigitalRegistration: PropTypes.bool,
		wantToTranfer: PropTypes.string,
		hasTransfered: PropTypes.bool,
		completedBankInfo: PropTypes.object,
		product: PropTypes.object,
	}),
	canTransfer: PropTypes.func,
	group: PropTypes.string,
	wantsToTransfer: PropTypes.func,
	showDigitalRegistration: PropTypes.bool,
	getProductContent: PropTypes.func,
};


module.exports = {
	DYBInfo: DybRegistration,
	CYBInfo: CybRegistration,
	GenericAccountInfo,
	CashISAAccountInfo,
	RibTbIntro,
	CashISARegistrationIntro,
	Transfer,
};
