/**
 * @module SavingsAccountReviewSection
 */

const React = require('react');
const { PropTypes } = React;

const AccountOpeningConstants = require('../../../constants/AccountOpeningConstants');

const GeneralReviewSection = require('./GeneralReviewSection');
const ReviewSection = require('./ReviewSection');
const MarketingPrefSection = require('./MarketingPrefSection');
const UsernameDetailsComponent = require('../findDetails/UsernameDetailsComponent');

const SavingsAccountReviewSection = props => {
	const savingsLeftContent = [
		{ label: props.content.reviewLabelincomeOtherSavingsTypeOptions, value: props.data.incomeOtherSavingsTypeOptions },
		{ label: props.content.reviewLabelincomeOtherSavingsFrequency, value: props.data.incomeOtherSavingsFrequency },
	];

	const savingsRightContent = [
		{ label: props.content.reviewLabelincomeOtherSavingsPurpose, value: props.data.incomeOtherSavingsPurpose },
		{ label: props.content.reviewLabelincomeOtherSavingsAmount, value: props.data.incomeOtherSavingsAmount },
	];

	return (
		<div>
			<GeneralReviewSection {...props} />
			<ReviewSection
				onEditLinkClick={props.onEditLinkClick}
				data={{
					title: props.content.reviewLabelsectionSA,
					leftContent: savingsLeftContent,
					rightContent: savingsRightContent,
					editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-SAVINGS',
				}}
			/>
			<MarketingPrefSection
				group={props.group}
				onContactMethodsChange={props.onContactMethodsChange}
				{...props}
			/>
			<UsernameDetailsComponent
				group={AccountOpeningConstants.GROUP_REVIEW}
				{...props}
			/>
		</div>
	);
};

SavingsAccountReviewSection.propTypes = {
	data: PropTypes.object.isRequired,
	content: PropTypes.shape({
		reviewLabelincomeOtherSavingsTypeOptions: PropTypes.string.isRequired,
		reviewLabelincomeOtherSavingsFrequency: PropTypes.string.isRequired,
		reviewLabelincomeOtherSavingsPurpose: PropTypes.string.isRequired,
		reviewLabelsectionSA: PropTypes.string.isRequired,
		reviewLabelincomeOtherSavingsAmount: PropTypes.string.isRequired,
	}).isRequired,
	onEditLinkClick: PropTypes.func.isRequired,
	group: PropTypes.string.isRequired,
	onContactMethodsChange: PropTypes.func.isRequired,
};

module.exports = SavingsAccountReviewSection;
