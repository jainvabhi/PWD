/**
 * @module ImportantInfoSection
 */

const _ = require('lodash');
const React = require('react');
const { PropTypes } = React;

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');
const AccountOpeningConstants = require('../../../constants/AccountOpeningConstants');

const { DocumentLink, getDocument } = require('../../common/links/DocumentLink');
const MandateSection = require('../review/MandateSection');

const NumberUtils = require('../../../utils/NumberUtils');
const ContentUtils = require('../../../utils/ContentUtils');

const CollapsibleSection = require('../../common/sections/CollapsibleSection');

const isCashISA = props => {
	const { data: { product } } = props;
	return product.productType.name === 'cashISA';
};

const hasDeclarationOnReview = props => {
	const { data: { product } } = props;
	return product.declarationOnReview;
};


const ImportantInfoSection = React.createClass({
	propTypes: {
		data: PropTypes.object.isRequired,
		cms: PropTypes.object.isRequired,
		content: PropTypes.object.isRequired,
		applyingFor: PropTypes.element.isRequired,
		onReviewAcceptTCs: PropTypes.func.isRequired,
		onProductTermsPDFClick: PropTypes.func.isRequired,
		group: PropTypes.string.isRequired,
		onDeclarationToggle: PropTypes.func,
		isDeclarationOpen: PropTypes.bool,
		envConfig: PropTypes.shape({
			bankId: PropTypes.string.isRequired,
		}),
	},

	/**
	 * Retrieve the additional documents for the selected account.
	 * @return {array} array of JSX elements.
	 */
	getAdditionalDocumentItems() {
		const docs = this.props.data.product.additionalDocumentItems;
		let onClick;
		return _.flow(
			docs => _.filter(docs, docKey => getDocument(docKey, this.props.envConfig.bankId, this.props.cms)),
			filtered => _.map(filtered, (additionalDocumentItem, index) => {
				if (additionalDocumentItem === 'termsAndConditions') {
					// not sure why we only track this document @ticket DGW2-946 will investigate
					onClick = this.props.onProductTermsPDFClick;
				}

				return (
					<li key={index}>
						<DocumentLink
							docKey={additionalDocumentItem}
							onClick={onClick}
							{...this.props}
						/>
					</li>
				);
			})
		)(docs);
	},

	/**
	 * Required document link section
	 *
	 */
	getDocumentSection() {
		const productType = this.props.data.product.productType;

		return productType && (
			<ul>
				{this.getAdditionalDocumentItems()}
			</ul>
		);
	},

	/**
	 * Retrieve the key features for the selected account.
	 * @param {object} productData Product object
	 * @return {array} array of JSX elements.
	 */
	getKeyFeatureItems(productData) {
		return _.map(productData.keyFeatureItems, (feature, index) => {
			let content = this.props.content[feature];

			if (feature === 'monthlyFee') {
				content = NumberUtils.appendCurrency(content, productData.monthlyFee);
			}

			content = ContentUtils.replaceWithProductConfigData(content, productData);

			return (<li key={index} dangerouslySetInnerHTML={{ __html: content }} />);
		});
	},

	/**
	 * Get a JSX element for each offer restriction item.
	 * @param  {Array} offerRestrictions	Offers restriction array content mapper
	 * @param  {string} title 				section  title object
	 * @return {Array} Of JSX elements.
	 */
	getOfferRestrictions(offerRestrictions, title) {
		if (_.isEmpty(offerRestrictions)) {
			return null;
		}

		const items = _(offerRestrictions)
			.filter(contentKey => this.props.content[contentKey])
			.map((contentKey, index) => (<li key={index}>{ContentUtils.replaceWithProductConfigData(this.props.content[contentKey], this.props.data.product)}</li>))
			.value();

		return (
				<div>
					<h4>{this.props.content[title]}</h4>
					<ul>
						{items}
					</ul>
				</div>
			);
	},

	/**
	 * Return an array of JSX elements formatted as bullet points
	 *
	 * @param  {String} key				the JSON key without the number suffix
	 * @param  {Array}  content 		the JSON items to be filtered through
	 * @return {Array}  Of JSX elements.
	 */
	getMandateBulletPoints(content) {
		const items = this.props.data.product.mandateItems;

		return _.flow(
			bullets => _.filter(bullets, item => content[item]),
			filtered => _.map(filtered, item => <li key={item}>{content[item]}</li>)
		)(items);
	},

	render() {
		const { product } = this.props.data;
		return (
			<div>
				<h2 className="icon-header important-information padding-bottom">{this.props.content.reviewImportantInformationTitle}</h2>
				<div className="key-features-section padding-bottom">
					<h3 className="sub-heading h4-style">{this.props.content.reviewKeyFeaturesTitle} {this.props.applyingFor}</h3>
					{product.description &&
						<p>{product.description}</p>
					}
					<ul>
						{this.getKeyFeatureItems(product)}
					</ul>
					{this.getOfferRestrictions(product.offerRestrictions, 'reviewOfferRestrictionsTitle')}
				</div>

				{isCashISA(this.props) && hasDeclarationOnReview(this.props) &&
					<CollapsibleSection
						onChange={this.props.onDeclarationToggle}
						isOpen={this.props.isDeclarationOpen}
					>
						<MandateSection
							key="reviewDeclarationSection"
							onReviewAcceptTCs={AccountOpeningActions.updateFormValue}
							acceptTsAndCs={false}
							group={AccountOpeningConstants.GROUP_REVIEW}
							termsName="offerAcceptFullTCs"
							termsClassName="terms-and-conditions-checkbox"
							termsCheckboContentKey="csshISAAcceptDecleration"
							termsDataAnchor="offer-accept-full-tcs"
							position="bottom"
							product={{
								...product,
								mandateItems: product.offerMandateItems,
							}}
							title={this.props.content.cashISAOfferDeclarationTitle}
							subTitle={this.props.content.cashISAOfferDeclarationSubTitle}
							additionalDeclarationsTitle={this.props.content.additionalDeclarationsTitle}
							{...this.props}
						/>
					</CollapsibleSection>
				}

				<h4>{this.props.content.reviewTermsDocumentsTitle}</h4>
				{this.getDocumentSection()}

				<MandateSection
					position="top"
					product={{
						mandateItems: product.mandateItems,
					}}
					{...this.props}
				/>
			</div>
		);
	},
});

module.exports = ImportantInfoSection;
