/**
 * @module CreditCardAccountReviewSection
 */

const React = require('react');
const { PropTypes } = React;

const AccountOpeningConstants = require('../../../constants/AccountOpeningConstants');

const ReviewSection = require('./ReviewSection');
const GeneralReviewSection = require('./GeneralReviewSection');
const DirectDebitReviewSection = require('./DirectDebitReviewSection');
const MarketingPrefSection = require('./MarketingPrefSection');
const { formatSortCode } = require('../../../utils/NumberUtils');

const UsernameDetailsComponent = require('../findDetails/UsernameDetailsComponent');

const CreditCardAccountReviewSection = props => {
	const bankInfo = props.data.useBankDetails === 'Yes' ? props.bankDetails.main : props.bankDetails.directDebit;

	const income1 = [{
		label: props.content.reviewLabelgrossAnnualIncome,
		value: props.data.grossAnnualIncome,
	}, {
		label: props.content.reviewLabelRevisedGrossAnnualIncome,
		value: props.data.revisedGrossAnnualIncome,
	}];

	const income2 = [{
		label: props.content.reviewLabelnetMonthlyIncome,
		value: props.data.netMonthlyIncome,
	}, {
		label: props.content.reviewLabelRevisedNetMonthlyIncome,
		value: props.data.revisedNetMonthlyIncome,
	}];

	const outgoings1 = [{
		label: props.content.reviewLabelmortgageOrRentExpenditure,
		value: props.data.mortgageOrRentExpenditure,
	}, {
		label: props.content.reviewLabelRevisedMortgageOrRentExpenditure,
		value: props.data.revisedMortgageOrRentExpenditure,
	}];

	const outgoings2 = [{
		label: props.content.reviewLabelexpenditureOther,
		value: props.data.expenditureOther,
	}, {
		label: props.content.reviewLabelRevisedExpenditureOther,
		value: props.data.revisedExpenditureOther,
	}];

	const mainBank1 = [{
		label: props.content.reviewLabelMainBankAcNo,
		value: props.data.bankDetailsAccountNumber,
	}, {
		label: props.content.reviewLabelMainBankSortCode,
		value: props.data.bankDetailsSortCode,
	}];

	const mainBank2 = [{
		label: props.content.reviewLabelMainBankLengthAtBank,
		value: `${props.data.lengthOfTimeBankYears} ${props.data.lengthOfTimeBankMonths}`,
	}, {
		label: props.content.reviewLabelMainBankPaymentDate,
		value: props.data.paymentDate,
	}];

	return (
		<div>
			<GeneralReviewSection {...props} citizenshipOnly />
			<ReviewSection
				onEditLinkClick={props.onEditLinkClick}
				data={{
					title: props.content.reviewLabelsectionIncome,
					leftContent: income1,
					rightContent: income2,
					editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-INCOME',
				}}
			/>

			<ReviewSection
				onEditLinkClick={props.onEditLinkClick}
				data={{
					title: props.content.reviewLabelsectionOutgoings,
					leftContent: outgoings1,
					rightContent: outgoings2,
					editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-OUTGOINGS',
				}}
			/>

			<ReviewSection
				onEditLinkClick={props.onEditLinkClick}
				data={{
					title: props.content.reviewLabelsectionBankDetails,
					leftContent: mainBank1,
					rightContent: mainBank2,
					editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-BANK-DETAILS',
				}}
			/>

			{bankInfo && <ReviewSection
				onEditLinkClick={props.onEditLinkClick}
				data={{
					title: props.content.reviewLabelsectionDirectDebit,
					editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-DIRECT-DEBIT',
				}}
			>
				<DirectDebitReviewSection
					bankItems={[{
						title: props.content.reviewLabelDDName,
						value: props.data.directDebitAccountName,
					}, {
						title: props.content.reviewLabelDDAccountNo,
						value: bankInfo.accountNumber,
					}, {
						title: props.content.reviewLabelDSortCode,
						value: formatSortCode(bankInfo.sortCode),
					}, {
						title: props.content.reviewLabelDDBankName,
						value: bankInfo.bank.name,
					}, {
						title: props.content.reviewLabelDDBankAddress,
						value: bankInfo.bank.address.addressLine1,
					}, {
						title: props.content.reviewLabelDDBankPostCode,
						value: bankInfo.bank.address.postalCode,
					}]}
					{...props}
				/>

			</ReviewSection>}
			<MarketingPrefSection
				group={props.group}
				onContactMethodsChange={props.onContactMethodsChange}
				{...props}
			/>
			<UsernameDetailsComponent
				group={AccountOpeningConstants.GROUP_REVIEW}
				{...props}
			/>
		</div>
	);
};

CreditCardAccountReviewSection.propTypes = {
	data: PropTypes.object.isRequired,
	bankDetails: PropTypes.object.isRequired,
	content: PropTypes.object.isRequired,
	onEditLinkClick: PropTypes.func.isRequired,
	group: PropTypes.string.isRequired,
	onContactMethodsChange: PropTypes.func.isRequired,
};

module.exports = CreditCardAccountReviewSection;
