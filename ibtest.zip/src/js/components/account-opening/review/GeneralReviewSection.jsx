/**
 * @module GeneralReviewSection
 */

const React = require('react');
const _ = require('lodash');
const { PropTypes } = React;

const config = require('../../../config');

const ArrayUtils = require('../../../utils/ArrayUtils');
const CountryUtils = require('../../../utils/CountryUtils');

const ReviewSection = require('./ReviewSection');

const GeneralReviewSection = props => {
	const personalDetails1 = [
		{ label: props.content.reviewLabeltitle, value: props.data.title, formatting: 'capitalize' },
		{ label: props.content.reviewLabelfirstName, value: props.data.firstName, formatting: 'capitalize' },
		{ label: props.content.reviewLabelmiddleName, value: props.data.middleName, formatting: 'capitalize', hidden: props.data.hasMiddleName === 'No' },
		{ label: props.content.reviewLabellastName, value: props.data.lastName, formatting: 'capitalize' },
		{ label: props.content.reviewLabeldateOfBirth, value: props.data.dateOfBirth },
		{ label: props.content.reviewLabelgender, value: props.data.gender, formatting: 'capitalize' },
		{ label: props.content.reviewLabelmaritalStatus, value: ArrayUtils.getDropdownLabelFromValue(props.data.maritalStatus, config.formOptionsMaritalStatus) },
		{ label: props.content.reviewLabeldependants, value: (props.data.dependants) ? props.data.dependants : '0' },
	];

	const personalDetails2 = [
		{ label: props.content.reviewLabeladdresses, value: props.data.addresses ? CountryUtils.getAddressString(props.data.addresses[0]) : '' },
		{ label: props.content.reviewLabelresidentialStatus, value: props.data.addresses ? ArrayUtils.getDropdownLabelFromValue(props.data.residentialStatus, config.formOptionsResidentialStatus) : '' },
		{ label: props.content.reviewLabeldateMoved, value: props.data.addresses ? props.data.addresses[0].dateMoved : '' },
	];

	_.transform(_.tail(props.data.addresses), (result, address) => {
		result.push(
			{ label: props.content.reviewLabelPreviousaddresses, value: CountryUtils.getAddressString(address) },
			{ label: props.content.reviewLabeldateMoved, value: address.dateMoved }
		);
	}, personalDetails2);

	const contactDetails1 = [
		{ label: props.content.reviewLabelemailAddress, value: props.data.emailAddress, formatting: 'lowercase' },
		{ label: props.content.reviewLabelpreferredContactMethod, value: ArrayUtils.getDropdownLabelFromValue(props.data.preferredContactMethod, config.formOptionsPreferredContactMethod) },
	];

	const contactDetails2 = [
		{ label: props.content.reviewLabelphoneNumber, value: props.formatPhoneNumber(props.data.phoneNumber) },
	];

	let nationality1 = [
		{ label: props.content.reviewLabelnationality, value: CountryUtils.getNationalityFromName(props.data.nationality), formatting: 'capitalize' },
		{ label: props.content.reviewLabelcountryBorn, value: props.data.countryBorn, formatting: 'capitalize' },
		{ label: props.content.reviewLabelcityBorn, value: props.data.cityBorn, formatting: 'capitalize' },
		{ label: props.content.reviewLabelukCitizen, value: props.data.ukCitizen, formatting: 'capitalize' },
	];

	const citizenships = (props.data.citizenshipList && props.data.citizenshipList.length) ? ArrayUtils.getCommaString(props.data.citizenshipList) : 'No';

	let nationality2 = [
		{ label: props.content.reviewLabelcitizenshipList, value: citizenships, formatting: 'capitalize' },
		{ label: props.content.reviewLabeltaxObligations, value: props.getTaxObligations(props.data.hasNoTaxOligations, props.data.taxObligationList), formatting: 'capitalize' },
		{ label: props.content.reviewLabelallTaxObligationsListed, value: 'Yes' },
	];

	const employment1 = [
		{ label: props.content.reviewLabelemploymentStatus, value: ArrayUtils.getDropdownLabelFromValue(props.data.employmentStatus, config.formOptionsEmploymentStatus) },
		{ label: props.content.reviewLabelemploymentOccupation, value: ArrayUtils.getDropdownLabelFromValue(props.data.employmentOccupation, config.formOptionsOccupation) },
	];

	const employment2 = [
		{ label: props.content.reviewLabelemployerName, value: props.data.employerName, formatting: 'capitalize' },
		{ label: props.content.reviewLabelemploymentStartDate, value: props.data.employmentStartDate },
	];

	if (props.citizenshipOnly) {
		nationality1 = [
			{ label: props.content.reviewLabelukCitizen, value: props.data.ukCitizen, formatting: 'capitalize' },
			{ label: props.content.reviewLabelAdditionalCitizenship, value: props.data.hasAdditionalCitizenships },
		];

		nationality2 = [
			{ label: props.content.reviewLabelcitizenshipList, value: citizenships, formatting: 'capitalize' },
		];
	}

	return (
		<div>
			<h2 className="icon-header personal-details">Personal details</h2>
			<ReviewSection
				onEditLinkClick={props.onEditLinkClick}
				data={{
					title: props.content.reviewLabelsectionPersonalDetails,
					leftContent: personalDetails1,
					rightContent: personalDetails2,
					editLinkTaskId: 'WEB-PERSONAL-DETAILS-PERSONAL',
				}}
			/>

			<ReviewSection
				onEditLinkClick={props.onEditLinkClick}
				data={{
					title: props.content.reviewLabelsectionContactDetails,
					leftContent: contactDetails1,
					rightContent: contactDetails2,
					editLinkTaskId: 'WEB-PERSONAL-DETAILS-CONTACT',
				}}
			/>

			{props.data.additionalCardHolder && <ReviewSection
				onEditLinkClick={props.onEditLinkClick}
				data={{
					title: props.content.reviewLabelsectionCardDetails,
					leftContent: [
						{
							label: props.content.reviewLabelAdditionalCard,
							value: props.data.additionalCardHolder,
						},
					],

					editLinkTaskId: 'WEB-PERSONAL-DETAILS-CARDS',
				}}
			/>}

			<ReviewSection
				onEditLinkClick={props.onEditLinkClick}
				data={{
					title: props.content.reviewLabelsectionNationality,
					leftContent: nationality1,
					rightContent: nationality2,
					editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-NATIONALITY',
				}}
			/>

			<h2 className="icon-header employment-details">Employment details</h2>

			<ReviewSection
				onEditLinkClick={props.onEditLinkClick}
				data={{
					title: props.content.reviewLabelsectionEmployment,
					leftContent: employment1,
					rightContent: employment2,
					editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-EMPLOYMENT',
				}}
			/>


		</div>
	);
};

GeneralReviewSection.propTypes = {
	data: PropTypes.object.isRequired,
	content: PropTypes.object.isRequired,
	onEditLinkClick: PropTypes.func.isRequired,
	formatPhoneNumber: PropTypes.func.isRequired,
	getTaxObligations: PropTypes.func.isRequired,
	citizenshipOnly: PropTypes.bool,

};

module.exports = GeneralReviewSection;
