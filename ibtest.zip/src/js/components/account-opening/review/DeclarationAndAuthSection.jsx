/**
 * @module DeclarationAndAuth
 */

const React = require('react');
const _ = require('lodash');
const { PropTypes } = React;

const CheckBoxQuestion = require('../../common/questionsets/CheckBoxQuestion');

const requiresDeclaration = props => {
	return props.data.product.productType.name === 'credit-card';
};

const DeclarationAndAuth = props => {
	if (!requiresDeclaration(props)) {
		return null;
	}

	return (
		<div className="review-section form-spacing">
			<h2 className="icon-header declaration-header">{props.content.declarationAndAuthTitle}</h2>

			<CheckBoxQuestion
				defaultValue={!!props.defaultValue}
				group={props.group}
				name={props.name}
				dataAnchor={props.name}
				onChange={props.onChange}
				required
			>
				{props.content.declarationAndAuthText}
			</CheckBoxQuestion>

			{props.data.product.declarationAndAuthBullets &&
				<ul>
					{_.map(
						props.data.product.declarationAndAuthBullets,
						key => (<li key={key}>{props.content[key]}</li>)
					)}
				</ul>
			}
		</div>
	);
};

DeclarationAndAuth.propTypes = {
	data: PropTypes.object.isRequired,
	content: PropTypes.object.isRequired,
	onChange: PropTypes.func.isRequired,
	name: PropTypes.string.isRequired,
	group: PropTypes.string.isRequired,
	defaultValue: PropTypes.string,
};

module.exports = DeclarationAndAuth;
