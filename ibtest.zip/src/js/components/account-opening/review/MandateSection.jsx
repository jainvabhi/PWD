/**
 * @module MandateSection
 */

const React = require('react');
const { PropTypes } = React;
const _ = require('lodash');

const CheckBoxQuestion = require('../../common/questionsets/CheckBoxQuestion');

const OfferHOC = require('../offer/OfferHOC');

const CheckBox = props => (
	<span>
		<CheckBoxQuestion
			defaultValue={!!props.defaultValue}
			group={props.group}
			name={props.name}
			dataAnchor={props.dataAnchor}
			onChange={props.onChange}
			required
		>
			{props.content[props.checkboxContentKey] && props.content[props.checkboxContentKey]}
		</CheckBoxQuestion>
	</span>
);

CheckBox.propTypes = {
	defaultValue: PropTypes.node,
	group: PropTypes.string,
	name: PropTypes.string.isRequired,
	dataAnchor: PropTypes.string,
	onChange: PropTypes.func.isRequired,
	content: PropTypes.object.isRequired,
	checkboxContentKey: PropTypes.string,
};

const GenericMandateItems = OfferHOC(props => (

	<div className={props.className}>
		{props.intro && props.intro}

		{props.position !== 'bottom' && <CheckBox {...props} />}
		{props.title && <h2>{props.title}</h2>}
		{props.subTitle && <h3>{props.subTitle}</h3>}
		<ul>
			{props.getMandateElements(props.mandateItems)}
		</ul>

		{props.legaleseOfferItem && <ul className="list-unstyled legalese-offer-item">{props.getMandateElements(props.legaleseOfferItem)}</ul>}

		{props.additionalMandateItems && <ul>{props.getMandateElements(props.additionalMandateItems)}</ul>}

		{props.additionalDeclarationsTitle && <h3>{props.additionalDeclarationsTitle}</h3>}

		{props.additionalDeclarations && <ul>{props.getMandateElements(props.additionalDeclarations)}</ul>}

		{props.offerMandateFootNotes && _.map(props.offerMandateFootNotes, (key, ndx) => {return <p key={ndx}>{props.content[key]}</p>;})}

		{props.footer && props.footer}

		{props.position === 'bottom' && <CheckBox {...props} />}

	</div>
));

GenericMandateItems.propTypes = {
	className: PropTypes.string,
	intro: PropTypes.node,
	footer: PropTypes.node,
	getMandateElements: PropTypes.func.isRequired,
	mandateItems: PropTypes.array,
	position: PropTypes.string,
	title: PropTypes.string,
	subTitle: PropTypes.string,
	additionalDeclarationsTitle: PropTypes.string,
	defaultValue: PropTypes.bool,
};

GenericMandateItems.defaultProps = {
	getMandateElements: () => {},
};

const isJoint = props => {
	const { data: { product, subType } } = props;
	return subType === 'JOINT' && product.additionalMandateItems && product.additionalMandateItems.joint;
};

const isCashISA = props => {
	const { data: { product } } = props;
	return product.productType.name === 'cashISA';
};

const MandateSection = React.createClass({
	propTypes: {
		data: PropTypes.object.isRequired,
		content: PropTypes.object.isRequired,
		onReviewAcceptTCs: PropTypes.func.isRequired,
		applyingFor: PropTypes.node,
		group: PropTypes.string,
		termsName: PropTypes.string,
		termsClassName: PropTypes.string,
		termsCheckboContentKey: PropTypes.string,
		termsDataAnchor: PropTypes.string,
		termsPosition: PropTypes.string,
		acceptTsAndCs: PropTypes.bool,
		product: PropTypes.shape({
			mandateItems: PropTypes.array,
			additionalMandateItems: PropTypes.object,
			additionalDeclarations: PropTypes.array,
			offerMandateFootNotes: PropTypes.array,
			legaleseOfferItem: PropTypes.array,
		}),
		title: PropTypes.string,
		subTitle: PropTypes.string,
		additionalDeclarationsTitle: PropTypes.string,
		position: PropTypes.string.isRequired,
		offer: PropTypes.object,
	},

	getDefaultProps() {
		return {
			termsName: 'reviewAcceptTsAndCs',
			termsClassName: 'review-accept-ts-and-cs',
			termsCheckboContentKey: 'reviewAcceptTsAndCs',
			termsDataAnchor: 'review-terms-and-conditions',
			termsPosition: 'top',
		};
	},

	render() {
		const { data: { product } } = this.props;

		let mandateItems = product.mandateItems;
		if (!_.isUndefined(this.props.data.productCode) && this.props.data.productCode === 'IM136' && !_.isUndefined(this.props.offer) && this.props.offer.product.code === '800') {
			mandateItems = product.offerMandateItemsB;
		}
		return (
			<div>
				{!isCashISA(this.props) && <GenericMandateItems
					data={this.props.data}
					name={this.props.termsName}
					className={this.props.termsClassName}
					dataAnchor={this.props.termsDataAnchor}
					checkboxContentKey={this.props.termsCheckboContentKey}
					position={this.props.termsPosition}
					mandateItems={mandateItems}
					content={this.props.content}
					group={this.props.group}
					defaultValue={this.props.acceptTsAndCs}
					onChange={this.props.onReviewAcceptTCs}
					footer={this.props.applyingFor && (<p>{this.props.content.reviewTermsDocumentsParagraph} {this.props.applyingFor}.</p>)}
				/>}

				{isCashISA(this.props) && <GenericMandateItems
					data={this.props.data}
					name={this.props.termsName}
					className={this.props.termsClassName}
					dataAnchor={this.props.termsDataAnchor}
					checkboxContentKey={this.props.termsCheckboContentKey}
					position={this.props.position}
					title={this.props.title}
					subTitle={this.props.subTitle}
					additionalDeclarationsTitle={this.props.additionalDeclarationsTitle}
					mandateItems={this.props.product.mandateItems}
					additionalMandateItems={this.props.product.additionalMandateItems}
					additionalDeclarations={this.props.product.additionalDeclarations}
					offerMandateFootNotes={this.props.product.offerMandateFootNotes}
					legaleseOfferItem={product.legaleseOfferItem}
					content={this.props.content}
					group={this.props.group}
					defaultValue={this.props.acceptTsAndCs}
					onChange={this.props.onReviewAcceptTCs}
					footer={this.props.applyingFor && (<p>{this.props.content.reviewTermsDocumentsParagraph} {this.props.applyingFor}.</p>)}
				/>}

				{isJoint(this.props) && <GenericMandateItems
					data={this.props.data}
					name={product.additionalMandateItems.joint.key}
					dataAnchor={product.additionalMandateItems.joint.key}
					checkboxContentKey={product.additionalMandateItems.joint.key}
					intro={this.props.content[`${product.additionalMandateItems.joint.key}Intro`] && (<p>{this.props.content[`${product.additionalMandateItems.joint.key}Intro`]}</p>)}
					footer={this.props.content[`${product.additionalMandateItems.joint.key}Footer`] && (<p>{this.props.content[`${product.additionalMandateItems.joint.key}Footer`]}</p>)}
					position="bottom"
					mandateItems={product.additionalMandateItems.joint.items}
					content={this.props.content}
					group={this.props.group}
					defaultValue={this.props.data[product.additionalMandateItems.joint.key]}
					onChange={this.props.onReviewAcceptTCs}
				/>}
			</div>
		);
	},
});

module.exports = MandateSection;
module.exports.CheckBox = CheckBox;
module.exports.GenericMandateItems = GenericMandateItems;
