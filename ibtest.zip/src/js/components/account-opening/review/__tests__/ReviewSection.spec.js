jest.unmock('../ReviewSection');
jest.unmock('../../../../config');

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const _ = require('lodash');
const Link = require('react-router').Link;
const { buildContent } = require('../../../../__helpers__/TestHelpers');

const ReviewSection = require('../ReviewSection');
const BrandUtils = require('../../../../utils/BrandUtils');

const shallowRender = props => {
	const shallowRenderer = TestUtils.createRenderer();
	shallowRenderer.render(
		<ReviewSection {...props} />
	);
	return shallowRenderer.getRenderOutput();
};

global.envConfig.websiteBaseDirectory = 'test/'

describe('ReviewSection', () => {
	let instance;
	let result;

	let content = buildContent([
		'reviewLabelgrossAnnualIncome',
		'reviewLabelnetMonthlyIncome',
		'reviewLabelincomeOtherAmount',
		'reviewLabelincomeOtherPaymentAmount',
	]);

	let data = {
		grossAnnualIncome: 100,
		netMonthlyIncome: 100,
		incomeOtherAmount: 100,
		incomeOtherFrequencyOptions: 'incomeOtherFrequencyOptions',
		incomeOtherAccountPurpose: 'incomeOtherAccountPurpose',
		incomeOtherPaymentTypeOptions: 'incomeOtherPaymentTypeOptions',
		incomeOtherPaymentAmount: 100,
		incomeOtherSavingsAmount: 100,
		incomeOtherSavingsFrequency: 'incomeOtherSavingsFrequency',
		mortgageOrRentExpenditure: 100,
		expenditureOther: 100,
		title: 'test',
		leftContent: [
			{label: 'reviewLabelgrossAnnualIncome', value: '100', formatting: 'capitalize'},
			{label: 'reviewLabelnetMonthlyIncome', value: 100},
		],
		rightContent: [
			{label: 'reviewLabelincomeOtherAmount', value: '100 - test', formatting: 'capitalize'},
			{label: 'reviewLabelincomeOtherPaymentAmount', value: 100},
			{label: 'reviewLabelincomeOtherPaymentAmount', value: true}
		],
	};

	describe('review-flat', () => {
		beforeEach(() => {
			BrandUtils.isAbleToDisplay.mockImplementation(key => key === 'review-flat');
			result = shallowRender({
				content,
				data,
				onEditLinkClick: () => {}
			})
		});

		it('should render correctly', () => {
			expect(result).toEqualJSX(
				<div className="review-section">
					<div className="row">
						<h4 className="indented">
							test
							<Link
								aria-label="Edit test"
								className="edit-link"
								data-task-id={undefined}
								onClick={() => {}}
								to="test/account-opening"
							>
								Edit
							</Link>
						</h4>
						<div className="col-xs-12 col-md-6">
							<div className="row review-row">
								<div className="col-xs-5 col-sm-5 review-row-left-col">
									reviewLabelgrossAnnualIncome
								</div>
								<div className="col-xs-2 col-sm-1 u-center">
									-
								</div>
								<div className="col-xs-5 col-sm-5 review-row-right-col">
									<span>100</span>
								</div>

							</div>
							<div className="row review-row">
								<div className="col-xs-5 col-sm-5 review-row-left-col">
									reviewLabelnetMonthlyIncome
								</div>

								<div className="col-xs-2 col-sm-1 u-center">
									-
								</div>
								<div className="col-xs-5 col-sm-5 review-row-right-col">
									<span>100</span>
								</div>

							</div>

						</div>
						<div className="col-xs-12 col-md-6">
							<div className="row review-row">
								<div className="col-xs-5 col-sm-5 review-row-left-col">
									reviewLabelincomeOtherAmount
								</div>

								<div className="col-xs-2 col-sm-1 u-center">
									-
								</div>

								<div className="col-xs-5 col-sm-5 review-row-right-col">
									<span>100 - test</span>
								</div>

							</div>

							<div className="row review-row">
								<div className="col-xs-5 col-sm-5 review-row-left-col">
									reviewLabelincomeOtherPaymentAmount
								</div>
								<div className="col-xs-2 col-sm-1 u-center">
									-
								</div>
								<div className="col-xs-5 col-sm-5 review-row-right-col">
									<span>100</span>
								</div>
							</div>
							<div className="row review-row">
								<div className="col-xs-5 col-sm-5 review-row-left-col">
									reviewLabelincomeOtherPaymentAmount
								</div>
								<div className="col-xs-2 col-sm-1 u-center">
									-
								</div>
								<div className="col-xs-5 col-sm-5 review-row-right-col" />
							</div>
						</div>
					</div>
				</div>
			);
		});

	});

	describe('review-paper', () => {
		beforeEach(() => {
			BrandUtils.isAbleToDisplay.mockImplementation(key => key === 'review-paper');
			result = shallowRender({
				content,
				data,
				onEditLinkClick: () => {}
			})
		});

		it('should render correctly', () => {
			expect(result).toEqualJSX(
				<div className="review-section">
					<div className="row">
						<h4 className="indented">
							test
							<Link
								aria-label="Edit test"
								className="edit-link"
								data-task-id={undefined}
								onClick={() => {}}
								to="test/account-opening"
							>
								Edit
							</Link>
						</h4>
						<div className="col-xs-12 col-md-12 first-row">
							<div className="row review-row">
								<div className="col-xs-5 review-row-left-col">
									reviewLabelgrossAnnualIncome
								</div>
								<div className="col-xs-7 review-row-right-col">
									<span className="u-text-capitalize">100</span>
								</div>

							</div>
							<div className="row review-row">
								<div className="col-xs-5 review-row-left-col">
									reviewLabelnetMonthlyIncome
								</div>

								<div className="col-xs-7 review-row-right-col">
									100
								</div>


							</div>

						</div>
						<div className="col-xs-12 col-md-12">
							<div className="row review-row">
								<div className="col-xs-5 review-row-left-col">
									reviewLabelincomeOtherAmount
								</div>
								<div className="col-xs-7 review-row-right-col">
									<span className="u-text-capitalize">
										100 - test
									</span>
								</div>

							</div>

							<div className="row review-row">
								<div className="col-xs-5 review-row-left-col">
									reviewLabelincomeOtherPaymentAmount
								</div>
								<div className="col-xs-7 review-row-right-col">
									100
								</div>

							</div>
							<div className="row review-row">
								<div className="col-xs-5 review-row-left-col">
									reviewLabelincomeOtherPaymentAmount
								</div>
								<div className="col-xs-7 review-row-right-col" />
							</div>
						</div>
					</div>
				</div>
			);
		});

	});


	describe('sub section should have title', () => {
		beforeEach(() => {
			BrandUtils.isAbleToDisplay.mockImplementation(key => key === 'review-paper');


			result = shallowRender({
				content,
				data: _.extend(data, {
					isSubSection: true
				}),
				onEditLinkClick: () => {}
			})
		});

		it('should render correctly', () => {
			expect(result).toIncludeJSX(
				<h5 className="indented">test</h5>
			);
		});

	});
});


