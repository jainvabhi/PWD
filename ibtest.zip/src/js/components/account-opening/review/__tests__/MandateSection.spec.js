jest.unmock('../MandateSection');
jest.unmock('../../offer/OfferHOC');

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const _ = require('lodash');

const { buildContent } = require('../../../../__helpers__/TestHelpers');

const ReviewSection = require('../ReviewSection');
const BrandUtils = require('../../../../utils/BrandUtils');

const MandateSection = require('../MandateSection');
const { SoloStandardTermsAndConditions, GenericMandateItems } = MandateSection;
const CheckBoxQuestion = require('../../../common/questionsets/CheckBoxQuestion');

const shallowRender = props => {
	const shallowRenderer = TestUtils.createRenderer();
	shallowRenderer.render(
		<MandateSection
			{...props}
		/>
	);
	return shallowRenderer.getRenderOutput();
};

describe('MandateSection', () => {
	let instance;
	let result;

	describe('SOLO', () => {
		let content = buildContent([
			'mandate1',
			'reviewTermsDocumentsParagraph',
		]);
		let product = {
			additionalMandateItems: {
				joint: { items: ['joint'], key: 'jointAcceptTsAndCs', remove: true },
			},
			mandateItems: ['mandate1'],
			productType: {
				name: '',
			},
		};
		let data = {
			product,
			products: {
				code: 12121
			},
		};
		let props = {
			applyingFor: (<div>applyingFor</div>),
			content,
			data,
			group: 'REVIEW',
			onReviewAcceptTCs: () => {},
			position: 'botttom',
			product,
		};

		beforeEach(() => {
			result = shallowRender(props);
		});

		it('should render correctly', () => {
			expect(result).toEqualJSX(<div>
				<GenericMandateItems
					name="reviewAcceptTsAndCs"
					group="REVIEW"
					position="top"
					className="review-accept-ts-and-cs"
					defaultValue={undefined}
					checkboxContentKey="reviewAcceptTsAndCs"
					dataAnchor="review-terms-and-conditions"
					content={content}
					footer={(<p>reviewTermsDocumentsParagraph <div>applyingFor</div>.</p>)}
					mandateItems={product.mandateItems}
					onChange={function noRefCheck() {}}
					data={data}
				/>
			</div>);
		});
	});

	describe('JOINT', () => {
		let content = buildContent([
			'jointAcceptTsAndCs',
			'jointAcceptTsAndCsFooter',
			'jointAcceptTsAndCsIntro',
			'jointMandate',
			'mandate1',
			'reviewTermsDocumentsParagraph',
		]);
		let product = {
			additionalMandateItems: {
				joint: { items: ['jointMandate'], key: 'jointAcceptTsAndCs', remove: true },
			},
			mandateItems: ['mandate1'],
			productType: {
				name: '',
			},
		};
		let data = {
			product,
			subType: 'JOINT',
			products: {
				code: 12121
			},
		};
		let props = {
			applyingFor: (<div>applyingFor</div>),
			content,
			data,
			group: 'REVIEW',
			onReviewAcceptTCs: () => {},
			position:"top",
			product,
		};

		beforeEach(() => {
			result = shallowRender(props);
		});

		it('should render correctly', () => {
			expect(result).toEqualJSX(
				<div>
					<GenericMandateItems
						name="reviewAcceptTsAndCs"
						group="REVIEW"
						position="top"
						className="review-accept-ts-and-cs"
						defaultValue={undefined}
						checkboxContentKey="reviewAcceptTsAndCs"
						dataAnchor="review-terms-and-conditions"
						content={content}
						footer={(<p>reviewTermsDocumentsParagraph <div>applyingFor</div>.</p>)}
						mandateItems={product.mandateItems}
						onChange={function noRefCheck() {}}
						data={data}
					/>
					<GenericMandateItems
						name="jointAcceptTsAndCs"
						group="REVIEW"
						position="bottom"
						defaultValue={undefined}
						checkboxContentKey="jointAcceptTsAndCs"
						dataAnchor="jointAcceptTsAndCs"
						footer={<p>jointAcceptTsAndCsFooter</p>}
						intro={<p>jointAcceptTsAndCsIntro</p>}
						content={content}
						mandateItems={product.additionalMandateItems.joint.items}
						onChange={function noRefCheck() {}}
						data={data}
					/>
				</div>
			);
		});
	});
});
