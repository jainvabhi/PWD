jest.autoMockOff();

const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');
const _ = require('lodash');
const Link = require('react-router').Link;
const { buildContent } = require('../../../../__helpers__/TestHelpers');

let instance;

const ImportantInfoSection = require('../ImportantInfoSection');
const { DocumentLink } = require('../../../common/links/DocumentLink');
const MandateSection = require('../MandateSection');

const shallowRender = props => {
	const shallowRenderer = TestUtils.createRenderer();
	instance = ReactDOM.render(
		<ImportantInfoSection {...props} />,
		document.createElement('div')
	);
	shallowRenderer.render(<ImportantInfoSection {...props} />);
	return shallowRenderer.getRenderOutput();
};

const cms = {
	documentList: [
		{
			brand: 'YB',
			webReference: 'dataProtection',
			docReference: 'dataProtection.pdf',
			docLinkText: 'Tariff details',
			docLinkTitle:
				'Download Tariff Details PDF. This link will open in a new browser window.',
			docVersion: '0417',
			fileName: 'dataProtection.pdf',
			docAttachmentName:
				'YB Current Account Tariff for personal customers.pdf',
			bank: 'YB',
			contentType: 'PDF',
			reason: 'DOCUMENTATION',
		},
		{
			brand: 'YB',
			webReference: 'termsAndConditions',
			docReference: 'termsAndConditions.pdf',
			docLinkText: 'Tariff details',
			docLinkTitle:
				'Download Tariff Details PDF. This link will open in a new browser window.',
			docVersion: '0417',
			fileName: 'termsAndConditions.pdf',
			docAttachmentName:
				'YB Current Account Tariff for personal customers.pdf',
			bank: 'YB',
			contentType: 'PDF',
			reason: 'DOCUMENTATION',
		},
		{
			brand: 'YB',
			webReference: 'currentTariff',
			docReference: 'current-account-tariff.pdf',
			docLinkText: 'Tariff details',
			docLinkTitle:
				'Download Tariff Details PDF. This link will open in a new browser window.',
			docVersion: '0417',
			fileName: 'current-account-tariff.pdf',
			docAttachmentName:
				'YB Current Account Tariff for personal customers.pdf',
			bank: 'YB',
			contentType: 'PDF',
			reason: 'DOCUMENTATION',
		},
		{
			brand: 'YB',
			webReference: 'financialServicesCompensationScheme',
			docReference: 'financialServicesCompensationScheme.pdf',
			docLinkText: 'Tariff details',
			docLinkTitle:
				'Download Tariff Details PDF. This link will open in a new browser window.',
			docVersion: '0417',
			fileName: 'financialServicesCompensationScheme.pdf',
			docAttachmentName:
				'YB Current Account Tariff for personal customers.pdf',
			bank: 'YB',
			contentType: 'PDF',
			reason: 'DOCUMENTATION',
		},
	],
};

let content = buildContent([
	'financialServicesCompensationSchemeDocLink',
	'financialServicesCompensationSchemeDocLinkText',
	'financialServicesCompensationSchemeDocLinkTitle',
	'financialServicesCompensationSchemeDocVersion',
	'reviewAcceptTsAndCs',
	'reviewImportantInformationTitle',
	'reviewKeyFeaturesTitle',
	'reviewOfferRestrictionsTitle',
	'reviewTermsDocumentsParagraph',
	'reviewTermsDocumentsTitle',
	'tariffDocLink',
	'tariffDocLinkText',
	'tariffDocLinkTitle',
	'tariffDocVersion',
	'termsAndConditionsDocLink',
	'termsAndConditionsDocLinkText',
	'termsAndConditionsDocLinkTitle',
	'termsAndConditionsDocVersion',
	'test1',
	'test2',
	'test3',
	'test4',
	'test5',
	'test6',
]);

describe('ImportantInfoSection', () => {
	let result;
	let product = {
		additionalDocumentItems: [
			'currentTariff',
			'financialServicesCompensationScheme',
			'termsAndConditions',
		],
		description: 'test',
		keyFeatureItems: ['test1', 'test2'],
		mandateItems: ['test1', 'test2'],
		offerRestrictions: ['test5', 'test5'],
		productType: {
			name: 'current',
		},
	};
	let data = {
		product,
		products: {
			code: 12121
		},
	};
	const offers = {
		"offers": [
	      {
	        "product": {
	          "code": "800",
	          "name": "CURRENT ACCOUNT",
	          "description": "",
	          "variant": null
	        },
	        "documents": [],
	        "features": {
	          "credit_limit": null
	        }
	      }
	    ]
	};
	let props = {
		applyingFor: <a>test</a>,
		cms,
		content,
		data,
		offers,
		envConfig: {
			bankId: 'YB',
		},
		getMandateElements: () => {},
		group: 'test',
		onProductTermsPDFClick: () => {},
		onReviewAcceptTCs: () => {},
		product,
	};

	beforeEach(() => {
		result = shallowRender(props);
	});

	describe('render', () => {
		it('should render correctly', () => {
			expect(result).toEqualJSX(
				<div>
					<h2 className="icon-header important-information padding-bottom">
						reviewImportantInformationTitle
					</h2>
					<div className="key-features-section padding-bottom">
						<h3 className="sub-heading h4-style">
							reviewKeyFeaturesTitle <a>test</a>
						</h3>
						<p>test</p>

						<ul>
							<li dangerouslySetInnerHTML={{ __html: 'test1' }} />
							<li dangerouslySetInnerHTML={{ __html: 'test2' }} />
						</ul>

						<div>
							<h4>reviewOfferRestrictionsTitle</h4>
							<ul>
								<li>test5</li>
								<li>test5</li>
							</ul>
						</div>
					</div>

					<h4>reviewTermsDocumentsTitle</h4>
					<ul>
						<li>
							<DocumentLink docKey="currentTariff" {...props} />
						</li>
						<li>
							<DocumentLink
								docKey="financialServicesCompensationScheme"
								{...props}
							/>
						</li>
						<li>
							<DocumentLink docKey="termsAndConditions" {...props} />
						</li>
					</ul>
					<MandateSection
						product={product}
						position="top"
						{...props}
					/>
				</div>
			);
		});
	});

	describe('getKeyFeatureItems', () => {
		it('should render a list of key feature items', () => {
			const productData = {
				keyFeatureItems: ['test1', 'test2'],
			};
			const result = instance.getKeyFeatureItems(productData);
			expect(result.length).toBe(2);
		});

		it('should not render a list of key feature items', () => {
			const productData = {};
			const result = instance.getKeyFeatureItems(productData);
			expect(result.length).toBe(0);
		});
	});

	describe('getOfferRestrictions', () => {
		it('should render a list of offer restrictions', () => {
			const offerRestrictions = ['test1', 'test2'];
			const result = instance.getOfferRestrictions(offerRestrictions, 'title');
			expect(result).not.toBeNull();
		});

		it('should not render a list if offer restrictions is empty', () => {
			const offerRestrictions = [];
			const result = instance.getOfferRestrictions(offerRestrictions, 'title');
			expect(result).toBeNull();
		});

		it('should not render a list if offer restrictions is undefined', () => {
			const result = instance.getOfferRestrictions(undefined, 'title');
			expect(result).toBeNull();
		});
	});

	describe('getAdditionalDocumentItems', () => {
		it('should render a list of additional documents', () => {
			let result = instance.getAdditionalDocumentItems();
			expect(result.length).toBe(3);
		});
		it('should not render a list if additional documents is empty', () => {
			let product = {
				description: 'test',
				keyFeatureItems: ['test1', 'test2'],
				additionalDocumentItems: [],
				offerRestrictions: ['test5', 'test5'],
				productType: {
					name: 'credit-card',
				},
			};
			let noDocProps = {
				...props,
				data: {
					product,
					products: {
						code: 12121
					},
				},
				product,
			};
			instance = ReactDOM.render(
				<ImportantInfoSection {...noDocProps} />,
				document.createElement('div')
			);
			const result = instance.getAdditionalDocumentItems();
			expect(result.length).toBe(0);
		});
	});

	describe('getMandateBulletPoints', () => {
		it('should render a list of mandate items that have keys', () => {
			let result = instance.getMandateBulletPoints(content);
			expect(result.length).toBe(2);
		});
	});
});
