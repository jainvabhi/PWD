jest.unmock('../CurrentAccountReviewSection');
jest.unmock('../ReviewSection');
jest.unmock('../../../../config');

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const _ = require('lodash');

const { buildContent } = require('../../../../__helpers__/TestHelpers');

const ReviewSection = require('../ReviewSection');
const BrandUtils = require('../../../../utils/BrandUtils');

const CurrentAccountReviewSection = require('../CurrentAccountReviewSection');
const GeneralReviewSection = require('../GeneralReviewSection');
const MarketingPrefSection = require('../MarketingPrefSection');
const UsernameDetailsComponent = require('../../findDetails/UsernameDetailsComponent');

const shallowRender = props => {
	const shallowRenderer = TestUtils.createRenderer();
	shallowRenderer.render(<CurrentAccountReviewSection
						   {...props}
						/>);
	return shallowRenderer.getRenderOutput();
};

describe('CurrentAccountReviewSection', () => {
	let instance;
	let result;

	let content = buildContent([
		'reviewLabelgrossAnnualIncome',
		'reviewLabelnetMonthlyIncome',
		'reviewLabelincomeOtherAmount',
		'reviewLabelincomeOtherAccountPurpose',
		'reviewLabelincomeOtherPaymentTypeOptions',
		'reviewLabelincomeOtherPaymentAmount',
		'reviewLabelincomeOtherSavingsAmount',
		'reviewLabelincomeOtherSavingsFrequency',
		'reviewLabelgrossAnnualIncome',
		'reviewLabelsectionOutgoings',
		'reviewLabelmortgageOrRentExpenditure',
		'reviewLabelexpenditureOther',
	]);

	let data = {
		grossAnnualIncome: 100,
		netMonthlyIncome: 100,
		incomeOtherAmount: 100,
		incomeOtherFrequencyOptions: 'incomeOtherFrequencyOptions',
		incomeOtherAccountPurpose: 'incomeOtherAccountPurpose',
		incomeOtherPaymentTypeOptions: 'incomeOtherPaymentTypeOptions',
		incomeOtherPaymentAmount: 100,
		incomeOtherSavingsAmount: 100,
		incomeOtherSavingsFrequency: 'incomeOtherSavingsFrequency',
		mortgageOrRentExpenditure: 100,
		expenditureOther: 100,
		product: {
			supportsOverdraft: false,
		},
	};

	let props = {
		content,
		data,
		onEditLinkClick: () => {},
		group: 'REVIEW',
		onContactMethodsChange: () => {},
	};

	describe('Current', () => {

		beforeEach(() => {
			result = shallowRender(props)
		});

		it('should render correctly', () => {
			expect(result).toEqualJSX(
				<div>
					<GeneralReviewSection {...props} />
					<ReviewSection
						data={{
						editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-INCOME',
						leftContent: [
							{label: 'reviewLabelgrossAnnualIncome', value: 100},
							{label: 'reviewLabelnetMonthlyIncome', value: 100},
							{label: 'reviewLabelincomeOtherAccountPurpose', value: undefined},
							{label: 'reviewLabelincomeOtherPaymentTypeOptions', value: undefined}
						],
						rightContent: [
							{label: 'reviewLabelincomeOtherAmount', value: '100 - undefined'},
							{label: 'reviewLabelincomeOtherPaymentAmount', value: 100}
						], title: undefined}}
						onEditLinkClick={function noRefCheck() {}}
					/>
					<ReviewSection
						data={{
							editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-OUTGOINGS',
							leftContent: [{label: 'reviewLabelmortgageOrRentExpenditure', value: 100}],
							rightContent: [{label: 'reviewLabelexpenditureOther', value: 100}],
							title: 'reviewLabelsectionOutgoings'}}
						onEditLinkClick={function noRefCheck() {}}
					/>
					<MarketingPrefSection
						content={{reviewLabelexpenditureOther: 'reviewLabelexpenditureOther', reviewLabelgrossAnnualIncome: 'reviewLabelgrossAnnualIncome', reviewLabelincomeOtherAccountPurpose: 'reviewLabelincomeOtherAccountPurpose', reviewLabelincomeOtherAmount: 'reviewLabelincomeOtherAmount', reviewLabelincomeOtherPaymentAmount: 'reviewLabelincomeOtherPaymentAmount', reviewLabelincomeOtherPaymentTypeOptions: 'reviewLabelincomeOtherPaymentTypeOptions', reviewLabelincomeOtherSavingsAmount: 'reviewLabelincomeOtherSavingsAmount', reviewLabelincomeOtherSavingsFrequency: 'reviewLabelincomeOtherSavingsFrequency', reviewLabelmortgageOrRentExpenditure: 'reviewLabelmortgageOrRentExpenditure', reviewLabelnetMonthlyIncome: 'reviewLabelnetMonthlyIncome', reviewLabelsectionOutgoings: 'reviewLabelsectionOutgoings'}}
						data={{expenditureOther: 100, grossAnnualIncome: 100, incomeOtherAccountPurpose: 'incomeOtherAccountPurpose', incomeOtherAmount: 100, incomeOtherFrequencyOptions: 'incomeOtherFrequencyOptions', incomeOtherPaymentAmount: 100, incomeOtherPaymentTypeOptions: 'incomeOtherPaymentTypeOptions', incomeOtherSavingsAmount: 100, incomeOtherSavingsFrequency: 'incomeOtherSavingsFrequency', mortgageOrRentExpenditure: 100, netMonthlyIncome: 100, product: { supportsOverdraft: false }}}
						group="REVIEW"
						onContactMethodsChange={function noRefCheck() {}}
						onEditLinkClick={function noRefCheck() {}}
					/>
					<UsernameDetailsComponent
						content={{
							reviewLabelexpenditureOther: 'reviewLabelexpenditureOther',
							reviewLabelgrossAnnualIncome: 'reviewLabelgrossAnnualIncome',
							reviewLabelincomeOtherAccountPurpose: 'reviewLabelincomeOtherAccountPurpose',
							reviewLabelincomeOtherAmount: 'reviewLabelincomeOtherAmount',
							reviewLabelincomeOtherPaymentAmount: 'reviewLabelincomeOtherPaymentAmount',
							reviewLabelincomeOtherPaymentTypeOptions: 'reviewLabelincomeOtherPaymentTypeOptions',
							reviewLabelincomeOtherSavingsAmount: 'reviewLabelincomeOtherSavingsAmount',
							reviewLabelincomeOtherSavingsFrequency: 'reviewLabelincomeOtherSavingsFrequency',
							reviewLabelmortgageOrRentExpenditure: 'reviewLabelmortgageOrRentExpenditure',
							reviewLabelnetMonthlyIncome: 'reviewLabelnetMonthlyIncome',
							reviewLabelsectionOutgoings: 'reviewLabelsectionOutgoings'
						}}
						data={{
							expenditureOther: 100,
							grossAnnualIncome: 100,
							incomeOtherAccountPurpose: 'incomeOtherAccountPurpose',
							incomeOtherAmount: 100,
							incomeOtherFrequencyOptions: 'incomeOtherFrequencyOptions',
							incomeOtherPaymentAmount: 100,
							incomeOtherPaymentTypeOptions: 'incomeOtherPaymentTypeOptions',
							incomeOtherSavingsAmount: 100,
							incomeOtherSavingsFrequency: 'incomeOtherSavingsFrequency',
							mortgageOrRentExpenditure: 100,
							netMonthlyIncome: 100,
							product: {
								supportsOverdraft: false
							}
						}}
						group="REVIEW"
						onContactMethodsChange={function noRefCheck(){}}
						onEditLinkClick={function noRefCheck(){}}
					/>
				</div>
			);
		});

	});

	describe('Current Bundled', () => {
		beforeEach(() => {
			BrandUtils.isAbleToDisplay.mockReturnValue(true);
			result = shallowRender({
				content,
				data,
				onEditLinkClick: () => {},
				group: 'REVIEW',
				onContactMethodsChange: () => {},
			})
		});

		it('should render correctly', () => {
			expect(result).toEqualJSX(
				<div>
					<GeneralReviewSection {...props} />
					<ReviewSection
						data={{editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-INCOME', leftContent: [{label: 'reviewLabelgrossAnnualIncome', value: 100}, {label: 'reviewLabelnetMonthlyIncome', value: 100}], rightContent: [{label: 'reviewLabelincomeOtherAmount', value: '100 - undefined'}], title: undefined}}
						onEditLinkClick={function noRefCheck() {}}
					/>
					<ReviewSection
						data={{isSubSection: true, leftContent: [{label: 'reviewLabelincomeOtherAccountPurpose', value: undefined}, {label: 'reviewLabelincomeOtherPaymentTypeOptions', value: undefined}], rightContent: [{label: 'reviewLabelincomeOtherPaymentAmount', value: 100}], title: undefined}}
						onEditLinkClick={function noRefCheck() {}}
					/>
					<ReviewSection
						data={{isSubSection: true, leftContent: [{label: 'reviewLabelincomeOtherSavingsAmount', value: 100}], rightContent: [{label: 'reviewLabelincomeOtherSavingsFrequency', value: undefined}], title: undefined}}
						onEditLinkClick={function noRefCheck() {}}
					/>
					<ReviewSection
						data={{editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-OUTGOINGS', leftContent: [{label: 'reviewLabelmortgageOrRentExpenditure', value: 100}], rightContent: [{label: 'reviewLabelexpenditureOther', value: 100}], title: 'reviewLabelsectionOutgoings'}}
						onEditLinkClick={function noRefCheck() {}}
					/>
					<MarketingPrefSection
						content={{reviewLabelexpenditureOther: 'reviewLabelexpenditureOther', reviewLabelgrossAnnualIncome: 'reviewLabelgrossAnnualIncome', reviewLabelincomeOtherAccountPurpose: 'reviewLabelincomeOtherAccountPurpose', reviewLabelincomeOtherAmount: 'reviewLabelincomeOtherAmount', reviewLabelincomeOtherPaymentAmount: 'reviewLabelincomeOtherPaymentAmount', reviewLabelincomeOtherPaymentTypeOptions: 'reviewLabelincomeOtherPaymentTypeOptions', reviewLabelincomeOtherSavingsAmount: 'reviewLabelincomeOtherSavingsAmount', reviewLabelincomeOtherSavingsFrequency: 'reviewLabelincomeOtherSavingsFrequency', reviewLabelmortgageOrRentExpenditure: 'reviewLabelmortgageOrRentExpenditure', reviewLabelnetMonthlyIncome: 'reviewLabelnetMonthlyIncome', reviewLabelsectionOutgoings: 'reviewLabelsectionOutgoings'}}
						data={{expenditureOther: 100, grossAnnualIncome: 100, incomeOtherAccountPurpose: 'incomeOtherAccountPurpose', incomeOtherAmount: 100, incomeOtherFrequencyOptions: 'incomeOtherFrequencyOptions', incomeOtherPaymentAmount: 100, incomeOtherPaymentTypeOptions: 'incomeOtherPaymentTypeOptions', incomeOtherSavingsAmount: 100, incomeOtherSavingsFrequency: 'incomeOtherSavingsFrequency', mortgageOrRentExpenditure: 100, netMonthlyIncome: 100, product: { supportsOverdraft: false }}}
						group="REVIEW"
						onContactMethodsChange={function noRefCheck() {}}
						onEditLinkClick={function noRefCheck() {}}
					/>
					<UsernameDetailsComponent
						content={{
							reviewLabelexpenditureOther: 'reviewLabelexpenditureOther',
							reviewLabelgrossAnnualIncome: 'reviewLabelgrossAnnualIncome',
							reviewLabelincomeOtherAccountPurpose: 'reviewLabelincomeOtherAccountPurpose',
							reviewLabelincomeOtherAmount: 'reviewLabelincomeOtherAmount',
							reviewLabelincomeOtherPaymentAmount: 'reviewLabelincomeOtherPaymentAmount',
							reviewLabelincomeOtherPaymentTypeOptions: 'reviewLabelincomeOtherPaymentTypeOptions',
							reviewLabelincomeOtherSavingsAmount: 'reviewLabelincomeOtherSavingsAmount',
							reviewLabelincomeOtherSavingsFrequency: 'reviewLabelincomeOtherSavingsFrequency',
							reviewLabelmortgageOrRentExpenditure: 'reviewLabelmortgageOrRentExpenditure',
							reviewLabelnetMonthlyIncome: 'reviewLabelnetMonthlyIncome',
							reviewLabelsectionOutgoings: 'reviewLabelsectionOutgoings'
						}}
						data={{
							expenditureOther: 100,
							grossAnnualIncome: 100,
							incomeOtherAccountPurpose: 'incomeOtherAccountPurpose',
							incomeOtherAmount: 100,
							incomeOtherFrequencyOptions: 'incomeOtherFrequencyOptions',
							incomeOtherPaymentAmount: 100,
							incomeOtherPaymentTypeOptions: 'incomeOtherPaymentTypeOptions',
							incomeOtherSavingsAmount: 100,
							incomeOtherSavingsFrequency: 'incomeOtherSavingsFrequency',
							mortgageOrRentExpenditure: 100,
							netMonthlyIncome: 100,
							product: {
								supportsOverdraft: false
							}
						}}
						group="REVIEW"
						onContactMethodsChange={function noRefCheck(){}}
						onEditLinkClick={function noRefCheck(){}}
					/>
				</div>
			);
		});

	});
});
