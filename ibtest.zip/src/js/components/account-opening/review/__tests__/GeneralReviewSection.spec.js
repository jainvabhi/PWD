jest.autoMockOff();

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const _ = require('lodash');

const { buildContent } = require('../../../../__helpers__/TestHelpers');

const ReviewSection = require('../ReviewSection');
const BrandUtils = require('../../../../utils/BrandUtils');

const GeneralReviewSection = require('../GeneralReviewSection');

const shallowRender = props => {
	const shallowRenderer = TestUtils.createRenderer();
	shallowRenderer.render(
			<GeneralReviewSection
				{...props}
			/>
		);
	return shallowRenderer.getRenderOutput();
};

describe('GeneralReviewSection', () => {
	let instance;
	let result;

	let content = buildContent([
		'reviewLabelsectionPersonalDetails',
		'reviewLabeltitle',
		'reviewLabelfirstName',
		'reviewLabelmiddleName',
		'reviewLabellastName',
		'reviewLabeldateOfBirth',
		'reviewLabelgender',
		'reviewLabelmaritalStatus',
		'reviewLabeldependants',
		'reviewLabeladdresses',
		'reviewLabeltitle',
		'reviewLabelresidentialStatus',
		'reviewLabeldateMoved',
		'reviewLabelPreviousaddresses',
		'reviewLabeldateMoved',
		'reviewLabelemailAddress',
		'reviewLabelpreferredContactMethod',
		'reviewLabelphoneNumber',
		'reviewLabelnationality',
		'reviewLabelcountryBorn',
		'reviewLabelcityBorn',
		'reviewLabelukCitizen',
		'reviewLabelcitizenshipList',
		'reviewLabeltaxObligations',
		'reviewLabelallTaxObligationsListed',
		'reviewLabelemploymentStatus',
		'reviewLabelemploymentOccupation',
		'reviewLabelemployerName',
		'reviewLabelemploymentStartDate',
  		'reviewLabelsectionContactDetails',
		'reviewLabelsectionNationality',
		'reviewLabelsectionEmployment',
		'reviewLabelsectionCardDetails',
		'reviewLabelAdditionalCard',
	]);

	let data = {
		emailAddress: 'test@test.com',
		preferredContactMethod: 'Email',
		phoneNumber: '07777777777',
		nationality:  'United Kingdom',
		taxObligationList:[{ 'taxCountry': 'Afghanistan', 'hasTaxNumber': 'Yes', 'taxNumber': '1235' }],
		citizenshipList: ['Afghanistan'],
		countryBorn: 'test',
		cityBorn: 'test',
		ukCitizen: 'test',
		hasNoTaxOligations: 'yes',
		employmentStatus:'FULL TIME',
		employmentOccupation:'ARMED FORCES',
		employerName:'test',
		employmentStartDate:'01-01-1972',
		title: 'MR',
		firstName: 'test',
		middleName:'test',
		lastName:'test',
		dateOfBirth: '01-01-1972',
		gender: 'male',
		maritalStatus: 'Single',
		dependants: '3',
		addresses: [{
			addressType: 'domestic',
			addressPrefix: '1/2',
			houseNumber : '39',
			houseName: 'Batcave',
			streetName : 'High Street',
			addressLine1: '2/1, 39 High Street, Glasgow, G11 1CB',
			addressLine2: 'addressLine2',
			city: 'Glasgow',
			postcode : 'G11 1CB',
			id: '1234',
			dateMoved: '11-12-2000',
		}],
		residentialStatus: 'Owner',

	};

	describe('render()', () => {
		beforeEach(() => {
			result = shallowRender({
				content,
				data,
				onEditLinkClick: () => {},
				formatPhoneNumber: d => d,
				getTaxObligations: d => d,
			})
		});


		it('should render web personal details section', () => {
			expect(result.props.children[1]).toEqualJSX(
				<ReviewSection
					data={{
						editLinkTaskId: 'WEB-PERSONAL-DETAILS-PERSONAL',
			            leftContent: [{
			                formatting: 'capitalize',
			                label: 'reviewLabeltitle',
			                value: 'MR'
			            }, {
			                formatting: 'capitalize',
			                label: 'reviewLabelfirstName',
			                value: 'test'
			            }, {
			                formatting: 'capitalize',
			                hidden: false,
			                label: 'reviewLabelmiddleName',
			                value: 'test'
			            }, {
			                formatting: 'capitalize',
			                label: 'reviewLabellastName',
			                value: 'test'
			            }, {
			                label: 'reviewLabeldateOfBirth',
			                value: '01-01-1972'
			            }, {
			                formatting: 'capitalize',
			                label: 'reviewLabelgender',
			                value: 'male'
			            }, {
			                label: 'reviewLabelmaritalStatus',
			                value: 'Single'
			            }, {
			                label: 'reviewLabeldependants',
			                value: '3'
			            }],
			            rightContent: [{
			                label: 'reviewLabeladdresses',
			                value: '1/2, Batcave, 39, High street, Addressline2, Glasgow, G11 1CB'
			            }, {
			                label: 'reviewLabelresidentialStatus',
			                value: 'Owner'
			            }, {
			                label: 'reviewLabeldateMoved',
			                value: '11-12-2000'
			            }],
			            title: 'reviewLabelsectionPersonalDetails'
					}}
					onEditLinkClick={() => {}}
				/>
			);
		});

		it('should render web contact details section', () => {
			expect(result.props.children[2]).toEqualJSX(
				<ReviewSection
					data={{
						editLinkTaskId: 'WEB-PERSONAL-DETAILS-CONTACT',
					    leftContent: [{
			               formatting: 'lowercase',
			               label: 'reviewLabelemailAddress',
			               value: 'test@test.com'
			           }, {
			               label: 'reviewLabelpreferredContactMethod',
			               value: 'Email'
			           }],
			           rightContent: [{
			               label: 'reviewLabelphoneNumber',
			               value: '07777777777'
			           }],
			           title: 'reviewLabelsectionContactDetails'
					}}
					onEditLinkClick={() => {}}
				/>
			);
		});


		it('should render web nationality details section', () => {
			expect(result.props.children[4]).toEqualJSX(
				<ReviewSection
					data={{
				 	   	editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-NATIONALITY',
				        leftContent: [{
				            formatting: 'capitalize',
				            label: 'reviewLabelnationality',
				            value: 'British'
				        }, {
				            formatting: 'capitalize',
				            label: 'reviewLabelcountryBorn',
				            value: 'test'
				        }, {
				            formatting: 'capitalize',
				            label: 'reviewLabelcityBorn',
				            value: 'test'
				        }, {
				            formatting: 'capitalize',
				            label: 'reviewLabelukCitizen',
				            value: 'test'
				        }],
				        rightContent: [{
				            formatting: 'capitalize',
				            label: 'reviewLabelcitizenshipList',
				            value: 'Afghanistan'
				        }, {
				            formatting: 'capitalize',
				            label: 'reviewLabeltaxObligations',
				            value: 'yes'
				        }, {
				            label: 'reviewLabelallTaxObligationsListed',
				            value: 'Yes'
				        }],
				        title: 'reviewLabelsectionNationality'
					}}
					onEditLinkClick={() => {}}
				/>
			);
		});

		it('should render web employment details section', () => {
			expect(result.props.children[6]).toEqualJSX(
				<ReviewSection
					data={{
						editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-EMPLOYMENT',
				        leftContent: [{
				            label: 'reviewLabelemploymentStatus',
				            value: 'Full time'
				        }, {
				            label: 'reviewLabelemploymentOccupation',
				            value: 'Armed Forces'
				        }],
				        rightContent: [{
				            formatting: 'capitalize',
				            label: 'reviewLabelemployerName',
				            value: 'test'
				        }, {
				            label: 'reviewLabelemploymentStartDate',
				            value: '01-01-1972'
				        }],
				        title: 'reviewLabelsectionEmployment'
					}}
					onEditLinkClick={() => {}}
				/>
			);
		});

		it('should render card details section when there is data', () => {
			result = shallowRender({
				content,
				data: {
					additionalCardHolder: 'Yes',
					...data,
				},
				onEditLinkClick: () => {},
				formatPhoneNumber: d => d,
				getTaxObligations: d => d,
			})

			expect(result.props.children[3]).toEqualJSX(
				<ReviewSection
					data={{
						editLinkTaskId: 'WEB-PERSONAL-DETAILS-CARDS',
			            leftContent: [{
			                label: 'reviewLabelAdditionalCard',
			                value: 'Yes',
			            }],
			            title: 'reviewLabelsectionCardDetails'
					}}
					onEditLinkClick={() => {}}
				/>
			);
		});

	});



});
