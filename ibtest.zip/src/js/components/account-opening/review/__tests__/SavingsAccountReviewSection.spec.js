jest.unmock('../SavingsAccountReviewSection');
jest.unmock('../ReviewSection');
jest.unmock('../../../../config');

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const _ = require('lodash');

const { buildContent } = require('../../../../__helpers__/TestHelpers');

const ReviewSection = require('../ReviewSection');
const BrandUtils = require('../../../../utils/BrandUtils');

const SavingsAccountReviewSection = require('../SavingsAccountReviewSection');
const GeneralReviewSection = require('../GeneralReviewSection');
const MarketingPrefSection = require('../MarketingPrefSection');
const UsernameDetailsComponent = require('../../findDetails/UsernameDetailsComponent');

const shallowRender = props => {
	const shallowRenderer = TestUtils.createRenderer();
	shallowRenderer.render(
		<SavingsAccountReviewSection
			{...props}
		/>
	);
	return shallowRenderer.getRenderOutput();
};

describe('SavingsAccountReviewSection', () => {
	let instance;
	let result;

	let content = buildContent([
		'reviewLabelincomeOtherSavingsTypeOptions',
		'reviewLabelincomeOtherSavingsFrequency',
		'reviewLabelincomeOtherSavingsPurpose',
		'reviewLabelsectionSA',
		'reviewLabelincomeOtherSavingsAmount',
	]);

	let data = {
		incomeOtherSavingsTypeOptions: 'incomeOtherSavingsTypeOptions',
		incomeOtherSavingsFrequency: 'incomeOtherSavingsFrequency',
		incomeOtherSavingsPurpose: 'incomeOtherSavingsPurpose',
		incomeOtherSavingsAmount: 'incomeOtherSavingsAmount',
	};

	let props = {
		content,
		data,
		onEditLinkClick: () => {},
		group: 'REVIEW',
		onContactMethodsChange: () => {},
	};

	beforeEach(() => {


		result = shallowRender(props)
	});

	it('should render correctly', () => {
		expect(result).toEqualJSX(
			<div>
				<GeneralReviewSection {...props} />
				<ReviewSection
					data={{editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-SAVINGS', leftContent: [{label: 'reviewLabelincomeOtherSavingsTypeOptions', value: 'incomeOtherSavingsTypeOptions'}, {label: 'reviewLabelincomeOtherSavingsFrequency', value: 'incomeOtherSavingsFrequency'}], rightContent: [{label: 'reviewLabelincomeOtherSavingsPurpose', value: 'incomeOtherSavingsPurpose'}, {label: 'reviewLabelincomeOtherSavingsAmount', value: 'incomeOtherSavingsAmount'}], title: 'reviewLabelsectionSA'}}
					onEditLinkClick={function noRefCheck() {}}
				/>
				<MarketingPrefSection
					content={{reviewLabelincomeOtherSavingsFrequency: 'reviewLabelincomeOtherSavingsFrequency', reviewLabelincomeOtherSavingsPurpose: 'reviewLabelincomeOtherSavingsPurpose', reviewLabelincomeOtherSavingsTypeOptions: 'reviewLabelincomeOtherSavingsTypeOptions', reviewLabelsectionSA: 'reviewLabelsectionSA', reviewLabelincomeOtherSavingsAmount: 'reviewLabelincomeOtherSavingsAmount'}}
					data={{incomeOtherSavingsFrequency: 'incomeOtherSavingsFrequency', incomeOtherSavingsPurpose: 'incomeOtherSavingsPurpose', incomeOtherSavingsTypeOptions: 'incomeOtherSavingsTypeOptions', incomeOtherSavingsAmount: 'incomeOtherSavingsAmount'}}
					group="REVIEW"
					onContactMethodsChange={function noRefCheck() {}}
					onEditLinkClick={function noRefCheck() {}}
				/>
				<UsernameDetailsComponent
					content={{
						reviewLabelincomeOtherSavingsAmount: 'reviewLabelincomeOtherSavingsAmount',
						reviewLabelincomeOtherSavingsFrequency: 'reviewLabelincomeOtherSavingsFrequency',
						reviewLabelincomeOtherSavingsPurpose: 'reviewLabelincomeOtherSavingsPurpose',
						reviewLabelincomeOtherSavingsTypeOptions: 'reviewLabelincomeOtherSavingsTypeOptions',
						reviewLabelsectionSA: 'reviewLabelsectionSA'
					}}
					data={{
						incomeOtherSavingsAmount: 'incomeOtherSavingsAmount',
						incomeOtherSavingsFrequency: 'incomeOtherSavingsFrequency',
						incomeOtherSavingsPurpose: 'incomeOtherSavingsPurpose',
						incomeOtherSavingsTypeOptions: 'incomeOtherSavingsTypeOptions'
					}}
					group="REVIEW"
					onContactMethodsChange={function noRefCheck(){}}
					onEditLinkClick={function noRefCheck(){}}
				/>
			</div>
		);
	});
});
