jest.autoMockOff();

const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');
const _ = require('lodash');
const Link = require('react-router').Link;
const { buildContent } = require('../../../../__helpers__/TestHelpers');


const DeclarationAndAuth = require('../DeclarationAndAuthSection');
const CheckBoxQuestion = require('../../../common/questionsets/CheckBoxQuestion');

const shallowRender = props => {
	const shallowRenderer = TestUtils.createRenderer();

	shallowRenderer.render(
		<DeclarationAndAuth {...props} />
	);
	return shallowRenderer.getRenderOutput();
};


describe('DeclarationAndAuth', () => {

	let result;

	let content = buildContent([
		'declarationAndAuthTitle',
		'declarationAndAuthText',
		'test',
	]);

	let data = {
		product: {
			declarationAndAuthBullets: ['test'],
			productType: {
				name: 'credit-card',
			}
		}
	};

	let props = {
		data,
		content,
		onChange: () => {},
		group: 'test',
		name: 'blah'
	}

	beforeEach(() => {
		result = shallowRender(props)
	});

	describe('render', () => {


		it('should render correctly', () => {
			expect(result).toEqualJSX(
				 <div className="review-section form-spacing">
					<h2 className="icon-header declaration-header">declarationAndAuthTitle</h2>

					<CheckBoxQuestion
						defaultValue={false}
						group={props.group}
						name={props.name}
						dataAnchor={props.name}
						onChange={props.onChange}
						required
					>
						declarationAndAuthText
					</CheckBoxQuestion>
					<ul>
						<li key="test">test</li>
					</ul>
				</div>
			);
		});

	});
});


