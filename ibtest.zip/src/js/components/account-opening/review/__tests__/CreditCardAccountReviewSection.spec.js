jest.autoMockOff();

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const _ = require('lodash');

const { buildContent } = require('../../../../__helpers__/TestHelpers');

const ReviewSection = require('../ReviewSection');
const BrandUtils = require('../../../../utils/BrandUtils');

const CreditCardAccountReviewSection = require('../CreditCardAccountReviewSection');
const GeneralReviewSection = require('../GeneralReviewSection');
const DirectDebitReviewSection = require('../DirectDebitReviewSection');

const shallowRender = props => {
	const shallowRenderer = TestUtils.createRenderer();
	shallowRenderer.render(
		<CreditCardAccountReviewSection {...props} />
	);
	return shallowRenderer.getRenderOutput();
};

describe('CreditCardAccountReviewSection', () => {
	let instance;
	let result;

	let content = buildContent([
		'reviewLabelgrossAnnualIncome',
		'reviewLabelnetMonthlyIncome',
		'reviewLabelincomeOtherAmount',
		'reviewLabelincomeOtherAccountPurpose',
		'reviewLabelincomeOtherPaymentTypeOptions',
		'reviewLabelincomeOtherPaymentAmount',
		'reviewLabelincomeOtherSavingsAmount',
		'reviewLabelincomeOtherSavingsFrequency',
		'reviewLabelgrossAnnualIncome',
		'reviewLabelsectionOutgoings',
		'reviewLabelmortgageOrRentExpenditure',
		'reviewLabelexpenditureOther',
		'reviewLabelRevisedNetMonthlyIncome',
		'reviewLabelRevisedGrossAnnualIncome',
		'reviewLabelRevisedMortgageOrRentExpenditure',
		'reviewLabelRevisedExpenditureOther',
		'reviewLabelDDName',
		'reviewLabelDDAccountNo',
		'reviewLabelDSortCode',
		'reviewLabelDDBankName',
		'reviewLabelDDBankAddress',
		'reviewLabelDDBankPostCode',
		'reviewLabelsectionDirectDebit',
		'reviewLabelsectionIncome',
		'reviewLabelMainBankAcNo',
		'reviewLabelMainBankSortCode',
		'reviewLabelMainBankLengthAtBank',
		'reviewLabelMainBankPaymentDate',
		'reviewLabelsectionBankDetails'
	]);

	let data = {
		bankDetailsAccountNumber: 10000000,
		bankDetailsSortCode: 100000,
		lengthOfTimeBankYears: '1 year',
		lengthOfTimeBankMonths: '1 month',
		paymentDate: '1 - 7',
		grossAnnualIncome: 100,
		netMonthlyIncome: 100,
		incomeOtherAmount: 100,
		incomeOtherFrequencyOptions: 'incomeOtherFrequencyOptions',
		incomeOtherAccountPurpose: 'incomeOtherAccountPurpose',
		incomeOtherPaymentTypeOptions: 'incomeOtherPaymentTypeOptions',
		incomeOtherPaymentAmount: 100,
		incomeOtherSavingsAmount: 100,
		incomeOtherSavingsFrequency: 'incomeOtherSavingsFrequency',
		mortgageOrRentExpenditure: 100,
		expenditureOther: 100,
		revisedNetMonthlyIncome: 100,
		revisedGrossAnnualIncome:100,
		revisedMortgageOrRentExpenditure:100,
		revisedExpenditureOther: 100,
		directDebitAccountName: 'Mr Test'
	};

	let props = {
		content,
		data,
		bankDetails: {
			main: null,
			directDebit: {
				sortCode: '263745',
				accountNumber: '00543212',
				accountName: 'Mr Joe Bloggs',
				bank: {
					name: 'TEST MAIN',
					address: {
						addressLine1: 'Glasgow',
						addressLine2: 'Head Office',
						addressLine3: 'Banking Hall',
						addressLine4: '30 St.Vincent Place',
						city: 'Glasgow',
						postalCode: 'G1 2 HL'
					}
				}
			}
		},
		onChange: () => {},
		onEditLinkClick: () => {},
		formatPhoneNumber: () => {},
		getTaxObligations: () => {},
		onContactMethodsChange: () => {},
		group:'test',
	};

	beforeEach(() => {
		result = shallowRender(props)
	});

	it('should render GeneralReviewSection', () => {
		expect(result).toIncludeJSX(
			<GeneralReviewSection {...props} citizenshipOnly />
		);
	});

	it('should render incoming section', () => {
		expect(result).toIncludeJSX(
				<ReviewSection
					data={{
					editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-INCOME',
					leftContent: [
						{label: 'reviewLabelgrossAnnualIncome', value: 100},
						{label: 'reviewLabelRevisedGrossAnnualIncome', value: 100},
					],
					rightContent: [
						{label: 'reviewLabelnetMonthlyIncome', value: 100},
						{label: 'reviewLabelRevisedNetMonthlyIncome', value: 100}
					], title: 'reviewLabelsectionIncome'}}
					onEditLinkClick={() => {}}
				/>

		);
	});

	it('should render outgoing section', () => {
		expect(result).toIncludeJSX(
				<ReviewSection
					data={{
						editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-OUTGOINGS',
						leftContent: [
							{label: 'reviewLabelmortgageOrRentExpenditure', value: 100},
							{label: 'reviewLabelRevisedMortgageOrRentExpenditure', value: 100}
						],
						rightContent: [
							{label: 'reviewLabelexpenditureOther', value: 100},
							{label: 'reviewLabelRevisedExpenditureOther', value: 100}
						],
						title: 'reviewLabelsectionOutgoings'}}
					onEditLinkClick={() => {}}
				/>
		);
	});

	it('should render bank details section', () => {
		expect(result).toIncludeJSX(
			<ReviewSection
				data={{
					editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-BANK-DETAILS',
					leftContent: [
						{label: 'reviewLabelMainBankAcNo', value: 10000000},
						{label: 'reviewLabelMainBankSortCode', value: 100000}
					],
					rightContent: [
						{label: 'reviewLabelMainBankLengthAtBank', value: '1 year 1 month'},
						{label: 'reviewLabelMainBankPaymentDate', value: '1 - 7'}
					],
					title: 'reviewLabelsectionBankDetails'}}
				onEditLinkClick={() => {}}
			/>
		);
	});


	it('should render direct debit section', () => {
		expect(result).toIncludeJSX(
			<ReviewSection
				data={{editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-DIRECT-DEBIT', title: 'reviewLabelsectionDirectDebit'}}
					onEditLinkClick={() => {}}
				>
				<DirectDebitReviewSection
					bankItems = {
						[{
							title: 'reviewLabelDDName',
							value: 'Mr Test'
						}, {
							title: 'reviewLabelDDAccountNo',
							value: '00543212'
						}, {
							title: 'reviewLabelDSortCode',
							value: '26-37-45'
						}, {
							title: 'reviewLabelDDBankName',
							value: 'TEST MAIN'
						}, {
							title: 'reviewLabelDDBankAddress',
							value: 'Glasgow'
						}, {
							title: 'reviewLabelDDBankPostCode',
							value: 'G1 2 HL'
						}]
					}
				 	{...props}
				/>
			</ReviewSection>
		);
	});

	it('should NOT render direct debit section if we dont have DD bank details', () => {

		result = shallowRender({
			content,
			data,
			bankDetails: {
				main: null,
				directDebit: null,
			},
			onEditLinkClick: () => {},
			formatPhoneNumber: () => {},
			getTaxObligations: () => {},
			onContactMethodsChange: () => {},
			group:'test',
		});

		expect(result).not.toIncludeJSX(
			<ReviewSection
				data={{editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-DIRECT-DEBIT', title: 'reviewLabelsectionDirectDebit'}}
					onEditLinkClick={() => {}}
				>
				<DirectDebitReviewSection
					bankItems = {
						[{
							title: 'reviewLabelDDName',
							value: 'Mr Test'
						}, {
							title: 'reviewLabelDDAccountNo',
							value: '00543212'
						}, {
							title: 'reviewLabelDSortCode',
							value: '26-37-45'
						}, {
							title: 'reviewLabelDDBankName',
							value: 'TEST MAIN'
						}, {
							title: 'reviewLabelDDBankAddress',
							value: 'Glasgow'
						}, {
							title: 'reviewLabelDDBankPostCode',
							value: 'G1 2 HL'
						}]
					}
				 	{...props}
				/>
			</ReviewSection>
		);
	});

	it('should render direct debit section wiht main bank details if selected', () => {
		const mainBankprops = {
			content,
			data:{
				useBankDetails: 'Yes',
				...data
			},
			bankDetails: {
				main: {
					sortCode: '263745',
					accountNumber: '00543212',
					accountName: 'Mr Joe Bloggs',
					bank: {
						name: 'TEST MAIN',
						address: {
							addressLine1: 'Glasgow',
							addressLine2: 'Head Office',
							addressLine3: 'Banking Hall',
							addressLine4: '30 St.Vincent Place',
							city: 'Glasgow',
							postalCode: 'G1 2 HL'
						}
					}
				},
				directDebit: null,
			},
			onChange:() => {},
			onEditLinkClick: () => {},
			formatPhoneNumber: () => {},
			getTaxObligations: () => {},
			onContactMethodsChange: () => {},
			group:'test',
		}
		result = shallowRender(mainBankprops);

		expect(result).toIncludeJSX(
			<ReviewSection
				data={{editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-DIRECT-DEBIT', title: 'reviewLabelsectionDirectDebit'}}
					onEditLinkClick={() => {}}
				>
				<DirectDebitReviewSection
					bankItems = {
						[{
							title: 'reviewLabelDDName',
							value: 'Mr Test'
						}, {
							title: 'reviewLabelDDAccountNo',
							value: '00543212'
						}, {
							title: 'reviewLabelDSortCode',
							value: '26-37-45'
						}, {
							title: 'reviewLabelDDBankName',
							value: 'TEST MAIN'
						}, {
							title: 'reviewLabelDDBankAddress',
							value: 'Glasgow'
						}, {
							title: 'reviewLabelDDBankPostCode',
							value: 'G1 2 HL'
						}]
					}

				 	{...mainBankprops}
				/>
			</ReviewSection>
		);
	});

});
