jest.autoMockOff();

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const _ = require('lodash');
const Link = require('react-router').Link;
const { buildContent } = require('../../../../__helpers__/TestHelpers');

const DirectDebitSection = require('../DirectDebitReviewSection');
const { CheckBoxQuestion } = require('../../../common/questionsets');

const shallowRender = props => {
	const shallowRenderer = TestUtils.createRenderer();
	shallowRenderer.render(
		<DirectDebitSection {...props} />
	);
	return shallowRenderer.getRenderOutput();
};


describe('ReviewSection', () => {
	let instance;
	let result;

	let content = buildContent([
		'debitReviewParagraph1',
		'debitReviewParagraph2',
		'debitReviewParagraph3',
		'debitReviewParagraph4',
		'debitReviewParagraph5',
		'debitReviewSubTitle',
		'reviewLabelDDName',
		'reviewLabelDDAccountNo',
		'reviewLabelDSortCode',
		'reviewLabelDDBankName',
		'debitGuaranteeHeader',
		'reviewLabelDDBankAddress',
		'reviewLabelDDBankPostCode',
		'debitGuaranteeItem1',
		'debitGuaranteeItem2',
		'debitGuaranteeItem3',
		'debitGuaranteeItem3b',
		'debitGuaranteeItem4',
		'debitReviewParagraph6',
		'debitReviewParagraph7',
		'debitReviewParagraph8',
		'debitReviewAddress',
		'debitReviewCheckBoxLabel'
	]);

	let data = {

	};

	let props = {
		data,
		group: 'test',
		onChange: () => {},
		content: {
			bankNames: {
				CB: 'TEST',
			},
			bankNameDD: {
				CB: 'TEST',
			},
			...content,
		},
		bankItems:[{
			title: 'reviewLabelDDName',
			value: 'Mr Joe Bloggs'
		}, {
			title: 'reviewLabelDDAccountNo',
			value: '00543212'
		}, {
			title: 'reviewLabelDSortCode',
			value: '263745'
		}, {
			title: 'reviewLabelDDBankName',
			value: 'TEST MAIN'
		}, {
			title: 'reviewLabelDDBankAddress',
			value: 'Glasgow'
		}, {
			title: 'reviewLabelDDBankPostCode',
			value: 'G1 2 HL'
		}]
	}

	describe('render', () => {
		beforeEach(() => {
			result = shallowRender(props)
		});

		it('should render correctly', () => {
			expect(result).toEqualJSX(
				<div className="indented">
					<div className="row">
						<div className="col-md-3">
							<p>{content.reviewLabelDDSetup}</p>
						</div>
						<div className="col-md-9">
							<p>{data.setUpDirectDebit}</p>
						</div>
					</div>

					<p>debitReviewParagraph2</p>

					<p>debitReviewParagraph3</p>
					<p><strong>debitReviewSubTitle</strong></p>
					<ul className="list-unstyled">
						<li>
							<ul className="list-unstyled row bank-list-item">
								<li className="col-md-6">reviewLabelDDName
								</li>
								<li className="col-md-6">Mr Joe Bloggs
								</li>
							</ul>
						</li>
						<li>
							<ul className="list-unstyled row bank-list-item" >
								<li className="col-md-6">reviewLabelDDAccountNo
								</li>
								<li className="col-md-6">00543212
								</li>
							</ul>
						</li>
						<li>
							<ul className="list-unstyled row bank-list-item" >
								<li className="col-md-6">reviewLabelDSortCode
								</li>
								<li className="col-md-6">263745
								</li>
							</ul>
						</li>
						<li>
							<ul className="list-unstyled row bank-list-item" >
								<li className="col-md-6">reviewLabelDDBankName
								</li>
								<li className="col-md-6">TEST MAIN
								</li>
							</ul>
						</li>
						<li>
							<ul className="list-unstyled row bank-list-item" >
								<li className="col-md-6">reviewLabelDDBankAddress
								</li>
								<li className="col-md-6">Glasgow
								</li>
							</ul>
						</li>
						<li>
							<ul className="list-unstyled row bank-list-item" >
								<li className="col-md-6">reviewLabelDDBankPostCode
								</li>
								<li className="col-md-6">G1 2 HL
								</li>
							</ul>
						</li>
					</ul>


					<p>debitReviewParagraph4</p>
					<p>debitReviewParagraph5</p>
					<p>debitReviewParagraph6</p>

					<div className="dd-guarantee-container">
						<h5 className="dd-guarantee-container__header">debitGuaranteeHeader</h5>
						<ul className="dd-guarantee-container__list">
								<li className="dd-guarantee-container__listitem">debitGuaranteeItem1</li>
								<li className="dd-guarantee-container__listitem">debitGuaranteeItem2</li>
								<li className="dd-guarantee-container__listitem">debitGuaranteeItem3
									<ul className="dd-guarantee-container__list">
										<li className="dd-guarantee-container__listitem">debitGuaranteeItem3b</li>
									</ul>
								</li>
								<li className="dd-guarantee-container__listitem">debitGuaranteeItem4</li>
						</ul>
					</div>

					<p>debitReviewParagraph7</p>
					<p>debitReviewParagraph8</p>
					<p dangerouslySetInnerHTML={{ __html: 'debitReviewAddress' }} />
					<CheckBoxQuestion
						defaultValue={undefined}
						group={'test'}
						name="directDebitReviewAcceptTsAndCs"
						dataAnchor="direct-debit-terms-and-conditions"
						onChange={() => {}}
						required
					>
						debitReviewCheckBoxLabel
					</CheckBoxQuestion>
				</div>
			);
		});

	});
});
