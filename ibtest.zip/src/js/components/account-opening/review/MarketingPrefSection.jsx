/**
* @module MarketingPrefSection
*/

const React = require('react');
const { PropTypes } = React;
const config = require('../../../config');
const MultiCheckBoxQuestion = require('../../common/questionsets/MultiCheckBoxQuestion');

const MarketingPrefSection = props => (
	<div className="review-section marketing-pref">
		<div className="row">
			<h4 className="indented">{props.content.marketingPrefsTitle}</h4>

			<p className="indented">{props.content.marketingPrefsText}</p>

			<div className="indented">
			<MultiCheckBoxQuestion
				name="contactMethods"
				group={props.group}
				data={config.formOptionsMarketingPreferences}
				defaultValue={props.data.contactMethods}
				onChange={props.onContactMethodsChange}
			/>
			</div>

			{props.content.marketingPrefsSmsDYB ? <p>{props.content.marketingPrefsSmsDYB}</p> : false}
		</div>
	</div>
);


MarketingPrefSection.propTypes = {
	data: PropTypes.object.isRequired,
	content: PropTypes.object.isRequired,
	onContactMethodsChange: PropTypes.func.isRequired,
	group: PropTypes.string.isRequired,
};

module.exports = MarketingPrefSection;
