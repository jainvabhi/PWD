/**
 * @module BondAccountReviewSection
 */

const React = require('react');
const { PropTypes } = React;

const AccountOpeningConstants = require('../../../constants/AccountOpeningConstants');

const GeneralReviewSection = require('./GeneralReviewSection');
const ReviewSection = require('./ReviewSection');
const MarketingPrefSection = require('./MarketingPrefSection');
const UsernameDetailsComponent = require('../findDetails/UsernameDetailsComponent');

const BondAccountReviewSection = props => {
	const niContent = props.data.niNumber ? { label: props.content.reviewLabelniNumber, value: props.data.niNumber } : { label: props.content.reviewLabelniNumberMissing, value: props.data.niReason };
	const savingsLeftContent = [
		{ label: props.content.reviewLabelincomeOtherSavingsTypeOptions, value: props.data.incomeOtherSavingsTypeOptions },
	];
	const savingsRightContent = [
		{ label: props.content.reviewLabelincomeOtherSavingsAmount, value: props.data.incomeOtherSavingsAmountBond },
	];

	return (
		<div>
			<GeneralReviewSection {...props} />
			{(props.data.niNumber || props.data.niReason) &&
				<ReviewSection
					onEditLinkClick={props.onEditLinkClick}
					data={{
						title: props.content.niNumberTitle,
						leftContent: [niContent],
						rightContent: [],
						editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-NI-NUMBER',
					}}
				/>
			}
			<ReviewSection
				onEditLinkClick={props.onEditLinkClick}
				data={{
					title: props.content.reviewLabelsectionSA,
					leftContent: savingsLeftContent,
					rightContent: savingsRightContent,
					editLinkTaskId: 'WEB-EMPLOYMENT-DETAILS-SAVINGS',
				}}
			/>
			<MarketingPrefSection
				group={props.group}
				onContactMethodsChange={props.onContactMethodsChange}
				{...props}
			/>
			<UsernameDetailsComponent
				group={AccountOpeningConstants.GROUP_REVIEW}
				{...props}
			/>
		</div>
	);
};

BondAccountReviewSection.propTypes = {
	data: PropTypes.object.isRequired,
	content: PropTypes.shape({
		niNumberTitle: PropTypes.string.isRequired,
		reviewLabelniNumber: PropTypes.string.isRequired,
		reviewLabelniNumberMissing: PropTypes.string.isRequired,
		reviewLabelincomeOtherSavingsTypeOptions: PropTypes.string.isRequired,
		reviewLabelincomeOtherSavingsFrequency: PropTypes.string.isRequired,
		reviewLabelincomeOtherSavingsPurpose: PropTypes.string.isRequired,
		reviewLabelsectionSA: PropTypes.string.isRequired,
		reviewLabelincomeOtherSavingsAmount: PropTypes.string.isRequired,
	}).isRequired,
	onEditLinkClick: PropTypes.func.isRequired,
	group: PropTypes.string.isRequired,
	onContactMethodsChange: PropTypes.func.isRequired,
};

module.exports = BondAccountReviewSection;
