/**
 * @module DirectDebitSection
 */

const React = require('react');
const _ = require('lodash');
const { PropTypes } = React;

const { CheckBoxQuestion } = require('../../common/questionsets');

const appendBankName = (contentKey, props) => contentKey && props.content.bankNameDD && contentKey.replace(/{bankName}/g, props.content.bankNameDD[props.data.bankID]);

const DirectDebitSection = props => {
	if (!props.bankItems) {
		return null;
	}

	const paymentType = props.data.howToPay ? props.data.howToPay.toLowerCase() : null;
	return (
		<div className="indented">
			<div className="row">
				<div className="col-md-3">
					<p>{props.content.reviewLabelDDSetup}</p>
				</div>
				<div className="col-md-9">
					<p>{props.data.setUpDirectDebit}</p>
				</div>
			</div>

			<p>{
				props.content.debitReviewParagraph2 &&
				props.content.debitReviewParagraph2.replace('{paymentAmount}', paymentType)
			}</p>

			<p>{props.content.debitReviewParagraph3}</p>
			<p><strong>{props.content.debitReviewSubTitle}</strong></p>
			<ul className="list-unstyled">
				{
					_.map(props.bankItems, item => {
						return (
							<li key={item.title}>
								<ul className="list-unstyled row bank-list-item" >
									<li className="col-md-6">{item.title}</li>
									<li className="col-md-6">{item.value}</li>
								</ul>
							</li>
						);
					})
				}
			</ul>
			<p>{appendBankName(props.content.debitReviewParagraph4, props)}</p>
			<p>{appendBankName(props.content.debitReviewParagraph5, props)}</p>
			<p>{props.content.debitReviewParagraph6}</p>

			<div className="dd-guarantee-container">
				<h5 className="dd-guarantee-container__header">{props.content.debitGuaranteeHeader}</h5>
				<ul className="dd-guarantee-container__list">
					<li key={1} className="dd-guarantee-container__listitem">{props.content.debitGuaranteeItem1}</li>
					<li key={2} className="dd-guarantee-container__listitem">{appendBankName(props.content.debitGuaranteeItem2, props)}</li>
					<li key={3} className="dd-guarantee-container__listitem">{appendBankName(props.content.debitGuaranteeItem3, props)}
						<ul className="dd-guarantee-container__list">
							<li key={'3b'} className="dd-guarantee-container__listitem">{appendBankName(props.content.debitGuaranteeItem3b, props)}</li>
						</ul>
					</li>
					<li key={4} className="dd-guarantee-container__listitem">{props.content.debitGuaranteeItem4}</li>
				</ul>
			</div>


			<p>{props.content.debitReviewParagraph7}</p>
			<p>{props.content.debitReviewParagraph8}</p>
			<p dangerouslySetInnerHTML={{ __html: props.content.debitReviewAddress }}/>

			<CheckBoxQuestion
				defaultValue={props.data.directDebitReviewAcceptTsAndCs}
				group={props.group}
				name="directDebitReviewAcceptTsAndCs"
				dataAnchor="direct-debit-terms-and-conditions"
				onChange={props.onChange}
				required
			>
				{props.content.debitReviewCheckBoxLabel}
			</CheckBoxQuestion>
		</div>
	);
};

DirectDebitSection.propTypes = {
	data: PropTypes.object.isRequired,
	bankItems: PropTypes.array.isRequired,
	content: PropTypes.object.isRequired,
	group: PropTypes.string.isRequired,
	onChange:PropTypes.func.isRequired,
};

module.exports = DirectDebitSection;
