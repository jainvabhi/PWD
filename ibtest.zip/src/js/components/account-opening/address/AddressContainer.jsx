/**
 * @module AddressContainer
 */

const React = require('react');
const { PropTypes } = React;
const ErrorMessage = require('../../common/ErrorMessage');
const ValidationUtils = require('../../../utils/ValidationUtils');
const ValidationStore = require('../../../stores/ValidationStore');
const _ = require('lodash');

const AddressContainer = React.createClass({
	propTypes: {
		addressId: PropTypes.number.isRequired,
		children: PropTypes.node.isRequired,
		group: PropTypes.string.isRequired,
		name: PropTypes.string,
		validations: PropTypes.object,
		addressSelected: PropTypes.bool,
		submitButtonClick: PropTypes.bool,
		content: PropTypes.object.isRequired,
		findAddressButtonClick: PropTypes.bool,
		data: PropTypes.object.isRequired,
	},

	getInitialState() {
		return {
			showErrorMessage: false,
		};
	},

	componentWillReceiveProps(nextProps) {
		if (this.props !== nextProps.props) {
			const showError = (!_.isUndefined(nextProps.findAddressButtonClick) && !this.getAddressSelected() && !nextProps.hasError && (!this.props.data || !this.props.data.id));
			if (showError && (!nextProps.findAddressButtonClick || this.getOnSubmitButtonClick(nextProps))) {
				this.setState({
					showErrorMessage: true,
				});
			} else if (!showError) {
				this.setState({
					showErrorMessage: false,
				});
			}
		}
	},

	getOnSubmitButtonClick(props) {
		return props.submitButtonClick;
	},

	getAddressSelected() {
		return this.props.addressSelected;
	},

	isValid() {
		return ValidationStore.isInvalid(this.props.group, this.props.name);
	},

	isValidPostCode() {
		return ValidationUtils.isKeyValid(this.props.validations, this.props.group, `postcode_${this.props.addressId}`);
	},

	render() {
		return (
			<div>
				<div className={`address-section${this.props.addressId}`}>{this.props.children}</div>
				{ this.state.showErrorMessage && <div role="alert" aria-live="assertive"><ErrorMessage text={this.props.content.addressContainerErrorMessage} extraClasses="help"/></div>}
			</div>
		);
	},
});

module.exports = AddressContainer;

