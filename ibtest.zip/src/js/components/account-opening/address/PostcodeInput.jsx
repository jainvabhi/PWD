/**
 * @module PostcodeInput
 */
const React = require('react');
const { PropTypes } = React;
const cx = require('classnames');

const InputMixin = require('../../../components/common/mixins/InputMixin');
const RegexUtils = require('../../../utils/RegexUtils');
const LoadingSpinner = require('../../LoadingSpinner');

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');

const isValidPostCode = val => RegexUtils.isValid(val, RegexUtils.regexes.postcode);

const PostcodeInput = React.createClass({

	propTypes: {
		onManualAddressClick: PropTypes.func,
		supportsManualInput: PropTypes.bool,
		hasError: PropTypes.bool,
		addressId: PropTypes.number.isRequired,
		group: PropTypes.string.isRequired,
		name: PropTypes.string.isRequired,
		onChange: PropTypes.func.isRequired,
		onSearch: PropTypes.func.isRequired,
		defaultValue: PropTypes.string,
		postcodeData: PropTypes.array,
		isSearching: PropTypes.bool,
		addressSelected: PropTypes.bool,
		content: PropTypes.object,
		required: PropTypes.bool,
		isManual: PropTypes.bool,
		data: PropTypes.object.isRequired,
	},

	mixins: [InputMixin],

	getInitialState() {
		return {
			value: this.props.defaultValue || '',
		};
	},

	/**
	 * Look up the postcode when the 'Find Address' button is clicked.
	 *
	 * @param {Object} event 		The click event
	 */
	_lookupPostcode(event) {
		event.preventDefault();

		if (!isValidPostCode(this.state.value)) {
			return;
		}

		this.props.onSearch(this.props.name, this.state.value);

		// @ticket DYB-32251: on focus will result in current value in postcode field being resent to store on blur
		this.component.focus();
	},

	/**
	 * The onchange event for postcode entry. Simply uppercases the input postcode and updates the state.
	 *
	 * @param {Object} event 		The click event
	 */
	_onChange(event) {
		const postcode = event.target.value;

		this.setState({ value: postcode.toUpperCase() });
	},

	/**
	 * The onBlur function to fire after a postcode has been entered.
	 * This will save the postcode to the store.
	 *
	 * @param {Object} event 		The click event
	 */
	_onPostcodeChange(event) {
		let postcode = event.currentTarget.value;

		// This is a helpful little bit to automatically format a UK postcode with a space in the correct spot if there isn't one already.
		const postcodeMatch = postcode.match(/^([A-Z]{1,2}\d{1,2}[A-Z]?)\s*(\d[A-Z]{2})$/);
		if (postcodeMatch !== null) {
			postcodeMatch.shift();
			postcode = postcodeMatch.join(' ');
		}

		AccountOpeningActions.updateFormValue('findAddressButtonClick', undefined);

		this.setState({ value: postcode }, () => {
			this.enableValidation();
			this.updateStateValidation();

			if (this.props.data.postcode === postcode) {
				this.props.onChange(this.props.name, postcode);
			}
		});
	},

	customValidator() {
		const isValidRegEx = isValidPostCode(this.state.value);
		const { postcodeData, addressSelected, isManual } = this.props;
		const hasSearched = !!postcodeData;
		const isValid = (this.state.value && !this.props.hasError) || (isValidRegEx && (hasSearched || addressSelected || isManual));
		if (isValidRegEx && !addressSelected) {
			AccountOpeningActions.updateFormValue('findAddressButtonClick', false);
		} else {
			AccountOpeningActions.updateFormValue('findAddressButtonClick', undefined);
		}
		return isValid;
	},

	render() {
		const textInputName = this.props.name;

		const classNames = cx('postcode-label-container', 'col-xs-12', {
			'col-md-3': this.props.supportsManualInput,
			'col-md-4': !this.props.supportsManualInput,
		});

		const inputClassNames = cx('btn btn-primary btn-lg btn-postcode-input btn-filled', {
			'btn-disabled': !isValidPostCode(this.state.value),
		});

		return (
			<fieldset className="row">
				<legend>Postcode</legend>
				<div className={classNames}>
					<label htmlFor={textInputName}>{this.props.content.postcodeSearchLegend}</label>
					{this.getHelpIcon()}
				</div>
				<div className={this.className(classNames)}>
					<input type="text"
						ref={component => this.component = component}
						name={textInputName}
						key={textInputName}
						title="Postcode"
						value={this.state.value}
						className={this.className('postcode-input', this.state.value && this.props.isSearching)}
						onChange={this._onChange}
						onBlur={this._onPostcodeChange}
						data-anchor="postcode-input"
						required={this.props.required}
					/>
				</div>
				<div className={classNames}>
					<button name={`address_${this.props.addressId}_findaddress`}
						onClick={this._lookupPostcode}
						className={inputClassNames}
						data-anchor="postcode-button"
						role="button"
						disabled={this.props.isSearching}
					>
						{this.props.isSearching ? <LoadingSpinner imgSize={30} /> : this.props.content.postcodeSearchButtonLabel }
					</button>
				</div>

				{(this.props.supportsManualInput && !this.props.isManual) && <div className={`${classNames} manual-postcode`}>
					<button
						onClick={this.props.onManualAddressClick}
						className="btn btn-primary btn-lg btn-postcode-input btn-postcode-manual"
						role="button"
						data-anchor={`manual-address-${this.props.addressId}`}
					>
						Add manually
					</button>
				</div>}

				{!this.props.isSearching && this.getErrorElement()}
				{this.getHelpElement()}
			</fieldset>
		);
	},
});

module.exports = PostcodeInput;
