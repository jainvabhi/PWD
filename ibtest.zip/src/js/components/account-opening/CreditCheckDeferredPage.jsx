/**
 * @module CreditCheckDeferredPage
 */

const React = require('react');
const { PropTypes } = React;
const Helmet = require('react-helmet');

const PageHeader = require('../common/PageHeader');
const ResultSection = require('../common/sections/ResultSection');

const envConfig = require('../../../static/config');
const BrandUtils = require('../../utils/BrandUtils');

const CreditCheckDeferredPage = props => {
	const prefix = 'creditCheckNoMatchReferred';
	const htmlContent = key => ({
		dangerouslySetInnerHTML: {
			__html: props.content[`${prefix}${key}`],
		},
	});
	const content = key => props.content[`${prefix}${key}`];
	const highlight = envConfig.bankId === 'DYB' ? 'attention' : null;
	return (
		<div className="account-opening result-page-wrapper proof-income-page-wrapper container-fluid">
			<Helmet title={props.content.creditCheckNoMatchReferredPageHeader} />
			<PageHeader visible={BrandUtils.isAbleToDisplay('result-pages-header')}
				title={`${props.content.landingPageTitle}${props.data.product.name}${props.data.product.nameSuffix}`}
				content={props.content}
			/>
			<div className="result-page declined-page" role="main">
				<div className="row text-center">
					<div className="col-xs-12">
						<ResultSection
							imgSrc={BrandUtils.getResultImage('declined-page-with-image', 'sorry-illustration.png')}
							imgAlt="Declined Result"
							title={props.content.creditCheckNoMatchReferredPageTitle}
						/>
						<div className="white-board">
							<p className={ highlight } { ...htmlContent('Paragraph1') } />
							<p>{ content('Paragraph2') }</p>
							<div className="align-center">
								<p>
									<a href={ content('UploadUrl') } target="_blank" className="btn btn-primary btn-lg btn-filled">{ content('UploadBtn') }</a>
								</p>
							</div>
							<p className={ envConfig.bankId !== 'DYB' ? 'attention' : null }>{ content('Paragraph3') }</p>
							<p { ...htmlContent('Paragraph4') }/>
							<div className="align-center">
								<ul className="document-list">
									{ content('Documents').map((item, key) => (<li className="document-list__item" key={key}><span className="text-center">{item}</span></li>))}
								</ul>
							</div>
							<p { ...htmlContent('Paragraph5') }/>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
};

CreditCheckDeferredPage.propTypes = {
	appData: PropTypes.object.isRequired,
	data: PropTypes.object.isRequired,
	content: PropTypes.object.isRequired,
};

module.exports = CreditCheckDeferredPage;
