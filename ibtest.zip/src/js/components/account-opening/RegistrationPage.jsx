/**
 * @module RegistrationPage
 */

const React = require('react');
const cx = require('classnames');
const _ = require('lodash');
const { PropTypes } = React;
const Helmet = require('react-helmet');

const PageHeader = require('../common/PageHeader');
const SectionFullWidth = require('../common/SectionFullWidth');
const ComponentHeader = require('../common/ComponentHeader');
const BottomNavigationBox = require('../common/BottomNavigationBox');
const ErrorMessage = require('../common/ErrorMessage');
const AlternativeProductsContent = require('../common/AlternativeProductsContent');
const ContentProductWrapper = require('../common/ContentProductWrapper');
const envConfig = require('../../../static/config');

const AccountOpeningConstants = require('../../constants/AccountOpeningConstants');

const ValidationUtils = require('../../utils/ValidationUtils');
const BrandUtils = require('../../utils/BrandUtils');

const RegistrationContainer = require('./registration/RegistrationContainer');
const TransferContainer = require('./registration/TransferContainer');
const { DYBInfo, CYBInfo } = require('./registration/RegistrationTypes');
const LoadingSpinner = require('../LoadingSpinner');
const hasAccountId = props => _.filter(props.data.completedBankInfo.accounts, acc => !!acc.accountId).length;

const { Registration } = require('../digital-registration');

const group = AccountOpeningConstants.GROUP_REGISTRATION;

const RegistrationPage = React.createClass({

	propTypes: {
		appData: PropTypes.object,
		data: PropTypes.object,
		validations: PropTypes.object,
		session: PropTypes.object,
		content: PropTypes.object,
		selectContentBasedOnDowngrade: PropTypes.func,
		showDigitalRegistration: PropTypes.bool,
		onSubmit: PropTypes.func,
		credentialErrorMessage: PropTypes.string,
		transferUser: PropTypes.func,
		canTransfer: PropTypes.func,
		wantsToTransfer: PropTypes.func,
		getProductContent: PropTypes.func.isRequired,
	},

	getInitialState() {
		return {
			awaitingHandoff: false,
		};
	},

	onSubmit(e) {
		if (this.props.canTransfer(this.props) && this.props.data.wantToTranfer === 'Yes') {
			this.setState({
				awaitingHandoff: true && this.props.data.product.productType.name === 'cashISA',
			}, () => {
				this.props.transferUser(this.props);
			});

			return;
		}

		this.props.onSubmit(e);
	},

	render() {
		// Illustration
		const imageUrl = BrandUtils.getResultImage('registration-page-with-image', 'offer-illustration.png');
		const illustration = imageUrl && <img src={imageUrl} alt="Registration" title="Registration" />;
		const errorMessage = <div role="alert" aria-live="assertive"><ErrorMessage text={this.props.credentialErrorMessage} extraClasses="error padding-bottom"/></div>;
		const title = this.props.data.hasTransfered && this.props.content.registrationPageTitlePostTransfer ? this.props.content.registrationPageTitlePostTransfer : this.props.selectContentBasedOnDowngrade('registrationPageTitle');

		const submitLabel = !this.props.canTransfer(this.props) || this.props.data.wantToTranfer === 'No' ? this.props.content.registrationSubmit : this.props.content.registrationTransferSubmit;

		return (
			<div className="registration-page-container">
				<div className="account-opening container-fluid">
					<Helmet title={this.props.content.registrationPageHeader} />
					<PageHeader visible={BrandUtils.isAbleToDisplay('result-pages-header')} title={this.props.content.loginPageTitle} content={this.props.content} />

					<div className="registration-page container" role="main">
						<SectionFullWidth className={cx({ 'text-center': envConfig.bankId !== 'DYB' })}>
							{illustration}
							<ComponentHeader
								title={title}
								titleLevel={1}
								titleClass="text-center"
								subtitleClass="text-center"
								wrapperClass="result-header"
							>
								<div className="registration-wrapper">
									<SectionFullWidth className="seperator">
								{!this.props.data.completedBankInfo &&
									<LoadingSpinner />
								}
									{envConfig.bankId === 'DYB' ?
											<DYBInfo group={group} {...this.props} /> :
											<CYBInfo group={group} {...this.props} />
									}
									</SectionFullWidth>

									{this.props.showDigitalRegistration &&
										!this.props.wantsToTransfer(this.props) &&
										<SectionFullWidth className="seperator">
											<Registration
												group={group}
												{...this.props}
											/>
										</SectionFullWidth>
									}

									{errorMessage}

									<BottomNavigationBox
										onClickNext={this.onSubmit}
										className="text-center"
										disabled={(!ValidationUtils.isGroupValid(this.props.validations, group) || this.props.appData.isApiCallInProgress || this.state.awaitingHandoff) || !(this.props.data.completedBankInfo && hasAccountId(this.props))}
										dataAnchorNext="registration-next"
										nextButtonLabel={submitLabel}
									/>
									{this.props.data.product.productImage && <div className={this.props.data.product.productImage}></div>}
								</div>
							</ComponentHeader>
						</SectionFullWidth>
					</div>
				</div>
			</div>
		);
	},
});

module.exports = ContentProductWrapper(TransferContainer(RegistrationContainer(AlternativeProductsContent(RegistrationPage))));
