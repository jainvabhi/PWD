const React = require('react');
const { PropTypes } = React;
const config = require('../../../config');

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');

const { DropdownQuestion, CurrencyQuestion } = require('../../common/questionsets');
const ContentUtils = require('../../../utils/ContentUtils');

const withinProductDepositRange = props => {
	const amount = parseInt(props.data.incomeOtherSavingsAmountBond, 10);
	const minimumTransfer = props.data.product.minimumTransfer;
	const maximumTransfer = props.data.product.maximumTransfer;

	return amount >= minimumTransfer && amount <= maximumTransfer;
};

const BondIssueAMLQuestions = props => (
	<span>
		<DropdownQuestion
			name="incomeOtherSavingsTypeOptions"
			group={props.group}
			data={config[props.data.product.formOptionsIncomeOtherPaymentQuestionSet] || config.formOptionsIncomeOtherPaymentCashISAType}
			onChange={AccountOpeningActions.updateFormValue}
			defaultValue={props.data.incomeOtherSavingsTypeOptions}
			dataAnchor="income-other-savings-type"
			required
		>
			{props.content.incomeOtherSavingsTypeOptions}
		</DropdownQuestion>
		<CurrencyQuestion
			name="incomeOtherSavingsAmountBond"
			group={props.group}
			onChange={AccountOpeningActions.updateFormValue}
			defaultValue={props.data.incomeOtherSavingsAmountBond}
			dataAnchor="income-other-savings-amount"
			helpText={props.content.incomeOtherSavingsAmountBondHelpMessage && ContentUtils.replaceWithProductConfigData(props.content.incomeOtherSavingsAmountBondHelpMessage, props.data.product)}
			validationText={props.content.incomeOtherSavingsAmountBondValidationMessage && ContentUtils.replaceWithProductConfigData(props.content.incomeOtherSavingsAmountBondValidationMessage, props.data.product)}
			customValidator={() => withinProductDepositRange(props)}
			required
		>
			{props.content.incomeOtherSavingsAmountBond}
		</CurrencyQuestion>
	</span>
);

BondIssueAMLQuestions.propTypes = {
	group: PropTypes.string.isRequired,
	data: PropTypes.shape({
		incomeOtherSavingsTypeOptions: PropTypes.arrayOf(PropTypes.string),
		incomeOtherSavingsAmount: PropTypes.number,
		incomeOtherSavingsAmountBond: PropTypes.string,
		product: PropTypes.shape({
			formOptionsIncomeOtherPaymentQuestionSet: PropTypes.string,
		}),
	}),
	content: PropTypes.shape({
		incomeOtherSavingsTypeOptions: PropTypes.string,
		incomeOtherSavingsAmountBond: PropTypes.string,
		incomeOtherSavingsFrequency: PropTypes.string,
		incomeOtherSavingsAmountBondHelpMessage: PropTypes.string,
		incomeOtherSavingsAmountBondValidationMessage: PropTypes.string,
	}),
};

module.exports = BondIssueAMLQuestions;
