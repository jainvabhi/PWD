const React = require('react');
const { PropTypes } = React;
const config = require('../../../config');

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');

const { DropdownQuestion, CurrencyQuestion } = require('../../common/questionsets');

const SavingsAMLQuestions = props => (
	<span>
		<DropdownQuestion
			name="incomeOtherSavingsTypeOptions"
			group={props.group}
			data={config.formOptionsIncomeOtherPaymentType}
			onChange={AccountOpeningActions.updateFormValue}
			defaultValue={props.data.incomeOtherSavingsTypeOptions}
			dataAnchor="income-other-savings-type"
			required
		>
			{props.content.incomeOtherSavingsTypeOptions}
		</DropdownQuestion>
		<CurrencyQuestion
			name="incomeOtherSavingsAmount"
			group={props.group}
			onChange={AccountOpeningActions.updateFormValue}
			defaultValue={props.data.incomeOtherSavingsAmount}
			dataAnchor="income-other-savings-amount"
			required
		>
			{props.content.incomeOtherSavingsAmount}
		</CurrencyQuestion>
		<DropdownQuestion
			name="incomeOtherSavingsFrequency"
			group={props.group}
			data={config.formOptionsSavingsFrequency}
			onChange={AccountOpeningActions.updateFormValue}
			defaultValue={props.data.incomeOtherSavingsFrequency}
			dataAnchor="income-other-savings-frequency"
			required
		>
			{props.content.incomeOtherSavingsFrequency}
		</DropdownQuestion>
		<DropdownQuestion
			name="incomeOtherSavingsPurpose"
			group={props.group}
			data={config.formOptionsSavingsAccountPurpose}
			onChange={AccountOpeningActions.updateFormValue}
			defaultValue={props.data.incomeOtherSavingsPurpose}
			dataAnchor="income-other-savings-purpose"
			required
		>
			{props.content.incomeOtherSavingsPurpose}
		</DropdownQuestion>
	</span>
);

SavingsAMLQuestions.propTypes = {
	group: PropTypes.string.isRequired,
	data: PropTypes.shape({
		incomeOtherSavingsTypeOptions: PropTypes.arrayOf(PropTypes.string),
		incomeOtherSavingsAmount: PropTypes.number,
		incomeOtherSavingsFrequency: PropTypes.string,
		incomeOtherSavingsPurpose: PropTypes.string,
		product: PropTypes.shape({
			savingUpHelp: PropTypes.string,
		}),
	}),
	content: PropTypes.shape({
		incomeOtherSavingsTypeOptions: PropTypes.string,
		incomeOtherSavingsAmountBond: PropTypes.string,
		incomeOtherSavingsFrequency: PropTypes.string,
		helpBuySavingUpAssistance: PropTypes.string,
		incomeOtherSavingsAmount: PropTypes.string,
		incomeOtherSavingsPurpose: PropTypes.string,
	}),
};

module.exports = SavingsAMLQuestions;
