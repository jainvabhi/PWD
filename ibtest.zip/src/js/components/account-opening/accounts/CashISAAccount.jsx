/**
 * @module CashISAAccount
 */

const React = require('react');
const { PropTypes } = React;

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');

const SectionFullWidth = require('../../common/SectionFullWidth.jsx');
const SavingsAccountPaymentInfoSection = require('./SavingsAccountPaymentInfoSection');
const GeneralEmploymentDetails = require('../employment/GeneralEmploymentDetails');

const onChange = (name, value) => AccountOpeningActions.updateFormValue(name, value);

const CashISAAMLQuestions = require('./CashISAAMLQuestions');
const BondIssueAMLQuestions = require('./BondIssueAMLQuestions');

const amlQuestions = {
	bond: props => (<BondIssueAMLQuestions {...props} />),
	default: props => (<CashISAAMLQuestions {...props} />),
};

const CashISAAccount = React.createClass({

	propTypes: {
		data: PropTypes.object.isRequired,
		content: PropTypes.object.isRequired,
		group: PropTypes.string.isRequired,
	},

	render() {
		return (
			<div>
				<GeneralEmploymentDetails
					{...this.props}
					onChange={onChange}
					taxExempt
					showNationalInsurance
				/>
			<SectionFullWidth id="savings-account-details">
					<hr />
					<SavingsAccountPaymentInfoSection
						{...this.props}
					/>
					{ amlQuestions[this.props.data.product.amlQuestionSet](this.props) }
				</SectionFullWidth>
			</div>
		);
	},
});

module.exports = CashISAAccount;
