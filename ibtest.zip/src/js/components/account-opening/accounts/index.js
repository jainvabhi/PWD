const CurrentAccount = require('./CurrentAccount');
const SavingsAccount = require('./SavingsAccount');
const CashISAAccount = require('./CashISAAccount');
const CreditCardAccount = require('./CreditCardAccount');

module.exports = {
	CurrentAccount,
	SavingsAccount,
	CashISAAccount,
	CreditCardAccount,
};
