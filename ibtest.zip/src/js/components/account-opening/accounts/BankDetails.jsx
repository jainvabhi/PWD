/**
 * @module BankDetails
 */

const React = require('react');
const { PropTypes } = React;
const _ = require('lodash');

const config = require('../../../config');
const ComponentHeader = require('../../common/ComponentHeader');
const AccountDetails = require('./AccountDetails');

const { MultiDropdownQuestion, DropdownQuestion } = require('../../common/questionsets');

const BankDetails = props => {
	const accountNo = {
		name: 'bankDetailsAccountNumber',
		value: props.data.bankDetailsAccountNumber,
		dataAnchor: 'bank-details-account-number',
		label: props.content.bankDetailsAccountNumber,
	};
	const sortCode = {
		name:'bankDetailsSortCode',
		value: props.data.bankDetailsSortCode,
		dataAnchor: 'bank-details-sort-code',
		label: props.content.bankDetailsSortCode,
	};

	return (
		<div>
			<ComponentHeader
				title={props.content.bankDetailsTitle}
				titleLevel={2}
				hasSeparator
			>
				{props.content.bankDetailsIntro && <p>{props.content.bankDetailsIntro}</p>}

				<AccountDetails
					type="main"
					name="bankDetails"
					accountNo={accountNo}
					sortCode={sortCode}
					{...props}
				/>
				<MultiDropdownQuestion
					group={props.group}
					onChange={props.onChange}
					dataAnchor="bank-details-length-time"
					data={[
						{
							range: _.range(0, 100),
							name: 'lengthOfTimeBankYears',
							valueSuffix: year => {
								return year === 1 ? 'year' : 'years';
							},
						},
						{
							range: _.range(0, 12),
							name: 'lengthOfTimeBankMonths',
							valueSuffix: month => {
								return month === 1 ? 'month' : 'months';
							},
						},

					]}
					defaultValues={[
						props.data.lengthOfTimeBankYears, props.data.lengthOfTimeBankMonths,
					]}
				>
					{props.content.lengthOfTimeAtBank}
				</MultiDropdownQuestion>
				<DropdownQuestion
					name={'paymentDate'}
					group={props.group}
					data={config.directDebitPaymentDates}
					onChange={props.onChange}
					defaultValue={props.data.paymentDate}
					dataAnchor={'direct-debit-payment-date'}
					required
				>
					{props.content.directDebitPaymentDates}
				</DropdownQuestion>
			</ComponentHeader>
		</div>
	);
};

BankDetails.propTypes = {
	group: PropTypes.string.isRequired,
	onChange: PropTypes.func.isRequired,
	data: PropTypes.object.isRequired,
	content: PropTypes.object.isRequired,
};

module.exports = BankDetails;
