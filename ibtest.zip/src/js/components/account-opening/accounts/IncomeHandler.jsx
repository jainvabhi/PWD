const React = require('react');
const { PropTypes } = React;

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');

const incomeValidator = (grossAnnualIncome, netMonthlyIncome) => {
	if (netMonthlyIncome === 0) {
		return true;
	}

	if ((netMonthlyIncome > 0) && (grossAnnualIncome === 0)) {
		return false;
	}

	if (netMonthlyIncome <= (grossAnnualIncome / 12)) {
		return true;
	}

	return false;
};

const IncomeHandler = WrappedComponent => React.createClass({

	propTypes: {
		data: PropTypes.object.isRequired,
		group: PropTypes.string.isRequired,
	},

	/**
	 * On change handler for has additional income question. Is the answer yes? If so then
	 * render in the additional income questions.
	 * @param  {string} name  the name of question
	 * @param  {string} value the value selected
	 */
	onHasAdditionalIncome(name, value) {
		const data = [{ key: name, value }];

		// Clear the saved list if user now says they don't have one.
		if (value === 'No') {
			data.push({ key: 'incomeOtherAmount', value: undefined });
			data.push({ key: 'incomeOtherFrequencyOptions', value: undefined });
		}

		AccountOpeningActions.updateFormValues(data);
	},

	onIncomeDetailsSectionChange(key, value) {
		const dispatchMap = {
			hasAdditionalIncome: this.onHasAdditionalIncome,
			grossAnnualIncome: this.updateGrossAnnualIncome,
			revisedGrossAnnualIncome: this.updateRevisedGrossAnnualIncome,
		};

		const dispatch = dispatchMap[key] || AccountOpeningActions.updateFormValue;

		dispatch(key, value);
	},

	/**
	 * method is required to update grossAnnualIncome
	 * and triger validation on netMonthlyIncome when grossAnnualIncome changes
	 * @param  {String} key   Changed key
	 * @param  {String} value Changed value
	 */
	updateRevisedGrossAnnualIncome(key, value) {
		const { revisedNetMonthlyIncome } = this.props.data;
		AccountOpeningActions.updateFormValue('revisedNetMonthlyIncome', ''); // @ticket DYB-21349
		AccountOpeningActions.updateFormValues([
				{ key, value },
				{ key: 'revisedNetMonthlyIncome', value: revisedNetMonthlyIncome },
		]);
	},

	/**
	 * method is required to update grossAnnualIncome
	 * and triger validation on netMonthlyIncome when grossAnnualIncome changes
	 * @param  {String} key   Changed key
	 * @param  {String} value Changed value
	 */
	updateGrossAnnualIncome(key, value) {
		const { netMonthlyIncome } = this.props.data;
		AccountOpeningActions.updateFormValue('netMonthlyIncome', ''); // @ticket DYB-21349
		AccountOpeningActions.updateFormValues([
				{ key, value },
				{ key: 'netMonthlyIncome', value: netMonthlyIncome },
		]);
	},

	netMonthlyIncomeValidator(grossAnnualIncome, netMonthlyIncome) {
			const annual = parseInt(grossAnnualIncome, 10);
			const monthly = parseInt(netMonthlyIncome, 10);
			return incomeValidator(annual, monthly);
	},

	incomeRevisionValidator(revisedGrossAnnualIncome, revisedNetMonthlyIncome) {
			const annual = parseInt(revisedGrossAnnualIncome, 10);
			const monthly = parseInt(revisedNetMonthlyIncome, 10);
			return incomeValidator(annual, monthly);
	},

	render() {
		return (
			<WrappedComponent
				{...this.props}
				onIncomeDetailsSectionChange={this.onIncomeDetailsSectionChange}
				netMonthlyIncomeValidator={this.netMonthlyIncomeValidator}
				incomeRevisionValidator={this.incomeRevisionValidator}
			/>
		);
	},
});

module.exports = IncomeHandler;
