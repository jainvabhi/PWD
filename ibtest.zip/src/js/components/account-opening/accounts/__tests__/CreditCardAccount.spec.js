jest.unmock('../CreditCardAccount');
jest.unmock('../IncomeDetails');
jest.unmock('../BankDetails');
jest.unmock('../CreditExpenditure');
jest.unmock('../Expenditure');
jest.unmock('../DirectDebit');
jest.unmock('../CurrentAccountPaymentInfo');
jest.unmock('../../employment/GeneralEmploymentDetails');
jest.unmock('../../employment/Nationality');
jest.unmock('../../../common/SectionFullWidth');


const React = require('react');
const TestUtils = require('react-addons-test-utils');
const ReactDOM = require('react-dom');

const { buildContent } = require('../../../../__helpers__/TestHelpers');

const container = document.createElement('div');
const render = (comp) => ReactDOM.render(comp, container);
const shallowRenderer = TestUtils.createRenderer();

const AccountOpeningActions = require('../../../../actions/AccountOpeningActions');

const CreditCardAccount = require('../CreditCardAccount');
const SectionFullWidth = require('../../../common/SectionFullWidth');
const { IncomeDetails, IncomeReduction } = require('../IncomeDetails');
const IncomeHandler = require('./../IncomeHandler');
const BankDetails = require('./../BankDetails');
const Expenditure = require('./../Expenditure');
const CreditExpenditure = require('./../CreditExpenditure');

const GeneralEmploymentDetails = require('../../employment/GeneralEmploymentDetails');

describe('CreditCardAccount', () => {
	let instance;
	let component;
	let result;

	let content = buildContent([
		'ukCitizen',
		'hasAdditionalCitizenships',
		'hasNoTaxOligations',
		'hasAdditionalIncome'

	]);

	let data = {
		product: {
			productType: {
				name: 'credit-card',
			}
		}
	};

	let props = {
		group: '',
		data: data,
		content: content,
		onChange: () => {},
		onIncomeDetailsSectionChange: () => {},
		onNationalitySectionChange: () => {},
		netMonthlyIncomeValidator:() => {},
		incomeRevisionValidator:() => {},
	};

	beforeEach(() => {
		component = (
			<CreditCardAccount {...props} />
		);
		instance = render(component);
		shallowRenderer.render(component);
		result = shallowRenderer.getRenderOutput();
	});

	it('should be defined', () => {
		expect(instance).toBeDefined();
	});

	it('should render GeneralEmploymentDetails section', () => {
		expect(result).toIncludeJSX(
			<GeneralEmploymentDetails
				taxExempt
				citizenshipOnly
				{...props}
			/>
		);
	});

	it('should render Income section section', () => {
		expect(result).toIncludeJSX(
			<SectionFullWidth id="income-details">
				<IncomeDetails
					onChange={props.onIncomeDetailsSectionChange}
					{...props}
				/>
			</SectionFullWidth>
		);
	});

	it('should render expenditure section', () => {
		expect(result).toIncludeJSX(
			<SectionFullWidth id="outgoings-details">
				<Expenditure
					onChange={AccountOpeningActions.updateFormValue}
					{...props}
				>
					<CreditExpenditure
						onChange={AccountOpeningActions.updateFormValue}
						{...props}
					/>
				</Expenditure>
			</SectionFullWidth>
		);
	});

	it('should render bank details section', () => {
		expect(result).toIncludeJSX(
			<SectionFullWidth id="bank-details">
				<BankDetails
					onChange={AccountOpeningActions.updateFormValue}
					{...props}
				/>
			</SectionFullWidth>
		);
	});





});


