jest.autoMockOff();
jest.mock('../../../../actions/BankDetailsActions');

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const ReactDOM = require('react-dom');

const container = document.createElement('div');
const render = (comp, el) => ReactDOM.render(comp, el || container);
const shallowRenderer = TestUtils.createRenderer();

const AccountDetails = require('../AccountDetails');
const { TextQuestion } = require('../../../common/questionsets');
const ErrorMessage = require('../../../common/ErrorMessage');
const BankDetailsActions = require('../../../../actions/BankDetailsActions');

describe('AccountDetails', () => {
	let instance;
	let component;
	let result;

	let content = {
		bankDetailsLookupError: '',
	};

	let data = {};

	const accountNo = {
		name:"bankDetailsAccountNumber",
		defaultValue: data.bankDetailsAccountNumber,
		dataAnchor:"bank-details-account-number",
		label: 'Main bank account number',
		length: 8,
		value: '99999999',
	};
	const sortCode = {
		name:"bankDetailsSortCode",
		defaultValue: data.bankDetailsSortCode,
		dataAnchor:"bank-details-sort-code",
		label: 'Main bank account sort code',
		length: 6,
		value: '999999',
	};

	let props = {
		group: 'test',
		name: 'bankdetails',
		type: 'main',
		data,
		content,
		onChange: () => {},
		validations: {
			test: {
				[sortCode.name]: {
					isValid: true
				},
				[accountNo.name]: {
					isValid: true
				}
			}
		},
		sortCode,
		accountNo,
		bankDetails: {
			main:null,
		},
		session: {},
	};


	beforeEach(() => {
		component = (
			<AccountDetails {...props} />
		);
		instance = render(component);
		shallowRenderer.render(component);
		result = shallowRenderer.getRenderOutput();
	});

	it('should be defined', () => {
		expect(instance).toBeDefined();
	});

	it('should render account number question', () => {
		expect(result).toIncludeJSX(
			<TextQuestion
				name="bankDetailsAccountNumber"
				inputClassName=""
				group={props.group}
				onChange={props.onChange}
				defaultValue={props.accountNo.value}
				minLength={8}
				maxLength={8}
				dataAnchor="bank-details-account-number"
				validateType="number"
				required
			>
				{'Main bank account number'}
			</TextQuestion>
		);
	});

	it('should render sort code question', () => {
		expect(result).toIncludeJSX(
			<TextQuestion
				name="bankDetailsSortCode"
				inputClassName=""
				group={props.group}
				onChange={props.onChange}
				defaultValue={props.sortCode.value}
				minLength={6}
				maxLength={6}
				dataAnchor="bank-details-sort-code"
				validateType="number"
				required
			>
				{'Main bank account sort code'}
			</TextQuestion>
		);
	});

	describe('WHEN bank details are wrong', () => {
		beforeEach(() => {
			component = (
				<AccountDetails {...{
						...props,
						bankDetails: {
							main: {
								inValid: true,
							},
						},

					}
				} />
			);
			instance = render(component);
			shallowRenderer.render(component);
			result = shallowRenderer.getRenderOutput();
		});

		it('should render an error message', () => {

			expect(result).toIncludeJSX(
				<ErrorMessage text={content.bankDetailsLookupError} visible={true} />
			);
		});

		it('should mark acc no as invalid', () => {

			expect(result).toIncludeJSX(
				<TextQuestion
					inputClassName={'error'}
					name="bankDetailsAccountNumber"
					group={props.group}
					onChange={props.onChange}
					defaultValue={props.accountNo.value}
					minLength={8}
					maxLength={8}
					dataAnchor="bank-details-account-number"
					validateType="number"
					required
				>
					{'Main bank account number'}
				</TextQuestion>
			);
		});

		it('should mark sort code as invalid', () => {
			expect(result).toIncludeJSX(
				<TextQuestion
					inputClassName={'error'}
					name="bankDetailsSortCode"
					group={props.group}
					onChange={props.onChange}
					defaultValue={props.sortCode.value}
					minLength={6}
					maxLength={6}
					dataAnchor="bank-details-sort-code"
					validateType="number"
					required
				>
					{'Main bank account sort code'}
				</TextQuestion>
			);
		});
	});

	describe('fetch bank ', () => {
		beforeEach(() => {
			BankDetailsActions.getBankDetails.mockClear()
			component = (
				<AccountDetails {...{
					...props,
					accountNo: {
						...accountNo,
						value: '11111111'
					},
				}} />
			);
			instance = render(component);
		});


		it('should fetch when valid', () => {
			expect(BankDetailsActions.getBankDetails.mock.calls.length).toBe(1);
		});

		it('should NOT fetch when details match the last fetch', () => {

			component = (
				<AccountDetails {...{
					...props,
					accountNo: {
						...accountNo,
						value: '1111111'
					},
				}} />
			);
			instance = render(component);
			expect(BankDetailsActions.getBankDetails.mock.calls.length).toBe(1);

			component = (
				<AccountDetails {...{
					...props,
					accountNo: {
						...accountNo,
						value: '11111111'
					},
				}} />
			);
			instance = render(component);
			expect(BankDetailsActions.getBankDetails.mock.calls.length).toBe(1);

			component = (
				<AccountDetails {...{
					...props,
					accountNo: {
						...accountNo,
						value: '44444444'
					},
				}} />
			);
			instance = render(component);
			expect(BankDetailsActions.getBankDetails.mock.calls.length).toBe(2);
		});

		it('should cache fetched details', () => {
			expect(instance.state).toEqual({
				accountNo: '11111111',
				sortCode: '999999',
			});
			component = (
				<AccountDetails {...{
					...props,
					accountNo: {
						...accountNo,
						value: '44444444'
					},
				}} />
			);
			instance = render(component);
			expect(instance.state).toEqual({
				accountNo: '44444444',
				sortCode: '999999',
			});
		});
	});
});
