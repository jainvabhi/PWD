jest.unmock('../IncomeHandler');

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const ReactDOM = require('react-dom');
const _ = require('lodash');
const container = document.createElement('div');
const render = (comp, el) => ReactDOM.render(comp, el || container);
const shallowRenderer = TestUtils.createRenderer();

const IncomeHandler = require('../IncomeHandler');
let Wrapper = React.createClass({
    render() {
        return (
            <div>test</div>
        );
    }
});

Wrapper = IncomeHandler(Wrapper);
const AccountOpeningActions = require('../../../../actions/AccountOpeningActions');

describe('CurrentAccount', () => {
	let instance;
	let component;
	let result;

	let content = {};

	let data = {};

	let props = {
		group: '',
		data: data,
		content: content,
	};


	describe('onHasAdditionalIncome - No', () => {
		let data;
		beforeEach(() => {
			component = (
				<Wrapper {...props} />
			);
			instance = render(component);
			shallowRenderer.render(component);
			result = shallowRenderer.getRenderOutput();

			instance.onIncomeDetailsSectionChange('hasAdditionalIncome', 'No');
			data = AccountOpeningActions.updateFormValues.mock.calls[0][0]
		});

		afterEach(() => {
			AccountOpeningActions.updateFormValues.mockClear();
		});

		it('should call with the correct data', () => {
			expect(data).toEqual([
				{ key: 'hasAdditionalIncome', value: 'No' },
				{ key: 'incomeOtherAmount', value: undefined },
				{ key: 'incomeOtherFrequencyOptions', value: undefined },
			]);
		});
	});

	describe('onHasAdditionalIncome - Yes', () => {
		let data;
		beforeEach(() => {
			instance = render(component);
			instance.onIncomeDetailsSectionChange('hasAdditionalIncome', 'Yes');
			data = AccountOpeningActions.updateFormValues.mock.calls[0][0]
		});

		afterEach(() => {
			AccountOpeningActions.updateFormValues.mockClear();
		});

		it('should call with the correct data', () => {
			expect(data).toEqual([
				{ key: 'hasAdditionalIncome', value: 'Yes' },
			]);
		});
	});

	describe('updateGrossAnnualIncome', () => {
		let data;
		let update;

		beforeEach(() => {
			instance = render(component);
			instance.onIncomeDetailsSectionChange('grossAnnualIncome', 1000);

			data = AccountOpeningActions.updateFormValues.mock.calls[0][0]
			update = AccountOpeningActions.updateFormValue.mock.calls[0]
		});

		afterEach(() => {
			AccountOpeningActions.updateFormValues.mockClear();
			AccountOpeningActions.updateFormValue.mockClear();
		});

		it('should call with the correct data', () => {
			expect(data).toEqual([
				{ key: 'grossAnnualIncome', value: 1000 },
				{ key: 'netMonthlyIncome', value: undefined },
			]);
		});

		it('should clear netMonthlyIncome', () => {
			expect(update).toEqual(['netMonthlyIncome', '']);
		});
	});

	describe('Income validation', () => {
		let component;
		let instance;
		let result;
		let props;

		let content = {
		};

		let data = {
			product: {
				productType: {
					name: 'current',
				}
			}
		};

		it('can validate net monthly income values', function() {
			const scenarios = [
				{grossAnnualIncome: '0', netMonthlyIncome: '0', result: true},
				{grossAnnualIncome: '0', netMonthlyIncome: '100', result: false},
				{grossAnnualIncome: '12000', netMonthlyIncome: '1000', result: true},
				{grossAnnualIncome: '12000', netMonthlyIncome: '500', result: true},
				{grossAnnualIncome: '12000', netMonthlyIncome: '1100', result: false},
				{grossAnnualIncome: undefined, netMonthlyIncome: undefined, result: false},
				{grossAnnualIncome: 'abc', netMonthlyIncome: 'cba', result: false}
			];

			_.each(scenarios, (scenario) => {
				data = {
					grossAnnualIncome: scenario.grossAnnualIncome,
					netMonthlyIncome: scenario.netMonthlyIncome,
					product: {
						productType: {
							name: 'current',
						}
					}
				}

				instance = TestUtils.renderIntoDocument(
					<Wrapper
						data={data}
						content={content}
						group='group'
						onChange={() => {}}
						/>
				);

				expect(instance.netMonthlyIncomeValidator(data.grossAnnualIncome, data.netMonthlyIncome)).toBe(scenario.result);
			});
		});
	});
});
