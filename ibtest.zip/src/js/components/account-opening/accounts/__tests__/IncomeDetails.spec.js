jest.unmock('../IncomeDetails');
jest.unmock('../CurrentAccountPaymentInfo');
jest.unmock('../../../../config');

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const ReactDOM = require('react-dom');
const _ = require('lodash');

const container = document.createElement('div');
const render = (comp) => ReactDOM.render(comp, container);
const shallowRenderer = TestUtils.createRenderer();

const { IncomeDetails, IncomeReduction } = require('../IncomeDetails');

const {
	DropdownQuestion,
	RadioQuestion,
	CurrencyQuestion,
} = require('../../../common/questionsets');


describe('IncomeDetails', () => {
	let component;
	let instance;
	let result;
	let props;

	let content = {
	};

	let data = {
		product: {
			productType: {
				name: 'current',
			}
		}
	};

	beforeEach(() => {
		component = (
			<IncomeDetails
				group='group'
				data={data}
				content={content}
				onChange={() => {}}
				netMonthlyIncomeValidator={() => {}}
				incomeRevisionValidator={() => {}}
			/>
		);
		instance = render(component);
		shallowRenderer.render(component);
		result = shallowRenderer.getRenderOutput();

	});

	it('should be defined', () => {
		expect(instance).toBeDefined();
	});

	describe('when using credit cards', () => {
		beforeEach(() => {
			props = {
				data: {
					product: {
						productType: {
							name: 'credit-card',
						}
					}
				},
				content,
				defaultValue:undefined,
				group:'group',
				labelText:undefined,
				name:"hasAdditionalIncome",
				incomeRevisionValidator: function noRefCheck() {},
				netMonthlyIncomeValidator: function noRefCheck() {},
				onChange:() => {},
				netMonthlyIncomeValidator:() => {},
				incomeRevisionValidator:() => {},
				options:[{
					anchor: 'income-other-sources-no',
					value: 'No',
				}, {
					anchor: 'income-other-sources-yes',
					value: 'Yes',
				}],
				required:true,
				showCurrentAccountPaymentInfo: false,
			};
			component = (
				<IncomeDetails
					{...props}
				/>
			);
			instance = render(component);
			shallowRenderer.render(component);
			result = shallowRenderer.getRenderOutput();
		});

		it('should NOT render "has Additional Income" radio', () => {


			expect(result).not.toIncludeJSX(
				<RadioQuestion
					{...props}
				/>
			);
		});

		it('should NOT render income reduction questions radio', () => {
			expect(result).toIncludeJSX(
				<IncomeReduction {...props} />
			);
		});


	});
});
