jest.autoMockOff();

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const ReactDOM = require('react-dom');

const container = document.createElement('div');
const render = (comp, el) => ReactDOM.render(comp, el || container);
const shallowRenderer = TestUtils.createRenderer();

const DirectDebit = require('../DirectDebit');
const AccountDetails = require('../AccountDetails');
const {
	TextQuestion,
	RadioQuestion,
	CurrencyQuestion,
	DropdownQuestion,
	CheckBoxQuestion,
 } = require('../../../common/questionsets');
const ComponentHeader = require('../../../common/ComponentHeader');

describe('BankDetails', () => {
	let instance;
	let component;
	let result;

	let content = {
		bankDetailsAccountNumber: 'bankDetailsAccountNumber',
		bankDetailsSortCode: 'bankDetailsSortCode',
		directDebitTitle: 'directDebitTitle',
		setUpDirectDebit: 'setUpDirectDebit',
	};

	let data = {
		mortgageOrRentExpenditure: 'mortgageOrRentExpenditure',
		expenditureOther: 'expenditureOther',
	};

	const accountNo = {
		name:"bankDetailsAccountNumber",
		defaultValue: data.bankDetailsAccountNumber,
		dataAnchor:"bank-details-account-number",
		label: 'bankDetailsAccountNumber',
		length: 8,
	};
	const sortCode = {
		name:"bankDetailsSortCode",
		defaultValue: data.bankDetailsSortCode,
		dataAnchor:"bank-details-sort-code",
		label: 'Main bank account sort code',
		length: 6,
	};

	let props = {
		group: 'test',
		data: data,
		content: content,
		onChange: () => {},
		validations: {},
		accountNo,
		sortCode,
	};


	beforeEach(() => {
		component = (
			<DirectDebit {...props} />
		);
		instance = render(component);
		shallowRenderer.render(component);
		result = shallowRenderer.getRenderOutput();
	});

	it('should be defined', () => {
		expect(instance).toBeDefined();
	});

	it('should render a header', () => {
		expect(result.props.children).toEqualJSX(
			<ComponentHeader
				title="directDebitTitle"
				titleLevel={2}
				hasSeparator={true}
			>
				{result.props.children.props.children}
			</ComponentHeader>
		);
	});


	it('should render setup direct debit question', () => {
		expect(result).toIncludeJSX(
			<RadioQuestion
				defaultValue={undefined}
				group={props.group}
				labelText={'setUpDirectDebit'}
				name="setUpDirectDebit"
				onChange={props.onChange}
				options={[{ value: 'No' }, { value: 'Yes' }]}
				required
			/>
		);
	});


});

