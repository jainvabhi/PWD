jest.unmock('../CurrentAccount');
jest.unmock('../../employment/GeneralEmploymentDetails');

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const ReactDOM = require('react-dom');

const container = document.createElement('div');
const render = (comp, el) => ReactDOM.render(comp, el || container);
const shallowRenderer = TestUtils.createRenderer();

const CurrentAccount = require('../CurrentAccount');
const { BundledAccount } = CurrentAccount;

const BrandUtils = require('../../../../utils/BrandUtils');
const AccountOpeningActions = require('../../../../actions/AccountOpeningActions');

const SectionFullWidth = require('../../../common/SectionFullWidth.jsx');
const { IncomeDetails } = require('../IncomeDetails');
const Expenditure = require('../Expenditure');
const CurrentAccountPaymentInfoSection = require('../CurrentAccountPaymentInfoSection');
const SavingsAccountPaymentInfoSection = require('../SavingsAccountPaymentInfoSection');
const GeneralEmploymentDetails = require('../../employment/GeneralEmploymentDetails');

describe('CurrentAccount', () => {
	let instance;
	let component;
	let result;

	let content = {
			};

	let data = {
		product: { supportsOverdraft: false }
	};

	let props = {
		group: '',
		data: data,
		content: content,
		onChange: () => {},
		onIncomeDetailsSectionChange: () => {},
		onNationalitySectionChange: () => {},
	};


	describe('standard', () => {
		beforeEach(() => {
			component = (
				<CurrentAccount {...props} />
			);
			instance = render(component);
			shallowRenderer.render(component);
			result = shallowRenderer.getRenderOutput();
		});

		it('should be defined', () => {
			expect(instance).toBeDefined();
		});

		it('should render correctly', () => {
			expect(result).toEqualJSX(
				<div>
					<GeneralEmploymentDetails {...props} />
					<SectionFullWidth id="income-details">
						<IncomeDetails
							onChange={() => {}}
							showCurrentAccountPaymentInfo={true}
							{...props}
						/>
					</SectionFullWidth>

					<SectionFullWidth id="outgoings-details">
						<Expenditure
							onChange={() => {}}
							{...props}
						/>
					</SectionFullWidth>
				</div>
			);
		});
	});

	describe('bundled', () => {
		beforeEach(() => {
			BrandUtils.isAbleToDisplay.mockReturnValue(true);
			component = (
				<CurrentAccount {...props} />
			);
			instance = render(component);
			shallowRenderer.render(component);
			result = shallowRenderer.getRenderOutput();
		});

		it('should be defined', () => {
			expect(instance).toBeDefined();
		});

		it('should render correctly', () => {
			expect(result).toEqualJSX(
				<div>
					<GeneralEmploymentDetails {...props} />
					<SectionFullWidth id="income-details">
						<IncomeDetails
							onChange={() => {}}
							showCurrentAccountPaymentInfo={false}
							{...props}
						/>
					</SectionFullWidth>

					<SectionFullWidth id="outgoings-details">
						<Expenditure
							onChange={() => {}}
							{...props}
						/>
					</SectionFullWidth>

					<BundledAccount
						onChange={() => {}}
						{...props}
					/>
				</div>
			);
		});
	});

});
