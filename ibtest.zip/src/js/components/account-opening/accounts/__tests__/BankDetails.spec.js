jest.autoMockOff();

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const ReactDOM = require('react-dom');
const _ = require('lodash');

const container = document.createElement('div');
const render = (comp, el) => ReactDOM.render(comp, el || container);
const shallowRenderer = TestUtils.createRenderer();

const config = require('../../../../config');
const BankDetails = require('../BankDetails');
const AccountDetails = require('../AccountDetails');
const { MultiDropdownQuestion, DropdownQuestion } = require('../../../common/questionsets');
const ComponentHeader = require('../../../common/ComponentHeader');

describe('BankDetails', () => {
	let instance;
	let component;
	let result;

	let content = {
		expenditureSectionTitle: 'expenditureSectionTitle',
		mortgageOrRentExpenditure: 'mortgageOrRentExpenditure',
		expenditureOther: 'expenditureOther',
		bankDetailsAccountNumber: 'bankDetailsAccountNumber',
		bankDetailsSortCode: 'bankDetailsSortCode',
		bankDetailsTitle: 'bankDetailsTitle',
		setUpDirectDebit: 'setUpDirectDebit',
		lengthOfTimeAtBank: 'lengthOfTimeAtBank',
		bankDetailsLookupError: 'bankDetailsLookupError',
	};

	let data = {
		mortgageOrRentExpenditure: 'mortgageOrRentExpenditure',
		expenditureOther: 'expenditureOther',
	};

	const accountNo = {
		name:"bankDetailsAccountNumber",
		defaultValue: data.bankDetailsAccountNumber,
		dataAnchor:"bank-details-account-number",
		label: 'Main bank account number',
		length: 8,
	};
	const sortCode = {
		name:"bankDetailsSortCode",
		defaultValue: data.bankDetailsSortCode,
		dataAnchor:"bank-details-sort-code",
		label: 'Main bank account sort code',
		length: 6,
	};

	let props = {
		group: 'test',
		name:'bankDetails',
		data: data,
		content: content,
		onChange: () => {},
		validations: {},
		accountNo,
		sortCode,
		bankDetails: {
			main:null,
		},
		session: {}
	};


	beforeEach(() => {
		component = (
			<BankDetails {...props} />
		);
		instance = render(component);
		shallowRenderer.render(component);
		result = shallowRenderer.getRenderOutput();
	});

	it('should be defined', () => {
		expect(instance).toBeDefined();
	});

	it('should render a header', () => {
		expect(result.props.children).toEqualJSX(
			<ComponentHeader
				title={'bankDetailsTitle'}
				titleLevel={2}
				hasSeparator={true}
			>
				{result.props.children.props.children}
			</ComponentHeader>
		);
	});


	it('should render account details component', () => {
		expect(result.props.children.props.children[1]).toEqual(
			<AccountDetails type="main" {...props} />
		);
	});


	it('should render bank length question', () => {
		expect(result).toIncludeJSX(
			<MultiDropdownQuestion
				group={props.group}
				onChange={props.onChange}
				dataAnchor="bank-details-length-time"
				data={[
					{
						range: _.range(0, 100),
						name: 'lengthOfTimeBankYears',
						valueSuffix: function noRefCheck() {},
					},
					{
						range: _.range(0, 12),
						name: 'lengthOfTimeBankMonths',
						valueSuffix: function noRefCheck() {},
					},

				]}
				defaultValues={[
					props.data.lengthOfTimeBankYears, props.data.lengthOfTimeBankMonths,
				]}
			>
				{'lengthOfTimeAtBank'}
			</MultiDropdownQuestion>
		);
	});

	it('should render payment date', () => {
		expect(result).toIncludeJSX(
			<DropdownQuestion
				name={'paymentDate'}
				group={props.group}
				data={config.directDebitPaymentDates}
				onChange={props.onChange}
				defaultValue={props.data.paymentDate}
				dataAnchor={'direct-debit-payment-date'}
				required
			>
				{props.content.directDebitPaymentDates}
			</DropdownQuestion>

		);
	});



});
