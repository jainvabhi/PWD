/**
 * @module DirectDebit
 */

const React = require('react');
const { PropTypes } = React;

const AccountDetails = require('./AccountDetails');
const ComponentHeader = require('../../common/ComponentHeader');

const BankDetailsActions = require('../../../actions/BankDetailsActions');
const AccountOpeningActions = require('../../../actions/AccountOpeningActions');

const {
	TextQuestion,
	RadioQuestion,
	CurrencyQuestion,
	CheckBoxQuestion,
 } = require('../../common/questionsets');

const ManualBankDetails = props => {
	const accountNo = {
		name: 'directDebitAccountNumber',
		value: props.data.directDebitAccountNumber,
		dataAnchor: 'direct-debit-account-number',
		label: props.content.directDebitAccountNumber,
	};
	const sortCode = {
		name:'directDebitSortCode',
		value: props.data.directDebitSortCode,
		dataAnchor: 'direct-debit-sort-code',
		label: props.content.directDebitSortCode,
	};
	return (
		<AccountDetails
			type="directDebit"
			name="directDebitBankDetails"
			accountNo={accountNo}
			sortCode={sortCode}
			{...props}
		/>
	);
};

ManualBankDetails.propTypes = {
	group: PropTypes.string.isRequired,
	onChange: PropTypes.func.isRequired,
	data: PropTypes.object.isRequired,
	content: PropTypes.object.isRequired,
};

const CoreSetupQuestions = props => {
	return (
		<div>
			<RadioQuestion
				align="left"
				defaultValue={props.data.useBankDetails}
				group={props.group}
				key="useBankDetails"
				labelText={props.content.useBankDetails}
				name="useBankDetails"
				onChange={props.onChange}
				options={[{ value: 'No' }, { value: 'Yes' }]}
				required
			/>

			<TextQuestion
				name="directDebitAccountName"
				group={props.group}
				onChange={props.onChange}
				defaultValue={props.data.directDebitAccountName}
				dataAnchor="direct-debit-account-name"
				validateType="alpha"
				maxLength={50}
				required
			>
				{props.content.directDebitAccountName}
			</TextQuestion>

			{props.data.useBankDetails === 'No' && <ManualBankDetails {...props} />}

			<RadioQuestion
				align="left"
				defaultValue={props.data.howToPay}
				group={props.group}
				key="howToPay"
				labelText={props.content.howToPay}
				name="howToPay"
				classNameBtnDiv={'stacked'}
				onChange={props.onChange}
				options={[{ value: 'Full balance' }, { value: 'Minimum amount' }, { value: 'Fixed amount' }]}
				blockList
				required
			/>
			{props.data.howToPay === 'Fixed amount' && <CurrencyQuestion
				name="directDebitPaymentAmount"
				group={props.group}
				onChange={props.onChange}
				defaultValue={props.data.directDebitPaymentAmount}
				dataAnchor="payment-amount"
				maxLength={6}
				validateGreaterThan={1}
				required
			>
				{props.content.directDebitPaymentAmount}
			</CurrencyQuestion>}

			<CheckBoxQuestion
				defaultValue={props.data.directDebitAcceptTsAndCs}
				group={props.group}
				name="directDebitAcceptTsAndCs"
				dataAnchor="direct-debit-terms-and-conditions"
				onChange={props.onChange}
				required
			>
				{props.content.directDebitAcceptTsAndCs}
			</CheckBoxQuestion>
		</div>
	);
};

CoreSetupQuestions.propTypes = {
	group: PropTypes.string.isRequired,
	onChange: PropTypes.func.isRequired,
	data: PropTypes.object.isRequired,
	content: PropTypes.object.isRequired,
};


const resetDirectDebitData = (key, value, onChange) => {
	if (value === 'No') {
		AccountOpeningActions.updateFormValues([
			{ key: 'directDebitAcceptTsAndCs', value: undefined },
			{ key: 'useBankDetails', value: undefined },
			{ key: 'directDebitAccountName', value: undefined },
			{ key: 'howToPay', value: undefined },
			{ key: 'directDebitPaymentAmount', value: undefined },
			{ key: 'directDebitAccountNumber', value: undefined },
			{ key: 'directDebitSortCode', value: undefined },
		]);

		BankDetailsActions.resetBankDetails('directDebit');
	}

	onChange(key, value);
};

const DirectDebit = props => {
	return (
		<div>
			<ComponentHeader
				title={props.content.directDebitTitle}
				titleLevel={2}
				hasSeparator
			>
				<p>{props.content.setUpDirectDebitIntro}</p>
				<RadioQuestion
					defaultValue={props.data.setUpDirectDebit}
					group={props.group}
					key="setUpDirectDebit"
					labelText={props.content.setUpDirectDebit}
					name="setUpDirectDebit"
					onChange={(key, val) => {
						resetDirectDebitData(key, val, props.onChange);
					}}
					options={[{ value: 'No' }, { value: 'Yes' }]}
					required
				/>
				{props.data.setUpDirectDebit === 'Yes' && <CoreSetupQuestions {...props} />}

			</ComponentHeader>
		</div>
	);
};

DirectDebit.propTypes = {
	group: PropTypes.string.isRequired,
	onChange: PropTypes.func.isRequired,
	data: PropTypes.object.isRequired,
	content: PropTypes.object.isRequired,
};

module.exports = DirectDebit;
