/**
 * @module AccountDetails
 */

const React = require('react');
const _ = require('lodash');
const { PropTypes } = React;
const cx = require('classnames');

const RegexUtils = require('../../../utils/RegexUtils');

const BankDetailsActions = require('../../../actions/BankDetailsActions');

const { TextQuestion } = require('../../common/questionsets');
const ErrorMessage = require('../../common/ErrorMessage');
const FormRow = require('../../common/FormRow');

const inValidBank = props => props.bankDetails[props.type] && props.bankDetails[props.type].inValid;

const isValidBank = props => inValidBank(props) === undefined || inValidBank(props) === null;

const checkValidation = (props, state) => {
	const isValid = RegexUtils.isValid(props.accountNo.value, RegexUtils.regexes.accountNo) && RegexUtils.isValid(props.sortCode.value, RegexUtils.regexes.sortCode);
	const newDetails = props.accountNo.value !== state.accountNo || props.sortCode.value !== state.sortCode;
	if (isValid && newDetails) {
		BankDetailsActions.getBankDetails(props.type, props.accountNo.value, props.sortCode.value);

		return {
			accountNo: props.accountNo.value,
			sortCode: props.sortCode.value,
		};
	}
};

const AccountDetails = React.createClass({
	propTypes: {
		type: PropTypes.string.isRequired,
		name: PropTypes.string.isRequired,
		group: PropTypes.string.isRequired,
		onChange: PropTypes.func.isRequired,
		accountNo: PropTypes.object.isRequired,
		session: PropTypes.object.isRequired,
		data: PropTypes.object.isRequired,
		sortCode: PropTypes.object.isRequired,
		validations: PropTypes.object.isRequired,
		bankDetails: PropTypes.object.isRequired,
		content: PropTypes.shape({
			bankDetailsLookupError: PropTypes.string.isRequired,
		}),
	},

	getInitialState() {
		return {};
	},

	componentWillReceiveProps(nextProps) {
		if (this.props.accountNo.value !== nextProps.accountNo.value || this.props.sortCode.value !== nextProps.sortCode.value) {
			const fetchedProps = checkValidation(nextProps, this.state);

			if (fetchedProps) {
				this.setState(fetchedProps);
			}
		}

		if (process.env.NODE_ENV === 'development') {
			// auto fetch when using a stub
			if (this.props.data.isStub && _.isEmpty(this.state)) {
				const bankState = checkValidation(nextProps, this.state);
				if (bankState) { this.setState(bankState); }
			}
		}
	},

	onChange(name, value) {
		this.props.onChange(this.props.name, !inValidBank(this.props));
		this.props.onChange(name, value);
	},

	render() {
		const inputClass = cx({
			error: inValidBank(this.props),
		});

		return (
			<div>
				<TextQuestion
					inputClassName={inputClass}
					name={this.props.accountNo.name}
					key={this.props.accountNo.name}
					dataAnchor={this.props.accountNo.dataAnchor}
					defaultValue={this.props.accountNo.value}
					group={this.props.group}
					onChange={this.onChange}
					minLength={8}
					maxLength={8}
					validateType="number"
					required
				>
					{this.props.accountNo.label}
				</TextQuestion>
				<TextQuestion
					inputClassName={inputClass}
					name={this.props.sortCode.name}
					key={this.props.sortCode.name}
					dataAnchor={this.props.sortCode.dataAnchor}
					defaultValue={this.props.sortCode.value}
					group={this.props.group}
					onChange={this.onChange}
					minLength={6}
					maxLength={6}
					validateType="number"
					required
				>
					{this.props.sortCode.label}
				</TextQuestion>
				<FormRow extraClasses="bank-details-error">
					<div role="alert" aria-live="assertive">
						<ErrorMessage text={this.props.content.bankDetailsLookupError} visible={!isValidBank(this.props)} />
					</div>
				</FormRow>
			</div>
		);
	},
});

module.exports = AccountDetails;
