/**
 * @module IncomeDetails
 */

const React = require('react');
const { PropTypes } = React;

const config = require('../../../config');

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');
const CurrentAccountPaymentInfo = require('./CurrentAccountPaymentInfo');
const ComponentHeader = require('../../common/ComponentHeader');

const ContentUtils = require('../../../utils/ContentUtils');

const {
	DropdownQuestion,
	RadioQuestion,
	CurrencyQuestion,
} = require('../../common/questionsets');

const isCreditCard = props => props.data.product.productType.name === 'credit-card';

const AdditionalIncome = props => {
	return (
		<div>
			<CurrencyQuestion
				name="incomeOtherAmount"
				group={props.group}
				onChange={props.onChange}
				defaultValue={props.data.incomeOtherAmount}
				dataAnchor="income-other-received"
				required
			>
				{props.content.incomeOtherAmount}
			</CurrencyQuestion>
			<DropdownQuestion
				name="incomeOtherFrequencyOptions"
				group={props.group}
				data={config.formOptionsOtherIncomeFrequency}
				onChange={props.onChange}
				defaultValue={props.data.incomeOtherFrequencyOptions}
				dataAnchor="income-other-frequency"
				required
			>
				{props.content.incomeOtherFrequency}
			</DropdownQuestion>

		</div>
	);
};

AdditionalIncome.propTypes = {
	group: PropTypes.string.isRequired,
	onChange: PropTypes.func.isRequired,
	data: PropTypes.object.isRequired,
	content: PropTypes.object.isRequired,
};

const resetIncomeReductionData = (key, value, onChange) => {
	if (value === 'No') {
		AccountOpeningActions.updateFormValues([
			{ key: 'revisedGrossAnnualIncome', value: undefined },
			{ key: 'revisedNetMonthlyIncome', value: undefined },
		]);
	}

	onChange(key, value);
};

const IncomeReduction = props => {
	return (
		<div>
			<RadioQuestion
				align="left"
				defaultValue={props.data.hasIncomeReduction}
				group={props.group}
				key="hasIncomeReduction"
				labelText={ContentUtils.getProductContent('hasIncomeReduction', props.content, props.data.productCode)}
				name="hasIncomeReduction"
				dataAnchor="hasIncomeReduction"
				onChange={(key, val) => {
					resetIncomeReductionData(key, val, props.onChange);
				}}
				options={[{ value: 'No' }, { value: 'Yes' }]}
				required
			/>
			{props.data.hasIncomeReduction === 'Yes' && <IncomeRevision {...props} />}
		</div>
	);
};

IncomeReduction.propTypes = {
	group: PropTypes.string.isRequired,
	onChange: PropTypes.func.isRequired,
	data: PropTypes.object.isRequired,
	content: PropTypes.object.isRequired,
	incomeRevisionValidator: PropTypes.func,
};

const IncomeRevision = props => {
	return (
		<div>
			<CurrencyQuestion
				name="revisedGrossAnnualIncome"
				group={props.group}
				onChange={props.onChange}
				defaultValue={props.data.revisedGrossAnnualIncome}
				dataAnchor="revised-annual-income"
				required
			>
				{props.content.revisedGrossAnnualIncome}
			</CurrencyQuestion>
			<CurrencyQuestion
				name="revisedNetMonthlyIncome"
				group={props.group}
				onChange={props.onChange}
				defaultValue={props.data.revisedNetMonthlyIncome}
				dataAnchor="revised-monthly-income"
				customValidator={() => props.incomeRevisionValidator(props.data.revisedGrossAnnualIncome, props.data.revisedNetMonthlyIncome)}
				required
			>
				{props.content.revisedNetMonthlyIncome}
			</CurrencyQuestion>
		</div>
	);
};

IncomeRevision.propTypes = {
	group: PropTypes.string.isRequired,
	onChange: PropTypes.func.isRequired,
	data: PropTypes.object.isRequired,
	content: PropTypes.object.isRequired,
	incomeRevisionValidator: PropTypes.func,
};

const IncomeDetails = React.createClass({

	propTypes: {
		group: PropTypes.string.isRequired,
		content: PropTypes.object.isRequired,
		data: PropTypes.object.isRequired,
		showCurrentAccountPaymentInfo: PropTypes.bool,
		onChange: PropTypes.func.isRequired,
		netMonthlyIncomeValidator: PropTypes.func.isRequired,
		incomeRevisionValidator: PropTypes.func.isRequired,
	},

	getDefaultProps() {
		return {
			showCurrentAccountPaymentInfo: false,
		};
	},

	render() {
		const shouldShowReduction = isCreditCard(this.props);
		return (
			<div>
				<ComponentHeader
					title={this.props.content.incomeSectionTitle}
					titleLevel={2}
					hasSeparator
				>
					{isCreditCard(this.props) && <p>{this.props.content.incomeIntro}</p>}
					<CurrencyQuestion
						name="grossAnnualIncome"
						group={this.props.group}
						onChange={this.props.onChange}
						defaultValue={this.props.data.grossAnnualIncome}
						dataAnchor="income-annual"
						required
					>
						{this.props.content.grossAnnualIncome}
					</CurrencyQuestion>
					<CurrencyQuestion
						name="netMonthlyIncome"
						group={this.props.group}
						onChange={this.props.onChange}
						defaultValue={this.props.data.netMonthlyIncome}
						dataAnchor="income-monthly"
						customValidator={() => this.props.netMonthlyIncomeValidator(this.props.data.grossAnnualIncome, this.props.data.netMonthlyIncome)}
						required
					>
						{this.props.content.netMonthlyIncome}
					</CurrencyQuestion>
					{!shouldShowReduction && <RadioQuestion
						defaultValue={this.props.data.hasAdditionalIncome}
						group={this.props.group}
						labelText={this.props.content.hasAdditionalIncome}
						name="hasAdditionalIncome"
						onChange={this.props.onChange}
						options={[{
							anchor: 'income-other-sources-no',
							value: 'No',
						}, {
							anchor: 'income-other-sources-yes',
							value: 'Yes',
						}]}
						required
					/>}

				</ComponentHeader>

				{this.props.data.hasAdditionalIncome === 'Yes' && !isCreditCard(this.props) && <AdditionalIncome {...this.props} />}

				{this.props.showCurrentAccountPaymentInfo && <CurrentAccountPaymentInfo
					{...this.props}
				/>}

				{shouldShowReduction &&
					<IncomeReduction
						incomeRevisionValidator={this.props.incomeRevisionValidator}
						{...this.props}
					/>}
			</div>

		);
	},
});


module.exports = {
	IncomeReduction,
	IncomeDetails,
};
