const React = require('react');
const { PropTypes } = React;

const config = require('../../../config');

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');

const BrandUtils = require('../../../utils/BrandUtils');

const SectionFullWidth = require('../../common/SectionFullWidth.jsx');
const { IncomeDetails } = require('./IncomeDetails');
const IncomeHandler = require('./IncomeHandler');
const Expenditure = require('./Expenditure');
const GeneralEmploymentDetails = require('../employment/GeneralEmploymentDetails');
const CurrentAccountPaymentInfoSection = require('./CurrentAccountPaymentInfoSection');
const SavingsAccountPaymentInfoSection = require('./SavingsAccountPaymentInfoSection');

const { Overdrafts } = require('../overdrafts');

const { DropdownQuestion, CurrencyQuestion } = require('../../common/questionsets');

const BundledAccount = props => {
	return (
		<div>
			<SectionFullWidth id="current-account-details">
				<CurrentAccountPaymentInfoSection
					group={props.group}
					onChange={props.onChange}
					{...props}
				/>
			</SectionFullWidth>

			<SectionFullWidth id="savings-account-details">
				<SavingsAccountPaymentInfoSection
					{...props}
				/>
					<CurrencyQuestion
						name="incomeOtherSavingsAmount"
						group={props.group}
						onChange={props.onChange}
						defaultValue={props.data.incomeOtherSavingsAmount}
						dataAnchor="income-other-savings-amount"
						required
					>
						{props.content.incomeOtherSavingsAmount}
					</CurrencyQuestion>
					<DropdownQuestion
						name="incomeOtherSavingsFrequency"
						group={props.group}
						data={config.formOptionsSavingsFrequency}
						onChange={props.onChange}
						defaultValue={props.data.incomeOtherSavingsFrequency}
						dataAnchor="income-other-savings-frequency"
						required
					>
						{props.content.incomeOtherSavingsFrequency}
					</DropdownQuestion>
			</SectionFullWidth>
		</div>
	);
};

BundledAccount.propTypes = {
	data: PropTypes.object.isRequired,
	content: PropTypes.object.isRequired,
	onChange: PropTypes.func.isRequired,
	group: PropTypes.string.isRequired,
};

const CurrentAccount = props => {
	// NOTE: This can become a product based switch
	const supportsBundled = BrandUtils.isAbleToDisplay('contains-additional-savings-account-payment-info');
	return (
		<div>
			<GeneralEmploymentDetails {...props} />
			<SectionFullWidth id="income-details">
				<IncomeDetails
					onChange={props.onIncomeDetailsSectionChange}
					showCurrentAccountPaymentInfo={!supportsBundled}
					{...props}
				/>
			</SectionFullWidth>

			<SectionFullWidth id="outgoings-details">
				<Expenditure
					onChange={AccountOpeningActions.updateFormValue}
					{...props}
				/>
			</SectionFullWidth>

			{props.data.product.supportsOverdraft && props.data.subType !== 'JOINT' && <Overdrafts
				onChange={AccountOpeningActions.updateFormValue}
				{...props}
			/>}

			{supportsBundled && <BundledAccount
				onChange={AccountOpeningActions.updateFormValue}
				{...props}
			/>}
		</div>
	);
};

CurrentAccount.propTypes = {
	group: PropTypes.string.isRequired,
	data: PropTypes.object.isRequired,
	onIncomeDetailsSectionChange: PropTypes.func.isRequired,
};

module.exports = IncomeHandler(CurrentAccount);
module.exports.BundledAccount = BundledAccount;
