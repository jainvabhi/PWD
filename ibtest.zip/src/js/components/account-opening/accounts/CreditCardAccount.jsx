const React = require('react');
const { PropTypes } = React;

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');

const GeneralEmploymentDetails = require('../employment/GeneralEmploymentDetails');

const SectionFullWidth = require('../../common/SectionFullWidth.jsx');
const { IncomeDetails } = require('./IncomeDetails');
const IncomeHandler = require('./IncomeHandler');
const BankDetails = require('./BankDetails');
const Expenditure = require('./Expenditure');
const CreditExpenditure = require('./CreditExpenditure');
const DirectDebit = require('./DirectDebit');

const CreditCardAccount = props => {
	return (
		<div>

			<GeneralEmploymentDetails
				taxExempt
				citizenshipOnly
				{...props}
			/>
			<SectionFullWidth id="income-details">
				<IncomeDetails
					onChange={props.onIncomeDetailsSectionChange}
					{...props}
				/>
			</SectionFullWidth>

			<SectionFullWidth id="outgoings-details">
				<Expenditure
					onChange={AccountOpeningActions.updateFormValue}
					{...props}

				>
					<CreditExpenditure
						onChange={AccountOpeningActions.updateFormValue}
						{...props}
					/>
				</Expenditure>
			</SectionFullWidth>
			<SectionFullWidth id="bank-details">
				<BankDetails
					onChange={AccountOpeningActions.updateFormValue}
					{...props}
				/>
			</SectionFullWidth>
			<SectionFullWidth id="direct-debit">
				<DirectDebit
					onChange={AccountOpeningActions.updateFormValue}
					{...props}
				/>
			</SectionFullWidth>
		</div>
	);
};

CreditCardAccount.propTypes = {
	data: PropTypes.object.isRequired,
	group: PropTypes.string.isRequired,
	onIncomeDetailsSectionChange: PropTypes.func.isRequired,
};

module.exports = IncomeHandler(CreditCardAccount);
