const React = require('react');
const { PropTypes } = React;
const config = require('../../../config');
const HelpMessage = require('../../common/HelpMessage');
const FormRow = require('../../common/FormRow');
const AccountOpeningActions = require('../../../actions/AccountOpeningActions');

const { DropdownQuestion, CurrencyQuestion } = require('../../common/questionsets');

const CashISAAMLQuestions = props => (
	<span>
		<DropdownQuestion
			name="incomeOtherSavingsTypeOptions"
			group={props.group}
			data={config.formOptionsIncomeOtherPaymentCashISAType}
			onChange={AccountOpeningActions.updateFormValue}
			defaultValue={props.data.incomeOtherSavingsTypeOptions}
			dataAnchor="income-other-savings-type"
			required
		>
			{props.content.incomeOtherSavingsTypeOptions}
		</DropdownQuestion>
		{props.data.product.savingUpHelp && <FormRow extraClasses="question-assist-message-container"><HelpMessage extraClasses="question-assist-message" text={props.content.helpBuySavingUpAssistance} /></FormRow>}
		<CurrencyQuestion
			name="incomeOtherSavingsAmount"
			group={props.group}
			onChange={AccountOpeningActions.updateFormValue}
			defaultValue={props.data.incomeOtherSavingsAmount}
			dataAnchor="income-other-savings-amount"
			required
		>
			{props.content.incomeOtherSavingsAmount}
		</CurrencyQuestion>
		<DropdownQuestion
			name="incomeOtherSavingsFrequency"
			group={props.group}
			data={config.formOptionsSavingsFrequency}
			onChange={AccountOpeningActions.updateFormValue}
			defaultValue={props.data.incomeOtherSavingsFrequency}
			dataAnchor="income-other-savings-frequency"
			required
		>
			{props.content.incomeOtherSavingsFrequency}
		</DropdownQuestion>
	</span>
);

CashISAAMLQuestions.propTypes = {
	group: PropTypes.string.isRequired,
	data: PropTypes.shape({
		incomeOtherSavingsTypeOptions: PropTypes.arrayOf(PropTypes.string),
		incomeOtherSavingsAmount: PropTypes.number,
		incomeOtherSavingsFrequency: PropTypes.string,
		product: PropTypes.shape({
			savingUpHelp: PropTypes.string,
		}),
	}),
	content: PropTypes.shape({
		incomeOtherSavingsTypeOptions: PropTypes.string,
		incomeOtherSavingsAmountBond: PropTypes.string,
		incomeOtherSavingsFrequency: PropTypes.string,
		helpBuySavingUpAssistance: PropTypes.string,
		incomeOtherSavingsAmount: PropTypes.string,
	}),
};

module.exports = CashISAAMLQuestions;
