/**
 * @module CreditExpenditure
 */

const React = require('react');
const { PropTypes } = React;

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');
const { CurrencyQuestion, RadioQuestion } = require('../../common/questionsets');

const ContentUtils = require('../../../utils/ContentUtils');

const RevisedExpenditure = props => (
	<div>
		<CurrencyQuestion
			name="revisedMortgageOrRentExpenditure"
			group={props.group}
			onChange={props.onChange}
			defaultValue={props.data.revisedMortgageOrRentExpenditure}
			dataAnchor="revised-expenditure-housing"
			required
		>
			{ContentUtils.getProductContent('revisedMortgageOrRentExpenditure', props.content, props.data.productCode)}
		</CurrencyQuestion>
		<CurrencyQuestion
			name="revisedExpenditureOther"
			group={props.group}
			onChange={props.onChange}
			defaultValue={props.data.revisedExpenditureOther}
			dataAnchor="revised-expenditure-other"
			required
		>
			{ContentUtils.getProductContent('revisedExpenditureOther', props.content, props.data.productCode)}
		</CurrencyQuestion>
	</div>
);

RevisedExpenditure.propTypes = {
	group: PropTypes.string.isRequired,
	onChange: PropTypes.func.isRequired,
	data: PropTypes.object.isRequired,
	content: PropTypes.object.isRequired,
};

const resetChangeOfCircumstancesData = (key, value, onChange) => {
	if (value === 'No') {
		AccountOpeningActions.updateFormValues([
			{ key: 'revisedMortgageOrRentExpenditure', value: undefined },
			{ key: 'revisedExpenditureOther', value: undefined },
		]);
	}

	onChange(key, value);
};

const CreditExpenditure = props => (
	<div>
		<RadioQuestion
			align="left"
			defaultValue={props.data.changeOfCircumstances}
			group={props.group}
			key="changeOfCircumstances"
			labelText={ContentUtils.getProductContent('changeOfCircumstances', props.content, props.data.productCode)}
			name="changeOfCircumstances"
			onChange={(key, val) => {
				resetChangeOfCircumstancesData(key, val, props.onChange);
			}}
			options={[{ value: 'No' }, { value: 'Yes' }]}
			required
		/>

		{props.data.changeOfCircumstances === 'Yes' && <RevisedExpenditure {...props} />}
	</div>
);

CreditExpenditure.propTypes = {
	group: PropTypes.string.isRequired,
	content: PropTypes.object.isRequired,
	data: PropTypes.object.isRequired,
	onChange: PropTypes.func.isRequired,
};

module.exports = CreditExpenditure;
