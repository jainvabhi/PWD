/**
 * @module Expenditure
 */

const React = require('react');
const { PropTypes } = React;

const ComponentHeader = require('../../common/ComponentHeader');
const { CurrencyQuestion } = require('../../common/questionsets');
const FormRow = require('../../common/FormRow');
const HelpMessage = require('../../common/HelpMessage');

const isJoint = subType => subType === 'JOINT';

const Expenditure = props => (
	<div>
		<ComponentHeader
			title={props.content.expenditureSectionTitle}
			titleLevel={2}
			hasSeparator
		>
			{isJoint(props.data.subType) && <FormRow extraClasses="question-assist-message-container"><HelpMessage extraClasses="question-assist-message" text={props.content.jointAccountExpenditureHelp} /></FormRow>}

			<CurrencyQuestion
				name="mortgageOrRentExpenditure"
				group={props.group}
				onChange={props.onChange}
				defaultValue={props.data.mortgageOrRentExpenditure}
				dataAnchor="expenditure-housing"
				required
			>
				{props.content.mortgageOrRentExpenditure}
			</CurrencyQuestion>
			<CurrencyQuestion
				name="expenditureOther"
				group={props.group}
				onChange={props.onChange}
				defaultValue={props.data.expenditureOther}
				dataAnchor="expenditure-other"
				required
			>
				{props.content.expenditureOther}
			</CurrencyQuestion>
			{props.children}
		</ComponentHeader>
	</div>
);

Expenditure.propTypes = {
	group: PropTypes.string.isRequired,
	content: PropTypes.object.isRequired,
	data: PropTypes.object.isRequired,
	children: PropTypes.object,
	onChange: PropTypes.func.isRequired,
};

module.exports = Expenditure;
