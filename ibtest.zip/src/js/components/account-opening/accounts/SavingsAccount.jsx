const React = require('react');
const { PropTypes } = React;

const SectionFullWidth = require('../../common/SectionFullWidth.jsx');
const SavingsAccountPaymentInfoSection = require('./SavingsAccountPaymentInfoSection');
const GeneralEmploymentDetails = require('../employment/GeneralEmploymentDetails');
const SavingsAMLQuestions = require('./SavingsAMLQuestions');
const BondIssueAMLQuestions = require('./BondIssueAMLQuestions');

const amlQuestions = {
	bond: props => (<BondIssueAMLQuestions {...props} />),
	default: props => (<SavingsAMLQuestions {...props} />),
};

const SavingsAccount = React.createClass({

	propTypes: {
		data: PropTypes.object.isRequired,
		content: PropTypes.object.isRequired,
		group: PropTypes.string.isRequired,
	},

	render() {
		return (
			<div>
				<GeneralEmploymentDetails {...this.props} />
				<SectionFullWidth id="savings-account-details">
					<hr />
					<SavingsAccountPaymentInfoSection
						{...this.props}
					/>
					{ amlQuestions[this.props.data.product.amlQuestionSet](this.props) }
				</SectionFullWidth>
			</div>
		);
	},
});


module.exports = SavingsAccount;
