/**
 * @module OfferPage
 */

const React = require('react');
const Helmet = require('react-helmet');
const _ = require('lodash');
const { PropTypes } = React;

const AccountOpeningActions = require('../../actions/AccountOpeningActions');
const AnalyticsActionCreator = require('../../actions/AnalyticsActionCreator');
const AccountOpeningConstants = require('../../constants/AccountOpeningConstants');

const AltProducts = require('./offer/AltProducts');
const BasicOffer = require('./offer/BasicOffer');
const CreditCardOffer = require('./offer/CreditCardOffer');
const OverdraftOffer = require('./offer/OverdraftOffer');

const PageHeader = require('../common/PageHeader');
const LoadingSpinner = require('../LoadingSpinner');


const BrandUtils = require('../../utils/BrandUtils');
const ProductUtils = require('../../utils/ProductUtils');
const ScreenshotUtils = require('../../utils/ScreenshotUtils');
const { DocumentFetcher } = require('../../documents');


const isOverdraftOffer = (offer, product) => offer && offer.features.credit_limit && product.productType.name === 'current';
const isCreditCard = product => product.productType.name === 'credit-card';

const { getProductCode } = ProductUtils;

const OfferPage = React.createClass({

	propTypes: {
		appData: PropTypes.object,
		data: PropTypes.shape({
			productOffer: PropTypes.object,
			productCode: PropTypes.string,
			caseId: PropTypes.string,
			bankID: PropTypes.string,
			offerAcceptFullTCs: PropTypes.bool,
			isDownGraded: PropTypes.bool,
			isAltProduct: PropTypes.bool,
			product: PropTypes.shape({
				productImage: PropTypes.string,
				name: PropTypes.string.isRequired,
				nameSuffix: PropTypes.string.isRequired,
			}),
		}),
		validations: PropTypes.object,
		content: PropTypes.object,
	},

	getInitialState() {
		return {};
	},

	componentDidMount() {
		AccountOpeningActions.requestProductOffer(this.props.data.caseId);

		AnalyticsActionCreator.track({
			path: '/user/experience/view',
			action: 'Appeared',
		}, {
			description: 'PageLoaded',
		});
	},

	componentWillReceiveProps(nextProps) {
		if (nextProps.data.productOffer && isCreditCard(nextProps.data.product)) {
			this.setState({ offers: nextProps.data.productOffer.offers });
		}

		if (nextProps.data.productOffer && !this.props.data.productOffer) {
			const offers = nextProps.data.productOffer.offers;
			const isAltProduct = offers.length > 1 || !!_.filter(offers, offer => {
				return getProductCode(offer.product.code) !== nextProps.data.productCode;
			}).length;
			AccountOpeningActions.updateOfferStatus(isAltProduct);
			this.setState({ offers });
		}
	},

	/**
	 * User has chosen to open/decline an account.
	 *
	 * @param  {Boolean} isDecline				Is decline action
	 * @param  {String} offerId					related offer ID
	 * @param  {String} offerProductCode		code of chosen product offer
	 * @param  {Array} documents 				audit documents
	 */
	onClickActionAccount(isDecline, offerId, offerProductCode, docs, wait = false) {
		if (!offerId) {
			console.warn('No offer available to accept');
			return;
		}

		const action = () => {
			AnalyticsActionCreator.track({
				path: '/user/experience/activity',
				action: 'Interacted',
			}, {
				description: 'UserAcceptsOffer',
				event: 'created',
			});

			AccountOpeningActions.respondToProductOffer(offerId, isDecline, getProductCode(offerProductCode), docs);
			AccountOpeningActions.navigateToWebTask('WEB-SUBMIT-FORM');
		};

		ScreenshotUtils.takeScreenshot(action, this.props.data.caseId, false, wait);
	},

	getOfferType() {
		const group = AccountOpeningConstants.GROUP_OFFER;

		if (isCreditCard(this.props.data.product)) {
			return (
				<CreditCardOffer
					{...this.props}
					offer={_.head(this.state.offers)}
					group={group}
					onClickActionAccount={this.onClickActionAccount}
				/>
			);
		}

		if (isOverdraftOffer(_.head(this.state.offers), this.props.data.product)) {
			return (
				<OverdraftOffer
					{...this.props}
					offer={_.head(this.state.offers)}
					group={group}
					onClickActionAccount={this.onClickActionAccount}
				/>
			);
		}

		if (this.props.data.isAltProduct) {
			return (
				<AltProducts
					{...this.props}
					offers={this.state.offers}
					group={group}
					onClickActionAccount={this.onClickActionAccount}
				/>
			);
		}

		return (
			<BasicOffer
				{...this.props}
				offer={_.head(this.state.offers)}
				group={group}
				onClickActionAccount={this.onClickActionAccount}
			/>
		);
	},

	render() {
		let spinner;

		if (this.props.appData.isApiCallInProgress || !this.state.offers) {
			spinner = <LoadingSpinner centerAlign imgSize={80} />;
		}

		return (
			<div className="account-opening result-page-wrapper offer-page-wrapper container-fluid">
				<Helmet title={this.props.content.offerPageHeader} />
				<PageHeader
					visible={BrandUtils.isAbleToDisplay('result-pages-header')}
					title={`${this.props.content.landingPageTitle}${this.props.data.product.name}${this.props.data.product.nameSuffix}`}
					content={this.props.content}
				/>
				<div className="result-page offer-page" role="main">
					<div className="row text-center">
						<div className="col-xs-12">
							{spinner}
							{this.getOfferType()}
							{!spinner && this.props.data.product.productImage && <div className={this.props.data.product.productImage}></div>}
						</div>
					</div>
				</div>
			</div>
		);
	},
});

module.exports = DocumentFetcher(OfferPage);
