/**
 * @module JointAccountPage
 */

const React = require('react');
const { PropTypes } = React;
const Helmet = require('react-helmet');

const RadioQuestion = require('../common/questionsets/RadioQuestion');
const AccountOpeningConstants = require('../../constants/AccountOpeningConstants');
const ResultSection = require('../common/sections/ResultSection');
const BottomNavigationBox = require('../common/BottomNavigationBox');
const PageHeader = require('../common/PageHeader');
const LinkCode = require('../account-opening/joint/LinkCode');

const RegexUtils = require('../../utils/RegexUtils');
const BrandUtils = require('../../utils/BrandUtils');

const SessionActionCreator = require('../../actions/SessionActionCreator');

const isLinkCodeValid = code => {
	return code && code.length === 6 && RegexUtils.isValid(code, RegexUtils.regexes.number);
};

const JointAccountPage = React.createClass({
	propTypes: {
		appData: PropTypes.object,
		content: PropTypes.shape({
			jointAccountPageHeader: PropTypes.string.isRequired,
			jointAccountPartyPresentNextLabel: PropTypes.string.isRequired,
			jointAccountLinkCodeViewTitle: PropTypes.string.isRequired,
			jointAccountExistingCustomerTitle: PropTypes.string.isRequired,
			jointAccountExistingCustomerTextQuestion: PropTypes.string.isRequired,
			jointAccountExistingCustomerTextQuestionHelp: PropTypes.string.isRequired,
		}),
		data: PropTypes.shape({
			jointLinkCode: PropTypes.string,
		}),
		validations: PropTypes.object,
		hasLinkCodeAsParam: PropTypes.bool.isRequired,
	},

	getInitialState() {
		return {
			nextTaskId: undefined,
			showExistingCustomerQuestion: false,
		};
	},

	componentWillMount() {
		SessionActionCreator.requestAccessTokenReset();
		this.setState({
			showExistingCustomerQuestion: isLinkCodeValid(this.props.data.jointLinkCode) && !this.props.hasLinkCodeAsParam,
		});
	},

	setNextTaskId(name, value) {
		this.setState({
			nextTaskId: value === 'Yes' ? 'WEB-JOINT-AUTHENTICATION' : 'WEB-ELIGIBILITY-PAGE',
		});
	},

	confirmCode() {
		this.setState({
			showExistingCustomerQuestion: true,
		});
	},

	renderLinkCodeQuestionView() {
		return (
			<LinkCode
				{...this.props}
				additionalLabelClasses="h3-style ja-link-code-label text-left"
				onClickNext={this.confirmCode}
			/>
		);
	},

	renderExistingCustomerQuestion() {
		return (
			<span>
				<RadioQuestion
					align={BrandUtils.isAbleToDisplay('initial-questions-radio-buttons-right') ? 'right' : 'left'}
					group={AccountOpeningConstants.GROUP_JOINT_ACCOUNT}
					helpText={this.props.content.jointAccountExistingCustomerTextQuestionHelp}
					labelText={this.props.content.jointAccountExistingCustomerTextQuestion}
					classNameLabelDiv="ja-existing-customer-question text-left"
					mainColumnSize={BrandUtils.defaultColumnSize() === 12 ? 12 : 6}
					mainColumnSizeMD={BrandUtils.defaultColumnSize() === 12 ? 12 : 6}
					name="isExistingCustomer"
					onChange={this.setNextTaskId}
					options={[{ anchor: 'existing-customer-no', value: 'No' }, { anchor: 'existing-customer-yes', value: 'Yes' }]}
					required
				/>
				<BottomNavigationBox
					disabled={!this.state.nextTaskId}
					nextTaskId={this.state.nextTaskId}
					nextButtonLabel={this.props.content.jointAccountPartyPresentNextLabel}
				/>
			</span>
		);
	},

	render() {
		const imgSrc = !this.state.showExistingCustomerQuestion ? BrandUtils.getResultImage('decline-page-with-image', 'decline-illustration.png') : BrandUtils.getResultImage('submission-page-with-image', 'registration-illustration.png');
		const resultSectionTitle = !this.state.showExistingCustomerQuestion ? this.props.content.jointAccountLinkCodeViewTitle : this.props.content.jointAccountExistingCustomerTitle;

		return (
			<div className="account-opening result-page-wrapper ja-multi-party-page-wrapper container-fluid">
				<Helmet title={this.props.content.jointAccountPageHeader} />
				<PageHeader title={this.props.content.jointAccountPageHeader} content={this.props.content} visible={BrandUtils.isAbleToDisplay('page-header-without-text')}/>
				<div className="result-page ja-multi-party-page white-board" role="main">
					<div className="row">
						<div className="col-xs-12">
							<ResultSection
								imgSrc={imgSrc}
								imgAlt="Loading"
								bodyClassName="text-center"
								title={resultSectionTitle}
							/>
							{this.state.showExistingCustomerQuestion ? this.renderExistingCustomerQuestion() : this.renderLinkCodeQuestionView()}
						</div>
					</div>
				</div>
			</div>
		);
	},
});

module.exports = JointAccountPage;
