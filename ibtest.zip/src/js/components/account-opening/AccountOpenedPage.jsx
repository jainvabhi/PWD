/**
 * @module AccountOpenedPage
 */

const React = require('react');
const { PropTypes } = React;
const Helmet = require('react-helmet');
const _ = require('lodash');

const AnalyticsActionCreator = require('../../actions/AnalyticsActionCreator');

const ResultSection = require('../common/sections/ResultSection');
const PageHeader = require('../common/PageHeader');
const AppLinks = require('../common/links/AppLinks');
const AlternativeProductsContent = require('../common/AlternativeProductsContent');
const Link = require('react-router').Link;

const BrandUtils = require('../../utils/BrandUtils');
const ContentUtils = require('../../utils/ContentUtils');
const { formatSortCode } = require('../../utils/NumberUtils');

const isCreditCard = props => props.data.product.productType.name === 'credit-card';

const AccountOpenedPage = React.createClass({
	propTypes: {
		data: PropTypes.object,
		validations: PropTypes.object,
		content: PropTypes.object,
		selectContentBasedOnDowngrade: PropTypes.func,
	},

	componentDidMount() {
		AnalyticsActionCreator.track({
			path: '/user/experience/view',
			action: 'Appeared',
		}, {
			description: 'PageLoaded',
		});
	},

	/**
	 * Get all bullet sections and return a JSX element.
	 *
	 * @param {Array} sections 		array of section config content keys.
	 * @return {Array} Of JSX elements.
	 */
	getBulletSections(sections) {
		return _.map(sections, (item, index) => {
			return (
				<div key={index}>
					<h3>{this.props.selectContentBasedOnDowngrade(`accountOpenedSection${item.header}Title`)}</h3>
					<ul>
						{this.getNotEmptyBullets(item.bullets)}
					</ul>
				</div>
			);
		});
	},

	/**
	 * Get a JSX element for each bullet point item.
	 *
	 * @param {Array} bullets 	array of content keys.
	 * @return {Array} Of JSX elements.
	 */
	getNotEmptyBullets(bullets) {
		return _.chain(bullets)
			.filter(value => {
				return value.applies ? value.applies(this.props.data) : value;
			})
			.map(value => {
				return _.isPlainObject(value) ? value.bullet : value;
			})
			.map(value => {
				const items = value.split('.');
				const key = `accountOpenedSection${items[0]}Bullet${items[1]}`;
				const text = this.props.selectContentBasedOnDowngrade(key);
				return text && (
					<li
						key={value}
						dangerouslySetInnerHTML={{ __html: text }}
					/>
				);
			})
			.filter(value => {
				return _.isObject(value);
			})
			.value();
	},

	accountDetails(data) {
		if (!data.product.showAccountDetailsOnOpened || !data.bankInfo || !_.head(data.bankInfo)) {
			return null;
		}

		const { accountNumber, sortCode } = _.head(data.bankInfo);

		const accountDetails = [
			{ label: this.props.content.accountOpenedAccountNumberLabel, value: accountNumber },
			{ label: this.props.content.accountOpenedSortCodeLabel, value: formatSortCode(sortCode) },
		];

		return (
			<ul className="account-info">
				<li><h3 className="account-info-item__label account-info-header">{ this.props.content.accountOpenedAccountDetailsHeading }</h3></li>
				{ accountDetails.map((detail, key) => (
					<li key={key}>
						<span className="account-info-item account-info-item__label">{ detail.label }</span>
						<span className="account-info-item account-info-item__value">{ detail.value }</span>
					</li>
				))
				}
			</ul>
		);
	},

	render() {
		let accountOpenedMoreInformation;
		const sections = this.props.data.product.accountOpenedSections;
		if (BrandUtils.isAbleToDisplay('account-opened-page-button')) {
			accountOpenedMoreInformation =
				(<div>
					<p>
						<Link
							to="/account-opening/somewhere"
							className="btn btn-lg btn-primary btn-next"
							onClick={this.onClickOpenAccount}
						>
							{this.props.content.accountOpenedAccessAccountText}
						</Link>
					</p>
					<p>
						<Link
							to="/account-opening/somewhere"
						>
							{this.props.content.accountOpenedHelpAndSupportText}
						</Link>
					</p>
				</div>);
		}

		return (
			<div className="account-opening result-page-wrapper account-opened-page-wrapper container-fluid">
				<Helmet title={this.props.content.accountOpenedPageHeader} />
				<PageHeader
					visible={BrandUtils.isAbleToDisplay('result-pages-header')}
					title={`${this.props.content.landingPageTitle}${this.props.data.product.name}${this.props.data.product.nameSuffix}`}
					content={this.props.content}
				/>
				<div className="result-page account-opened-page" role="main">
					<div className="row">
						<div className="col-xs-12">
							<ResultSection
								imgSrc={BrandUtils.getResultImage('account-opened-page-with-image', 'registration-illustration.png')}
								imgAlt="Account Opened"
								titleClass="text-center"
								title={this.props.selectContentBasedOnDowngrade('accountOpenedPageTitle')}
							>
								<div className="white-board">
									<h3>{this.props.selectContentBasedOnDowngrade('accountOpenedAppDownloadTitle')}</h3>
									<div className="account-info__container">
										{ this.accountDetails(this.props.data) }
									</div>
									{!this.props.data.isAltProduct && <AppLinks feature="app-links" {...this.props} />}
									{this.props.content.accountOpenedAppDownloadTitle && isCreditCard(this.props) && <ul>{ContentUtils.getContentListElements('accountOpenedAppDownloadBullet', this.props.content)}</ul>}
									{this.getBulletSections(sections)}
									{accountOpenedMoreInformation}
								</div>
							</ResultSection>
							{this.props.data.product.productImage && [<hr key={0}/>, <div key={1} className={this.props.data.product.productImage}></div>]}
						</div>
					</div>
				</div>
			</div>
		);
	},
});

module.exports = AlternativeProductsContent(AccountOpenedPage);
