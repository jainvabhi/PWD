const React = require('react');
const { PropTypes } = React;
const Helmet = require('react-helmet');

const PageHeader = require('../common/PageHeader');
const ResultSection = require('../common/sections/ResultSection');

const PartyPresentQuestion = require('../account-opening/joint/PartyPresentQuestion');

const BrandUtils = require('../../utils/BrandUtils');

const JointAccountMultiPartyPage = React.createClass({

	propTypes: {
		data: PropTypes.shape({
			productCode: PropTypes.string.isRequired,
			jointLinkCode: PropTypes.string,
			product: PropTypes.shape({
				name: PropTypes.string.isRequired,
				nameSuffix: PropTypes.string.isRequired,
			}),
		}),
		content: PropTypes.shape({
			landingPageTitle: PropTypes.string.isRequired,
			jointAccountMultiPartyPageHeader: PropTypes.string.isRequired,
			jointAccountMultiPageTitle: PropTypes.string.isRequired,
			jointAccountPartyOneWaiting: PropTypes.string.isRequired,
		}),
	},

	getInitialState() {
		return {
			showNextStep: true,
		};
	},

	componentWillReceiveProps(nextProps) {
		if (nextProps.data.jointLinkCode !== this.props.data.jointLinkCode) {
			this.setState({
				showNextStep: false,
			});
		}
	},

	render() {
		return (
			<div className="account-opening result-page-wrapper ja-multi-party-page-wrapper container-fluid">
				<Helmet title={this.props.content.jointAccountMultiPartyPageHeader} />
				<PageHeader visible={BrandUtils.isAbleToDisplay('result-pages-header')}
							title={`${this.props.content.landingPageTitle}${this.props.data.product.name}${this.props.data.product.nameSuffix}`}
							content={this.props.content}
				/>
				<div className="result-page ja-multi-party-page white-board" role="main">
					<div className="row text-center">
						<div className="col-xs-12">
							<ResultSection
								imgSrc={BrandUtils.getResultImage('submission-page-with-image', 'registration-illustration.png')}
								imgAlt="Loading"
								bodyClassName="text-center"
								title={this.props.content.jointAccountMultiPageTitle}
							/>
							{!this.props.data.jointLinkCode && !this.state.showNextStep && <p>{this.props.content.jointAccountPartyOneWaiting}</p>}
							{this.props.data.jointLinkCode && <PartyPresentQuestion {...this.props} />}
						</div>
					</div>
				</div>
			</div>
		);
	},
});

module.exports = JointAccountMultiPartyPage;
