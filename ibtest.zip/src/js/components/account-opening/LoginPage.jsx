/**
 * @module LoginPage
 * @desc Top Level Component for Login functionality
 * @requires react
 * @requires AccountOpeningActions
 * @requires PageHeader
 * @requires LoginComponent
 * @requires PageColumnWrapper
 * @requires SectionCentered
 * @requires SideBarColumnWrapper
 * @requires BrandUtils
 */

const React = require('react');
const { PropTypes } = React;
const Helmet = require('react-helmet');
const envConfig = require('../../../static/config');

const AccountOpeningActions = require('../../actions/AccountOpeningActions');
const PageSessionActions = require('../../actions/PageSessionActions');

const PageHeader = require('../common/PageHeader');
const PageColumnWrapper = require('../common/PageColumnWrapper');
const SideBarColumnWrapper = require('../common/SideBarColumnWrapper');
const SectionCentered = require('../common/SectionCentered');
const FindCustomerComponent = require('./findDetails/FindCustomerComponent');
const BrandUtils = require('../../utils/BrandUtils');

const LoginPage = React.createClass({
	/**
	 * @type {Object}
	 */
	propTypes: {
		appData: PropTypes.object,
		data: PropTypes.object,
		validations: PropTypes.object,
		content: PropTypes.object,
	},

	componentDidMount() {
		PageSessionActions.setPageSession({
			persisted: true,
		});
	},

	render() {
		const loginPageTitleH2 = BrandUtils.isAbleToDisplay('login-page-title') ? <h2>{this.props.content.loginPageTitle}</h2> : false;

		const onSuccess = () => {
			AccountOpeningActions.navigateToWebTask('WEB-PORTAL');
		};

		return (
			<div className="account-opening login-page container-fluid">
				<Helmet title={this.props.content.loginPageHeader} />
				<PageHeader title={this.props.content.loginPageTitle} content={this.props.content} />

				<div className="row main-container">
					<PageColumnWrapper content={this.props.content}>
						{loginPageTitleH2}

						<SectionCentered centredColumnSize={12}>
							<p>Please complete the following authentication questions</p>
							<div className="padding-bottom">
								<FindCustomerComponent
									{...this.props}
									targetScope={envConfig.targetScope.login}
									onSuccess={onSuccess}
								/>
							</div>
						<p>{this.props.content.loginPageContact}</p>
						</SectionCentered>
					</PageColumnWrapper>

				<SideBarColumnWrapper
					appData={this.props.appData}
					content={this.props.content}
					data={this.props.data}
				/>
				</div>
			</div>
		);
	},
});

module.exports = LoginPage;
