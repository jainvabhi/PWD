/**
 * @module NationalInsuranceNumberMissingComponent
 */

const React = require('react');
const { PropTypes } = React;
const _ = require('lodash');
const config = require('../../../config');
const RadioQuestion = require('../../../components/common/questionsets/RadioQuestion');
const ErrorMessage = require('../../../components/common/ErrorMessage');

const showError = props => props.validations.GROUP_PAGE_2 && props.validations.GROUP_PAGE_2.niReason && props.validations.GROUP_PAGE_2.niReason.isEnabled && !props.validations.GROUP_PAGE_2.niReason.isValid;

const mapOptions = props => {
	return _.map(config.formOptionsNIMissingReason, reason => {
		return {
			...reason,
			value: reason.value === 'invalid' ? reason.value : reason.label,
			image: config.formOptionsRadioButtonImages.image.replace('{bankId}', props.data.bankID.toLowerCase()),
			checkedImage: config.formOptionsRadioButtonImages.checkedImage.replace('{bankId}', props.data.bankID.toLowerCase()),
		};
	});
};

const NationalInsuranceNumberMissingComponent = props => {
	return (
		<span>
			<RadioQuestion
				align="left"
				className="fancy-radio"
				name="niReason"
				labelText={props.content.niNumberMissingQuestion}
				group={props.group}
				helpText={props.content.niNumberMissingHelpText}
				onChange={props.onChange}
				options={mapOptions(props)}
				defaultValue={props.data.niReason}
				validateNotEqualTo="invalid"
				required
			/>
			{showError(props) && <ErrorMessage text={props.content.niNumerMissingReasonError}/>}
		</span>
	);
};

NationalInsuranceNumberMissingComponent.propTypes = {
	group: PropTypes.string.isRequired,
	data: PropTypes.shape({
		bankID: PropTypes.string.isRequired,
		niReason: PropTypes.string,
	}),
	content: PropTypes.shape({
		niNumberMissingHelpText: PropTypes.string.isRequired,
		niNumberMissingQuestion: PropTypes.string.isRequired,
		niNumerMissingReasonError: PropTypes.string.isRequired,
	}),
	onChange: PropTypes.func.isRequired,
};

module.exports = NationalInsuranceNumberMissingComponent;
