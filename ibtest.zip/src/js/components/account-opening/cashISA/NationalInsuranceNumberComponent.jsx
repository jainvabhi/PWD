/**
 * @module NationalInsuranceNumberComponent
 */

const React = require('react');
const { PropTypes } = React;
const TextQuestion = require('../../common/questionsets/TextQuestion');
const RegexUtils = require('../../../utils/RegexUtils');

const NationalInsuranceNumberComponent = props => {
	return (
		<TextQuestion
			name="niNumber"
			group={props.group}
			minLength={2}
			maxLength={9}
			dataAnchor="niNumber"
			onChange={props.onChange}
			valueFormatter={value => value && value.toUpperCase()}
			defaultValue={props.data.niNumber}
			validateRegex={RegexUtils.regexes.niNumber}
			validationText={props.content.niNumberValidationText}
			helpText={props.content.niNumberQuestionInputHelpText}
			required
		>
			{props.content.niNumberTitle}
		</TextQuestion>
	);
};

NationalInsuranceNumberComponent.propTypes = {
	group: PropTypes.string,
	content: PropTypes.shape({
		niNumberTitle: PropTypes.string.isRequired,
		niNumberMissingQuestion: PropTypes.string.isRequired,
		niNumberValidationText: PropTypes.string.isRequired,
		niNumberQuestionInputHelpText: PropTypes.string.isRequired,
	}),
	data: PropTypes.shape({
		niNumber: PropTypes.string,
	}),
	onChange: PropTypes.func.isRequired,
};

module.exports = NationalInsuranceNumberComponent;
