jest.unmock('../NationalInsuranceSection');

const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');

const RadioQuestion = require('../../../common/questionsets/RadioQuestion');
const ErrorMessage = require('../../../common/ErrorMessage');
const NationalInsuranceSection = require('../NationalInsuranceSection');
const NationalInsuranceNumberMissingComponent = require('../NationalInsuranceNumberMissingComponent');
const NationalInsuranceNumberComponent = require('../NationalInsuranceNumberComponent');

const container = document.createElement('div');
const render = (comp, el) => ReactDOM.render(comp, el || container);

const shallowRenderer = TestUtils.createRenderer();

const getProps = props => {
	return {
		group: 'Capture',
		content: {
			niNumberQuestion: '',
			niNumberQuestionHelpText: '',
			niNumberTitle: '',
			niNumberRequiredValidationMessage: '',
		},
		data: {
			product: {
			},
			...props,
		}
	};
};

describe('NationalInsuranceSection', () => {
	let component;
	let instance;

	describe('when NI question is not answered', () => {
		beforeEach(() => {
			shallowRenderer.render(
				<NationalInsuranceSection {...getProps()} />
			);

			instance = shallowRenderer.getMountedInstance();
			instance.setState({
				hasNINumber: true,
			});

			component = shallowRenderer.getRenderOutput();
		});

		it('should not render any input box for initial render', () => {
			expect(component).not.toIncludeJSX(
				<NationalInsuranceNumberMissingComponent {...getProps()} />
			);

			expect(component).not.toIncludeJSX(
				<NationalInsuranceNumberComponent {...getProps()} />
			);
		});
	});

	describe('when NI question is no', () => {
		beforeEach(() => {
			shallowRenderer.render(
				<NationalInsuranceSection {...getProps()} />
			);

			instance = shallowRenderer.getMountedInstance();
			instance.setState({
				hasNINumber: 'No',
			});

			component = shallowRenderer.getRenderOutput();
		});

		it('should render national insurance missing component', () => {
			expect(component).toIncludeJSX(
				<NationalInsuranceNumberMissingComponent {...getProps()} />
			);
		});
	});

	describe('when NI question is yes', () => {
		beforeEach(() => {
			shallowRenderer.render(
				<NationalInsuranceSection {...getProps()} />
			);

			instance = shallowRenderer.getMountedInstance();
			instance.setState({
				hasNINumber: 'Yes',
			});

			component = shallowRenderer.getRenderOutput();
		});

		it('should render national input component', () => {
			expect(component).toIncludeJSX(
				<NationalInsuranceNumberComponent {...getProps()} />
			);
		});
	});

	describe('when NI has been set previously with NI number', () => {
		beforeEach(() => {
			shallowRenderer.render(
				<NationalInsuranceSection {...getProps({
					niNumber: '12345',
				})} />
			);

			instance = shallowRenderer.getMountedInstance();

			component = shallowRenderer.getRenderOutput();
		});

		it('should render national input component set to Yes', () => {
			expect(component).toIncludeJSX(
				<RadioQuestion
					align="left"
					blockList={false}
					defaultValue="Yes"
					group="Capture"
					helpText=""
					labelText=""
					mainColumnSize={8}
					mainColumnSizeMD={8}
					name="niNumberQuestion"
					onChange={function noRefCheck() {}}
					options={[{value: 'No'}, {value: 'Yes'}]}
					validateEqualTo={undefined}
					required={true}
				/>
			);
		});
	});

	describe('when NI has been set previously with missing reason', () => {
		beforeEach(() => {
			shallowRenderer.render(
				<NationalInsuranceSection {...getProps({
					niReason: 'Forgot it',
				})} />
			);

			instance = shallowRenderer.getMountedInstance();

			component = shallowRenderer.getRenderOutput();
		});

		it('should render national input component set to No', () => {
			expect(component).toIncludeJSX(
				<RadioQuestion
					align="left"
					blockList={false}
					defaultValue="No"
					group="Capture"
					helpText=""
					labelText=""
					mainColumnSize={8}
					mainColumnSizeMD={8}
					name="niNumberQuestion"
					onChange={function noRefCheck() {}}
					options={[{value: 'No'}, {value: 'Yes'}]}
					validateEqualTo={undefined}
					required={true}
				/>
			);
		});
	});

	describe('when customer does not have NI number but it is required', () => {
		beforeEach(() => {
			shallowRenderer.render(
				<NationalInsuranceSection {...getProps({
					product: {
						niNumberRequired: 'Yes',
					},
				})} />
			);

			instance = shallowRenderer.getMountedInstance();
			instance.setState({
				hasNINumber: 'No',
			});

			component = shallowRenderer.getRenderOutput();
		});

		it('should render national input component', () => {
			expect(component).toIncludeJSX(
				<ErrorMessage
					extraClasses="error"
					text=""
					visible={true}
				/>
			);
		});
	});
});
