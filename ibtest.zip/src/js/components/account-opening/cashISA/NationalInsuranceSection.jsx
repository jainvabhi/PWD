/**
 * @module NationalInsuranceSection
 */

const React = require('react');
const { PropTypes } = React;

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');
const ComponentHeader = require('../../common/ComponentHeader');
const RadioQuestion = require('../../common/questionsets/RadioQuestion');
const SectionFullWidth = require('../../common/SectionFullWidth');
const ErrorMessage = require('../../common/ErrorMessage');

const NationalInsuranceNumberComponent = require('./NationalInsuranceNumberComponent');
const NationalInsuranceNumberMissingComponent = require('./NationalInsuranceNumberMissingComponent');

const resetNIFields = () => {
	AccountOpeningActions.resetNIFields();
};

const NationalInsuranceSection = React.createClass({
	propTypes: {
		group: PropTypes.string.isRequired,
		data: PropTypes.shape({
			niNumber: PropTypes.string,
			niReason: PropTypes.string,
			product: PropTypes.shape({
				niNumberRequired: PropTypes.string,
			}),
		}),
		content: PropTypes.shape({
			niNumberTitle: PropTypes.string.isRequired,
			niNumberQuestion: PropTypes.string.isRequired,
			niNumberQuestionHelpText: PropTypes.string.isRequired,
			niNumberRequiredValidationMessage: PropTypes.string.isRequired,
		}),
	},

	getInitialState() {
		return {
			hasNINumber: this.getDefaultValue(),
		};
	},

	onChange(name, value) {
		resetNIFields(this.props);

		this.setState({
			hasNINumber: value,
		});
	},

	getNIInputComponent() {
		if (this.state.hasNINumber === 'Yes') {
			return (<NationalInsuranceNumberComponent {...this.props} />);
		} else if (this.props.data.product.niNumberRequired && this.state.hasNINumber === 'No') {
			return (<ErrorMessage text={this.props.content.niNumberRequiredValidationMessage} />);
		} else if (this.state.hasNINumber === 'No') {
			return (<NationalInsuranceNumberMissingComponent {...this.props} />);
		} else {
			return null;
		}
	},

	getDefaultValue() {
		if (this.props.data.niNumber) {
			return 'Yes';
		} else if (this.props.data.niReason) {
			return 'No';
		} else {
			return undefined;
		}
	},

	render() {
		return (
			<ComponentHeader
				title={this.props.content.niNumberTitle}
				titleLevel={2}
				hasSeparator
			>
				<SectionFullWidth id="national-insurance-number">
					<RadioQuestion
						key="ni-number-available"
						align="left"
						defaultValue={this.getDefaultValue()}
						group={this.props.group}
						labelText={this.props.content.niNumberQuestion}
						helpText={this.props.content.niNumberQuestionHelpText}
						mainColumnSize={8}
						mainColumnSizeMD={8}
						name="niNumberQuestion"
						onChange={this.onChange}
						options={[{ value: 'No' }, { value: 'Yes' }]}
						validateEqualTo={this.props.data.product.niNumberRequired}
						required
					/>
					{this.getNIInputComponent()}
				</SectionFullWidth>
			</ComponentHeader>
		);
	},
});

module.exports = NationalInsuranceSection;
