/**
 * @module LetterCodePage
 */

const React = require('react');
const { PropTypes } = React;
const _ = require('lodash');
const Helmet = require('react-helmet');
const cx = require('classnames');

const LetterCodeForm = require('./lettercode/LetterCodeForm');

const PageHeader = require('../common/PageHeader');
const SectionCentered = require('../common/SectionCentered');
const ComponentHeader = require('../common/ComponentHeader');

const PartyPresentQuestion = require('./joint/PartyPresentQuestion');

const BrandUtils = require('../../utils/BrandUtils');
const ContentUtils = require('../../utils/ContentUtils');

const DYBfooter = props => {
	return (
		<div>
			<div>
				{ContentUtils.getContentParagraphs('lettercodeFooter', props.content)}
			</div>
		</div>
	);
};


DYBfooter.propTypes = {
	content: PropTypes.shape({
		sideBarTitle: PropTypes.string.isRequired,
	}),
};

const CYBfooter = props => {
	return (
		<p>
			{props.content.lettercodeFooter}
			<br/>
			<span className="letter-code-page__number"><strong>{props.content.phoneNumber}</strong></span>
			<br/>
			<span className="letter-code-page__footnote">{props.content.lettercodeFooterFootnote}</span>
		</p>
	);
};

CYBfooter.propTypes = {
	content: PropTypes.shape({
		lettercodeFooter: PropTypes.string.isRequired,
		lettercodeFooterFootnote: PropTypes.string.isRequired,
		phoneNumber: PropTypes.string.isRequired,
		sideBarTitle: PropTypes.string.isRequired,
	}),
};

const LetterCodePage = props => {
	const wrapperClassNames = cx({
		'white-board': BrandUtils.isAbleToDisplay('result-pages-header'),
	});

	const canProgress = props.appData.apiTaskId === 'confirmcode' && _.every([
		props.data.completedTasks['SAVE_AND_RESUME'],
		!props.data.completedTasks['WEB-REVIEW-DETAILS'],
	]);

	const title = canProgress ? props.content.letterCodePageHeader : props.content.letterCodePageUnhappyHeader;
	const footer = BrandUtils.isAbleToDisplay('result-pages-header') ? <DYBfooter {...props} /> : <CYBfooter {...props} />;

	return (
		<div className="account-opening letter-code-page container-fluid">
			<Helmet title={props.content.letterCodePageTitle} />
			<PageHeader
				visible={BrandUtils.isAbleToDisplay('result-pages-header')}
				title={title}
				{...props}
			/>

			<div className="row main-container">
				<SectionCentered centredColumnSize={12} className="result-page">
					{!BrandUtils.isAbleToDisplay('result-pages-header') && <img
						className="letter-code-page__image"
						src={BrandUtils.getResultImage('lettercode-page-with-image', 'sorry-illustration.png')}
					/>}
					<ComponentHeader
						wrapperClass="letter-code-page__header"
						titleLevel={1}
						hasSubtitleSeparator={!BrandUtils.isAbleToDisplay('result-pages-header')}
						title={title}
						titleClass={'letter-code-page__headertitle'}
					/>
					<div className={wrapperClassNames}>

						{canProgress && <LetterCodeForm {...props} />}
						{!canProgress && <p>{props.content.letterCodePageUnhappyExplaination}</p>}

						{BrandUtils.isAbleToDisplay('joint') && !canProgress && props.data.jointLinkCode && <PartyPresentQuestion {...props} />}
						{canProgress && <div className="letter-code-page__footer">
							{footer}
						</div>}
					</div>


				</SectionCentered>

			</div>
		</div>
	);
};

LetterCodePage.propTypes = {
	appData: PropTypes.object,
	data: PropTypes.shape({
		letterCodeAPIError: PropTypes.boolean,
		completedTasks: PropTypes.object,
		jointLinkCode: PropTypes.string,
	}),
	content: PropTypes.shape({
		letterCodePageHeader: PropTypes.string.isRequired,
		letterCodePageUnhappyHeader: PropTypes.string.isRequired,
		letterCodePageTitle: PropTypes.string.isRequired,
		lettercodeFooter: PropTypes.string.isRequired,
		lettercodeFooterFootnote: PropTypes.string.isRequired,
		letterCodePageUnhappyExplaination: PropTypes.string.isRequired,
		phoneNumber: PropTypes.string.isRequired,
		sideBarTitle: PropTypes.string.isRequired,
	}),
};

module.exports = {
	LetterCodePage,
	DYBfooter,
	CYBfooter,
};
