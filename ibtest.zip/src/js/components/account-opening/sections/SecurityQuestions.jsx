/**
 * @module SecurityQuestions
 */

const React = require('react');
const { PropTypes } = React;
const _ = require('lodash');

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');

const TextQuestion = require('../../common/questionsets/TextQuestion');
const DropdownQuestion = require('../../common/questionsets/DropdownQuestion');

const AccountOpeningConstants = require('../../../constants/AccountOpeningConstants');

const group = AccountOpeningConstants.GROUP_REGISTRATION;

const SecurityQuestions = React.createClass({

	propTypes: {
		numQuestions: PropTypes.number.isRequired,
		data: PropTypes.object.isRequired,
		content: PropTypes.object.isRequired,
		securityQuestions: PropTypes.array,
	},

	_getSelectedSecurityQuestions(questionId) {
		return _.range(1, this.props.numQuestions + 1)
			.filter(i => (questionId !== i) && this.props.data[`securityQuestion${i}`])
			.map(i => this.props.data[`securityQuestion${i}`]);
	},

	renderSecurityQuestion(i) {
		const selectedSecurityQuestions = this._getSelectedSecurityQuestions(i);
		return (
			<div key={i}>
				<DropdownQuestion
					name={`securityQuestion${i}`}
					data={this.props.securityQuestions}
					filter={selectedSecurityQuestions}
					group={group}
					onChange={AccountOpeningActions.updateFormValue}
					defaultValue={this.props.data[`securityQuestion${i}`]}
					validateNotEqualToThese={selectedSecurityQuestions}
					validationText={this.props.content.securityQuestionDropdownValidationMessage}
					helpText={this.props.content.securityQuestionDropdownHelpText}
					dataAnchor={`security-Q${i}`}
					required
				>
					{`Security question ${i}`}
				</DropdownQuestion>
				<TextQuestion
					name={`securityQuestion${i}Answer`}
					group={group}
					onChange={AccountOpeningActions.updateFormValue}
					defaultValue={this.props.data[`securityQuestion${i}Answer`]}
					minLength={6}
					maxLength={20}
					validateType="alphanumeric"
					maskValueOnBlur
					helpText={this.props.content.securityQuestionInputHelpText}
					validationText={this.props.content.securityQuestionInputValidationMessage}
					dataAnchor={`security-A${i}`}
					required
					encrypt
				>
					{`Answer ${i}`}
				</TextQuestion>
			</div>
		);
	},

	render() {
		return (
			<div>
				{_.map(_.range(1, this.props.numQuestions + 1), i => this.renderSecurityQuestion(i))}
			</div>
		);
	},
});

module.exports = SecurityQuestions;
