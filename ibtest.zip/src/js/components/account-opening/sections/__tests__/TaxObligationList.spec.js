jest.unmock('../TaxObligationList');
jest.unmock('../../../common/questionsets/DropdownQuestion');
jest.unmock('../../../common/questionsets/Dropdown');
jest.unmock('../../../../utils/CountryUtils');

const React = require('react');
const ReactDOM = require('react-dom');
const _ = require('lodash');
const TestUtils = require('react-addons-test-utils');
const shallowRenderer = TestUtils.createRenderer();
const TaxObligationList = require('../TaxObligationList');
const DropdownQuestion = require('../../../common/questionsets/DropdownQuestion');
const RadioQuestion = require('../../../common/questionsets/RadioQuestion');
const TextQuestion = require('../../../common/questionsets/TextQuestion');
const InputMixin = require('../../../common/mixins/InputMixin');
const CountryUtils = require('../../../../utils/CountryUtils');
const { buildContent } = require('../../../../__helpers__/TestHelpers');

const content = buildContent([
	'taxObligationsListCountryFieldName',
	'taxObligationsListHasTaxNumberFieldName',
	'taxObligationsListTaxNumberName',
]);

const render = (data = {}) => {
	const props = {
		content,
		name: 'taxObligationList',
		data,
		group: 'GROUP',
	};
	const el = document.createElement('div');
	const component = <TaxObligationList {...props} />;
	const instance = ReactDOM.render(component, el);
	shallowRenderer.render(component);
	return { props, instance, output: shallowRenderer.getRenderOutput() };
};

const expectOptionsToEqualTaxObligationListWithout = (dropdown, without) => {
	const options = TestUtils.scryRenderedDOMComponentsWithTag(dropdown, 'option');
	const optionValues = options.map(option => option.textContent);
	const countries = CountryUtils
		.withCountryNames()
		.map(i => i.value);
	const expectation = ['Select...'].concat(_.without(countries, ...without));
	expect(optionValues).toEqual(expectation);
};

describe('TaxObligationList', () => {

	describe('on mount', () => {
		it('renders', () => {
			const { props, output } = render();
			expect(output).toEqualJSX(
				<div>
					<div>
						<DropdownQuestion
							customValidator={function noRefCheck() {}}
							data={CountryUtils.withCountryNames(data => data.code !== 'GB')}
							dataAnchor="tax-nationality"
							defaultValue={undefined}
							filter={[]}
							group="GROUP"
							helpText={undefined}
							name="taxCountry0"
							onChange={function noRefCheck() {}}
						>
							1. taxObligationsListCountryFieldName
						</DropdownQuestion>
						<RadioQuestion
							align="left"
							blockList={false}
							defaultValue={undefined}
							group="GROUP"
							helpText={undefined}
							id="hasTaxNumber0"
							labelText="taxObligationsListHasTaxNumberFieldName"
							mainColumnSize={undefined}
							mainColumnSizeMD={undefined}
							name="hasTaxNumber0"
							onChange={function noRefCheck() {}}
							options={[{anchor: 'tax-id-number-no', value: 'No'}, {anchor: 'tax-id-number-yes', value: 'Yes'}]}
							required={true}
						/>
					</div>
					<fieldset>
						<a
							className="btn btn-primary btn-lg pull-right margin-left"
							href="#"
							onClick={function noRefCheck() {}}
							role="button"
						>
							Add another
						</a>
						<div
							aria-live="assertive"
							role="alert"
						/>
					</fieldset>
				</div>
			);
		});
	});

	describe('with a dropdown', () => {
		it('renders the dropdown without the United Kingdom', () => {
			const { props, instance } = render({
				taxObligationList: [
					{ taxCountry: 'American Samoa' },
				]
			});
			const dropdowns = TestUtils.scryRenderedComponentsWithType(instance, DropdownQuestion);
			expectOptionsToEqualTaxObligationListWithout(dropdowns[0], ['United Kingdom']);
		});
	});

	describe('with multiple dropdowns', () => {
		it('renders the other dropdowns without the other selected answer or the Unitied Kingdom', () => {
			const { props, instance } = render({
				taxObligationList: [
					{ taxCountry: 'American Samoa' },
					{ taxCountry: 'Antarctica' },
				]
			});
			const dropdowns = TestUtils.scryRenderedComponentsWithType(instance, DropdownQuestion);
			expectOptionsToEqualTaxObligationListWithout(dropdowns[0], ['Antarctica', 'United Kingdom']);
			expectOptionsToEqualTaxObligationListWithout(dropdowns[1], ['American Samoa', 'United Kingdom']);
		});
	});
});
