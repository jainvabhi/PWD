jest.unmock('../SecurityQuestions');
jest.unmock('../../../common/questionsets/DropdownQuestion');
jest.unmock('../../../common/questionsets/Dropdown');

const React = require('react');
const ReactDOM = require('react-dom');
const _ = require('lodash');
const TestUtils = require('react-addons-test-utils');
const SecurityQuestions = require('../SecurityQuestions');
const DropdownQuestion = require('../../../common/questionsets/DropdownQuestion');

describe('SecurityQuestions', function() {
	let data = {};
	const securityQuestions = [
		'The name of a memorable place to you?',
		'Your favourite film of all time?',
		'Your favourite meal or restaurant?',
		'What is your favourite book of all time?',
		'What is your favourite teacher or subject?',
		'What is your favourite TV star or show?',
	];
	const render = (data = {}) => {
		const props = {
			numQuestions: 5,
			data,
			securityQuestions,
			content: {},
		};
		const el = document.createElement('div');
		const instance = ReactDOM.render(<SecurityQuestions {...props} />, el);
		return { props, instance };
	};

	const expectOptionsToEqualSecurityQuestionsWithout = (dropdown, without = []) => {
		const options = TestUtils.scryRenderedDOMComponentsWithTag(dropdown, 'option');
		const optionValues = options.map(option => option.textContent);
		const expectation = ['Select...'].concat(_.without(securityQuestions, without));
		expect(optionValues).toEqual(expectation);
	};

	describe('on mount', () => {
		it('renders a numQuestion prop number of DropdownQuestions', () => {
			const { props, instance } = render();
			const dropdowns = TestUtils.scryRenderedComponentsWithType(instance, DropdownQuestion);
			expect(dropdowns.length).toEqual(props.numQuestions);
		});

		it('renders options for each security question', () => {
			const { instance } = render();
			const dropdowns = TestUtils.scryRenderedComponentsWithType(instance, DropdownQuestion);
			dropdowns.map(dropdown => {
				expectOptionsToEqualSecurityQuestionsWithout(dropdown);
			});
		});

		describe('with the first dropdown using a selected security question', () => {
			beforeEach(() => {
				data = {
					securityQuestion1: securityQuestions[0],
				};
			});

			it('renders the first dropdown with options for each security questions', () => {
				const { instance } = render(data);
				const dropdowns = TestUtils.scryRenderedComponentsWithType(instance, DropdownQuestion);
				expectOptionsToEqualSecurityQuestionsWithout(dropdowns[0]);
			});

			it('renders the other dropdowns with options for each security questions minus the selected question', () => {
				const { instance } = render(data);
				const dropdowns = TestUtils.scryRenderedComponentsWithType(instance, DropdownQuestion);
				_.chain(1)
					.range(dropdowns.length)
					.map(dropdown => {
						expectOptionsToEqualSecurityQuestionsWithout(dropdown, securityQuestions[0]);
					});
			});
		});

		describe('with the first and second dropdowns are using a selected security question', () => {
			beforeEach(() => {
				data = {
					securityQuestion1: securityQuestions[0],
					securityQuestion2: securityQuestions[4],
				};
			});

			it('renders the first dropdown with options for each security questions minus the second selected question', () => {
				const { instance } = render(data);
				const dropdowns = TestUtils.scryRenderedComponentsWithType(instance, DropdownQuestion);
				expectOptionsToEqualSecurityQuestionsWithout(dropdowns[0], securityQuestions[4]);
			});

			it('renders the second dropdown with options for each security questions minus the first selected question', () => {
				const { instance } = render(data);
				const dropdowns = TestUtils.scryRenderedComponentsWithType(instance, DropdownQuestion);
				expectOptionsToEqualSecurityQuestionsWithout(dropdowns[1], securityQuestions[0]);
			});

			it('renders the other remaining dropdowns with options for each security questions minus the selected questions', () => {
				const { instance } = render(data);
				const dropdowns = TestUtils.scryRenderedComponentsWithType(instance, DropdownQuestion);
				_.chain(2)
					.range(dropdowns.length)
					.map(dropdown => {
						expectOptionsToEqualSecurityQuestionsWithout(dropdown, [securityQuestions[0], securityQuestions[4]]);
					});
			});
		});
	});
});
