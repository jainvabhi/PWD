jest.unmock('../PersonalDetailsPage');
jest.unmock('react-bootstrap-datetimepicker');
jest.unmock('../../common/ComponentHeader');
jest.unmock('../../common/PageColumnWrapper');
jest.unmock('../../common/SectionFullWidth');
jest.unmock('../personalDetails');
jest.unmock('../personalDetails/Title');
jest.unmock('../personalDetails/FirstName');
jest.unmock('../personalDetails/LastName');
jest.unmock('../personalDetails/MiddleName');
jest.unmock('../personalDetails/DateOfBirth');
jest.unmock('../personalDetails/PhoneNumber');
jest.unmock('../personalDetails/EmailAddress');
jest.unmock('../personalDetails/AdditionalCardHolder');
jest.unmock('../personalDetails/NumberOfDependants');
jest.unmock('../../common/mixins/InputMixin');
jest.unmock('../../common/questionsets/ReadOnlyQuestion');
jest.unmock('../../common/questionsets/DropdownQuestion');
jest.unmock('../../common/questionsets/Dropdown');
jest.unmock('../../../config');
jest.unmock('../../../config/FormOptions');
jest.unmock('../../../utils/RegexUtils');
jest.unmock('../../../utils/BrandUtils');
const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');

const PersonalDetailsPage = require('../PersonalDetailsPage');

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');
const AnalyticsActionCreator = require('../../../actions/AnalyticsActionCreator');
const CredentialsActions = require('../../../actions/CredentialsActions');
const RegexUtils = require('../../../utils/RegexUtils');
const BrandUtils = require('../../../utils/BrandUtils');


const { Title } = require('../personalDetails');

const _ = require('lodash');

const render = (comp, el) => ReactDOM.render(comp, el);

const shallowRender = props => {
	const shallowRenderer = TestUtils.createRenderer();
	shallowRenderer.render(<PersonalDetailsPage
		envConfig={{}}
		{...props}
	/>);
	return shallowRenderer.getRenderOutput();
};

const getData = props => {
	return {
		product: {
			productType: {
				name: 'current',
			},
		},
		completedTasks: {},
		...props,
	};
};

describe('Personal Details Page', function() {

	const content = {
		titleQuestion: 'test',
		firstNameQuestion: 'test',
		lastNameQuestion:  'test',
		middleNameQuestion:  'test',
		dateOfBirthQuestion: 'test',
		phoneNumberQuestion: 'test',
		emailAddressQuestion: 'test',
		emailAddressConfirmationQuestion: 'test',
	};

	const data = {
		productCode: 'IM540',
	};

	// Render an instance of the component
	let instance;

	describe('when there is an access token present', () => {
		describe('and no bank id is present', () => {
			beforeEach(() => {
				instance = TestUtils.renderIntoDocument(<PersonalDetailsPage
					envConfig={{}}
					data={getData()}
					content={content}
					session={{
						accessToken: 'accessToken'
					}}
					appData={{}} />
				);
			});

			it('should not call for credentials', () => {
				expect(CredentialsActions.getCredentials.mock.calls.length).toBe(0);
			});
		});
	});

	describe('WHEN canEditBankSelection is called', () => {
		describe('SHOULD return false', () => {
			it('when we have an active case ID ', () => {
				instance = TestUtils.renderIntoDocument(
					<PersonalDetailsPage
						envConfig={{}}
						data={getData({
							caseId: 'test-false',
							completedTasks: {}
						})}
						content={content}
						session={{}}
						appData={{}}
					/>
				);
				expect(instance.canEditBankSelection()).toBe(false);
			});

			it('when we come through save and resume', () => {
				instance = TestUtils.renderIntoDocument(
					<PersonalDetailsPage
						envConfig={{}}
						data={getData({
							completedTasks: {'SAVE_AND_RESUME': true}
						})}
						content={content}
						session={{}}
						appData={{}}
					/>
				);
				expect(instance.canEditBankSelection()).toBe(false);
			});
		});
		describe('SHOULD return true', () => {
			it('when we have NO active case ID', () => {
				instance = TestUtils.renderIntoDocument(
					<PersonalDetailsPage
						envConfig={{}}
						data={getData({
						})}
						content={content}
						session={{}}
						appData={{}}
					/>
				);
				expect(instance.canEditBankSelection()).toBe(true);
			});

			it('when we DO NOT come through save and resume', () => {
				instance = TestUtils.renderIntoDocument(
					<PersonalDetailsPage
						envConfig={{}}
						data={getData({
							completedTasks: {}
						})}
						content={content}
						session={{}}
						appData={{}}
					/>
				);
				expect(instance.canEditBankSelection()).toBe(true);
			});
		});
	});

	describe('when user enters phone number', () => {
		let expectedPhoneNumber;

		function setupTest(number, dataProp, isPhoneNumber, isMobileNumber) {
			RegexUtils.isValid = jest.fn().mockReturnValueOnce(isPhoneNumber).mockReturnValueOnce(isMobileNumber);

			instance = TestUtils.renderIntoDocument(<PersonalDetailsPage
				envConfig={{}}
				data={dataProp}
				content={content}
				appData={{}} />
			);

			AnalyticsActionCreator.track.mockClear();
			expectedPhoneNumber = number;
			instance.onPhoneNumberChange('phoneNumber', expectedPhoneNumber);
		}

		beforeEach(() => {
			setupTest('0141338404', getData(), true, false);
		});

		afterEach(() => {
			AnalyticsActionCreator.track.mockClear();
		});

		it('should test phone number against regex utils', () => {
			let [actualPhoneNumber, actualRegex] = RegexUtils.isValid.mock.calls[0];
			expect(RegexUtils.regexes.phone).toBe(actualRegex);
		});

		describe('and it is valid', () => {

			beforeEach(() => {
				setupTest('0141338404', getData(), true, false);
			});

			afterEach(() => {
				AnalyticsActionCreator.track.mockClear();
			});

			it('should sucessfully pass validation with RegexUtils', () => {
				let [actualPhoneNumber, actualRegex] = RegexUtils.isValid.mock.calls[0];

				expect(RegexUtils.isValid.mock.calls.length).toBeGreaterThan(0);
				expect(actualPhoneNumber).toEqual(expectedPhoneNumber);
			});

			it('should start track through analytics', () => {
				expect(AnalyticsActionCreator.track.mock.calls.length).toBeGreaterThan(0);
			});

			it('should test for mobile number', () => {
				let [actualPhoneNumber, actualRegex] = RegexUtils.isValid.mock.calls[1];
				expect(actualRegex).toBe(RegexUtils.regexes.mobilePhone);
			});
		});

		describe('and it is invalid', () => {
			beforeEach(() => {
				setupTest('cheese 404', getData(), false, false);
			});

			afterEach(() => {
				AnalyticsActionCreator.track.mockClear();
			});

			it('should sucessfully fail validation with RegexUtils', () => {
				let [actualPhoneNumber, actualRegex] = RegexUtils.isValid.mock.calls[0];
				expect(RegexUtils.isValid.mock.calls.length).toBeGreaterThan(0);
				expect(actualPhoneNumber).toEqual(expectedPhoneNumber);
				expect(RegexUtils.regexes.phone).toBe(actualRegex);
				expect(AnalyticsActionCreator.track.mock.calls.length).toEqual(0);
			});
		});

		describe('and it is home phone number', () => {
			beforeEach(() => {
				setupTest('07545338404', getData(), true, false);
			});

			it('should set analytics attribute type to phone number', () => {
				let [type, attributes] = AnalyticsActionCreator.track.mock.calls[0];
				expect(attributes.type).toEqual('HomePhone');
			});
		});

		describe('and it is mobile phone number', () => {
			beforeEach(() => {
				setupTest('07545338404', getData(), true, true);
			});

			it('should set analytics type to mobile phone', () => {
				let [type, attributes] = AnalyticsActionCreator.track.mock.calls[0];
				expect(attributes.type).toEqual('MobilePhone');
			});
		});

		describe('and it is first entry', () => {

			beforeEach(() => {
				setupTest('0', getData(), true, false);
			})

			it('should set analytics attribute event to be created', () => {
				let [type, attributes] = AnalyticsActionCreator.track.mock.calls[0];
				expect(attributes.event).toEqual('created');
			})
		})

		describe('and it is subsequent entry', () => {

			beforeEach(() => {
				setupTest('01', getData({phoneNumber: '0'}), true, false);
			})

			it('should set analytics attribute event to be created', () => {
				let [type, attributes] = AnalyticsActionCreator.track.mock.calls[0];
				expect(attributes.event).toEqual('updated');
			})
		})
	});

	describe('when user selects option from preferred contact method dropdown', () => {
		beforeEach(() => {
			instance = TestUtils.renderIntoDocument(<PersonalDetailsPage
				envConfig={{}}
				data={getData()}
				content={content}
				appData={{}} />
			);

			AnalyticsActionCreator.track.mockClear();
			AccountOpeningActions.updateFormValue.mockClear();
			RegexUtils.isValid.mockClear();
			instance.onPreferredContactMethodChange('phone', '01413384040');
		});

		afterEach(() => {
			AnalyticsActionCreator.track.mockClear();
			AccountOpeningActions.updateFormValue.mockClear();
			RegexUtils.isValid.mockClear();
		});

		it('should raise account opening actions update form value action', () => {
			expect(AccountOpeningActions.updateFormValue.mock.calls[0].length).toBeGreaterThan(0);
		});

		it('should track click analytics event', () => {
			let [type, attributes] = AnalyticsActionCreator.track.mock.calls[0];
			expect(attributes.event).toBe('click');
			expect(AnalyticsActionCreator.track.mock.calls[0].length).toBeGreaterThan(0);
		})

		it('should determine which type of contact number we are recoding', () => {
			expect(RegexUtils.isValid.mock.calls[0].length).toBeGreaterThan(0);
		});
	});

	describe('getNextButtonLabel', () => {

		beforeEach(() => {
			instance = TestUtils.renderIntoDocument(
				<PersonalDetailsPage
					envConfig={{}}
					data={getData()}
					content={content}
					appData={{}}
					session={{
						accessToken: 'sdsadsadasdsadsadasd',
					}}
				/>
			);
		});

		it('should return "Review" ', () => {
			expect(instance.getNextButtonLabel(true, false, true)).toBe('Review');
		});

		it('should return "Continue"', () => {
			expect(instance.getNextButtonLabel(false, false, true)).toBe('Continue');
		});

		it('should return "Submitting..."', () => {
			expect(instance.getNextButtonLabel(false, true, false)).toBe('Submitting...');
		});
	});

	describe('onHasDependantsChange', () => {

		beforeEach(() => {
			instance = TestUtils.renderIntoDocument(<PersonalDetailsPage
				envConfig={{}}
				data={getData()}
				content={content}
				appData={{}} />
			);
		});

		afterEach(() => {
			AccountOpeningActions.updateFormValues.mockClear();
		});

		it('stores the passed in arguments', () => {

			instance.onHasDependantsChange('hasDependants', 'Yes');

			var updateArgs = AccountOpeningActions.updateFormValues.mock.calls[0][0];
			expect(updateArgs[0].key).toBe('hasDependants');
			expect(updateArgs[0].value).toBe('Yes');
		});

		it('sets the number of dependents to 1 when passed in Yes', () => {
			instance.onHasDependantsChange('hasDependants', 'Yes');

			var updateArgs = AccountOpeningActions.updateFormValues.mock.calls[0][0];
			expect(updateArgs[1].key).toBe('dependants');
			expect(updateArgs[1].value).toBe('1');
		});

		it('unsets the number of dependents when passed in No', () => {
			instance.onHasDependantsChange('hasDependants', 'No');

			var updateArgs = AccountOpeningActions.updateFormValues.mock.calls[0][0];
			expect(updateArgs[1].key).toBe('dependants');
			expect(updateArgs[1].value).toBeUndefined();
		});
	});

	describe('validateGender', () => {
		let instance = TestUtils.renderIntoDocument(<PersonalDetailsPage
				envConfig={{}}
				data={getData()}
				content={content}
				appData={{}} />);

		it('should return false if selected gender does not match the title', () => {
			let result = instance.isTitleGenderValid('Mr', 'Female');
			expect(result).toBe(false);
		});

		it('should return false if selected gender does not match the title', () => {
			let result = instance.isTitleGenderValid('Master', 'Female');
			expect(result).toBe(false);
		});

		it('should return false if selected gender does not match the title', () => {
			let result = instance.isTitleGenderValid('Mrs', 'Male');
			expect(result).toBe(false);
		});

		it('should return false if selected gender does not match the title', () => {
			let result = instance.isTitleGenderValid('Miss', 'Male');
			expect(result).toBe(false);
		});

		it('should return false if selected gender does not match the title', () => {
			let result = instance.isTitleGenderValid('Ms', 'Male');
			expect(result).toBe(false);
		});

		it('should return true if selected gender matches the title', () => {
			let result = instance.isTitleGenderValid('Mr', 'Male');
			expect(result).toBe(true);
		});

		it('should return true if selected gender matches the title', () => {
			let result = instance.isTitleGenderValid('Master', 'Male');
			expect(result).toBe(true);
		});

		it('should return true if selected gender matches the title', () => {
			let result = instance.isTitleGenderValid('Mrs', 'Female');
			expect(result).toBe(true);
		});

		it('should return true if selected gender matches the title', () => {
			let result = instance.isTitleGenderValid('Miss', 'Female');
			expect(result).toBe(true);
		});

		it('should return true if selected gender matches the title', () => {
			let result = instance.isTitleGenderValid('Ms', 'Female');
			expect(result).toBe(true);
		});

		it('should return false if title is gender neutral in RM', () => {
			let result = instance.isTitleGenderValid('Dr', 'Male');
			expect(result).toBe(false);
		});

		it('should return false if title is gender neutral in RM', () => {
			let result = instance.isTitleGenderValid('Lady', 'Male');
			expect(result).toBe(false);
		});

		it('should return false if title is gender neutral in RM', () => {
			let result = instance.isTitleGenderValid('Lord', 'Male');
			expect(result).toBe(false);
		});

		it('should return false if title is gender neutral in RM', () => {
			let result = instance.isTitleGenderValid('Prof', 'Male');
			expect(result).toBe(false);
		});

		it('should return false if title is gender neutral in RM', () => {
			let result = instance.isTitleGenderValid('Rev', 'Male');
			expect(result).toBe(false);
		});

		it('should return false if title is gender neutral in RM', () => {
			let result = instance.isTitleGenderValid('Sir', 'Male');
			expect(result).toBe(false);
		});

		it('should return false if title is gender neutral in RM', () => {
			let result = instance.isTitleGenderValid('Dr', 'Female');
			expect(result).toBe(false);
		});

		it('should return false if title is gender neutral in RM', () => {
			let result = instance.isTitleGenderValid('Lady', 'Female');
			expect(result).toBe(false);
		});

		it('should return false if title is gender neutral in RM', () => {
			let result = instance.isTitleGenderValid('Lord', 'Female');
			expect(result).toBe(false);
		});

		it('should return false if title is gender neutral in RM', () => {
			let result = instance.isTitleGenderValid('Prof', 'Female');
			expect(result).toBe(false);
		});

		it('should return false if title is gender neutral in RM', () => {
			let result = instance.isTitleGenderValid('Rev', 'Female');
			expect(result).toBe(false);
		});

		it('should return false if title is gender neutral in RM', () => {
			let result = instance.isTitleGenderValid('Sir', 'Female');
			expect(result).toBe(false);
		});

		it('should return false if title is undefined', () => {
			let result = instance.isTitleGenderValid(undefined, 'Male');
			expect(result).toBe(false);
		});

		it('should return false if gender is undefined', () => {
			let result = instance.isTitleGenderValid('Mr', undefined);
			expect(result).toBe(false);
		});

		it('should return false if title and gender are undefined', () => {
			let result = instance.isTitleGenderValid(undefined, undefined);
			expect(result).toBe(false);
		});
	});

	describe('Joint Account Invalid Product', () => {

		beforeEach(() => {
			const container = document.createElement('div');

			instance = render(<PersonalDetailsPage
				envConfig={{}}
				data={getData()}
				content={content}
				appData={{}} />, container);

			instance = render(<PersonalDetailsPage
				envConfig={{}}
				data={getData({productInvalid: true,})}
				content={content}
				appData={{}} />, container);
		});

		afterEach(() => {
			AccountOpeningActions.navigateToWebTask.mockClear();
		});

		it('should send app to web-error screen', () => {
			expect(AccountOpeningActions.navigateToWebTask.mock.calls.length).toBe(1);
		})
	});

	describe('Title outwith predefined 11 known titles', () => {
		it('should not be read only when existing customer and invalid title', () => {
			instance = shallowRender({
				envConfig: {},
				data: getData({productInvalid: true, title: 'Wing Commander', isExistingCustomer: 'Yes'}),
				content: content,
				appData: {},
			});

			expect(instance).toIncludeJSX(
				<Title
					data={[{gender: 'Male', label: 'Mr', value: 'Mr'}, {gender: 'Female', label: 'Mrs', value: 'Mrs'}, {gender: 'Female', label: 'Miss', value: 'Miss'}, {gender: 'Female', label: 'Ms', value: 'Ms'}, {gender: 'Male', label: 'Master', value: 'Master'}, {gender: null, label: 'Dr', value: 'Dr'}, {gender: null, label: 'Lady', value: 'Lady'}, {gender: null, label: 'Lord', value: 'Lord'}, {gender: null, label: 'Prof', value: 'Prof'}, {gender: null, label: 'Rev', value: 'Rev'}, {gender: null, label: 'Sir', value: 'Sir'}]}
					dataAnchor="title"
					defaultValue={undefined}
					group="GROUP_PAGE_1"
					label="test"
					name="title"
					onChange={function noRefCheck() {}}
					readOnly={undefined}
					required={true}
				/>
			);
		});

		it('should be read only when existing customer and valid title', () => {
			instance = shallowRender({
				envConfig: {},
				data: getData({productInvalid: true, title: 'Mr', isExistingCustomer: 'Yes'}),
				content: content,
				appData: {},
			});

			expect(instance).toIncludeJSX(
				<Title
					data={[{gender: 'Male', label: 'Mr', value: 'Mr'}, {gender: 'Female', label: 'Mrs', value: 'Mrs'}, {gender: 'Female', label: 'Miss', value: 'Miss'}, {gender: 'Female', label: 'Ms', value: 'Ms'}, {gender: 'Male', label: 'Master', value: 'Master'}, {gender: null, label: 'Dr', value: 'Dr'}, {gender: null, label: 'Lady', value: 'Lady'}, {gender: null, label: 'Lord', value: 'Lord'}, {gender: null, label: 'Prof', value: 'Prof'}, {gender: null, label: 'Rev', value: 'Rev'}, {gender: null, label: 'Sir', value: 'Sir'}]}
					dataAnchor="title"
					defaultValue="Mr"
					group="GROUP_PAGE_1"
					label="test"
					name="title"
					onChange={function noRefCheck() {}}
					readOnly="Yes"
					required={true}
				/>
			);
		});
	});

	const testCases = [{
		description: 'WHEN user clicks back button AND they have not hit review AND the form is valid',
		props: {
			updateGroupValidations: () => true,
			data: {
				isReviewing: false,
				product: {
					productType: '',
				},
				completedTasks: {}
			},
			envConfig: {},
		},
		expect: 1,
	}, {
		description: 'WHEN user clicks back button AND they have not hit review AND the form is invalid',
		props: {
			updateGroupValidations: () => false,
			data: {
				isReviewing: false,
				product: {
					productType: '',
				},
				completedTasks: {}
			},
			envConfig: {},
		},
		expect: 1,
	}, {
		description: 'WHEN user clicks back button AND they have hit review AND the form is valid',
		props: {
			updateGroupValidations: () => true,
			data: {
				isReviewing: true,
				product: {
					productType: '',
				},
				completedTasks: {}
			},
			envConfig: {},
		},
		expect: 1,
	}, {
		description: 'WHEN user clicks back button AND they have hit review AND the form is invalid',
		props: {
			updateGroupValidations: () => false,
			data: {
				isReviewing: true,
				product: {
					productType: '',
				},
				completedTasks: {}
			},
			envConfig: {},
		},
		expect: 0,
	}];

	const executeTestCase = testCase => {
		it(testCase.description, () => {
			BrandUtils.isAbleToDisplay.mockReturnValue = () => true;
			AccountOpeningActions.navigateToWebTask.mockClear();
			const instance = TestUtils.renderIntoDocument(
				<PersonalDetailsPage
					{...testCase.props}
					appData={{}}
					content={content}
				/>
			);

			instance.onClickBack({preventDefault: () => {}});

			expect(AccountOpeningActions.navigateToWebTask.mock.calls.length).toBe(testCase.expect);
		});
	}

	testCases.forEach(executeTestCase);
});
