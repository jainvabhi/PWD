/**
 * @test SubmissionPage
 */
jest.unmock('../SubmissionPage');

const React = require('react');
const TestUtils = require('react-addons-test-utils');

const SubmissionPage = require('../SubmissionPage');

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');
const UrlUtils = require('../../../utils/UrlUtils');

const render = () => {
	const props = {
		content: {},
		data: {
			product: {
				name: 'Current Account Plus',
				nameSuffix: '',
			},
		},
	};
	TestUtils.renderIntoDocument(<SubmissionPage {...props} />);
};

describe('SubmissionPage', () => {
	beforeEach(() => {
		console.error = () => {};
	});

	describe('without url params', () => {
		it('should redirect to WEB-LOGIN', () => {
			render();
			expect(AccountOpeningActions.navigateToWebTask.mock.calls[0][0]).toEqual('WEB-LOGIN');
		});
	});

	describe('with url params: caseId and type', () => {
		it('should fetch the case', () => {
			const caseId = 1234;
			const type = 'savings';
			const values = {
				caseId,
				type,
			};
			UrlUtils.getParam.mockImplementation(key => values[key]);
			render();
			const getCaseCall = AccountOpeningActions.getCase.mock.calls
			expect(getCaseCall[0][0]).toBe(caseId);
			expect(getCaseCall[0][1]).toBe(type);
		});
	});
});
