jest.unmock('../JointAccountPage');

jest.unmock('../../../utils/RegexUtils');


const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');
const Helmet = require('react-helmet');

const PageHeader = require('../../common/PageHeader');
const PageColumnWrapper = require('../../common/PageColumnWrapper');
const SideBarColumnWrapper = require('../../common/SideBarColumnWrapper');
const SectionCentered = require('../../common/SectionCentered');
const ComponentHeader = require('../../common/ComponentHeader');
const RadioQuestion = require('../../common/questionsets/RadioQuestion');
const BottomNavigationBox = require('../../common/BottomNavigationBox');
const ResultSection = require('../../common/sections/ResultSection');

const JointAccountPage = require('../JointAccountPage');
const LinkCode = require('../joint/LinkCode');

const shallowRender = props => {
	const shallowRenderer = TestUtils.createRenderer();
	shallowRenderer.render(<JointAccountPage
						   {...props}
						/>);
	return shallowRenderer.getRenderOutput();
};

const render = (comp, el) => ReactDOM.render(comp, el || container);

const getContent = () => {
	return {
		jointAccountPageHeader: 'header',
		jointAccountPartyPresentNextLabel: 'label',
		jointAccountLinkCodeViewTitle: 'view-title',
		jointAccountExistingCustomerTitle: 'existing-title',
		jointAccountExistingCustomerTextQuestion: 'existing-question',
		jointAccountExistingCustomerTextQuestionHelp: 'jointAccountExistingCustomerTextQuestionHelp',
	}
};

const getProps = (linkCode, linkCaseRequestInvalid = false, hasLinkCodeAsParam = true) => {
	return {
		appData: {
			isApiCallInProgress: false,
		},
		data: {
			jointLinkCode: linkCode,
			linkCaseRequestInvalid,
		},
		content: getContent(),
		hasLinkCodeAsParam: hasLinkCodeAsParam,
	}
}

describe('JointAccountPage', () => {
	let component;
	let props;

	describe('Given party 2 lands on page', () => {
		beforeEach(() => {
			props = getProps('');
			component = shallowRender(props);
		});

		it('should render confirm link code question', () => {
			expect(component).toIncludeJSX(
				<LinkCode
					additionalLabelClasses="h3-style ja-link-code-label text-left"
					content={props.content}
					appData={{isApiCallInProgress: false}}
					data={{jointLinkCode: '', linkCaseRequestInvalid: false}}
					hasLinkCodeAsParam={true}
					onClickNext={function noRefCheck() {}}
				/>
			);
		});

		describe('and link code is already set during side by side', () => {
			beforeEach(() => {
				const container = document.createElement('div');
				props = getProps('111111', false, false);
				component = render(<JointAccountPage {...props} />, container);
			});

			it('should render existing customer question', () => {
				expect(component.state.showExistingCustomerQuestion).toBe(true);
			});
		});
	});
});
