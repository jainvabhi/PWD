jest.unmock('../PageValidator');
jest.unmock('../../../utils/ValidationUtils');

const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');

const PageValidator = require('../PageValidator');
const AccountOpeningActions = require('../../../actions/AccountOpeningActions');
const ValidationUtils = require('../../../utils/ValidationUtils');
const AnalyticsActions = require('../../../actions/AnalyticsActionCreator');

const _ = require('lodash');
const container = document.createElement('div')
const render = (comp, el) => ReactDOM.render(comp, el || container);
let instance;

const shallowRender = props => {
	const shallowRenderer = TestUtils.createRenderer();
	const WrappedComponent = PageValidator(Child);
	shallowRenderer.render(<WrappedComponent {...props} />);
	instance = render(<WrappedComponent {...props} />);
	return shallowRenderer.getRenderOutput();
};

const Child = props => (
	<h1>Child</h1>
);

describe('GIVEN a PageValidator', () => {
	const executeTest = testCase => {
		it(testCase.description, () => {
			AccountOpeningActions.enableValidation.mockClear();
			AccountOpeningActions.updateValidation.mockClear();
			AnalyticsActions.recordError.mockClear();

			const { enableCount, updateCount } = testCase.expect;
			const component = shallowRender(testCase.props);
			component.props.updateGroupValidations(testCase.group);

			const invalidFields = _.chain(testCase.props.validations[testCase.group])
			.keys()
			.filter(key => !testCase.props.validations[testCase.group][key].isValid)
			.map(key => `${key}Question`)
			.value();

			expect(AccountOpeningActions.enableValidation.mock.calls.length).toBe(enableCount);
			expect(AccountOpeningActions.updateValidation.mock.calls.length).toBe(updateCount);
			expect(AnalyticsActions.recordError.mock.calls[0][0].message).toEqual(invalidFields);
		});
	};

	const testCases = [{
		description: 'SHOULD enable all validations for group',
		expect: {
			enableCount: 3,
			updateCount: 3,
		},
		group: 'page1',
		props: {
			data: {
				product: {
					productType: {
						name: 'current',
					},
				},
			},
			validations: {
				page1: {
					firstName: {},
					lastName: {},
					nationality: {}
				},
			},
		},
	}, {
		description: 'SHOULD NOT enable validations for group that already enabled',
		expect: {
			enableCount: 2,
			updateCount: 3,
		},
		group: 'page1',
		props: {
			data: {
				product: {
					productType: {
						name: 'current',
					},
				},
			},
			validations: {
				page1: {
					firstName: {
						isEnabled: true,
					},
					lastName: {},
					nationality: {}
				},
			},
		},
	}, {
		description: 'SHOULD NOT update validation state for already valid entries',
		expect: {
			enableCount: 2,
			updateCount: 2,
		},
		group: 'page1',
		props: {
			data: {
				product: {
					productType: {
						name: 'current',
					},
				},
			},
			validations: {
				page1: {
					firstName: {},
					lastName: {
						isEnabled: true,
						isValid: true,
					},
					nationality: {}
				},
			},
		},
	}, {
		description: 'SHOULD update validation state for enabled entries',
		expect: {
			enableCount: 2,
			updateCount: 3,
		},
		group: 'page1',
		props: {
			data: {
				product: {
					productType: {
						name: 'current',
					},
				},
			},
			validations: {
				page1: {
					firstName: {},
					lastName: {},
					nationality: {
						isEnabled: true,
						isValid: false,
					}
				},
			},
		},
	}];

	testCases.forEach(executeTest);

	describe('GIVEN we have the bank lookup data', () => {
		it('when no bank details are set do not flag invalid', () => {
			const component = shallowRender({
				bankDetails: {
					main: null,
					directDebit: null,
				},
				data: {
					product: {
						productType: {
							name: 'credit-card',
						},
					},
				},
				validations: {
					page9: {
						sortCode: {
							isEnabled: true,
							isValid: true,
						},
					},
				}
			});

			expect(component.props.updateGroupValidations('page9')).toBe(true);
		});

		it('when no bank details are INVALID update state to reflect', () => {
			const component = shallowRender({
				bankDetails: {
					main: {
						inValid: true
					},
					directDebit: null,
				},
				data: {
					product: {
						productType: {
							name: 'credit-card',
						},
					},
				},
				validations: {
					page10: {
						sortCode: {
							isEnabled: true,
							isValid: true,
						},
					},
				}
			});

			expect(component.props.updateGroupValidations('page10')).toBe(false);
		});
	});
});
