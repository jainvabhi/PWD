jest.autoMockOff();

const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');

const Helmet = require('react-helmet');

const PageHeader = require('../../common/PageHeader');
const SectionCentered = require('../../common/SectionCentered');
const ComponentHeader = require('../../common/ComponentHeader');
const PartyPresentQuestion = require('../joint/PartyPresentQuestion');

const BrandUtils = require('../../../utils/BrandUtils');
const RegexUtils = require('../../../utils/RegexUtils');

const {
	LetterCodePage,
	DYBfooter,
	CYBfooter,
} = require('../LetterCodePage');
const LetterCodeForm = require('../lettercode/LetterCodeForm');
let instance;
const shallowRenderer = TestUtils.createRenderer();
const shallowRender = props => {
	instance = TestUtils.renderIntoDocument(<LetterCodePage {...props} />);

	shallowRenderer.render(
		<LetterCodePage {...props} />
	);
	return shallowRenderer.getRenderOutput();
};

const getProps = (data, apiTask = 'confirmcode') => {
	return {
		appData: {
			apiTaskId: apiTask,
		},
		validations: {},
		content: {
			letterCodePageHeader: 'letterCodePageHeader',
			letterCodePageTitle: 'letterCodePageTitle',
			phoneNumber: 'phoneNumber',
			lettercodeFooter: 'lettercodeFooter',
			lettercodeFooterFootnote: 'lettercodeFooterFootnote',
			letterCodeLabel: 'letterCodeLabel',
			letterCodeAPIError: 'letterCodeAPIError',
			letterCodeSubmitBtn: 'letterCodeSubmitBtn',
			lettercodeLimitError: 'lettercodeLimitError',
			letterCodePageUnhappyHeader: 'letterCodePageUnhappyHeader',
			letterCodePageUnhappyExplaination: 'letterCodePageUnhappyExplaination',
			sideBarTitle: 'sideBarTitle',
			letterCodeValidationMessage: 'letterCodeValidationMessage',
			letterCodeInputHelpText: 'letterCodeInputHelpText',
			jointAccountMultiPartyRadioQuestionTitle: 'jointAccountMultiPartyRadioQuestionTitle',
			letterCodeErrorInvalid: 'lettercodeErrorInvalid',
			letterCodeLimitError: 'lettercodeLimitError',
			jointAccountIsSecondPartyPresent: 'jointAccountIsSecondPartyPresent',
			jointAccountLetterCodeIntro: 'jointAccountLetterCodeIntro',
		},
		data,
	};
};

describe('LetterCodePage', () => {
	let component;
	let props;

	describe('when initially loaded', () => {
		beforeEach(() => {
			props = getProps({
				completedTasks: {},
			});
			component = shallowRender(props);
		});

		it('should render a message', () => {
			expect(component).toEqualJSX(
				<div className="account-opening letter-code-page container-fluid">
					<Helmet title='letterCodePageTitle' />
					<PageHeader
						visible={false}
						title='letterCodePageUnhappyHeader'
						{...props}
					/>

					<div className="row main-container">
						<SectionCentered centredColumnSize={12} className="result-page">
							<img
								className="letter-code-page__image"
								src="/test/images/cb/sorry-illustration.png"
							/>
							<ComponentHeader
								wrapperClass="letter-code-page__header"
								titleLevel={1}
								hasSubtitleSeparator
								title={'letterCodePageUnhappyHeader'}
								titleClass={'letter-code-page__headertitle'}
							/>
							<div className="">
								<p>letterCodePageUnhappyExplaination</p>
							</div>
						</SectionCentered>
					</div>
				</div>
			);
		});
	});

	describe('when loaded via save and resume', () => {
		beforeEach(() => {
		});

		it('should be able to progress if confirmed code task', () => {
			props = getProps({
				completedTasks: {
					'SAVE_AND_RESUME': true,
				},
			});
			component = shallowRender(props);
			expect(component).toEqualJSX(
				<div className="account-opening letter-code-page container-fluid">
					<Helmet title='letterCodePageTitle' />
					<PageHeader
						visible={false}
						title='letterCodePageHeader'
						{...props}
					/>

					<div className="row main-container">
						<SectionCentered centredColumnSize={12} className="result-page">
							<img
								className="letter-code-page__image"
								src="/test/images/cb/sorry-illustration.png"
							/>
							<ComponentHeader
								wrapperClass="letter-code-page__header"
								titleLevel={1}
								hasSubtitleSeparator
								title={'letterCodePageHeader'}
								titleClass={'letter-code-page__headertitle'}
							/>
							<div className="">

								<LetterCodeForm {...props} />
								<div className="letter-code-page__footer">
									<CYBfooter {...props} />
								</div>
							</div>

						</SectionCentered>

					</div>
				</div>
			);
		});

		it('should NOT be able to progress if confirmed  auth code task', () => {
			props = getProps({
				completedTasks: {
					'SAVE_AND_RESUME': true,
				},
			}, 'confirmauthcode');
			component = shallowRender(props);
			expect(component).not.toEqualJSX(
				<div className="account-opening letter-code-page container-fluid">
					<Helmet title='letterCodePageTitle' />
					<PageHeader
						visible={false}
						title='letterCodePageHeader'
						{...props}
					/>

					<div className="row main-container">
						<SectionCentered centredColumnSize={12} className="result-page">
							<img
								className="letter-code-page__image"
								src="/test/images/cb/sorry-illustration.png"
							/>
							<ComponentHeader
								wrapperClass="letter-code-page__header"
								titleLevel={1}
								hasSubtitleSeparator
								title={'letterCodePageHeader'}
								titleClass={'letter-code-page__headertitle'}
							/>
							<div className="">

								<LetterCodeForm {...props} />
								<div className="letter-code-page__footer">
									<CYBfooter {...props} />
								</div>
							</div>

						</SectionCentered>

					</div>
				</div>
			);
		});
	});


	describe('when on party 1 load 1st time', () => {
		beforeEach(() => {
			props = getProps({
				completedTasks: {'WEB-SUBMIT-CALL3D': true},
				jointLinkCode: '43232',
			});
			component = shallowRender(props);
		});

		it('should offer party2 questions to continue', () => {
			expect(component).toIncludeJSX(
				<PartyPresentQuestion {...props} />
			);
		});
	});

});
