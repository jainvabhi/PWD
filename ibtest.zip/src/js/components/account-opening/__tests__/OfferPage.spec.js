jest.unmock('../../../config');
jest.unmock('../../common/sections/ResultSection');
jest.unmock('../../common/ComponentHeader');
jest.unmock('../OfferPage');
jest.unmock('../offer/AltProducts');
jest.unmock('../offer/BasicOffer');
jest.unmock('../offer/OfferHOC');
jest.unmock('../offer/OfferDetails');
jest.unmock('../offer/MultiProducts');
jest.unmock('../offer/SingleProduct');
jest.unmock('../offer/OfferSummary');
jest.unmock('../offer/OfferSummary');
jest.unmock('../../../documents');

const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');
const TestHelpers = require('../../../__helpers__/TestHelpers');
const _ = require('lodash');
const { buildFindMockByDataAnchorFilter, buildContent } = require('../../../__helpers__/TestHelpers');

const config = require('../../../config');
const OfferPage = require('../OfferPage');
const ProductUtils = require('../../../utils/ProductUtils');
const BrandUtils = require('../../../utils/BrandUtils');
const ValidationUtils = require('../../../utils/ValidationUtils');
const ContentUtils = require('../../../utils/ContentUtils');
const HtmlUtils = require('../../../utils/HtmlUtils');
const ScreenshotUtils = require('../../../utils/ScreenshotUtils');

const PageHeader = require('../../common/PageHeader');
const CheckBoxQuestion = require('../../common/questionsets/CheckBoxQuestion');
const ResultSection = require('../../common/sections/ResultSection');
const ListSection = require('../../common/sections/ListSection');

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');

const container = document.createElement('div');
const render = (comp, el) => ReactDOM.render(comp, el || container);

let instance;

const contentKeys = [
	'offerPageUnsuccessfulTitle',
	'offerPageAlternativeOfferTitle',
	'offerPageDowngradeTitle',
	'offerPageHeader',
	'offerPageTitle',
	'offerPageAltTitle',
	'offerPageSubTitle',
	'offerPageIntroTitle',
	'offerPageKeyFeaturesTitle',
	'offerPageofferRestrictionsTitle',
	'offerPageDocumentToReadSectionTitle',
	'offerPageDeclineOffer',
	'offerConditionsIntro',
	'offerTandCQuestion',
	'mandateBullet9',
	'mandateBullet10',
	'mandateBullet12',
	'offerPageContinue',
	'openAccountButton',
	'declineAccountButton',
	'downgradedOfferPageEmail',
	'downgradedOfferPageKeyFeaturesTitle',
	'downgradedOfferKeyFeaturesParagraph',
	'termsAndConditionsDocLinkText',
	'tariffDocLinkText',
	];

const content = buildContent(contentKeys);
const shallowRenderer = TestUtils.createRenderer();



const productStub = {
	"reference_id": "CS-10001",
	"uuid": "xxxxxxxxxxxxx",
	"offers": [{
		"id": "OFFER-1",
		"product": {
			"name": "CURRENT ACCOUNT",
			"code": "136",
		},
		"features": {},
	},
	{
		"id": "OFFER-2",
		"product": {
			"name": "SAVINGS ACCOUNT",
			"code": "125",
		},
		"features": {},
	}]
};

const downgradeProductStub = {
	"reference_id": "CS-10001",
	"uuid": "zzzzzzzzzzzzzzz",
	"offers": [{
		"id": "OFFER-2",
		"product": {
			"name": "CURRENT ACCOUNT",
			"code": "800",
		},
		"features": {},
	}]
};

const stubfactory = (isAltProduct) => {
	const stub = isAltProduct ? downgradeProductStub : productStub;
	return _.clone(stub);
};

const setProduct = (isAltProduct) => {
	const offers = stubfactory(isAltProduct);
	const newData = {
		productOffer: offers,
		productCode: isAltProduct ? 'IMxxxx' : 'IM136',
		isAltProduct: isAltProduct,
		product: {
			alternativeOfferItems: [1, 2, 3],
			name: 'blah',
			nameSuffix: '',
		   	offerRestrictions: [1, 2, 3, 4],
		   	additionalDocumentItems: [1, 2, 3, 4, 5],
			productType: {
				name: 'savings',
			}
		},
	};
	instance = render(
		<OfferPage
			data={newData}
			content={content}
			validations={{}}
			documents={undefined}
			appData={{isApiCallInProgress: false}}
		/>
	);

};

ProductUtils.getProduct.mockReturnValue({
	alternativeOfferItems: [1, 2, 3],
	name: 'blah',
   	offerRestrictions: [1, 2, 3, 4],
   	additionalDocumentItems: [1, 2, 3, 4, 5],
	productType: {
		name: 'savings',
	}
});

describe('OfferPage', () => {
	beforeEach(() => {
		const data = {
			productCode: 'IM1343',
			product: {
				alternativeOfferItems: [],
				productType: {
					name: 'current',
				},
				name: 'blah',
				nameSuffix: '',
			},
		};

		ValidationUtils.isGroupValid.mockReturnValue(true)

		const promise = TestHelpers.buildPromise('catch');

		BrandUtils.hasFeature.mockReturnValue(promise);

		instance = render(
			<OfferPage data={data} validations={{}} documents={undefined} content={content} appData={{}} />
		);
	});

	describe('componentWillReceiveProps', () => {
		it('returns an empty list if no items are passed in', () => {
			expect(AccountOpeningActions.updateOfferStatus.mock.calls.length).toBe(0);
		});

		describe('WHEN downGrade', () => {
			beforeEach(() => {
				AccountOpeningActions.updateOfferStatus.mockClear();
				setProduct(true);
			});

			it('calls the action to downgrade app state', () => {
				expect(AccountOpeningActions.updateOfferStatus.mock.calls[0][0]).toBe(true)
			});

			it('sets downgraded offer into state', () => {
				expect(instance.state.offers[0]).toEqual({
					...stubfactory(true).offers[0]
				})
			});
		});

	});

	describe('onClickActionAccount', () => {

		beforeEach(() => {
			spyOn(ScreenshotUtils, 'takeScreenshot').and.callFake((action, caseId) => {
				action();
			});
			console.warn = jest.genMockFunction();
		});

		describe('WHEN downGrade', () => {
			let button;
			beforeEach(() => {
				setProduct(true);
			});

			describe('decline', () => {
				beforeEach(() => {
					AccountOpeningActions.respondToProductOffer.mockClear();
					button = TestUtils.findRenderedDOMComponentWithClass(
						instance,
						'btn-decline'
					);
					TestUtils.Simulate.click(button);
				});

				it('should fire action to decline ', () => {
					expect(AccountOpeningActions.respondToProductOffer.mock.calls[0][0]).toBe(stubfactory(true).offers[0].id);
					expect(AccountOpeningActions.respondToProductOffer.mock.calls[0][1]).toBe(true)
				});
			});


			describe('accept', () => {

				beforeEach(() => {
					BrandUtils.hasFeature.mockClear();
					AccountOpeningActions.respondToProductOffer.mockClear();

					button = TestUtils.findRenderedDOMComponentWithClass(
						instance,
						'btn-next'
					);

					const promise = TestHelpers.buildPromise();

					BrandUtils.hasFeature.mockReturnValue(promise);

					TestUtils.Simulate.click(button);
				});

				it('should fire action to accept ', () => {
					expect(AccountOpeningActions.respondToProductOffer.mock.calls[0][0]).toBe(stubfactory(true).offers[0].id);
					expect(AccountOpeningActions.respondToProductOffer.mock.calls[0][1]).toBe(false)
				});

				it('should take screenshot of offer page', () => {
					expect(ScreenshotUtils.takeScreenshot).toHaveBeenCalled();
				});
			});
		});

		describe('WHEN normal offer', () => {
			let button;

			beforeEach(() => {
				setProduct(false);
			});

			describe('accept', () => {

				beforeEach(() => {
					AccountOpeningActions.respondToProductOffer.mockClear();
					button = TestUtils.findRenderedDOMComponentWithClass(
						instance,
						'btn-next'
					);

					const promise = TestHelpers.buildPromise();
					BrandUtils.hasFeature.mockReturnValue(promise);
					TestUtils.Simulate.click(button);
				});

				it('should fire action to accept ', () => {
					expect(AccountOpeningActions.respondToProductOffer.mock.calls[0][0]).toBe(stubfactory(false).offers[0].id);
					expect(AccountOpeningActions.respondToProductOffer.mock.calls[0][1]).toBe(false)
				});

				it('should take screenshot of offer page', () => {
					expect(ScreenshotUtils.takeScreenshot).toHaveBeenCalled();
				});
			});
		});

		it('should NOT fire action to accept when no offerId  ', () => {
			AccountOpeningActions.respondToProductOffer.mockClear();
			const stub = stubfactory(false);
			let newProps;
			let button;

			//stub.offers[0].id = undefined;

			newProps = _.assign({}, instance.props, {
				appData: {
					isApiCallInProgress: false
				},
				data: {
					productOffer: stub,
					productCode: 'IM125',
					isAltProduct: true,
					product: {
						name: 'test',
						nameSuffix: '',
						alternativeOfferItems: [],
						productType: {
							name: 'savings',
						}
					},
				}
			});

			instance = render(
				<OfferPage data={newProps.data} validations={{}} documents={undefined} content={newProps.content} appData={newProps.appData} />
			);

			instance.onClickActionAccount(false, undefined)
			expect(AccountOpeningActions.respondToProductOffer.mock.calls.length).toBe(0);
		});
	});
});
