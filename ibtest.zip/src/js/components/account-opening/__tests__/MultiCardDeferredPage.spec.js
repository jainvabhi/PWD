jest.autoMockOff();

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const ReactDOM = require('react-dom');
const _ = require('lodash');

const container = document.createElement('div');
const render = (comp, el) => ReactDOM.render(comp, el || container);
const shallowRenderer = TestUtils.createRenderer();


const { buildContent } = require('../../../__helpers__/TestHelpers');

const MultiCardDeferredPage = require('../MultiCardDeferredPage');
const Helmet = require('react-helmet');

// Components
const ResultSection = require('../../common/sections/ResultSection');
const PageHeader = require('../../common/PageHeader');

// Utils
const BrandUtils = require('../../../utils/BrandUtils');
const ProductUtils = require('../../../utils/ProductUtils');
const ContentUtils = require('../../../utils/ContentUtils');


describe('Deferred Page', function() {
	let instance, result, component;
	let props = {
		content: buildContent([
			'multiCardDeferredPageTitle',
			'multiCardDeferredPageIntro',
			'multiCardDeferredPageListIntro',
			'multiCardDeferredPageListItem1',
			'multiCardDeferredPageListItem2',
			'multiCardDeferredPageListItem3',
			'landingPageTitle',
		]),
		data: {
			productCode:'IM135',
			product: {
				name: 'Current Account Plus',
				nameSuffix: '',
			},
		}
	}


	beforeEach(() => {
		component = (
			<MultiCardDeferredPage
				{...props} />
		);

		instance = render(component);
		shallowRenderer.render(component);
		result = shallowRenderer.getRenderOutput();

	});

	it ('renders with no deferred items', function() {
		expect(result).toEqualJSX(
				<div className="account-opening result-page-wrapper deferred-page-wrapper container-fluid">
					<Helmet title={props.content.deferredPageHeader} />
					<PageHeader visible={false}
								title={'landingPageTitleCurrent Account Plus'}
								content={props.content}
					/>
					<div className="result-page multi-carddeferred-page" role="main">
						<div className="row text-center">
							<div className="col-xs-12">
								<ResultSection
									imgSrc={BrandUtils.getResultImage('deferred-page-with-image', 'time-illustration.png')}
									imgAlt="Deferred Result"
									title={props.content.multiCardDeferredPageTitle}
								/>
								<div className="white-board">
									<p>{props.content.multiCardDeferredPageIntro}</p>

									<p>{props.content.multiCardDeferredPageListIntro}</p>
									<ul className="list-unstyled">
										<li>multiCardDeferredPageListItem1</li>
										<li>multiCardDeferredPageListItem2</li>
										<li>multiCardDeferredPageListItem3</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
		)
	});

});
