jest.unmock('../LoginPage');

const React = require('react');
const TestUtils = require('react-addons-test-utils');

const LoginPage = require('../LoginPage');
const PageSessionActions = require('../../../actions/PageSessionActions');
const { buildContent } = require('../../../__helpers__/TestHelpers');

const content = buildContent(['loginPageHeader']);

const render = () => {
	const props = {
		content,
	};
	TestUtils.renderIntoDocument(<LoginPage {...props} />);
};

describe('LoginPage', () => {
	describe('on mount', () => {
		it('sets PageSession persisted', () => {
			render();
			expect(PageSessionActions.setPageSession.mock.calls[0][0]).toEqual({
				persisted: true,
			});
		});
	});
});
