/**
 * @test HasTransfered
 */
jest.unmock('../HasTransfered');

const React = require('react');
const TestUtils = require('react-addons-test-utils');

const HasTransfered = require('../HasTransfered');

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');
const SessionServerActionCreator = require('../../../actions/SessionServerActionCreator');
const UrlUtils = require('../../../utils/UrlUtils');

let data = {};
let content = {};
let result;
let instance;

const Component = props => (
	<HasTransfered {...props}/>
);

const shallowRender = props => {
	const shallowRenderer = TestUtils.createRenderer();

	shallowRenderer.render(
		<Component{...props} />
	);
	instance = TestUtils.renderIntoDocument(<Component {...props} />);
	return shallowRenderer.getRenderOutput();
};

describe('HasTransfered', () => {

	beforeEach(() => {
		SessionServerActionCreator.setAccessToken.mockClear();
		AccountOpeningActions.updateFormValue.mockClear();
		const props = {
			data,
			appData: {},
			content,
			location: {
				hash: '#case_id=test_case_id&id_token=test_token',
				pathname: '',
				search: '',
				action: '',
				query: '',
			}
		}
		result = shallowRender(props);
	});

	it('should set flag for having transfered', () => {
		expect(AccountOpeningActions.updateFormValue.mock.calls[0][0]).toBe('hasTransfered');
		expect(AccountOpeningActions.updateFormValue.mock.calls[0][1]).toBe(true);
	});

	it('should set case id', () => {
		expect(AccountOpeningActions.updateFormValue.mock.calls[1][0]).toBe('caseId');
		expect(AccountOpeningActions.updateFormValue.mock.calls[1][1]).toBe('test_case_id');
	});

	it('should set access token', () => {
		expect(SessionServerActionCreator.setAccessToken.mock.calls.length).toBe(1);
		expect(SessionServerActionCreator.setAccessToken.mock.calls[0][0]).toEqual({
			scope: 30,
			access_token: 'test_token',
		});
	});



});
