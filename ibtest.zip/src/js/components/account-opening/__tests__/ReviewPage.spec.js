jest.unmock('../ReviewPage');
jest.unmock('react-bootstrap-datetimepicker');
jest.unmock('../../../config/BrandConfig');
jest.unmock('../../../config');
jest.unmock('../../common/PageColumnWrapper');
jest.unmock('../../../config/ProductData');
jest.unmock('../review/CurrentAccountReviewSection');
jest.unmock('../review/DeclarationAndAuthSection');
jest.unmock('../../common/links/NewWindowLink');
jest.unmock('../review/GeneralReviewSection');
jest.unmock('../review/MarketingPrefSection');


const React = require('react');
const TestUtils = require('react-addons-test-utils');

const _ = require('lodash');

const ReviewPage = require('../ReviewPage');
const ArrayUtils = require('../../../utils/ArrayUtils');
const MaskingUtils = require('../../../utils/MaskingUtils');
const PathUtils = require('../../../utils/PathUtils');
const BrandUtils = require('../../../utils/BrandUtils');
const config = require('../../../config');
const CredentialsActions = require('../../../actions/CredentialsActions');

const BottomNavigationBox = require('../../common/BottomNavigationBox');
const MandateSection = require('../review/MandateSection');
const MultiCheckBoxQuestion = require('../../common/questionsets/MultiCheckBoxQuestion');


PathUtils.getPath.mockReturnValue('/test/');
BrandUtils.appendBrand.mockReturnValue('/test/');

const product = {
	productLink: 'test1',
	name: 'test1',
	productType: { name: 'current', urlPart: 'current' },
	additionalDocumentItems: [
	'tariff',
	'financialServicesCompensationScheme',
	'termsAndConditions'
	],
	mandateItems: ['test1', 'test2', 'NOKEY']
}

const getData = props => {
	return {
		product: {
			productType: {
				name: 'current',
			},
		},
		...props,
	};
};

describe('ReviewPage', () => {
	let instance;

	const content = {
		test1: 'test 1',
		test1: 'test 1',
		test2: 'test 2',
		tariffDocLinkText: 'test',
		tariffDocLinkLink: 'test',
		financialServicesCompensationSchemeDocLinkText: 'test',
		financialServicesCompensationSchemeDocLink: 'test',
		termsAndConditionsDocLinkText: 'test',
		termsAndConditionsDocLink: 'test',
	};

	const data = {
		productCode: 'IM136',
		product: product,
	};

	beforeEach(() => {
		BottomNavigationBox.mockClear();
		MultiCheckBoxQuestion.mockClear();

		instance = TestUtils.renderIntoDocument(
			<ReviewPage appData={{}} content={content} data={data} validations={{}} />
		);
	});

	describe('First render', () => {
		it('is defined', () => {
			expect(instance).toBeDefined()
		});

		it('should render the marketing questions', () => {
			expect(MultiCheckBoxQuestion.mock.calls.length).toBe(1);
		});

		it('should render a next button', () => {
			expect(BottomNavigationBox.mock.calls.length).toBe(1);
		});
	});

	describe('and a bank id is present', () => {
		beforeEach(() => {
			instance = TestUtils.renderIntoDocument(<ReviewPage
				envConfig={{}}
				data={getData({bankID: 'DYB',})}
				content={content}
				session={{
					accessToken: 'accessToken'
				}}
				validations={{}}
				appData={{}} />
			);
		});

		it('should call for credentials', () => {
			expect(CredentialsActions.getCredentials.mock.calls.length).toBe(1);
		});
	});


	describe('getTaxObligations', () => {
		it('should return a string containing No if there are no tax obligations', () => {
			const noObligations = 'Yes';
			const result = instance.getTaxObligations(noObligations, undefined);
			expect(result).toMatch('No');
		});

		it('it should render the string using ArrayUtils', () => {
			ArrayUtils.getCommaString.mockClear();
			const noObligations = 'No';
			const result = instance.getTaxObligations(noObligations, 'test');
			expect(ArrayUtils.getCommaString.mock.calls.length).toBe(1);
		});
	});

	describe('formatPhoneNumber', () => {
		it('existing customer is masked', () => {
			MaskingUtils.applyMask.mockClear();

			const instance = TestUtils.renderIntoDocument(
				<ReviewPage
				appData={{}}
				validations={{}}
				content={content}
				data={
					{
						productCode: 'IM135',
						product: product,
						isExistingCustomer: 'Yes',
						phoneNumber: '07711316179',
					}
				} />
			);

			expect(MaskingUtils.applyMask.mock.calls[0]).toEqual(['07711316179', 3, 5]);
		});

		it('ntb is not masked', () => {
			MaskingUtils.applyMask.mockClear();

			const instance = TestUtils.renderIntoDocument(
				<ReviewPage
				appData={{}}
				validations={{}}
				content={content}
				data={
					{
						productCode: 'IM135',
						product: product,
						isExistingCustomer: 'No',
						phoneNumber: '07711316179',
					}
				} />
			);

			expect(MaskingUtils.applyMask.mock.calls.length).toBe(0);
		});
	});
});
