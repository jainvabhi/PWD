jest.unmock('../AppStyle');

// React
const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');

// Component
const AppStyle = require('../AppStyle');
const _ = require('lodash');

const container = document.createElement('div');
const render = (comp, el) => ReactDOM.render(comp, el);

describe('DropdownQuestion', () => {

	describe('on the DYB bank', ()=> {
		it('uses the dyb class', () => {
			let props = {
				bankId: 'DYB',
				children: [],
				data: {
					isAltProduct: false,
				},
			};
			const instance = render(<AppStyle {...props} />, container);
			expect(document.body.className).toEqual('dyb');
		});
	});

	describe('on the YB bank', ()=> {
		it('uses the yb class', () => {
			let props = {
				bankId: 'YB',
				children: [],
				data: {
					isAltProduct: false,
				},
			};
			const instance = render(<AppStyle {...props} />, container);
			expect(document.body.className).toEqual('yb');
		});
	});

	describe('on the YB bank with isAltProduct and BANKID YB', ()=> {
		it('uses the yb', () => {
			let props = {
				bankId: 'YB',
				children: [],
				data: {
					isAltProduct: true,
					bankID: 'YB',
				},
			};
			const instance = render(<AppStyle {...props} />, container);
			expect(document.body.className).toEqual('yb alt-product yb-offer');
		});
	});

	describe('on the CB bank', ()=> {
		it('', () => {
			let props = {
				bankId: 'CB',
				children: [],
				data: {
					isAltProduct: false,
				},
			};
			const instance = render(<AppStyle {...props} />, container);
			expect(document.body.className).toEqual('cb');
		});
	});

	describe('on the CB bank with isAltProduct and BANKID CB', ()=> {
		it('', () => {
			let props = {
				bankId: 'CB',
				children: [],
				data: {
					isAltProduct: true,
					bankID: 'CB',
				},
			};
			const instance = render(<AppStyle {...props} />, container);
			expect(document.body.className).toEqual('cb alt-product cb-offer');
		});
	});
});
