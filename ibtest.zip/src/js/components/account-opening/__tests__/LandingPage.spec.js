jest.unmock('../LandingPage');
jest.unmock('../../common/questionsets/RadioQuestion');
jest.unmock('../../common/links/DocumentLink');
jest.unmock('../../../utils/BrandUtils');

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const ReactDOM = require('react-dom');
const _ = require('lodash');

const container = document.createElement('div');
const render = (comp) => ReactDOM.render(comp, container);
const shallowRenderer = TestUtils.createRenderer();

const ComponentHeader = require('../../common/ComponentHeader');
const RadioQuestion = require('../../common/questionsets/RadioQuestion');
const PageHeader = require('../../common/PageHeader');
const ProgressBar = require('./../ProgressBar');
const SectionFullWidth = require('../../common/SectionFullWidth');
const PageColumnWrapper = require('../../common/PageColumnWrapper');
const SideBarColumnWrapper = require('../../common/SideBarColumnWrapper');
const ContentProductWrapper = require('../../common/ContentProductWrapper');
const AccountOpeningActions = require('../../../actions/AccountOpeningActions');
const AccountOpeningConstants = require('../../../constants/AccountOpeningConstants');

const ValidationStore = require('../../../stores/ValidationStore');
const BrandUtils = require('../../../utils/BrandUtils');
const ProductUtils = require('../../../utils/ProductUtils');

const LandingPage = require('../LandingPage');

describe('Landing Page', function() {

	const content = {
		landingPageTitle: 'landingPageTitle',
		existingCustomerTitle : 'existingCustomerTitle',
		isExistingCustomer: 'isExistingCustomer',
		eligibilityAge18Question:'eligibilityAge18Question',
		eligibilityBankruptQuestion:'eligibilityBankruptQuestion',
		eligibilityUKResidentQuestion:'eligibilityUKResidentQuestion',
		eligibilityDeviceQuestion:'eligibilityDeviceQuestion',
	};
	const appData = {};
	const data = {
		productCode: 'IM135',
		isExistingCustomer: 'No',
		product: {
			eligibilityQuestions: {
				'eligibilityAge18Question': 'Yes',
				'eligibilityBankruptQuestion' : 'No',
				'eligibilityUKResidentQuestion': 'Yes',
			},
			productType:{
				name: 'savings',
			},
			name: 'Current Account Plus',
			nameSuffix: '',
		},
	};

	let instance;
	let component;
	let result;

	beforeEach(() => {
		BrandUtils.isAbleToDisplay = () => true;
		component = (
			<LandingPage
				content={content}
				data={data}
				appData={appData}
				getProductContent={() => {}}
			/>
		);

		instance = render(component);
		shallowRenderer.render(component);
		result = shallowRenderer.getRenderOutput();
	});

	describe('render()', function() {
		it('the default layout', function() {

			expect(result).toEqualJSX(
				<div className="account-opening landing-page container-fluid">
					<PageHeader title={'landingPageTitleCurrent Account Plus'} content={content} />

					<div className="row main-container" content={content}>
						<PageColumnWrapper content={content}>

							{/* Progress Bar */}
							<SectionFullWidth>
								<ProgressBar timeRemaining={15} />
							</SectionFullWidth>

							<SectionFullWidth>
								<ComponentHeader title={'existingCustomerTitle'} hasSeparator titleLevel={2}>
									<RadioQuestion
										align={BrandUtils.isAbleToDisplay('initial-questions-radio-buttons-right') ? 'right' : 'left'}
										defaultValue={'No'}
										group={AccountOpeningConstants.GROUP_ELIGIBILITY}
										labelText={'isExistingCustomer'}
										mainColumnSize={BrandUtils.defaultColumnSize() === 12 ? 12 : 5}
										mainColumnSizeMD={BrandUtils.defaultColumnSize() === 12 ? 12 : 6}
										name="isExistingCustomer"
										onChange={AccountOpeningActions.updateFormValue}
										options={[{ anchor: 'existing-customer-no', value: 'No' }, { anchor: 'existing-customer-yes', value: 'Yes' }]}
										required
										validateEqualTo="No"
									/>
								</ComponentHeader>
							</SectionFullWidth>

						</PageColumnWrapper>

						<SideBarColumnWrapper
							appData={appData}
							content={content}
							data={data}
						/>
					</div>
				</div>
			);

		});
	});

	describe('getEligibilityQuestionElements()', function() {
		beforeEach(() => {
			BrandUtils.isAbleToDisplay = () => true;
			ValidationStore.getValidation = () => true;
			component = (
				<LandingPage
					content={content}
					data={data}
					appData={appData}
					getProductContent={() => {}}
				/>
			);

			instance = render(component);
			shallowRenderer.render(component);
			result = shallowRenderer.getRenderOutput();
		});

		it('render the mapped questions with valid conditions', function() {
			expect(result).toIncludeJSX(
				<ComponentHeader
					hasSeparator={true}
					subTitle={undefined}
					title={undefined}
					titleLevel={2}
					wrapperClass="initial-questions"
					>
					<RadioQuestion
						align={'right'}
						defaultValue={data['eligibilityAge18Question']}
						group={'GROUP_ELIGIBILITY'}
						id={'eligibilityAge18Question'}
						labelText={content['eligibilityAge18Question']}
						mainColumnSize={6}
						mainColumnSizeMD={6}
						name={'eligibilityAge18Question'}
						onChange={() => {}}
						options={[{ value: 'No' }, { value: 'Yes' }]}
						required
						validateEqualTo={'Yes'}
					/>
					<RadioQuestion
						align={'right'}
						defaultValue={data['eligibilityBankruptQuestion']}
						group={'GROUP_ELIGIBILITY'}
						id={'eligibilityBankruptQuestion'}
						labelText={content['eligibilityBankruptQuestion']}
						mainColumnSize={6}
						mainColumnSizeMD={6}
						name={'eligibilityBankruptQuestion'}
						onChange={() => {}}
						options={[{ value: 'No' }, { value: 'Yes' }]}
						required
						validateEqualTo={'No'}
					/>
					<RadioQuestion
						align={'right'}
						defaultValue={data['eligibilityUKResidentQuestion']}
						group={'GROUP_ELIGIBILITY'}
						id={'eligibilityUKResidentQuestion'}
						labelText={content['eligibilityUKResidentQuestion']}
						mainColumnSize={6}
						mainColumnSizeMD={6}
						name={'eligibilityUKResidentQuestion'}
						onChange={() => {}}
						options={[{ value: 'No' }, { value: 'Yes' }]}
						required
						validateEqualTo={'Yes'}
					/>
					<RadioQuestion
						align={'right'}
						defaultValue={data['eligibilityDeviceQuestion']}
						group={'GROUP_ELIGIBILITY'}
						id={'eligibilityDeviceQuestion'}
						labelText={content['eligibilityDeviceQuestion']}
						mainColumnSize={6}
						mainColumnSizeMD={6}
						name={'eligibilityDeviceQuestion'}
						onChange={() => {}}
						options={[{ value: 'No' }, { value: 'Yes' }]}
						required
						validateEqualTo={'Yes'}
					/>
				</ComponentHeader>

			);

		});
	});


});
