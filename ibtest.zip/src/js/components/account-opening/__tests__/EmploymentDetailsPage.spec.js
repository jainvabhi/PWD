jest.unmock('../EmploymentDetailsPage');
jest.unmock('../employment/TaxObligationsComponent');
jest.unmock('../employment/Nationality');
jest.unmock('react-bootstrap-datetimepicker');
jest.unmock('../../../config');
jest.unmock('../../../utils/BrandUtils');

// React
const React = require('react');

// React Addons
const TestUtils = require('react-addons-test-utils');

// Component
const EmploymentDetailsPage = require('../EmploymentDetailsPage');
const AccountOpeningActions = require('../../../actions/AccountOpeningActions');
const BrandUtils = require('../../../utils/BrandUtils');

// Lodash
const _ = require('lodash');

describe('Employment Details Page', () => {

	const content = {
	};

	let data = {
		productCode: 'IM136',
	};

	let instance;

	beforeEach(() => {
		instance = TestUtils.renderIntoDocument(
			<EmploymentDetailsPage
				data={data}
				appData={{}}
				content={content} />
		);
	})

	it ('should be defined', function() {
		expect(instance).toBeDefined();
	});


	const testCases = [{
		description: 'WHEN user clicks back button AND they have not hit review AND the form is valid',
		props: {
			updateGroupValidations: () => true,
			data: {
				isReviewing: false,
			}
		},
		expect: 1,
	}, {
		description: 'WHEN user clicks back button AND they have not hit review AND the form is invalid',
		props: {
			updateGroupValidations: () => false,
			data: {
				isReviewing: false,
			}
		},
		expect: 1,
	}, {
		description: 'WHEN user clicks back button AND they have hit review AND the form is valid',
		props: {
			updateGroupValidations: () => true,
			data: {
				isReviewing: true,
			}
		},
		expect: 1,
	}, {
		description: 'WHEN user clicks back button AND they have hit review AND the form is invalid',
		props: {
			updateGroupValidations: () => false,
			data: {
				isReviewing: true,
			}
		},
		expect: 0,
	}];

	const executeTestCase = testCase => {
		it(testCase.description, () => {
			BrandUtils.isAbleToDisplay.mockReturnValue = () => true;
			AccountOpeningActions.navigateToWebTask.mockClear();
			const instance = TestUtils.renderIntoDocument(
				<EmploymentDetailsPage
					{...testCase.props}
					appData={{}}
					content={content}
				/>
			);

			instance.onClickBack({preventDefault: () => {}});

			expect(AccountOpeningActions.navigateToWebTask.mock.calls.length).toBe(testCase.expect);
		});
	}

	testCases.forEach(executeTestCase);
});
