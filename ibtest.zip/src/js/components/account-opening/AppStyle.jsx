const React = require('react');
const { PropTypes } = React;
const cx = require('classnames');
const withSideEffect = require('react-side-effect');

function appClassNames(bankId, data) {
	return cx({
		dyb: bankId === 'DYB',
		yb: bankId === 'YB',
		cb: bankId === 'CB',
		'alt-product': data.isAltProduct,
		'cb-offer': data.isAltProduct && data.bankID === 'CB',
		'yb-offer': data.isAltProduct && data.bankID === 'YB',
	});
}

const AppStyle = React.createClass({
	propTypes: {
		bankId: PropTypes.string.isRequired,
		children: PropTypes.array.isRequired,
		data: PropTypes.object.isRequired,
	},

	render() {
		return (
			<div>{this.props.children}</div>
		);
	},
});

function reducePropsToState(propsList) {
	let bankId = '';
	let data = {};
	propsList.forEach(props => {
		if (props.bankId) { bankId = props.bankId; }
		if (props.data) { data = props.data; }
	});
	return appClassNames(bankId, data);
}

function handleStateChangeOnClient(classNames) {
	document.body.className = classNames;
}

module.exports = withSideEffect(
	reducePropsToState,
	handleStateChangeOnClient
)(AppStyle);
