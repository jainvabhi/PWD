/**
 * @module AuthenticationPage
 */

const React = require('react');
const Helmet = require('react-helmet');
const { withRouter, routerShape } = require('react-router');
const PropTypes = React.PropTypes;

const PageHeader = require('../common/PageHeader');
const PageColumnWrapper = require('../common/PageColumnWrapper');
const SideBarColumnWrapper = require('../common/SideBarColumnWrapper');

const SectionCentered = require('../common/SectionCentered');

const LoadingSpinner = require('../LoadingSpinner');
const AccountOpeningActions = require('../../actions/AccountOpeningActions');
const CustomerActions = require('../../actions/CustomerActions');
const AppActions = require('../../actions/AppActions');

const CustomerStore = require('../../stores/CustomerStore');
const SessionStore = require('../../stores/SessionStore');

const BrandUtils = require('../../utils/BrandUtils');
const UrlUtils = require('../../utils/UrlUtils');

const getStateFromStores = () => {
	return {
		customer: CustomerStore.getAll(),
		challenge: SessionStore.getChallenge(),
		authentication: SessionStore.getAuthentication(),
	};
};

const AuthenticationPage = React.createClass({
	propTypes: {
		data: PropTypes.object,
		content: PropTypes.object,
		envConfig: PropTypes.object,
		validations: PropTypes.object,
		appData: PropTypes.object,
		session: PropTypes.object,
		router: routerShape,
	},

	/**
	 * Get values from store as well as set the first question.
	 * @return {object} initial state
	 */
	getInitialState() {
		const baseState = { fetchingUserDetails: false };
		return { ...baseState, ...getStateFromStores() } || baseState;
	},

	componentDidMount() {
		if (!BrandUtils.isAbleToDisplay('authentication-page')) {
			AppActions.handleError({
				source: 'Authentication.disabled',
			});
		}

		CustomerStore.addChangeListener(this._onStoreChange);

		AccountOpeningActions.updateFormValue('isExistingCustomer', 'Yes');
	},

	componentWillReceiveProps(nextProps) {
		if (nextProps.session.challengeMissingDetailsError) {
			AppActions.handleError({
				source: 'AuthenticationPage.missingDetails',
				missingDetails: true,
			});
		}

		if (nextProps.session.authenticated && !this.state.fetchingUserDetails && nextProps.data.bankID) {
			this.setState({ fetchingUserDetails: true }, () => {
				CustomerActions.getCustomers();
			});
		}
	},

	componentWillUnmount() {
		CustomerStore.removeChangeListener(this._onStoreChange);
	},

	_onStoreChange() {
		this.setState(getStateFromStores(), () => {
			this.fetchCustomerData();
		});
	},

	/**
	 * Fetches customer data and redirects to the next screen on success
	 * On failure redirects to error page
	 */
	fetchCustomerData() {
		const customer = this.state.customer;

		if (customer.error) {
			AppActions.handleError({
				source: 'Authentication.customerError',
			});
			return;
		}

		if (!customer.customerId && !customer.isGetCustomersRequesting) {
			CustomerActions.getCustomers();
		}

		if (customer.customerId && !customer.customerNumber && !customer.isGetCustomerByIdRequesting) {
			CustomerActions.getCustomerById();
		}

		if (customer.customerNumber) {
			if (!UrlUtils.getParam('returnUrl')) {
				AccountOpeningActions.navigateToWebTask('WEB-ELIGIBILITY-PAGE');
			} else {
				this.props.router.push(UrlUtils.getParam('returnUrl'));
			}
		}
	},

	render() {
		const authPageTitle = BrandUtils.isAbleToDisplay('auth-page-title') ? this.props.content.authPageTitle : `${this.props.content.landingPageTitle}${this.props.data.product.name}${this.props.data.product.nameSuffix}`;

		if (!BrandUtils.isAbleToDisplay('authentication-page')) {
			return null;
		}

		return (
			<div className="account-opening authentication-page container-fluid">
				<Helmet title={this.props.content.authPageHeader} />
				<PageHeader title={authPageTitle} content={this.props.content} />

				<div className="row main-container">
					<PageColumnWrapper content={this.props.content}>
						<SectionCentered centredColumnSize={12}>
								<div className="padding-bottom">
									<LoadingSpinner
										centerAlign
										backdrop={this.props.envConfig.bankId === 'DYB'}
									/>
								</div>
								<p>{this.props.content.authPageContact}</p>
						</SectionCentered>
					</PageColumnWrapper>

					<SideBarColumnWrapper
						appData={this.props.appData}
						content={this.props.content}
						data={this.props.data}
					/>
				</div>
			</div>
		);
	},
});

module.exports = withRouter(AuthenticationPage);
