/**
 * @module AccountOpening
 */

const React = require('react');
const { PropTypes } = React;

const envConfig = require('../../../static/config');

const BlurFilter = require('../common/ui-filters/BlurFilter');

const CallValidate3DStore = require('../../stores/CallValidate3DStore');
const ContentStore = require('../../stores/AccountOpeningContentStore');
const CustomerStore = require('../../stores/CustomerStore');
const DataStore = require('../../stores/AccountOpeningDataStore');
const PostcodeStore = require('../../stores/PostcodeAddressStore');
const SessionStore = require('../../stores/SessionStore');
const ValidationStore = require('../../stores/ValidationStore');
const BankDetailsStore = require('../../stores/BankDetailsStore');
const CMSStore = require('../../stores/CMSStore');
const PageSessionStore = require('../../stores/PageSessionStore');

const CMSActions = require('../../actions/CMSActions');

const addProps = require('../addProps');

const Helmet = require('react-helmet');
const StepupChallenge = require('./StepupChallenge');
const AppStyle = require('./AppStyle');

function getStateFromStores() {
	return {
		call3d: CallValidate3DStore.getAllQuestions(),
		content: ContentStore.getAll(),
		customer: CustomerStore.getAll(),
		data: DataStore.getAll(),
		postcodeData: PostcodeStore.getAll(),
		session: SessionStore.getAll(),
		validations: ValidationStore.getAll(),
		bankDetails: BankDetailsStore.getAll(),
		cms: CMSStore.getAll(),
		pageSession: PageSessionStore.getAll(),
	};
}

const AccountOpening = React.createClass({
	propTypes: {
		appData: PropTypes.object,
		pushState: PropTypes.object,
		children: PropTypes.node,
	},

	getInitialState() {
		return getStateFromStores();
	},

	componentDidMount() {
		CallValidate3DStore.addChangeListener(this._onStoreChange);
		ContentStore.addChangeListener(this._onStoreChange);
		CustomerStore.addChangeListener(this._onStoreChange);
		DataStore.addChangeListener(this._onStoreChange);
		PostcodeStore.addChangeListener(this._onStoreChange);
		SessionStore.addChangeListener(this._onStoreChange);
		ValidationStore.addChangeListener(this._onStoreChange);
		BankDetailsStore.addChangeListener(this._onStoreChange);
		CMSStore.addChangeListener(this._onStoreChange);
		PageSessionStore.addChangeListener(this._onStoreChange);

		CMSActions.getCMS();

		if (!envConfig.disableNavigationWarning) {
			window.addEventListener('beforeunload', this.onWindowBeforeUnload);
		}
	},

	componentWillReceiveProps(newProps) {
		if (newProps.appData.disableUnload) {
			window.removeEventListener('beforeunload', this.onWindowBeforeUnload);
		}
	},

	componentWillUnmount() {
		CallValidate3DStore.removeChangeListener(this._onStoreChange);
		ContentStore.removeChangeListener(this._onStoreChange);
		CustomerStore.removeChangeListener(this._onStoreChange);
		DataStore.removeChangeListener(this._onStoreChange);
		PostcodeStore.removeChangeListener(this._onStoreChange);
		SessionStore.removeChangeListener(this._onStoreChange);
		ValidationStore.removeChangeListener(this._onStoreChange);
		CMSStore.removeChangeListener(this._onStoreChange);
		PageSessionStore.removeChangeListener(this._onStoreChange);

		BankDetailsStore.addChangeListener(this._onStoreChange);

		window.removeEventListener('beforeunload', this.onWindowBeforeUnload);
	},

	/**
	 * Triggered before a refresh or tab close.
	 *
	 * @param  {Event} e
	 */
	onWindowBeforeUnload(e) {
		const event = e || window.event;
		const confirmationMessage = this.state.content.navigationWarning;

		event.returnValue = confirmationMessage;     // Gecko and Trident
		return confirmationMessage;                  // Gecko and WebKit
	},

	/**
	 * Store has been updated.
	 *
	 * @param  {Event} e
	 */
	_onStoreChange() {
		this.setState(getStateFromStores());
	},

	render() {
		const { children, ...props } = this.props;
		return (
			<AppStyle bankId={envConfig.bankId} data={this.state.data}>
				<Helmet
					title={this.state.content.landingPagePageHeader}
					titleTemplate={`%s | ${this.state.content.documentTitle}`}
				/>
				<BlurFilter enabled={this.props.appData.requireOTPAuthentication}>
					{children && React.cloneElement(
						children, {
							...props,
							...this.state,
						}
					)}
				</BlurFilter>
				<StepupChallenge {...this.props} {...this.state}/>
			</AppStyle>
		);
	},
});

module.exports = addProps(AccountOpening);
