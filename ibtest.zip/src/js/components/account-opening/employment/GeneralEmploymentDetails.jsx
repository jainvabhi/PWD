/**
 * @module GeneralEmploymentDetails
 */

const React = require('react');
const { PropTypes } = React;

const SectionFullWidth = require('../../common/SectionFullWidth');
const EmploymentSection = require('../sections/EmploymentSection');
const Nationality = require('./Nationality');
const TaxObligationsComponent = require('./TaxObligationsComponent');

const GeneralEmploymentDetails = props => (
	<div>
		<SectionFullWidth id="employment-details">
			<EmploymentSection
				group={props.group}
				{...props}
			/>
		</SectionFullWidth>

		<SectionFullWidth id="nationality-details">
			<Nationality
				group={props.group}
				onChange={props.onNationalitySectionChange}
				{...props}
			/>
		</SectionFullWidth>

		{!props.taxExempt && <SectionFullWidth id="tax-details">
			<TaxObligationsComponent
				group={props.group}
				{...props}
			/>
		</SectionFullWidth>}
	</div>
);


GeneralEmploymentDetails.propTypes = {
	group: PropTypes.string.isRequired,
	onNationalitySectionChange: PropTypes.func.isRequired,
	taxExempt: PropTypes.bool,
	showNationalInsurance: PropTypes.bool,
	citizenshipOnly: PropTypes.bool,
};

module.exports = GeneralEmploymentDetails;
