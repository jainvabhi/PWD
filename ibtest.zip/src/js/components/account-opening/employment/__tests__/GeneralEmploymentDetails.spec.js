jest.autoMockOff();

const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');
const _ = require('lodash');

const container = document.createElement('div');
const render = (comp, el) => ReactDOM.render(comp, el || container);
const shallowRenderer = TestUtils.createRenderer();

const GeneralEmploymentDetails = require('../GeneralEmploymentDetails');
const SectionFullWidth = require('../../../common/SectionFullWidth');
const EmploymentSection = require('../../sections/EmploymentSection');
const Nationality = require('../Nationality');
const TaxObligationsComponent = require('../TaxObligationsComponent');

describe('Base Employment', () => {
	let instance;
	let component;
	let result;

	let content = {
		ukCitizen: 'ukCitizen',
		hasNoTaxOligations: 'hasNoTaxOligations',
		hasNoTaxOligations: 'hasNoTaxOligations',
		hasAdditionalCitizenships: 'hasAdditionalCitizenships',

	};
	let data = {
		product: {
			productType: 'savings',
		},
	};

	let props = {
		group:'group',
		data:data,
		content:content,
		onNationalitySectionChange: () => {},

	};

	beforeEach(() => {
		component = (
			<GeneralEmploymentDetails {...props} />
		);

		instance = render(component);
		shallowRenderer.render(component);
		result = shallowRenderer.getRenderOutput();
	});

	it('should be defined', () => {
		expect(instance).toBeDefined();
	});



	describe('render()', () =>{
		it('should render the Employment Section', () => {
			expect(result).toIncludeJSX(
				<SectionFullWidth id="employment-details">
					<EmploymentSection
						group={props.group}
						{...props}
					/>
				</SectionFullWidth>
			);
		});

		it('should render the Nationality Section', () => {
			expect(result).toIncludeJSX(
				<SectionFullWidth id="nationality-details">
					<Nationality
						group={props.group}
						onChange={props.onNationalitySectionChange}
						{...props}
					/>
				</SectionFullWidth>
			);
		});

		it('should render the TaxObligationsComponent', () => {
			expect(result).toIncludeJSX(
				<SectionFullWidth id="tax-details">
					<TaxObligationsComponent
						group={props.group}
						{...props}
					/>
				</SectionFullWidth>
			);
		});

		describe('when tax exempt', () =>{

			beforeEach(() => {
				component = (
					<GeneralEmploymentDetails taxExempt {...props} />
				);

				instance = render(component);
				shallowRenderer.render(component);
				result = shallowRenderer.getRenderOutput();
			});
			it('should NOT render the TaxObligationsComponent', () => {
				expect(result).not.toIncludeJSX(
					<SectionFullWidth id="tax-details">
						<TaxObligationsComponent
							group={props.group}
							{...props}
						/>
					</SectionFullWidth>
				);
			});
		});

	});
});
