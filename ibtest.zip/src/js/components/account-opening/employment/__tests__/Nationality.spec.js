jest.unmock('../Nationality');
jest.unmock('../../../../config');
jest.unmock('../../../../utils/CountryUtils');

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const shallowRenderer = TestUtils.createRenderer();
const Nationality = require('../Nationality');
const { NationalityAdditional } = require('../Nationality');
const ComponentHeader = require('../../../common/ComponentHeader');
const CitizenshipList = require('../../sections/CitizenshipList');
const { DropdownQuestion, TextQuestion, RadioQuestion } = require('../../../common/questionsets');
const CountryUtils = require('../../../../utils/CountryUtils');

const content = {};

const render = (data = {}) => {
	const props = {
		content,
		data,
		group: 'GROUP',
		onChange: () => {},
	};
	shallowRenderer.render(<Nationality {...props} />);
	return { props, instance: shallowRenderer.getRenderOutput() };
};

describe('Nationality', () => {

	it('renders', () => {
		const { instance } = render();
		const countries = CountryUtils.withCountryNames();
		expect(instance).toEqualJSX(
			<ComponentHeader
				hasSeparator={true}
				title={undefined}
				titleLevel={2}
				wrapperClass=""
			>
				<NationalityAdditional
					content={{}}
					data={{}}
					group="GROUP"
					onChange={function noRefCheck() {}}
				/>
				<RadioQuestion
					align="left"
					blockList={false}
					defaultValue={undefined}
					group="GROUP"
					labelText={undefined}
					mainColumnSize={undefined}
					mainColumnSizeMD={undefined}
					name="ukCitizen"
					onChange={function noRefCheck() {}}
					options={[{anchor: 'nationality-uk-no', value: 'No'}, {anchor: 'nationality-uk-yes', value: 'Yes'}]}
					required={true}
				/>
				<RadioQuestion
					align="left"
					blockList={false}
					defaultValue={undefined}
					group="GROUP"
					labelText={undefined}
					mainColumnSize={undefined}
					mainColumnSizeMD={undefined}
					name="hasAdditionalCitizenships"
					onChange={function noRefCheck() {}}
					options={[{anchor: 'nationality-other-no', value: 'No'}, {anchor: 'nationality-other-yes', value: 'Yes'}]}
					required={true}
					validateEqualTo="Yes"
				/>
			</ComponentHeader>
		);
	});

	describe('with a UK citizen', () => {

		it('excludes Unitied Kingdom from CitizenshipList', () => {
			const { instance } = render({
				hasAdditionalCitizenships: 'Yes',
				ukCitizen: 'Yes',
			});
			const countries = CountryUtils.withCountryNames(data => data.code !== 'GB');
			expect(instance).toIncludeJSX(
				<CitizenshipList
					content={{}}
					data={countries}
					defaultValue={undefined}
					group="GROUP"
					name="citizenshipList"
					onChange={function noRefCheck() {}}
				/>
			);
		});
	});

	describe('with a non-UK citizen', () => {

		it('includes Unitied Kingdom from CitizenshipList', () => {
			const { instance } = render({
				hasAdditionalCitizenships: 'Yes',
				ukCitizen: 'No',
			});
			const countries = CountryUtils.withCountryNames();
			expect(instance).toIncludeJSX(
				<CitizenshipList
					content={{}}
					data={countries}
					defaultValue={undefined}
					group="GROUP"
					name="citizenshipList"
					onChange={function noRefCheck() {}}
				/>
			);
		});
	});
});
