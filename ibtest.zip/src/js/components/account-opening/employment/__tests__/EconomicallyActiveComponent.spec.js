jest.disableAutomock();

const _ = require('lodash');
const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');
const shallowRenderer = TestUtils.createRenderer();

const config = require('../../../../config');
const EconomicallyActiveComponent = require('../EconomicallyActiveComponent');
const { DropdownQuestion, TextQuestion, DatePickerQuestion } = require('../../../common/questionsets');
const { buildContent } = require('../../../../__helpers__/TestHelpers');

const content = buildContent([
	'employmentStartDateQuestion',
	'employmentEmployerNameQuestion',
]);

const fieldNames = buildContent([
	'employmentOccupation',
	'employmentEmployerName',
	'employmentStartDate',
]);

const render = (override = {}) => {
	const props = {
		group: 'group',
		data: {},
		fieldNames,
		visible: true,
		content,
		onChange: () => {},
		...override,
	};
	const el = document.createElement('div');
	const component = <EconomicallyActiveComponent {...props} />;
	const instance = ReactDOM.render(component, el);
	shallowRenderer.render(component);
	return { props, instance, output: shallowRenderer.getRenderOutput() };
};

describe('Economically Active', () => {
	describe('getEmploymentStartDateLimit()', () =>{
		it('should return a date 16 years after the DOB given', () => {
			const { instance } = render();
			const dateLimit = instance.getEmploymentStartDateLimit('24-03-1981').format('DD-MM-YYYY');
			expect(dateLimit).toEqual('24-03-1997');
		});
	});

	describe('render()', () =>{
		it('should render the occupation dropdown', () => {
			const { props, output } = render();
			expect(output).toIncludeJSX(
				<DropdownQuestion
					group={props.group}
					name={props.fieldNames.employmentOccupation}
					data={config.formOptionsOccupation}
					onChange={props.onChange}
					defaultValue={props.data[props.fieldNames.employmentOccupation]}
					dataAnchor="employment-occupation"
					required
				>
					Occupation
				</DropdownQuestion>
			);
		});

		it('should render other income payment amount', () => {
			const { props, instance, output } = render();
			expect(output).toIncludeJSX(
				<DatePickerQuestion
					name={props.fieldNames.employmentStartDate}
					group={props.group}
					onChange={props.onChange}
					defaultValue={props.data[props.fieldNames.employmentStartDate]}
					validateBeforeToday
					validateAfterDate={instance.getEmploymentStartDateLimit(props.data.dateOfBirth)}
					dataAnchor="employment-start-date"
					required
				>
					{props.content.employmentStartDateQuestion}
				</DatePickerQuestion>
			);
		});

		it('should render other income type dropdown', () => {
			const { props, output } = render();
			expect(output).toIncludeJSX(
				<TextQuestion
					name={props.fieldNames.employmentEmployerName}
					group={props.group}
					onChange={props.onChange}
					defaultValue={props.data[props.fieldNames.employmentEmployerName]}
					minLength={2}
					maxLength={40}
					dataAnchor="employer-name"
					required
				>
					{props.content.employmentEmployerNameQuestion}
				</TextQuestion>
			);
		});

		it('should return null if set not to be visible', () => {
			const { props, output } = render({
				fieldNames: {},
				visible: false,
			});
			expect(output).toBe(null);
		});
	});
});
