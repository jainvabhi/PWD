/**
 * @module AdditionalCardHolder
 */

const React = require('react');
const PropTypes = React.PropTypes;

const SectionFullWidth = require('../../common/SectionFullWidth.jsx');
const ComponentHeader = require('../../common/ComponentHeader');
const { RadioQuestion } = require('../../common/questionsets');

const canHaveAdditionalCards = props => props.data.product && props.data.product.productType.name === 'credit-card';

const AdditionalCardHolder = props => {
	if (!canHaveAdditionalCards(props)) {
		return null;
	}
	return (
		<SectionFullWidth id="cardholders">
			<ComponentHeader
				title={props.content.additionalCardTitle}
				titleLevel={props.titleLevel}
				hasSeparator
			>
				{props.content.additionalCardHolderIntro && <p>{props.content.additionalCardHolderIntro}</p>}
				<RadioQuestion
					defaultValue={props.data.additionalCardHolder}
					group={props.group}
					labelText={props.content.additionalCardHolderLabel}
					name={props.name}
					onChange={props.onChange}
					options={[{
						anchor: 'additional-card-no',
						value: 'No',
					}, {
						anchor: 'additional-card-yes',
						value: 'Yes',
					}]}
					required={props.required}
				/>
				{props.data.additionalCardHolder === 'Yes' && <p>{props.content.additionalCardHolderInfo}</p>}
			</ComponentHeader>
		</SectionFullWidth>
	);
};

AdditionalCardHolder.propTypes = {
	content: PropTypes.object.isRequired,
	data: PropTypes.object.isRequired,
	name: PropTypes.string.isRequired,
	group: PropTypes.string.isRequired,
	titleLevel: PropTypes.number.isRequired,
	onChange: PropTypes.func,
	defaultValue: PropTypes.string,
	required: PropTypes.bool,
};

AdditionalCardHolder.defaultProps = {
	name: 'additionalCardHolder',
	titleLevel: 2,
	onChange: () => {},
	dataAnchor: 'additional-card',
	required: true,
};

module.exports = AdditionalCardHolder;
