jest.autoMockOff();

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const ReactDOM = require('react-dom');
const _ = require('lodash');

const container = document.createElement('div');
const render = (comp, el) => ReactDOM.render(comp, el || container);
const shallowRenderer = TestUtils.createRenderer();

const SectionFullWidth = require('../../../common/SectionFullWidth.jsx');
const ComponentHeader = require('../../../common/ComponentHeader');
const { RadioQuestion } = require('../../../common/questionsets');
const AdditionalCardHolder = require('../AdditionalCardHolder');

describe('AdditionalCardHolder', () => {
	let result, component, instance;

	let props = {
		data: {
			product: {
				productType: { name : 'credit-card' }
			}
		},
		group: 'test',
		name: "testing",
		onChange: () => {},
		content: {
			additionalCardTitle: 'additionalCardTitle',
			additionalCardHolderLabel: 'additionalCardHolderLabel',
			additionalCardHolderInfo: 'additionalCardHolderInfo',
		}
	};



	beforeEach(() => {
		component = (
			<AdditionalCardHolder
			{...props}
			/>
		);

		instance = render(component);
		shallowRenderer.render(component);
		result = shallowRenderer.getRenderOutput();
	});


	it('should render basic component', () => {

		expect(result).toEqualJSX(
			<SectionFullWidth id="cardholders">
				<ComponentHeader
					title={props.content.additionalCardTitle}
					titleLevel={2}
					hasSeparator
				>
					<RadioQuestion
						defaultValue={props.data.additionalCardHolder}
						group={props.group}
						labelText={props.content.additionalCardHolderLabel}
						name={props.name}
						onChange={props.onChange}
						options={[{
							anchor: 'additional-card-no',
							value: 'No',
						}, {
							anchor: 'additional-card-yes',
							value: 'Yes',
						}]}
						required={true}
					/>
				</ComponentHeader>
			</SectionFullWidth>
		);
	});

	it('should info if selected yes', () => {
		component = (
			<AdditionalCardHolder
			{...{
				...props,
				data: {
					...props.data,
					additionalCardHolder: 'Yes'
				}
			}}
			/>
		);

		instance = render(component);
		shallowRenderer.render(component);
		result = shallowRenderer.getRenderOutput();
		expect(result).toIncludeJSX(
			<p>{props.content.additionalCardHolderInfo}</p>
		);
	});

	it('should NOT render unless correct product type', () => {
		component = (
			<AdditionalCardHolder
			{...props}
			data={{
				product: {
					productType: {name : 'current'}
				}
			}}

			/>
		);

		instance = render(component);
		shallowRenderer.render(component);
		result = shallowRenderer.getRenderOutput();
		expect(result).toBe(null);
	});

});
