jest.unmock('../MiddleName');
jest.unmock('../../../common/questionsets/ReadOnlyQuestion');
jest.unmock('../../../common/questionsets/TextQuestion');
jest.unmock('../../../common/questionsets/RadioQuestion');

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const ReactDOM = require('react-dom');
const _ = require('lodash');

const container = document.createElement('div');
const render = (comp, el) => ReactDOM.render(comp, el || container);
const shallowRenderer = TestUtils.createRenderer();

const { TextQuestion, ReadOnlyQuestion, RadioQuestion } = require('../../../common/questionsets');
const MiddleName = require('../MiddleName');
const MiddleNameTextQuestion = require('../MiddleName').MiddleNameTextQuestion;

describe('MiddleName', () => {
	let result, component, instance;

	let props = {
		data: {},
		content: {
			hasMiddleNameQuestion:'hasMiddleNameQuestion',
			middleNameQuestion:'middleNameQuestion',
		},
		group:'test',
		onHasMiddleNameChange: () => {},
		onChange: () => {},
	}

	beforeEach(() => {
		component = (
			<MiddleName {...props} />
		);

		//instance = render(component); uncommenting this causes some intermitant babel errors, not required anyway
		shallowRenderer.render(component);
		result = shallowRenderer.getRenderOutput();

	});

	it('should render core component' , () => {
		expect(result).toEqualJSX(
			<div>
				<ReadOnlyQuestion readOnly={props.data.isExistingCustomer}>
					<RadioQuestion
						defaultValue={props.data.hasMiddleName}
						group={props.group}
						labelText={props.content.hasMiddleNameQuestion}
						name="hasMiddleName"
						onChange={props.onHasMiddleNameChange}
						options={[{
							anchor: 'middle-name-no',
							value: 'No',
						}, {
							anchor: 'middle-name-yes',
							value: 'Yes',
						}]}
						required
						visible={!props.data.isExistingCustomer}
					/>
				</ReadOnlyQuestion>

				<MiddleNameTextQuestion
					defaultValue={props.data.middleName}
					label={props.content.middleNameQuestion}
					readOnly="No"
					dataAnchor="middle-name"
					maxLength={12}
					minLength={2}
					name="middleName"
					validateType="alphaTwoSpaces"
					required
					{...props}
				/>
			</div>
		);
	});
});



describe('MiddleNameTextQuestion', () => {
	let result, component, instance;

	beforeEach(() => {
		component = (
			<MiddleNameTextQuestion
				readOnly={'Yes'}
				group={''}
				data={{}}
				defaultValue={'default'}
				label={'test'} />
		);

		instance = render(component);
		shallowRenderer.render(component);
		result = shallowRenderer.getRenderOutput();

	});

	it('do NOT render without hasMiddleName' , () => {
		expect(result).toBe(null);
	});


	describe('WHEN editable', () => {
			beforeEach(() => {
				component = (
					<MiddleNameTextQuestion
						group={''}
						data={{
							hasMiddleName: 'Yes'
						}}
						label={'test'} />
				);

				instance = render(component);
				shallowRenderer.render(component);
				result = shallowRenderer.getRenderOutput();
			});



			it('should NOT be readOnly', () => {
				expect(result.props.readOnly).toEqual('No');
			});

			it('should have a name', () => {
				expect(result.props.children.props.name).toEqual('middleName');
			});

			it('should have a data-anchor', () => {
				expect(result.props.children.props.dataAnchor).toEqual('middle-name');
			});

			it('should have a alphaTwoSpaces validation', () => {
				expect(result.props.children.props.validateType).toEqual('alphaTwoSpaces');
			});

			it('should have a min-length', () => {
				expect(result.props.children.props.minLength).toEqual(2);
			});

			it('should have a max-length', () => {
				expect(result.props.children.props.maxLength).toEqual(12);
			});


		describe('overrides', () => {

			beforeEach(() => {
				component = (
					<MiddleNameTextQuestion
						name={'test-name'}
						validateType={'test-validation'}
						dataAnchor={'test-data-anchor'}
						required={false}
						group={''}
						minLength={4}
						maxLength={432}
						data={{
							hasMiddleName: 'Yes'
						}}
						defaultValue={'default'}
						label={'test'} />
				);

				instance = render(component);
				shallowRenderer.render(component);

			});

			beforeEach(() => {
				result = shallowRenderer.getRenderOutput();
			});

			it('should return the defaultValue if one is provided', () => {
				expect(result.props.children.props.defaultValue).toEqual('default');
			});

			it('should have a name', () => {
				expect(result.props.children.props.name).toEqual('test-name');
			});

			it('should have a data-anchor', () => {
				expect(result.props.children.props.dataAnchor).toEqual('test-data-anchor');
			});

			it('should have a alphaTwoSpaces validation', () => {
				expect(result.props.children.props.validateType).toEqual('test-validation');
			});

			it('should have a required validation set to false', () => {
				expect(result.props.children.props.required).toBe(false);
			});

			it('should have a min-length', () => {
				expect(result.props.children.props.minLength).toEqual(4);
			});

			it('should have a max-length', () => {
				expect(result.props.children.props.maxLength).toEqual(432);
			});
		});
	});

	describe('WHEN is is NOT editable', () => {
		beforeEach(() => {
			component = (
				<MiddleNameTextQuestion
					readOnly={'Yes'}
					group={''}
					data={{
						hasMiddleName: 'Yes'
					}}
					defaultValue={'default'}
					label={'test'} />
			);

			instance = render(component);
			shallowRenderer.render(component);
			result = shallowRenderer.getRenderOutput();

		});

		it('should be readOnly', () => {
			expect(result.props.readOnly).toEqual('Yes');
		});

	});

});
