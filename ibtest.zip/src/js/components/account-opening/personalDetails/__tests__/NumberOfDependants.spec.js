jest.autoMockOff();

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const ReactDOM = require('react-dom');
const _ = require('lodash');

const container = document.createElement('div');
const render = (comp, el) => ReactDOM.render(comp, el || container);
const shallowRenderer = TestUtils.createRenderer();

const { RadioQuestion, DropdownQuestion } = require('../../../common/questionsets');
const NumberOfDependants = require('../NumberOfDependants');
const GetNumberOfDependantsQuestion = require('../NumberOfDependants').GetNumberOfDependantsQuestion;

describe('NumberOfDependants', () => {
	let result, component, instance;

	let props = {
		data: {
			product: {
			}
		},
		group: 'test',
		name: "testing",
		onChange: () => {},
		onHasDependantsChange: () => {},
		content: {
			hasDependantsQuestion: 'hasDependantsQuestion',
		}
	};



	beforeEach(() => {
		component = (
			<NumberOfDependants
			{...props}
			/>
		);

		instance = render(component);
		shallowRenderer.render(component);
		result = shallowRenderer.getRenderOutput();
	});


	it('should render basic component', () => {

		expect(result).toEqualJSX(
			<div>
				<RadioQuestion
					defaultValue={props.data.hasDependants}
					group={props.group}
					labelText={props.content.hasDependantsQuestion}
					name="hasDependants"
					onChange={props.onHasDependantsChange}
					options={[{
						anchor: 'dependents-no',
						value: 'No',
					}, {
						anchor: 'dependents-yes',
						value: 'Yes',
					}]}
					required
				/>

				<GetNumberOfDependantsQuestion {...props} />
		</div>
		);
	});

	it('should render dropdown when yes is selected', () => {
		shallowRenderer.render(
			<GetNumberOfDependantsQuestion
				{...props}
				data={{
					hasDependants: 'Yes',
				}}
			/>
		);
		result = shallowRenderer.getRenderOutput();
		expect(result).toEqualJSX(
			<DropdownQuestion
				name="dependants"
				data={['1', '2', '3', '4', '5', '6', '7', '8', '9']}
				group={props.group}
				onChange={props.onChange}
				defaultValue={props.data.dependants}
				minLength={1}
				maxLength={1}
				dataAnchor="dependants"
			>
				Number of dependants
			</DropdownQuestion>
		);
	});

});
