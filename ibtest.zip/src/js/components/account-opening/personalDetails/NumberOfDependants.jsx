/**
 * @module NumberOfDependants
 */

const React = require('react');
const PropTypes = React.PropTypes;
const _ = require('lodash');

const { RadioQuestion, DropdownQuestion } = require('../../common/questionsets');

const GetNumberOfDependantsQuestion = props => {
	if (props.data.hasDependants !== 'Yes') {
		return null;
	}

	const dropDownValues = _.times(9, num => {
		return `${num + 1}`;
	});

	return (
		<DropdownQuestion
			name="dependants"
			data={dropDownValues}
			group={props.group}
			onChange={props.onChange}
			defaultValue={props.data.dependants}
			minLength={1}
			maxLength={1}
			dataAnchor="dependants"
		>
			Number of dependants
		</DropdownQuestion>
	);
};

GetNumberOfDependantsQuestion.propTypes = {
	data: PropTypes.object.isRequired,
	content: PropTypes.object.isRequired,
	group: PropTypes.string.isRequired,
	onChange: PropTypes.func,
};

const NumberOfDependants = props => {
	return (
		<div>
			<RadioQuestion
				defaultValue={props.data.hasDependants}
				group={props.group}
				labelText={props.content.hasDependantsQuestion}
				name="hasDependants"
				onChange={props.onHasDependantsChange}
				options={[{
					anchor: 'dependents-no',
					value: 'No',
				}, {
					anchor: 'dependents-yes',
					value: 'Yes',
				}]}
				required
			/>

			<GetNumberOfDependantsQuestion {...props} />
		</div>
	);
};

NumberOfDependants.propTypes = {
	data: PropTypes.object.isRequired,
	onHasDependantsChange: PropTypes.func.isRequired,
	content: PropTypes.object.isRequired,
	group: PropTypes.string.isRequired,
	onChange: PropTypes.func.isRequired,
};


module.exports = NumberOfDependants;
module.exports.GetNumberOfDependantsQuestion = GetNumberOfDependantsQuestion;
