/**
 * @module MiddleName
 */

const React = require('react');
const PropTypes = React.PropTypes;

const AnalyticsWrapper = require('../../common/AnalyticsWrapper');
const { TextQuestion, ReadOnlyQuestion, RadioQuestion } = require('../../common/questionsets');

const MiddleNameTextQuestion = props => {
	if (props.data.hasMiddleName !== 'Yes') {
		return null;
	}

	return (
		<ReadOnlyQuestion readOnly={props.readOnly}>
			<TextQuestion {...props} >
				{props.label}
			</TextQuestion>
		</ReadOnlyQuestion>

	);
};

MiddleNameTextQuestion.propTypes = {
	readOnly: PropTypes.string,
	name: PropTypes.string.isRequired,
	data: PropTypes.object.isRequired,
	group: PropTypes.string.isRequired,
	onChange: PropTypes.func,
	defaultValue: PropTypes.string,
	dataAnchor: PropTypes.string.isRequired,
	required: PropTypes.bool,
	label: PropTypes.string.isRequired,
};

MiddleNameTextQuestion.defaultProps = {
	readOnly: 'No',
	name: 'middleName',
	minLength: 2,
	maxLength: 12,
	onChange: () => {},
	validateType: 'alphaTwoSpaces',
	dataAnchor: 'middle-name',
	required: true,
};

const MiddleName = props => {
	return (
		<div>
			<ReadOnlyQuestion readOnly={props.data.isExistingCustomer}>
				<RadioQuestion
					defaultValue={props.data.hasMiddleName}
					group={props.group}
					labelText={props.content.hasMiddleNameQuestion}
					name="hasMiddleName"
					onChange={props.onHasMiddleNameChange}
					options={[{
						anchor: 'middle-name-no',
						value: 'No',
					}, {
						anchor: 'middle-name-yes',
						value: 'Yes',
					}]}
					required
					visible={!props.data.isExistingCustomer}
				/>
			</ReadOnlyQuestion>

			<MiddleNameTextQuestion
				defaultValue={props.data.middleName}
				label={props.content.middleNameQuestion}
				readOnly={props.data.isExistingCustomer}
				required
				{...props}
			/>
		</div>
	);
};


MiddleName.propTypes = {
	data: PropTypes.object.isRequired,
	content: PropTypes.object.isRequired,
	group: PropTypes.string.isRequired,
	onChange: PropTypes.func,
	onHasMiddleNameChange: PropTypes.func,
};

module.exports = AnalyticsWrapper(MiddleName);
module.exports.MiddleNameTextQuestion = MiddleNameTextQuestion;
