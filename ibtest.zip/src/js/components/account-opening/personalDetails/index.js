module.exports = {
	Title: require('./Title'),
	FirstName: require('./FirstName'),
	LastName: require('./LastName'),
	MiddleName: require('./MiddleName'),
	DateOfBirth: require('./DateOfBirth'),
	PhoneNumber: require('./PhoneNumber'),
	EmailAddress: require('./EmailAddress'),
	Gender: require('./Gender'),
	AdditionalCardHolder: require('./AdditionalCardHolder'),
	NumberOfDependants: require('./NumberOfDependants'),
};
