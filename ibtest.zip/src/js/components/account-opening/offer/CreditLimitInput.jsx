/**
 * @module CreditLimitInput
 */

const React = require('react');
const { PropTypes } = React;
const cx = require('classnames');

const InputMixin = require('../../common/mixins/InputMixin');
const ErrorMessage = require('../../common/ErrorMessage');
const AccountOpeningActions = require('../../../actions/AccountOpeningActions');

const CreditLimitInput = React.createClass({
	propTypes: {
		appData: PropTypes.object.isRequired,
		data: PropTypes.object.isRequired,
		content: PropTypes.object.isRequired,
		onChange: PropTypes.func.isRequired,
		value: PropTypes.string,
		name: PropTypes.string.isRequired,
		group: PropTypes.string.isRequired,
		isValid: PropTypes.func.isRequired,
	},

	mixins: [InputMixin],

	getInitialState() {
		return {
			value: this.props.value,
			isValid: true,
		};
	},

	componentWillReceiveProps(nextProps) {
		if (this.props.value !== nextProps.value && this.props.isValid(nextProps.value)) {
			this.setState({
				value: nextProps.value,
				isValid: true,
			});
		}
	},

	onChange(e) {
		const value = e.target.value;
		const isValid = this.props.isValid(value);

		this.setState({
			value: value,
			isValid: isValid,
		}, () => {
			AccountOpeningActions.updateValidation(this.props.group, 'creditLimit', isValid);

			if (this.state.isValid) {
				this.props.onChange(this.state.value);
			}
		});
	},

	render() {
		return (
			<div className="col-md-12">
				<div className={'row form-spacing text-question'}>
					<div
						className={cx('col-xs-12', {
							'col-md-6': this.props.data.bankId !== 'DYB',
							'col-md-8': this.props.data.bankId === 'DYB',
						})}
					>
						<label
							className={cx('col-xs-12', {
								'col-md-8': this.props.data.bankId === 'DYB',
							})}
							htmlFor={this.props.name}
						>
							{this.props.content.creditLimitInputLabel}
						</label>
					</div>
					<div
						className={cx('col-xs-12', {
							'col-md-6': this.props.data.bankId !== 'DYB',
							'col-md-4': this.props.data.bankId === 'DYB',
						})}
					>
						<input
							type="text"
							className={cx({
								'error': !this.state.isValid,
							})}
							id={this.props.name}
							name={this.props.name}
							ref="textInput"
							title={this.props.content.creditLimitInputLabel}
							data-anchor={this.props.name}
							onChange={this.onChange}
							value={this.state.value}
						/>
					</div>
					{!this.state.isValid && <ErrorMessage text={this.getValidationText()} />}
				</div>
			</div>
		);
	},
});

module.exports = CreditLimitInput;
