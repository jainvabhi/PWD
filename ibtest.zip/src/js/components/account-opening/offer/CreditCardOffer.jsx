/**
 * @module CreditCardOffer
 */

const React = require('react');
const _ = require('lodash');
const moment = require('moment');
const { PropTypes } = React;
const envConfig = require('../../../../static/config');

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');
const AccountOpeningConstants = require('../../../constants/AccountOpeningConstants');

const OfferHOC = require('./OfferHOC');
const OfferDetails = require('./OfferDetails');
const CreditLimit = require('./CreditLimit');
const AgreeementSection = require('./AgreeementSection');

const { DybCreditKeyFeatures, CybCreditKeyFeatures } = require('./KeyFeatures');
const { DybCreditPreContract, CybCreditPreContract } = require('./PreContract');
const CreditAgreement = require('./CreditAgreement');
const ValidationUtils = require('../../../utils/ValidationUtils');
const NumberUtils = require('../../../utils/NumberUtils');
const BrandUtils = require('../../../utils/BrandUtils');
const { mapDocumentAuditInfo } = require('../../common/links/DocumentLink');

const errorMsg = 'Please make sure you’ve ticked the boxes in the key features, pre-contract credit information and credit agreement before you continue.';

function getHtmlContent(documents) {
	if (!documents || !documents.length) {
		return '';
	}

	return atob((_.find(documents, doc => {
		return doc.format.toLowerCase() === 'html';
	}) || {
		content: '',
	}).content);
}


function getPdfDocument(documents) {
	if (!documents || !documents.length) {
		return '';
	}

	return _.find(documents, doc => doc.format.toLowerCase() === 'pdf');
}

const CreditCardOffer = React.createClass({
	propTypes: {
		appData: PropTypes.object.isRequired,
		cms: PropTypes.object.isRequired,
		envConfig: PropTypes.object.isRequired,
		validations: PropTypes.object.isRequired,
		group: PropTypes.string.isRequired,
		data: PropTypes.object.isRequired,
		content: PropTypes.object.isRequired,
		offer: PropTypes.object,
		onClickActionAccount: PropTypes.func.isRequired,
		documentActions: PropTypes.object,
		documents: PropTypes.array,
	},

	getInitialState() {
		return {
			hasClickedAccept: false,
			offerKeyFeatures: {
				isOpen: false,
			},
			offerPreContract:{
				isOpen: false,
			},
			offerCreditAgreement:{
				isOpen: false,
			},
		};
	},

	componentWillReceiveProps(nextProps) {
		if (!nextProps.documents && nextProps.offer && nextProps.offer.documents && !this.state.fetchingDocuments && !BrandUtils.isAbleToDisplay('disable_credit_agreement')) {
			this.setState({ fetchingDocuments: true });
			const docs = nextProps.offer.documents.filter(x => x.format.toLowerCase() === 'html');
			nextProps.documentActions.fetch(docs);
		}
	},

	onAcceptChange(key, val) {
		AccountOpeningActions.updateFormValue(key, val);
	},

	onUpdateOffer(amount) {
		AccountOpeningActions.updateProductOffer(this.props.offer.id, amount);
	},

	toggleAgreement(key) {
		this.setState({
			[key]: {
				isOpen: !this.state[key].isOpen,
				hasRead: true,
			},
		});
	},

	acceptCreditOffer() {
		const isValid = ValidationUtils.isGroupValid(this.props.validations, AccountOpeningConstants.GROUP_OFFER);
		this.setState({
			hasClickedAccept: true,
		});
		if (!isValid) {
			return;
		}

		const state = _.mapValues(this.state, (obj, key) => {
			if (key === 'hasClickedAccept') {
                return obj;
            }
			return {
				isOpen: key === 'offerCreditAgreement',
				hasRead: true,
			};
		});
		const auditDocs = [
			'ccKeyFeatures',
			'ccPreContractInfo',
		];
		const ccCreditAgreementAuditInfo = {
			reason: 'DOCUMENTATION',
			name: 'ccCreditAgreement',
			version: '',
			consent: 'Y',
			timestamp:  moment().format(),
		};
		const docs = [...mapDocumentAuditInfo(auditDocs, this.props.envConfig.bankId, this.props.cms), ccCreditAgreementAuditInfo];

		this.setState({
			...state,
		}, () => {
			this.props.onClickActionAccount(false, this.props.offer.id, this.props.offer.product.code, docs, true);
		});
	},

	render() {
		const pageTitle = this.props.content.creditOfferPageTitle ? this.props.content.creditOfferPageTitle
			.replace('{productName}', this.props.data.product.name)
			.replace('{productArticle}', this.props.data.product.productArticle) : null;
		const isValid = ValidationUtils.isGroupValid(this.props.validations, AccountOpeningConstants.GROUP_OFFER);
		const showError = this.state.hasClickedAccept && !isValid;

		if (!this.props.offer) {
			return null;
		}

		if (this.props.offer.features['credit_limit']['update_offer']) {
			return (
				<OfferDetails
					{...this.props}
					headerIllustration="offer-illustration.png"
					pageTitle={pageTitle}
				>
					<CreditLimit
						onUpdateOffer={this.onUpdateOffer}
						{...this.props}
					/>
				</OfferDetails>
			);
		}

		const subTitle = this.props.content.creditOfferPageMinSubTitle && parseInt(this.props.offer.features.credit_limit.offer_limit) === parseInt(this.props.offer.features.credit_limit.minimum) ? this.props.content.creditOfferPageMinSubTitle : this.props.content.creditOfferPageSubTitle;

		return (
			<OfferDetails
				{...this.props}
				headerIllustration="offer-illustration.png"
				pageTitle={this.props.content.creditOfferPageTitle &&
					this.props.content.creditOfferPageTitle
					.replace('{productName}', this.props.data.product.name)
					.replace('{productArticle}', this.props.data.product.productArticle)

				}
			>
				<h2 className="text-center credit-subtitle">{subTitle} <br/> <span className="credit-limit-amount">£{NumberUtils.formatWithComma(this.props.offer.features.credit_limit.offer_limit)}</span></h2>
				<p>{this.props.content.creditOfferPagePara1}</p>
				<p>{this.props.content.creditOfferPagePara2}</p>
				<p>{this.props.content.creditOfferPagePara3}</p>
				<hr />

				<AgreeementSection
					title={this.props.content.creditOfferKeyFeaturesTitle}
					intro={this.props.content.creditOfferKeyFeaturesIntro}
					group={AccountOpeningConstants.GROUP_OFFER}
					disabled={false}
					hasRead={this.state.offerKeyFeatures.hasRead}
					name="offerKeyFeatures"
					onChange={this.toggleAgreement}
					onAcceptChange={this.onAcceptChange}
					isOpen={this.state.offerKeyFeatures.isOpen}
					docKey="ccKeyFeatures"
					{...this.props}
				>
					{envConfig.bankId === 'DYB' ?
							<DybCreditKeyFeatures {...this.props} /> :
							<CybCreditKeyFeatures {...this.props} />
					}

				</AgreeementSection>
				<AgreeementSection
					title={this.props.content.creditOfferPreContractTitle}
					intro={this.props.content.creditOfferPreContractIntro}
					group={AccountOpeningConstants.GROUP_OFFER}
					disabled={!this.props.data.offerKeyFeatures}
					hasRead={this.state.offerPreContract.hasRead}
					name="offerPreContract"
					onChange={this.toggleAgreement}
					onAcceptChange={this.onAcceptChange}
					isOpen={this.state.offerPreContract.isOpen}
					docKey="ccPreContractInfo"
					{...this.props}
				>
					{envConfig.bankId === 'DYB' ?
							<DybCreditPreContract {...this.props} /> :
							<CybCreditPreContract {...this.props} />
					}
				</AgreeementSection>

				<AgreeementSection
					title={this.props.content.creditOfferCreditAgreementTitle}
					intro={this.props.content.creditOfferCreditAgreementIntro}
					group={AccountOpeningConstants.GROUP_OFFER}
					disabled={!this.props.data.offerPreContract}
					hasRead={this.state.offerCreditAgreement.hasRead}
					name="offerCreditAgreement"
					onChange={this.toggleAgreement}
					onAcceptChange={this.onAcceptChange}
					isOpen={this.state.offerCreditAgreement.isOpen}
					docKey="ccCreditAgreement"
					onDownload={() => this.props.documentActions.download(getPdfDocument(this.props.offer.documents))}
					credit
					{...this.props}
				>
					<CreditAgreement content={getHtmlContent(this.props.documents)} />
				</AgreeementSection>
				<div>

					<div className="text-center">
						{showError && <p className="error">{errorMsg}</p>}
						<button
							className="btn btn-lg btn-primary inline btn-next btn-accept"
							onClick={this.acceptCreditOffer}
							data-anchor="accept-next"
							disabled={this.props.appData.isApiCallInProgress}
						>
							{this.props.content.openAccountButton}
						</button>
					</div>

				</div>
			</OfferDetails>
		);
	},
});

module.exports = OfferHOC(CreditCardOffer);
