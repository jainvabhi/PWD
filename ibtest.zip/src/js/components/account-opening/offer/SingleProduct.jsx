/**
 * @module OfferPage
 */

const React = require('react');
const { PropTypes } = React;

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');

const ListSection = require('../../common/sections/ListSection');
const MandateSection = require('../review/MandateSection');
const OfferHOC = require('./OfferHOC');

const ProductUtils = require('../../../utils/ProductUtils');
const ValidationUtils = require('../../../utils/ValidationUtils');

const { getProductCode } = ProductUtils;

const SingleProduct = props => {
	const productCode = getProductCode(props.offer.product.code);
	const product = ProductUtils.getProduct(productCode);
	const productName = product.name;
	const offerItems = product.alternativeOfferItems;
	const offerRestrictionsItems = product.offerRestrictions;
	const docsToRead = product.additionalDocumentItems;
	const subTitle = `${props.content.offerPageAlternativeOfferTitle}<span class="brand-highlight">${productName}</span>`;
	return (
		<div>
			{!props.goBack && <h2 dangerouslySetInnerHTML={{ __html: subTitle }} />}
			<h3 dangerouslySetInnerHTML={{ __html: props.content.offerPageSubTitle }} />
			<ListSection
				wrapperFn={props.getOfferElements}
				items={offerItems}
			/>
			<ListSection
				wrapperFn={props.getOfferElements}
				items={offerRestrictionsItems}
				title={props.content.offerPageofferRestrictionsTitle}
			/>
			<ListSection
				wrapperFn={props.getDocumentElements}
				items={docsToRead}
				title={props.content.offerPageDocumentToReadSectionTitle}
			/>

			<MandateSection
				key="offerAcceptFullTCsDiv"
				onReviewAcceptTCs={AccountOpeningActions.updateFormValue}
				defaultValue={props.data.offerAcceptFullTCs}
				group={props.group}
				termsName="offerAcceptFullTCs"
				termsClassName="terms-and-conditions-checkbox"
				termsCheckboContentKey="offerTandCQuestion"
				termsDataAnchor="offer-accept-full-tcs"
				product={{
					mandateItems: product.offerMandateItems,
				}}
				position="top"
				{...props}
			/>

			<p>{props.content.downgradedOfferPageEmail}</p>
			<div className="offer-result-actions clearfix">
				<div className="row">
					<div className="col-xs-12 col-md-6 col-md-push-5 text-center">
						<button
							className="btn btn-lg btn-primary inline btn-next"
							onClick={() => {
								props.onClickActionAccount(false, props.offer.id, props.offer.product.code);
							}}
							data-anchor="accept-next"
							disabled={!ValidationUtils.isGroupValid(props.validations, props.group) || props.appData.isApiCallInProgress}
						>
							{props.content.altOpenAccountButton}
						</button>
					</div>
					<div className="col-xs-12 col-md-6 col-md-pull-5 text-center">
						{props.goBack && <button
							className="btn btn-lg btn-primary inline btn-back"
							onClick={() => { props.onClickGoBack();}}
						>
							Go Back
						</button>}
						{!props.goBack && <button
							className="btn btn-lg btn-primary inline btn-decline"
							onClick={() => { props.onClickActionAccount(true, props.offer.id);}}
							data-anchor="accept-decline"
							disabled={props.appData.isApiCallInProgress}
						>
							{props.content.altDeclineAccountButton}
						</button>}

					</div>
				</div>
			</div>
		</div>
	);
};

SingleProduct.propTypes = {
	validations: PropTypes.object,
	appData: PropTypes.object.isRequired,
	offer: PropTypes.object.isRequired,
	group: PropTypes.string.isRequired,
	data: PropTypes.shape({
		offerAcceptFullTCs: PropTypes.boolean,
		productOffer: PropTypes.object.isRequired,
		product: PropTypes.shape({
			alternativeOfferItems: PropTypes.array,
		}).isRequired,
	}),
	getOfferElements: PropTypes.func.isRequired,
	getDocumentElements: PropTypes.func.isRequired,
	getMandateElements: PropTypes.func.isRequired,
	onClickActionAccount: PropTypes.func.isRequired,
	content: PropTypes.object.isRequired,
	goBack: PropTypes.bool,
};

module.exports = OfferHOC(SingleProduct);
