/**
 * @module CreditLimitFeature
 */

const React = require('react');
const _ = require('lodash');

function getHtmlContent(documents) {
	if (!documents || !documents.length) {
		return '';
	}

	return atob((_.find(documents, doc => {
		return doc.format.toLowerCase() === 'html';
	}) || {
		content: '',
	}).content);
}


function getPdfDocument(documents) {
	if (!documents || !documents.length) {
		return '';
	}

	return _.find(documents, doc => doc.format.toLowerCase() === 'pdf');
}

const CreditLimitFeature = WrappedComponent => React.createClass({
	render() {
		return (
			<WrappedComponent
				{...this.props}
				getHtmlContent={getHtmlContent}
				getPdfDocument={getPdfDocument}
			/>
		);
	},
});

module.exports = CreditLimitFeature;
