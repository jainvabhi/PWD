jest.autoMockOff();

const React = require('react');
const TestUtils = require('react-addons-test-utils');
const ReactDOM = require('react-dom');

const CreditCardOffer = require('../CreditCardOffer');
const { buildContent } = require('../../../../__helpers__/TestHelpers');

const content = buildContent([
	'creditOfferPageTitle',
	'creditOfferPageSubTitle',
	'creditOfferPreContractTitle',
	'creditOfferPreContractIntro',
	'creditOfferKeyFeaturesTitle',
	'creditOfferKeyFeaturesIntro',
	'creditOfferCreditAgreementTitle',
	'creditOfferCreditAgreementIntro',
]);

const render = (overrideProps = {}) => {
	const props = {
		content,
		group: 'test',
		data: {
			productCode: 'xxx',
			product: {
				alternativeOfferItems: [],
				name: 'test',
				productType: {
					name: '',
				},
			},
		},
		product: {
			alternativeOfferItems: [],
			name: 'test',
		},
		appData: {
			isApiCallInProgress: false,
		},
		validations: {},
		getOfferElements: () => {},
		getDocumentElements: () => {},
		getOfferElements: () => {},
		onClickActionAccount: jest.fn(),
		envConfig: {
			bankID: 'DYB',
		},
		cms: {},
		offer: {
			product: {
				code: 'XX',
			},
			features: {
				credit_limit: {
					update_offer: false,
				},
			},
		},
		...overrideProps,
	};
	const el = document.createElement('div');
	const component = <CreditCardOffer {...props} />;
	const instance = ReactDOM.render(component, el);
	return { props, instance };
};

describe('CreditCardOffer', () => {
	describe('on mount', () => {
		it('does not show the error message', () => {
			const { instance } = render();
			const errorMsg = TestUtils.scryRenderedDOMComponentsWithClass(
				instance,
				'error'
			);
			expect(errorMsg.length).toEqual(0);
		});
	});
	describe('when continue is clicked', () => {
		describe('when invalid', () => {
			it('shows the error message', () => {
				const { props, instance, output } = render({
					validations: {
						GROUP_OFFER: {
							offerKeyFeatures: {
								isValid: false,
							},
						},
					},
				});
				const button = TestUtils.findRenderedDOMComponentWithClass(
					instance,
					'btn-accept'
				);
				TestUtils.Simulate.click(button);
				expect(props.onClickActionAccount).not.toHaveBeenCalled();
				const errorMsg = TestUtils.scryRenderedDOMComponentsWithClass(
					instance,
					'error'
				);
				expect(errorMsg.length).toEqual(1);
			});
		});
		describe('when valid', () => {
			it('does not show the error message', () => {
				const { props, instance, output } = render({
					validations: {
						GROUP_OFFER: {
							offerKeyFeatures: {
								isValid: true,
							},
						},
					},
				});
				const button = TestUtils.findRenderedDOMComponentWithClass(
					instance,
					'btn-accept'
				);
				TestUtils.Simulate.click(button);
				expect(props.onClickActionAccount).toHaveBeenCalled();
				const errorMsg = TestUtils.scryRenderedDOMComponentsWithClass(
					instance,
					'error'
				);
				expect(errorMsg.length).toEqual(0);
			});
		});
	});
});
