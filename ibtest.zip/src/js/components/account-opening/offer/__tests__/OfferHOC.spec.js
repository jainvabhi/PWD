jest.unmock('../OfferHOC');
jest.unmock('../../../../utils/ContentUtils');
jest.unmock('../../../common/links/DocumentLink');

const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');
const _ = require('lodash');
const { buildFindMockByDataAnchorFilter, buildContent } = require('../../../../__helpers__/TestHelpers');

const config = require('../../../../config');
const OfferHOC = require('../OfferHOC');

const ProductUtils = require('../../../../utils/ProductUtils');
const ValidationUtils = require('../../../../utils/ValidationUtils');
const ContentUtils = require('../../../../utils/ContentUtils');
const HtmlUtils = require('../../../../utils/HtmlUtils');
const PathUtils = require('../../../../utils/PathUtils');
const BrandUtils = require('../../../../utils/BrandUtils');

PathUtils.getPath.mockReturnValue('/test/');
ProductUtils.getProduct.mockReturnValue({
	productType: 'test'
});
BrandUtils.appendBrand.mockReturnValue('/test/');

const container = document.createElement('div');
const render = (comp, el) => ReactDOM.render(comp, el || container);
let Wrapper = React.createClass({
    render() {
        return (
            <div>test</div>
        );
    }
});

Wrapper = OfferHOC(Wrapper);

let instance;

const contentKeys = ['test1', 'test2', 'debitContactlessOfferItem', 'interestOfferItem'];

const content = buildContent(contentKeys);
content.productConfigToken = 'test1 {minimumDeposit}';
content.productConfigToken1 = 'test2 {maturityDate}';

const shallowRenderer = TestUtils.createRenderer();

const data = {
	productOffer: {
		offers: [1, 2, 3]
	},
	productCode: 'blah',
	product: {
		productType: '',
		minimumDeposit: 2000,
		maturityDate: '12/07/2017',
	},
	products: {
		code: 12121
	}
};

const offers = {
	"offers": [
      {
        "product": {
          "code": "800",
          "name": "CURRENT ACCOUNT",
          "description": "",
          "variant": null
        },
        "documents": [],
        "features": {
          "credit_limit": null
        }
      }
    ]
};

const cms = {
	documentList: [
        {
           "brand": "YB",
           "webReference": "termsAndConditions",
           "docReference": "termsAndConditions.pdf",
           "docLinkText": "Terms & Conditions",
           "docLinkTitle": "Download Terms & Conditions PDF.",
           "docVersion": "0617",
           "fileName": "BTandCs-0617.pdf",
           "docAttachmentName": "B Terms and Conditions.pdf",
           "bank": "YB",
           "contentType": "PDF",
           "reason": "DOCUMENTATION"
        },
        {
           "brand": "YB",
           "webReference": "currentTariff",
           "docReference": "currenttariff.pdf",
           "docLinkText": "Terms & Conditions",
           "docLinkTitle": "Download Terms & Conditions PDF.",
           "docVersion": "0617",
           "fileName": "currenttariff-0617.pdf",
           "docAttachmentName": "B Terms and Conditions.pdf",
           "bank": "YB",
           "contentType": "PDF",
           "reason": "DOCUMENTATION"
        },
	]
}
describe('OfferHOC', () => {


	describe('getOfferElements', () => {
		beforeEach(() => {
			instance = render(
				<Wrapper data={data} content={content} cms={cms} envConfig={{bankId: 'YB'}} offers={offers} validations={{}} appData={{isApiCallInProgress: false}} />
			);
		});

		it('returns null if offerItems is not an array', () => {
			expect(instance.getOfferElements()).toBe(null);
			expect(instance.getOfferElements(null)).toBe(null);
			expect(instance.getOfferElements('null')).toBe(null);
		});


		it('returns an item for each data element passed in', () => {
			const result = instance.getOfferElements(['debitContactlessOfferItem', 'interestOfferItem']);
			expect(result.length).toBe(2);
		});

		it('returns an empty list if no items are passed in', () => {
			const result = instance.getOfferElements([]);
			expect(result.length).toBe(0);
		});

		it('returns an empty list if the content is not mapped', () => {
			const result = instance.getOfferElements(['NoContent1', 'NoContent2']);
			expect(result.length).toBe(0);
		});

		it('returns an item with their token replaced', () => {
			const result = instance.getOfferElements(['productConfigToken', 'productConfigToken1']);
			expect(result[0].props.dangerouslySetInnerHTML.__html).toEqual('test1 2000');
			expect(result[1].props.dangerouslySetInnerHTML.__html).toEqual('test2 12/07/2017');
		});

		it('hasSavingsAccountItems', () => {
			ProductUtils.getSavingAccountItems.mockReturnValue([1, 2, 3])
			HtmlUtils.getTextItems.mockReturnValue({
				test: 'test'
			});

			const result = instance.getOfferElements(['debitContactlessOfferItem']);
			expect(HtmlUtils.getTextItems.mock.calls.length).toBe(1);
			expect(result.length).toBe(2);
		});
	});

	describe('getDocumentElements', () => {

		it('returns null if docItems is not an array', () => {
			expect(instance.getDocumentElements()).toBe(null);
			expect(instance.getDocumentElements(null)).toBe(null);
			expect(instance.getDocumentElements('null')).toBe(null);
		});

		it('returns an item for each data element passed in', () => {
			const result = instance.getDocumentElements(['termsAndConditions', 'currentTariff']);
			expect(result.length).toBe(2);
		});

		it('returns an empty list if no items are passed in', () => {
			const result = instance.getDocumentElements([]);
			expect(result.length).toBe(0);
		});

		it('returns an empty list if the content is not mapped', () => {
			const result = instance.getDocumentElements(['testing']);
			expect(result.length).toBe(0);
		});
	});

	describe('getMandateElements', () => {
		it('returns null if docItems is not an array', () => {
			expect(instance.getMandateElements()).toBe(null);
			expect(instance.getMandateElements(null)).toBe(null);
			expect(instance.getMandateElements('null')).toBe(null);
		});

		it('returns an item for each data element passed in', () => {
			const result = instance.getMandateElements(['test1', 'test2']);
			expect(result.length).toBe(2);
		});

		it('returns an empty list if no items are passed in', () => {
			const result = instance.getMandateElements([]);
			expect(result.length).toBe(0);
		});

		it('returns an empty list if the content is not mapped', () => {
			const result = instance.getMandateElements(['testing']);
			expect(result.length).toBe(0);
		});

		it('returns an item with their token replaced', () => {
			const result = instance.getMandateElements(['productConfigToken']);
			expect(result[0].props.children).toBe(`test1 ${data.product.minimumDeposit}`);
		});
	});
});
