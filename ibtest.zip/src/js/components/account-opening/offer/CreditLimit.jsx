/**
 * @module CreditLimit
 */

const React = require('react');
const _ = require('lodash');
const { PropTypes } = React;

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');
const Slider = require('react-rangeslider').default;
const CreditLimitInput = require('./CreditLimitInput');
const ValidationUtils = require('../../../utils/ValidationUtils');

const stepAmount = 100;

const isValidAmount = value => {
	return !/\D/g.test(value)
		&& value % stepAmount === 0;
};

const inRange = (value, props) => {
	return value >= props.offer.features.credit_limit.minimum
		&& value <= props.offer.features.credit_limit.offer_limit;
};

const isValid = (value, props) => {
	return isValidAmount(value) && inRange(value, props);
};

const CreditLimit = React.createClass({
	propTypes: {
		appData: PropTypes.object.isRequired,
		group: PropTypes.string.isRequired,
		data: PropTypes.object.isRequired,
		validations: PropTypes.object.isRequired,
		content: PropTypes.object.isRequired,
		offer: PropTypes.object.isRequired,
		onUpdateOffer: PropTypes.func.isRequired,
	},

	componentDidMount() {
		AccountOpeningActions.updateFormValue('creditLimit', this.props.offer.features.credit_limit.offer_limit);
	},

	decreaseLimit() {
		const value = parseInt(this.props.data.creditLimit) || this.props.offer.features.credit_limit.minimum;
		if (value - stepAmount < this.props.offer.features.credit_limit.minimum) {
			return;
		}

		AccountOpeningActions.updateFormValue('creditLimit', value - stepAmount);
	},

	increaseLimit() {
		const value = parseInt(this.props.data.creditLimit) || this.props.offer.features.credit_limit.minimum;
		if (value + stepAmount > this.props.offer.features.credit_limit.offer_limit) {
			return;
		}

		AccountOpeningActions.updateFormValue('creditLimit', value + stepAmount);
	},

	handleChange(value) {
		AccountOpeningActions.updateFormValue('creditLimit', value);
	},

	render() {
		const creditLimitValue = `${!_.isUndefined(this.props.data.creditLimit) ? this.props.data.creditLimit : this.props.offer.features.credit_limit.offer_limit}`;

		return (
			<div className="row">
				{this.props.content.creditLimitInputIntro && <p>{this.props.content.creditLimitInputIntro}</p>}
				<CreditLimitInput
					name={'creditLimitInput'}
					isValid={value => isValid(value, this.props)}
					group={this.props.group}
					validationText={this.props.content.creditLimitValidationMsg}
					value={creditLimitValue}
					onChange={this.handleChange}
					{...this.props}
				/>

				<div className="text-center col-md-12">
					<div className="slider-wrapper row">
						<div className="control col-md-1 col-sm-1 col-xs-2" onClick={this.decreaseLimit}>
							<span>-</span>
						</div>
						<div className="col-md-10 col-sm-10 col-xs-8">
							<Slider
								min={this.props.offer.features.credit_limit.minimum}
								max={this.props.offer.features.credit_limit.offer_limit}
								step={stepAmount}
								value={!_.isUndefined(this.props.data.creditLimit) ? parseInt(this.props.data.creditLimit) : this.props.offer.features.credit_limit.minimum}
								onChange={this.handleChange}
							/>
							</div>
							<div className="control col-md-1 col-sm-1 col-xs-2" onClick={this.increaseLimit}>
								<span>+</span>
							</div>
					</div>

						<p className="credit-limit-confirmation">{this.props.content.creditLimitConfirmation}</p>

					<button
						className="btn btn-lg btn-primary inline btn-next"
						onClick={() => { this.props.onUpdateOffer(this.props.data.creditLimit || this.props.offer.features.credit_limit.minimum);}}
						data-anchor="update-next"
						disabled={!ValidationUtils.isGroupValid(this.props.validations, this.props.group) || this.props.appData.isApiCallInProgress}
					>
						{this.props.content.creditLimitBtn}
					</button>
				</div>
			</div>
		);
	},
});

module.exports = CreditLimit;
