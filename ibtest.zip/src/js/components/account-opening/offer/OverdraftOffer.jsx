const React = require('react');
const { PropTypes } = React;
const moment = require('moment');
const _ = require('lodash');
const envConfig = require('../../../../static/config');
const AccountOpeningActions = require('../../../actions/AccountOpeningActions');
const AccountOpeningConstants = require('../../../constants/AccountOpeningConstants');
const OfferHOC = require('./OfferHOC');
const OfferDetails = require('./OfferDetails');
const ListSection = require('../../common/sections/ListSection');
const CreditAgreement = require('./CreditAgreement');
const AgreeementSection = require('./AgreeementSection');
const { CybOverdraftKeyFeatures, DybOverdraftKeyFeatures } = require('./KeyFeatures');
const CreditLimitFeature = require('./CreditLimitFeature');

const BrandUtils = require('../../../utils/BrandUtils');
const ContentUtils = require('../../../utils/ContentUtils');
const ProductUtils = require('../../../utils/ProductUtils');
const ValidationUtils = require('../../../utils/ValidationUtils');
const ScreenshotUtils = require('../../../utils/ScreenshotUtils');

const { mapDocumentAuditInfo } = require('../../common/links/DocumentLink');

const isConditional = offer => offer.features['credit_limit']['income_proof_required'];
const isDeclined = offer => !offer.features['credit_limit']['offer_limit'];
const isReduced = (offer, data) => offer.features['credit_limit']['offer_limit'] < data.overdraftLimit;
const canAcceptOverdraft = offer => !isConditional(offer) && offer.features['credit_limit']['offer_limit'] > 0;

const { getProductCode } = ProductUtils;

const addOverdraft = items => {
	return [
		...items,
		'offerItemOverdraft',
	];
};

const replaceOfferFeature = (items, keys) => {
	const replacements = [
		...items,
	];

	_.chain(keys)
	.map(key => items.indexOf(key))
	.filter(key => key >= 0)
	.each(ndx => replacements[ndx] = `${replacements[ndx]}Overdraft`)
	.value();

	return replacements;
};

const getOutcome = props => {
	const amount = `£${props.offer.features['credit_limit']['offer_limit']}`;

	if (isDeclined(props.offer)) {
		return envConfig.bankId === 'DYB' ? 'We can offer you B' : '';
	}

	if (isConditional(props.offer) && !isReduced(props.offer, props.data)) {
		return props.content.overdraftsFullOffer && props.content.overdraftsFullOffer.replace('{amount}', amount) + props.content.overdraftsConditionalOfferSuffix;
	}

	if (isConditional(props.offer) && isReduced(props.offer, props.data)) {
		return props.content.overdraftsReducedOffer && props.content.overdraftsReducedOffer.replace('{amount}', amount) + props.content.overdraftsConditionalOfferSuffix;
	}

	if (isReduced(props.offer, props.data)) {
		return props.content.overdraftsReducedOffer && props.content.overdraftsReducedOffer.replace('{amount}', amount);
	}

	return props.content.overdraftsSuccessfulOffer && props.content.overdraftsSuccessfulOffer
	.replace('{productName}', props.data.product.name)
	.replace('{productArticle}', props.data.product.productArticle)
	.replace('{amount}', amount);
};

const getSorryPageExplanation2 = props => {
	return <p>{props.content.overdraftsDeclineCreditAgency}</p>;
};

getSorryPageExplanation2.propTypes = {
	content: PropTypes.shape({
		overdraftsDeclineCreditAgency: PropTypes.string,
	}),
};

const DeclinedOverdraftOffer = props => (
	<span>
		<h2 className="offer-additional-info">However, we are unable to offer you an overdraft at the moment</h2>
		{getSorryPageExplanation2(props)}
		<div className="row">
			<div className="col-md-6">
				<div className="overdraft-decline-credit">
					<p className="overdraft-decline-credit__link"><a href="http://www.experian.co.uk" target="_blank">www.experian.co.uk</a></p>
					<p>Consumer Help Service</p>
					<p>Experian Limited</p>
					<p>PO Box 8000</p>
					<p>Nottingham</p>
					<p>NG80 7WF</p>
					<p className="overdraft-decline-credit__tel">Tel. 0344 481 8000</p>
				</div>
			</div>
			<div className="col-md-6">
				<div className="overdraft-decline-credit">
					<p className="overdraft-decline-credit__link"><a href="http://www.callcredit.co.uk" target="_blank">www.callcredit.co.uk</a></p>
					<p>Consumer Help Service</p>
					<p>Call Credit Limited</p>
					<p>PO Box 491</p>
					<p>Leeds</p>
					<p>LS3 1WZ</p>
					<p className="overdraft-decline-credit__tel">Tel. 0330 024 7579</p>
				</div>
			</div>
		</div>
	</span>
);

DeclinedOverdraftOffer.propTypes = {
	data: PropTypes.shape({
		productCode: PropTypes.string,
	}),
	content: PropTypes.shape({}),
};

const ConditionalOverdraftOffer = props => (
	<span>
		{ContentUtils.getContentParagraphs('overdraftConditionalParagraph', props.content)}
	</span>
);

ConditionalOverdraftOffer.propTypes = {
	content: PropTypes.object,
};

const OverdraftOffer = CreditLimitFeature(React.createClass({
	propTypes: {
		appData: PropTypes.object.isRequired,
		cms: PropTypes.object.isRequired,
		envConfig: PropTypes.object.isRequired,
		validations: PropTypes.object.isRequired,
		group: PropTypes.string.isRequired,
		data: PropTypes.object.isRequired,
		content: PropTypes.object.isRequired,
		offer: PropTypes.object.isRequired,
		onClickActionAccount: PropTypes.func.isRequired,
		documentActions: PropTypes.object,
		documents: PropTypes.array,
		getOfferElements: PropTypes.func,
		getPdfDocument: PropTypes.func,
		getHtmlContent: PropTypes.func,
	},

	getInitialState() {
		return {
			offerKeyFeatures: {
				isOpen: false,
			},
			offerPreContract:{
				isOpen: false,
			},
			offerCreditAgreement:{
				isOpen: false,
			},
			acceptingOffer: false,
		};
	},

	componentWillReceiveProps(nextProps) {
		if (!this.props.documents && this.props.offer.documents && !this.state.fetchingDocuments && !BrandUtils.isAbleToDisplay('disable_credit_agreement')) {
			this.setState({ fetchingDocuments: true });
			const docs = this.props.offer.documents.filter(x => x.format.toLowerCase() === 'html');
			this.props.documentActions.fetch(docs);
		}

		if (nextProps.data.acceptUpdate && !this.state.acceptingOffer) {
			this.setState({
				acceptingOffer: true,
			}, () => {
				AccountOpeningActions.respondToProductOffer(this.props.offer.id, false, getProductCode(this.props.offer.product.code));
				AccountOpeningActions.navigateToWebTask('WEB-SUBMIT-FORM');
			});
		}
	},

	onToggleAgreement(key) {
		this.setState({
			[key]: {
				isOpen: !this.state[key].isOpen,
				hasRead: true,
			},
		});
	},

	onAcceptOffer() {
		if (canAcceptOverdraft(this.props.offer)) {
			this.acceptCreditOffer();
		} else {
			this.props.onClickActionAccount(false, this.props.offer.id, this.props.offer.product.code);
		}
	},

	onUpdateOffer() {
		const action = () => {
			AccountOpeningActions.updateProductOffer(this.props.offer.id, 0, true);
		};

		this.setState({
			offerKeyFeatures: {
				isOpen: true,
			},
			offerPreContract:{
				isOpen: true,
			},
			offerCreditAgreement:{
				isOpen: true,
			},
		}, () => {
			ScreenshotUtils.takeScreenshot(action, this.props.data.caseId);
		});
	},

	acceptCreditOffer() {
		const auditDocs = [
			'odKeyFeatures',
		];

		const odFaciltiesLetterAuditInfo = {
			reason: 'DOCUMENTATION',
			name: 'Overdraft Facility Agreement',
			version: '',
			consent: 'Y',
			timestamp:  moment().format(),
		};

		const docs = [...mapDocumentAuditInfo(auditDocs, this.props.envConfig.bankId, this.props.cms), odFaciltiesLetterAuditInfo];

		this.setState({
			offerKeyFeatures: {
				isOpen: true,
			},
			offerPreContract:{
				isOpen: true,
			},
			offerCreditAgreement:{
				isOpen: true,
			},
		}, () => {
			this.props.onClickActionAccount(false, this.props.offer.id, this.props.offer.product.code, docs, true);
		});
	},

	render() {
		const isValid = ValidationUtils.isGroupValid(this.props.validations, AccountOpeningConstants.GROUP_OFFER);
		if (!this.props.offer || this.props.offer.features['credit_limit']['offer_limit'] && !this.props.documents) {
			return null;
		}
		const isCondtionalOverdraft = isConditional(this.props.offer);
		const isDeclinedOverdraft = isDeclined(this.props.offer);
		const hasOverdraft = canAcceptOverdraft(this.props.offer) && !isCondtionalOverdraft && !isDeclinedOverdraft;

		return (
			<OfferDetails
				{...this.props}
				headerIllustration="offer-illustration.png"
				pageTitle={this.props.content.offerPageTitle &&
					this.props.content.offerPageTitle
					.replace('{productName}', this.props.data.product.name)
					.replace('{productArticle}', this.props.data.product.productArticle)

				}
				subTitle={this.props.content.offerPageSubTitle}
				additionalInfo={getOutcome(this.props)}
			>
				<ListSection
					wrapperFn={this.props.getOfferElements}
					items={hasOverdraft ? replaceOfferFeature(addOverdraft(ProductUtils.getOfferItems(this.props.data.productCode)), ['offerItemDebitContactless', 'offerItemDebitContactlessLimited', 'offerItemCaControl', 'offerItemCaDirectCaPlus']) : ProductUtils.getOfferItems(this.props.data.productCode)}
				/>
				{isCondtionalOverdraft && <ConditionalOverdraftOffer {...this.props} />}
				{hasOverdraft && <p>{this.props.content.overdraftOfferAcknowledge}</p>}
				{hasOverdraft && [<AgreeementSection
					title="1. Key features"
					intro="Please read the key features then tick the box before moving on to the overdraft facility agreement"
					group={AccountOpeningConstants.GROUP_OFFER}
					disabled={false}
					hasRead={this.state.offerKeyFeatures.hasRead}
					name="offerKeyFeatures"
					onChange={this.onToggleAgreement}
					onAcceptChange={AccountOpeningActions.updateFormValue}
					isOpen={this.state.offerKeyFeatures.isOpen}
					docKey="odKeyFeatures"
					nonCreditCheckboxLabel="By ticking this box you acknowledge the above key features"
					{...this.props}
				>
					{envConfig.bankId === 'DYB' ?
							<DybOverdraftKeyFeatures {...this.props} /> :
							<CybOverdraftKeyFeatures {...this.props} />
					}
				</AgreeementSection>,
				<AgreeementSection
					title="2. Overdraft facility agreement"
					intro="Please read, then tick the box."
					group={AccountOpeningConstants.GROUP_OFFER}
					disabled={false}
					hasRead={this.state.offerCreditAgreement.hasRead}
					name="offerCreditAgreement"
					onChange={this.onToggleAgreement}
					onAcceptChange={(key, val) => {
						if (val === true) {
							this.setState({
								isValid: val,
							});
						}
						AccountOpeningActions.updateFormValue(key, val);
					}}
					isOpen={this.state.offerCreditAgreement.isOpen}
					nonCreditCheckboxLabel="By ticking this box, this represents my signature agreeing to legally bound by the above terms"
					onDownload={() => this.props.documentActions.download(this.props.getPdfDocument(this.props.offer.documents))}
					{...this.props}
				>
					<CreditAgreement content={this.props.getHtmlContent(this.props.documents)} />
				</AgreeementSection>]}
				{isDeclinedOverdraft && <DeclinedOverdraftOffer {...this.props} />}
				{isDeclinedOverdraft && <p>{this.props.content.mandateParagraph}</p>}
				<div className="offer-page-controls-wrapper">
					<div className="text-center">
						{!isDeclinedOverdraft && !isCondtionalOverdraft && <button
							className="btn btn-lg btn-primary inline btn-next"
							onClick={this.onAcceptOffer}
							data-anchor="accept-next"
							disabled={this.props.appData.isApiCallInProgress || !isValid}
						>
							{this.props.content.overdraftOpenAccountWithOverdraft}
						</button>}
						{isDeclinedOverdraft &&
							<button
								className="btn btn-lg btn-primary inline btn-next"
								onClick={this.onAcceptOffer}
								data-anchor="accept-next"
								disabled={this.props.appData.isApiCallInProgress}
							>
							{this.props.content.openAccountButton}
						</button>}

						{!isDeclinedOverdraft && !isCondtionalOverdraft && <button
							className="btn btn-lg btn-primary inline btn-next"
							onClick={this.onUpdateOffer}
							data-anchor="accept-next"
							disabled={this.props.appData.isApiCallInProgress}
						>
							{this.props.content.overdraftOpenAccountWithoutOverdraft}
						</button>}
						{isDeclinedOverdraft && <div className="offer-info text-center">{this.props.content.offerPageDeclineOffer}</div>}
						{isCondtionalOverdraft && <button
							className="btn btn-lg btn-primary inline btn-next"
							onClick={this.onUpdateOffer}
							data-anchor="accept-next"
							disabled={this.props.appData.isApiCallInProgress}
						>
							{this.props.content.overdraftOpenAccountOnly}
						</button>}
						{isCondtionalOverdraft &&
							<a
								className="btn btn-lg btn-primary inline btn-next"
								href="https://send.cbonline.co.uk"
								target="_blank"
							>
							Upload Proof of Income
						</a>
						}
					</div>
				</div>
			</OfferDetails>
		);
	},
}));

module.exports = OfferHOC(OverdraftOffer);
