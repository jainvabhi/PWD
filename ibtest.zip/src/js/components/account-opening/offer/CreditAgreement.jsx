/**
 * @module CreditAgreement
 */

const React = require('react');
const { PropTypes } = React;

const CreditAgreement = props => (
	<div>
		<p dangerouslySetInnerHTML={{ __html: props.content }} />
	</div>
);

CreditAgreement.propTypes = {
	content: PropTypes.string,
};

module.exports = CreditAgreement;
