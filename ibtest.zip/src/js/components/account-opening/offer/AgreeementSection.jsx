/**
 * @module AgreeementSection
 */

const React = require('react');
const { PropTypes } = React;
const cx = require('classnames');
const moment = require('moment');

const config = require('../../../config');
const PathUtils = require('../../../utils/PathUtils');
const CheckBoxQuestion = require('../../common/questionsets/CheckBoxQuestion');
const { DocumentLink } = require('../../common/links/DocumentLink');

const AgreementDownloadLink = props => {
	const linkText = 'Print/Save a copy';
	const btnClass = 'btn-link';

	if (props.onDownload) {
		return (
			<button
				className={btnClass}
				onClick={() => {
					props.onDownload();
				}}
				title="Print/Save a copy. This link will open in a new browser window"
			>
				{linkText}
			</button>
		);
	}

	return (
		<DocumentLink
			text={linkText}
			{...props}
		/>
	);
};

AgreementDownloadLink.propTypes = {
	documentLink: PropTypes.string,
	name: PropTypes.string.isRequired,
	onDownload: PropTypes.func,
	onChange: PropTypes.func.isRequired,
};

const AgreeementSection = props => {
	if (props.disabled) {
		return (
			<h3 className="agreement-title">{props.title}</h3>
		);
	}

	return (
		<div>
			<h3 className="agreement-title">{props.title}</h3>
			<p>{props.intro}</p>
			<div className="agreewrapper">
				<div className={cx({
						'agreewrapper__content': !props.isOpen,
						'agreewrapper__content-expanded': props.isOpen,
					})}
				>
					<div>
					{!props.isOpen && <div className="mask" />}
					{props.children}
					</div>
				</div>
				<div className="agreewrapper__toggle">
					<div className="row">
						<div className="col-md-6 col-sm-12">
							<button
								className="btn btn-lg btn-primary inline btn-next"
								disabled={props.disabled}
								onClick={() => {props.onChange(props.name);}}
							>
								{!props.isOpen ? 'Expand to view' : 'Close'}
								<span
									className={cx('arrow', {
										'down': !props.isOpen,
										'up': props.isOpen,
									})}
								/>
							</button>
						</div>

					</div>

				</div>
				<div className="agreewrapper__agree">
					<div
						className={cx('row', {
							'agreewrapper__agree-mask': !props.hasRead,
						})}
					>
					{!props.credit &&
						<div>
							<div className="col-md-9 col-sm-12">
								<CheckBoxQuestion
									group={props.group}
									name={props.name}
									dataAnchor={`offer-${props.name}`}
									disabled={!props.hasRead}
									onChange={props.onAcceptChange}
									required
								>
									{props.nonCreditCheckboxLabel}
								</CheckBoxQuestion>
							</div>
							<div className="col-md-3 col-sm-12">
									<div className="agreewrapper__agree-document-link">
										{props.isOpen && <AgreementDownloadLink {...props} />}
									</div>
							</div>
						</div>
					}

					{props.credit &&
						<div>
							<div className="col-md-12">
								<h4>Please sign the credit agreement</h4>
								<p>This is a Credit Agreement regulated by the Consumer Credit Act 1974.</p>
								<p>This is a legally binding contract. Please tick the box below and click the ‘Open my account’ button to agree to be bound by the terms and conditions of this agreement.</p>
								<p>This is a digital signature and is equivalent to signing a paper copy of the agreement.</p>
							</div>

							<div className="col-md-6">
								<p>Your signature</p>
								<CheckBoxQuestion
									group={props.group}
									name={props.name}
									disabled={!props.hasRead}
									dataAnchor={`offer-${props.name}`}
									onChange={props.onAcceptChange}
									required
								>
									I agree to be bound by the terms of this credit agreement
								</CheckBoxQuestion>

								<p className="agreewrapper__agree-date">Date of agreement: {moment().format(config.dateFormat)} </p>

							</div>

							<div className="col-md-6">
								<p>Clydesdale Bank PLC</p>
								<img className="agreewrapper__agree-sig" src={PathUtils.getPath('images/common/signature.png')} />
								<p className="agreewrapper__agree-date">Date: {moment().format(config.dateFormat)} </p>
							</div>

							<div className="col-md-12 col-sm-12">
									<div className="agreewrapper__agree-document-link">
										{props.isOpen && <AgreementDownloadLink {...props} />}
									</div>
							</div>

						</div>
					}
					</div>
				</div>
			</div>
		</div>
	);
};

AgreeementSection.defaultProps = {
	nonCreditCheckboxLabel: 'I have read, and printed or saved a copy of the above',
};

AgreeementSection.propTypes = {
	data: PropTypes.object.isRequired,
	content: PropTypes.object.isRequired,
	children: PropTypes.object.isRequired,
	name: PropTypes.string.isRequired,
	isOpen: PropTypes.bool.isRequired,
	title: PropTypes.string.isRequired,
	group: PropTypes.string.isRequired,
	intro: PropTypes.string.isRequired,
	disabled: PropTypes.bool.isRequired,
	hasRead: PropTypes.bool,
	credit: PropTypes.bool,
	onChange: PropTypes.func.isRequired,
	onAcceptChange: PropTypes.func.isRequired,
	nonCreditCheckboxLabel: PropTypes.string,
};

module.exports = AgreeementSection;
