/**
 * @module KeyFeatures
 */

const React = require('react');

const CybCreditKeyFeatures = () => (
	<div>
		<h5>Gold Mastercard Credit Card</h5>
		<p><strong>Key Features</strong></p>
		<p>Here’s an overview of the Gold Mastercard Credit Card’s key features. It explains:</p>
		<ul>
			<li>how you can use your credit card;</li>
			<li>interest rates and charges;</li>
			<li>how to make payments;</li>
			<li>what balance transfers are and how to make them; and</li>
			<li>how to get in touch if you have any questions.</li>
		</ul>
		<p>It’s really important to read and consider all your documents, including this document and the SECCI, very carefully to make sure the Gold Mastercard Credit Card is the right option for you. If you need more information or you have any questions, our help line is open 24 hours a day, 7 days a week. Just call 0800 678 3320. Or you can write to us at the address on the copy of the agreement we have emailed to you.</p>
		<h5>How you can use your credit card</h5>
		<p>A credit card is designed for short-term borrowing, to:</p>
		<ul>
			<li>buy everyday items or spread the cost of more expensive items;</li>
			<li>get cash out in an emergency; and</li>
			<li>transfer a balance from another credit card.</li>
		</ul>
		<p>Using a credit card for longer-term borrowing or withdrawing cash can be expensive. If you’re looking to borrow money for a longer period, or if you need a loan with a fixed interest rate, we can help you find a suitable alternative to a credit card. </p>
		<p>You get the first 12 months interest-free when you transfer a balance from another credit card. There’s a 3% fee (minimum £3), so that’s £30 for every £1,000 transferred.</p>
		<h5>Credit limit</h5>
		<p>There’s a limit to how much you can spend on your credit card and this will be agreed after the agreement is made. It’s important to make sure your credit limit is an amount you can afford to pay back. When we set your credit limit, you can ask us to reduce it at any time, and ask us to keep it the same if we’ve told you we’re increasing it.</p>
		<h5>Interest rates and charges</h5>
		<p>The interest rate and charges you pay depend on how you use your credit card, and are outlined in the Summary Box. For example, if you use the card to withdraw cash, transfer money to another account, buy foreign currency or travellers cheques, or to gamble, you’ll pay a higher rate of interest and a cash fee of 3% (minimum £3) – that’s an extra £6 for every £200 spent. And you’ll start paying interest immediately. If you’re using your credit card abroad, a Non-Sterling Transaction Fee of 2.95% of the amount converted into sterling will apply.</p>
		<h5>Increasing and decreasing interest rates</h5>
		<p>Sometimes we have to increase or decrease our interest rates for some or all of our customers. If we increase your rates or charges, we’ll give you at least 30 days’ personal notice. If we make a change that benefits you (for example, we reduce your interest rate) we’ll still give you personal notice but we might make the change more quickly.</p>
		<h5>Promotional interest rate</h5>
		<p>Once your application has been approved, you’ll be able to buy things using your credit card and enjoy a promotional interest rate of 0% for 26 months. After that, you’ll automatically switch to our standard rate. All the information about our interest rates and charges is set out in the Summary Box</p>
		<h5>How to make payments</h5>
		<p>Each month, you’ll need to make at least the minimum payment to your account. This amount will be shown on your statement each month. You can also repay more than the minimum or pay the full amount you owe. If you only pay the minimum payment each month you will be charged interest and it will take you longer, and cost you more, to repay the full balance.</p>
		<h5>Missed payments</h5>
		<p>It’s really important to keep up with your monthly repayments as late or missed payments lead to charges and possibly legal action. Please get in touch with us if you’re struggling to manage your money.</p>
		<h5>What happens if you miss a payment?</h5>
		<ul>
			<li>You will be charged a fee of £12.00.</li>
			<li>For every month you’re over your credit limit, you will be charged £12.00.</li>
			<li>You might lose any introductory or promotional rates and you might have to repay the balance early, in full.</li>
			<li>The cost of your debt will increase as interest will be added to it. The amount of interest you pay will be based on the entire balance.</li>
			<li>Your credit rating may be affected, which could make it harder to get credit in the future.</li>
			<li>You may face legal action to recover what you owe and we may start bankruptcy proceedings, which could put your home at risk. You might also have to pay our legal costs.</li>
			<li>If you live in England or Wales, we may seek a charging order from the court, which means we can be paid from the proceeds when you sell your home.</li>
			<li>If you live in Scotland, we may seek an inhibition from the court, which means you cannot sell or transfer ownership of your home or take out further loans secured on your home until our debt is repaid.</li>
			<li>We might use money you have in another account with us to pay arrears or anything you owe us on the account.</li>
		</ul>
		<h5>Balance transfers</h5>
		<p>Sometimes transferring what you owe from one credit or store card to another can help you manage your borrowings more easily. You can make balance transfers to your Clydesdale Bank Gold Mastercard Credit Card and details of any fees, interest and limits will be explained when you ask us to make a balance transfer. It’s worth noting that:</p>
		<ul>
			<li>you will be charged a 3% fee (minimum £3) when you transfer the balance – that’s £30 per £1,000 transferred. Once the promotional period is over, you will be charged the standard purchases interest rate on anything you’ve not paid off</li>
			<li>interest will be charged on your balance transfer fee until the fee is paid off. It won’t be charged during any promotional purchases period, so it’s a good idea to try and pay the fee off in full during this time if you can.</li>
		</ul>
		<h5>Changing your mind</h5>
		<p>Once we’ve confirmed that your agreement has been signed, you have up to 14 days, from the day after the agreement is made, to change your mind. If you do, please write to or call us. You will then have 30 days to repay anything you’ve borrowed, including any interest. If you don’t repay all amounts within 30 days, you’ll continue to be charged interest.</p>
		<p>If you’re happy with the credit card agreement, it will continue until you or we end it.</p>
	</div>
);


const DybCreditKeyFeatures = () => (
	<div>
		<h5>B credit card</h5>
		<p><strong>Key Features</strong></p>
		<p><strong>Here’s an overview of the B credit card’s key features. It explains: </strong></p>
		<ul>
		<li>how you can use your credit card;</li>
		<li>interest rates and charges;</li>
		<li>how to make payments; </li>
		<li>what balance transfers are and how to make them; and</li>
		<li>how to get in touch if you have any questions. </li>
		</ul>
		<p>It’s really important to read and consider all your documents, including this document and the Standard European Consumer Credit Information (SECCI), very carefully to make sure the B credit card is the right option for you. If you need more information or you have any questions, our help line is open Monday to Friday 8am - 8pm, Saturday 9am - 5pm, Sunday 10am - 5pm. Just call 0800 678 3654. Or you can write to us at the address on the copy of the agreement we have emailed to you.</p>
		<p><strong>How you can use your credit card</strong></p>
		<ul>
		<li>A credit card is designed for short-term borrowing, to: </li>
		<li>buy everyday items or spread the cost of more expensive items; </li>
		<li>get cash out in an emergency; and </li>
		<li>transfer a balance from another credit card. </li>
		</ul>
		<p>Using a credit card for longer-term borrowing or withdrawing cash can be expensive. If you’re looking to borrow money for a longer period, or if you need a loan with a fixed interest rate, we can help you find a suitable alternative to a credit card.</p>
		<p><strong>Credit limit</strong></p>
		<p>There’s a limit to how much you can spend on your credit card and this will be agreed after the agreement is made. It’s important to make sure your credit limit is an amount you can afford to pay back. When we set your credit limit, you can ask us to reduce it at any time, and ask us to keep it the same if we’ve told you we’re increasing it.</p>
		<p><strong>Interest rates and charges</strong></p>
		<p>The interest rate and charges you pay depend on how you use your credit card, and are outlined in the Summary Box.</p>
		<p>For example, if you use the card to withdraw cash, transfer money to another account, buy foreign currency or travellers cheques, or to gamble, you’ll pay a higher rate of interest and a cash fee of 3% (minimum £3) – that’s an extra £6 for every £200 spent. And you’ll start paying interest immediately.</p>
		<p><strong>Increasing and decreasing interest rates</strong></p>
		<p>Sometimes we have to increase or decrease our interest rates for some or all of our customers.</p>
		<p>If we increase your rates or charges, we’ll give you at least 30 days’ personal notice. If we make a change that benefits you (for example, we reduce your interest rate) we’ll still give you personal notice but we might make the change more quickly.</p>

		<p><strong>How to make payments</strong></p>
		<p>Each month, you’ll need to make at least the minimum payment to your account. This amount will be shown on your statement each month.</p>
		<p>You can also repay more than the minimum or pay the full amount you owe. If you only pay the minimum payment each month you will be charged interest and it will take you longer, and cost you more, to repay the full balance.</p>
		<p><strong>Missed payments</strong></p>
		<p>It’s really important to keep up with your monthly repayments as late or missed payments lead to charges and possibly legal action. Please get in touch with us if you’re struggling to manage your money.</p>
		<p><strong>What happens if you miss a payment?</strong></p>
		<ul>
			<li>You will be charged a fee of £12.00.</li>
			<li>For every month you’re over your credit limit, you will be charged £12.00.</li>
			<li>You might lose any promotional rates and you might have to repay the balance early, in full.</li>
			<li>The cost of your debt will increase as interest will be added to it. The amount of interest you pay will be based on the entire balance.</li>
			<li>Your credit rating may be affected, which could make it harder to get credit in the future.</li>
			<li>You may face legal action to recover what you owe and we may start bankruptcy proceedings, which could put your home at risk. You might also have to pay our legal costs.</li>
			<li>If you live in England or Wales, we may seek a charging order from the court, which means we can be paid from the proceeds when you sell your home.</li>
			<li>If you live in Scotland, we may seek an inhibition from the court, which means you cannot sell or transfer ownership of your home or take out further loans secured on your home until our debt is repaid.</li>
			<li>We might use money you have in any other Clydesdale Bank PLC accounts you hold to pay arrears or anything you owe us on the account.</li>
		</ul>
		<p><strong>Balance transfers</strong></p>
		<p>Sometimes transferring what you owe from one credit or store card to another can help you manage your borrowings more easily. You can make balance transfers to your B credit card and details of any fees, interest and limits will be explained when you ask us to make a balance transfer.</p>
		<p><strong>Changing your mind</strong></p>
		<p>Once we’ve confirmed that your agreement has been signed, you have up to 14 days, from the day after the agreement is made, to change your mind. If you do, please write to or call us. You will then have 30 days to repay anything you’ve borrowed, including any interest. If you don’t repay all amounts within 30 days, you’ll continue to be charged interest.</p>
		<p>If you’re happy with the credit card agreement, it will continue until you or we end it.</p>
	</div>
);

const CybOverdraftKeyFeatures = () => (
	<div>
		<h5>IMPORTANT INFORMATION – PLEASE READ</h5>
		<p>You should consider the information in this key features document and any other documentation carefully. If we give you the documentation in person, you can take it away and consider it before entering into the Overdraft Facility Agreement. If we provide it online you can save or download it.</p>
		<p><strong>Features</strong></p>
		<p>An Overdraft provides you with immediate funds to assist with day to day operating costs. An Overdraft is repayable on demand, which means we can ask you to repay the whole of any outstanding balance at any time although we will normally give you prior notice. Full details of the facility, are provided in the Overdraft Facility Agreement which we will provide to you.</p>
		<p><strong>Interest Rates & Charges</strong></p>
		<p>The interest rate applicable to the Overdraft is not a fixed rate. It is a variable rate which is shown in your Overdraft Facility Agreement. The costs of the Overdraft will depend on how much is used by you and for how long. We will notify you in advance of the charges which will be applied.</p>
		<p><strong>Consequences of Default</strong></p>
		<p>If you exceed your Overdraft and go into Unplanned Borrowing (that is where you exceed the amount available in your account, including any overdraft facility, without first agreeing it with us):</p>
		<ul>
			<li>you may have to repay the Overdraft in full should the position not be corrected (i.e. if you do not bring yourself back within your planned overdraft or back into credit)</li>
			<li>you may be liable for fees as described in your account terms & conditions and tariff</li>
			<li>your credit records may be affected in a way that makes it more difficult or more expensive to obtain further credit</li>
			<li>you may face legal action to recover what you owe</li>
			<li>we may take action to enforce any security we hold</li>
			<li>we may use money you have in any another account(s) with us to pay arrears or anything you owe us on the account</li>
			<li>you may also have to pay us our legal costs.</li>
		</ul>
		<p><strong>Cancellation</strong></p>
		<p>If you change your mind about taking out an Overdraft, you have a legal right to cancel it within 14 days from the day after it is available on your account, or from the day you receive your Overdraft Facility Agreement, whichever is later. If you do want to cancel your Overdraft, you will need to repay any outstanding balance, interest and fees within 30 days of the date you cancel it. In addition to your cancellation right, you can remove your overdraft at any time by repaying any outstanding, balance, interest and fees.</p>
		<p>You can cancel or remove your Overdraft by:</p>
		<ul>
			<li>Writing to your branch</li>
			<li>Contacting your Private Relationship Manager</li>
			<li>Calling us on 0800 678 3350</li>
			<li>Visiting any of our branches</li>
		</ul>
		<p>Please ask us if you have any questions about this key features information or the Overdraft Facility Agreement, or if you require further information or explanation.</p>
		<p>If you do not cancel, the Overdraft will continue until ended by either one of us.</p>
	</div>
);

const DybOverdraftKeyFeatures = () => (
	<div>
		<h5>IMPORTANT INFORMATION – PLEASE READ</h5>
		<p>You should consider the information in this key features document and any other documentation carefully. If we give you the documentation in person, you can take it away and consider it before entering into the Overdraft Facility Agreement. If we provide it online you can save or download it.</p>
		<p><strong>Features</strong></p>
		<p>An Overdraft provides you with immediate funds to assist with day to day operating costs. An Overdraft is repayable on demand, which means we can ask you to repay the whole of any outstanding balance at any time although we will normally give you prior notice. Full details of the facility, are provided in the Overdraft Facility Agreement which we will provide to you.</p>
		<p><strong>Interest Rates & Charges</strong></p>
		<p>The interest rate applicable to the Overdraft is not a fixed rate. It is a variable rate which is shown in your Overdraft Facility Agreement. The costs of the Overdraft will depend on how much is used by you and for how long. We will notify you in advance of the charges which will be applied.</p>
		<p><strong>Consequences of Default</strong></p>
		<p>If you exceed your Overdraft and go into Unplanned Borrowing (that is where you exceed the amount available in your account, including any overdraft facility, without first agreeing it with us):</p>
		<ul>
			<li>you may have to repay the Overdraft in full should the position not be corrected (i.e. if you do not bring yourself back within your planned overdraft or back into credit)</li>
			<li>you may be liable for fees as described in your account terms & conditions and tariff</li>
			<li>your credit records may be affected in a way that makes it more difficult or more expensive to obtain further credit</li>
			<li>you may face legal action to recover what you owe</li>
			<li>we may take action to enforce any security we hold</li>
			<li>we may use money you have in any another account(s) with us to pay arrears or anything you owe us on the account</li>
			<li>you may also have to pay us our legal costs.</li>
		</ul>
		<p><strong>Cancellation</strong></p>
		<p>If you change your mind about taking out an Overdraft, you have a legal right to cancel it within 14 days from the day after it is available on your account, or from the day you receive your Overdraft Facility Agreement, whichever is later. If you do want to cancel your Overdraft, you will need to repay any outstanding balance, interest and fees within 30 days of the date you cancel it. In addition to your cancellation right, you can remove your overdraft at any time by repaying any outstanding, balance, interest and fees.</p>
		<p>You can cancel or remove your Overdraft by:</p>
		<ul>
			<li>Writing to your branch</li>
			<li>Contacting your Private Relationship Manager</li>
			<li>Calling us on 0800 678 3654</li>
			<li>Visiting any of our branches</li>
		</ul>
		<p>Please ask us if you have any questions about this key features information or the Overdraft Facility Agreement, or if you require further information or explanation.</p>
		<p>If you do not cancel, the Overdraft will continue until ended by either one of us.</p>
	</div>
);

module.exports = {
	DybCreditKeyFeatures,
	CybCreditKeyFeatures,
	DybOverdraftKeyFeatures,
	CybOverdraftKeyFeatures,
};
