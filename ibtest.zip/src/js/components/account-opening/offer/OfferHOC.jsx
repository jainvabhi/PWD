/**
 * @module OfferHOC
 */

const React = require('react');
const { PropTypes } = React;
const _ = require('lodash');

const ContentUtils = require('../../../utils/ContentUtils');
const ProductUtils = require('../../../utils/ProductUtils');
const HtmlUtils = require('../../../utils/HtmlUtils');
const { DocumentLink, getDocument } = require('../../common/links/DocumentLink');

const savingsAccountRootKey = 'savingsAccountInformation';

const productName = (content, productName) => {
	return content.replace('{productName}', productName);
};

const OfferHOC = WrappedComponent => React.createClass({

	propTypes: {
		appData: PropTypes.object,
		data: PropTypes.shape({
			productOffer: PropTypes.object,
			productCode: PropTypes.string,
			caseId: PropTypes.string,
			bankID: PropTypes.string,
			product: PropTypes.object,
			products: PropTypes.object,
		}),
		validations: PropTypes.object,
		content: PropTypes.object,
		envConfig: PropTypes.object,
		offers: PropTypes.object,
		cms: PropTypes.object,
	},


	/**
	 * Get a JSX element for each document item.
	 * @param  {Array} docItems		Offers array content mapper
	 * @return {Array} Of JSX elements.
	 */
	getDocumentElements(docItems) {
		if (!_.isArray(docItems)) {
			return null;
		}
		let brand;
		return _.chain(docItems)
			.filter(docKey => getDocument(docKey, this.props.envConfig.bankId, this.props.cms))
			.map((key, i) => {
				brand = this.props.envConfig.bankId;
				if (!_.isUndefined(this.props.data.productCode) && this.props.data.productCode === 'IM136' && !_.isUndefined(this.props.offers) && this.props.offers[0].product.code === '800' && key === 'termsAndConditions') {
					brand = 'CYB';
				} else if (!_.isUndefined(this.props.data.productCode) && this.props.data.productCode === 'IM136' && !_.isUndefined(this.props.offers) && this.props.offers[0].product.code === '800' && key === 'currentTariff') {
					brand = this.props.data.bankID;
				}
				return (
					<li
						name={key}
						key={i}
					>
						<DocumentLink
							docKey={key}
							brand={brand}
							{...this.props}
						/>
					</li>

				);
			})
			.value();
	},

	/**
	 * Get a JSX element for each offer item.
	 * @param  {Array} offerItems	Offers array content mapper
	 * @return {Array} Of JSX elements.
	 */
	getOfferElements(offerItems) {
		if (!_.isArray(offerItems)) {
			return null;
		}

		const contentModifiers = _.flow([
			content => { return ContentUtils.replaceWithProductConfigData(content, this.props.data.product);},
		]);

		const offerElements = _.chain(offerItems)
			.map(offerName => {
				return {
					name: offerName,
					content: contentModifiers(this.props.content[offerName]),
				};
			})
			.reject(item => {
				return !item.content;
			})
			.map((item, i) => {
				// @ticket DYB-22764
				return (
					<li
						name={item.name}
						key={i}
						dangerouslySetInnerHTML={{ __html: item.content }}
					/>
				);
			})
			.value();

		const isJoint = data => data.subType === 'JOINT';
		const hasSavingsAccountItems = this.props.data.productOffer && !_.isEmpty(ProductUtils.getSavingAccountItems(this.props.data.productOffer.offers));
		const htmlFactory = (c, k) => <li name={k} key={k} dangerouslySetInnerHTML={{ __html: c }}></li>;

		if (hasSavingsAccountItems) {
			offerElements.push(HtmlUtils.getTextItems(htmlFactory, savingsAccountRootKey, this.props.content));
		}

		if (isJoint(this.props.data)) {
			_.each(this.props.data.product.jointAccountFeatures, key => {
				offerElements.push(htmlFactory(this.props.content[key], key));
			});
		}

		return offerElements;
	},

	getMandateElements(mandateItems) {
		if (!_.isArray(mandateItems)) {
			return null;
		}

		const contentModifiers = _.flow([
			content => { return productName(content, this.props.data.product.name);},
			content => { return ContentUtils.replaceWithProductConfigData(content, this.props.data.product);},
		]);

		return _.flow(
			bullets => _.filter(bullets, item => this.props.content[item]),
			items => _.map(items, item => (<li key={item}>{contentModifiers(this.props.content[item])}</li>))
		)(mandateItems);
	},

	render() {
		return (
			<WrappedComponent
				{...this.props}
				getOfferElements={this.getOfferElements}
				getDocumentElements={this.getDocumentElements}
				getMandateElements={this.getMandateElements}
			/>
		);
	},
});

module.exports = OfferHOC;
