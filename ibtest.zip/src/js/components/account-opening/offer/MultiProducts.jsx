/**
 * @module MultiProducts
 */

const React = require('react');
const { PropTypes } = React;
const _ = require('lodash');

const OfferSummary = require('./OfferSummary');
const SingleProduct = require('./SingleProduct');
const Modal = require('../../common/modals/Modal');

const MultiProducts = React.createClass({

	propTypes: {
		selectedOffer: PropTypes.object,
		offers: PropTypes.array.isRequired,
		onClickMoreInfo: PropTypes.func.isRequired,
		onClickGoBack: PropTypes.func.isRequired,
		appData: PropTypes.object.isRequired,
		content: PropTypes.object.isRequired,
		onClickActionAccount: PropTypes.func.isRequired,
	},

	getInitialState() {
		return {
			isConfirming: false,
			confirmed: false,
		};
	},

	confirmCancel(cancelApplication) {
		this.setState({
			confirmed: cancelApplication,
			isConfirming: false,
		});

		if (cancelApplication) {
			this.props.onClickActionAccount(
				true,
				_.head(this.props.offers).id // @ticket DGW2-984
			);
		}
	},

	askForConfirmation() {
		this.setState({
			isConfirming: true,
		});
	},

	render() {
		return (
			<div>
				{this.state.isConfirming &&
					<Modal title={this.props.content.offerCancelApplicationModalTitle}>
						<div>
							<button
								onClick={() => { this.confirmCancel(false); }}
								className="btn btn-primary"
								data-anchor="confirm-cancel-button"
								role="button"
							>
								{this.props.content.offerCancelApplicationDecline}
							</button>
							<button
								onClick={() => { this.confirmCancel(true); }}
								className="btn btn-primary btn-next"
								data-anchor="confirm-cancel-button"
								role="button"
							>
								{this.props.content.offerCancelApplicationConfirm}
							</button>
						</div>
					</Modal>
				}
				{!this.props.selectedOffer && (
					<div>
					{_.map(this.props.offers, (offer, i) => {
						return (
							<OfferSummary
								key={i}
								offer={offer}
								isLast={i + 1 === this.props.offers.length}
								{...this.props}
							/>
						);
					})}
					</div>
					)
				}
				{!this.props.selectedOffer && (
					<div>
						<hr/>
						<p>{this.props.content.offerCancelIntro}</p>
						<a
							className="btn btn-lg btn-primary btn-next"
							onClick={this.askForConfirmation}
							disabled={this.props.appData.isApiCallInProgress}
						>
							{this.props.content.offerCancelApplicationBtn}
						</a>
					</div>
				)}
				{this.props.selectedOffer && <SingleProduct offer={this.props.selectedOffer} goBack {...this.props} />}
			</div>
		);
	},
});

module.exports = MultiProducts;
