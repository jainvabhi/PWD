/**
 * @module AltProducts
 */

const React = require('react');
const _ = require('lodash');
const { PropTypes } = React;

const OfferDetails = require('./OfferDetails');
const MultiProducts = require('./MultiProducts');
const SingleProduct = require('./SingleProduct');
const ProductUtils = require('../../../utils/ProductUtils');
const OfferHOC = require('./OfferHOC');
const config = require('../../../config');

const { getProductCode } = ProductUtils;

const AltProducts = React.createClass({

	propTypes: {
		data: PropTypes.shape({
			productCode: PropTypes.string.isRequired,
		}),
		content: PropTypes.object.isRequired,
		offers: PropTypes.array.isRequired,
		onClickActionAccount: PropTypes.func.isRequired,
	},

	getInitialState() {
		return {
			selectedOffer: undefined,
		};
	},

	/**
	 * Go back click handler
	 *
	 */
	onClickGoBack() {
		this.updateScrollPosition();
		this.setState({
			selectedOffer: undefined,
		});
	},

	/**
	 * More info click handler
	 *
	 * @param  {Object} product	selected product object
	 */
	onClickMoreInfo(product) {
		this.updateScrollPosition();
		this.setState({
			selectedOffer: product,
		});
	},

	/**
	 * Reset scroll top top of page
	 *
	 */
	updateScrollPosition() {
		window.scrollTo(0, 0);
	},

	render() {
		if (!this.props.offers) {
			return null;
		}

		let singleOffer;
		let product;
		const headerIllustration = 'downgrade-illustration.png';
		let pageTitle = this.props.content.offerPageUnsuccessfulTitle
			&& this.props.content.offerPageUnsuccessfulTitle
			.replace('{productTitle}', ProductUtils.getName(this.props.data.productCode));

		if (this.props.offers.length === 1) {
			singleOffer = _.head(this.props.offers);
			const productCode = getProductCode(singleOffer.product.code);
			if (productCode === config.readyCashCode) {
				product = ProductUtils.getProduct(this.props.data.productCode);
				pageTitle = this.props.content.offerPageDowngradeTitle && this.props.content.offerPageDowngradeTitle
						.replace('{productTitle}', product.name);
			}
		}

		if (this.state.selectedOffer) {
			const productCode = getProductCode(this.state.selectedOffer.product.code);
			product = ProductUtils.getProduct(productCode);
			pageTitle = this.props.content.offerPageTitle &&
				this.props.content.offerPageTitle
					.replace('{productName}', product.name)
					.replace('{productArticle}', product.productArticle);
		}

		return (
			<OfferDetails
				headerIllustration={headerIllustration}
				pageTitle={pageTitle}
				{...this.props}
			>
				{!singleOffer && <MultiProducts
					onClickMoreInfo={this.onClickMoreInfo}
					onClickGoBack={this.onClickGoBack}
					selectedOffer={this.state.selectedOffer}
					{...this.props}
				/>}
				{singleOffer && <SingleProduct offer={singleOffer || this.state.selectedOffer} {...this.props} />}
			</OfferDetails>
		);
	},
});

module.exports = OfferHOC(AltProducts);
