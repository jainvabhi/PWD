/**
 * @module BasicOffer
 */

const React = require('react');
const { PropTypes } = React;

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');

const OfferDetails = require('./OfferDetails');
const ListSection = require('../../common/sections/ListSection');
const MandateSection = require('../review/MandateSection');
const OfferHOC = require('./OfferHOC');
const ProductUtils = require('../../../utils/ProductUtils');
const ValidationUtils = require('../../../utils/ValidationUtils');

const isCashISA = product => product.productType.name === 'cashISA';

const hasDeclarationOnReview = props => {
	const { data: { product } } = props;
	return product.declarationOnReview;
};

const BasicOffer = props => {
	const isValid = ValidationUtils.isGroupValid(props.validations, props.group);
	if (!props.offer) {
		return null;
	}
	const { product } = props.data;
	return (
		<OfferDetails
			{...props}
			headerIllustration="offer-illustration.png"
			pageTitle={props.content.offerPageTitle &&
				props.content.offerPageTitle
				.replace('{productName}', product.name)
				.replace('{productArticle}', product.productArticle)

			}
			subTitle={props.content.offerPageSubTitle}
		>
			<div>
				<ListSection
					wrapperFn={props.getOfferElements}
					items={ProductUtils.getOfferItems(props.data.productCode)}
				/>
				{isCashISA(product) && !hasDeclarationOnReview(props) && <MandateSection
					key="offersMandateSection"
					onReviewAcceptTCs={AccountOpeningActions.updateFormValue}
					acceptTsAndCs={props.data.offerAcceptFullTCs}
					group={props.group}
					termsName="offerAcceptFullTCs"
					termsClassName="terms-and-conditions-checkbox"
					termsCheckboContentKey="csshISAAcceptDecleration"
					termsDataAnchor="offer-accept-full-tcs"
					position="bottom"
					product={{
						...product,
						mandateItems: product.offerMandateItems,
					}}
					title={props.content.cashISAOfferDeclarationTitle}
					subTitle={props.content.cashISAOfferDeclarationSubTitle}
					additionalDeclarationsTitle={props.content.additionalDeclarationsTitle}
					{...props}
				/>}
				<h3>{props.content.mandateTitle}</h3>
				{!isCashISA(product) && <p>{props.content.mandateParagraph}</p>}
				<div className="text-center">
					<button
						className="btn btn-lg btn-primary inline btn-next"
						onClick={() => { props.onClickActionAccount(false, props.offer.id, props.offer.product.code);}}
						data-anchor="accept-next"
						disabled={props.appData.isApiCallInProgress || !isValid}
					>
						{props.content.openAccountButton}
					</button>
				</div>
				{(!isCashISA(product) || product.productImage) && <hr />}
				{!isCashISA(product) && <div className="offer-info text-center">{props.content.offerPageDeclineOffer}</div>}
			</div>
		</OfferDetails>
	);
};

BasicOffer.propTypes = {
	appData: PropTypes.object.isRequired,
	group: PropTypes.string.isRequired,
	data: PropTypes.shape({
		productCode: PropTypes.string,
		offerAcceptFullTCs: PropTypes.bool,
		product: PropTypes.shape({
			name: PropTypes.string,
			productArticle: PropTypes.string,
			offerMandateItems: PropTypes.array,
			legaleseOfferItem: PropTypes.array,
			additionalMandateItems: PropTypes.oneOfType([
				PropTypes.array,
				PropTypes.object,
			]),
			additionalDeclarations: PropTypes.array,
			offerMandateFootNotes: PropTypes.array,
			productImage: PropTypes.string,
		}).isRequired,
	}).isRequired,
	onClickActionAccount: PropTypes.func.isRequired,
	getOfferElements: PropTypes.func.isRequired,
	content: PropTypes.object.isRequired,
	offer: PropTypes.object,
	validations: PropTypes.object,
};

module.exports = OfferHOC(BasicOffer);
