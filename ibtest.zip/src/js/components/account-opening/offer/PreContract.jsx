/**
 * @module PreContract
 */

const React = require('react');
const { PropTypes } = React;
const NewWindowLink = require('../../common/links/NewWindowLink');

const Row = props => {
	return (
		<div className="row">
			<div className="col-md-6">
				<p dangerouslySetInnerHTML={{ __html: props.title }}/>
			</div>

			<div className="col-md-6">
				{props.children}
			</div>
		</div>
	);
};

Row.propTypes = {
	content: PropTypes.object.isRequired,
	title: PropTypes.string.isRequired,
	children: PropTypes.oneOfType([
		PropTypes.object,
		PropTypes.array,
	]),
};

const CybCreditPreContract = props => {
	return (
		<div>
			<h4 className="h2 lead">PRE-CONTRACT CREDIT INFORMATION</h4>
			<p>(Standard European Consumer Credit Information)</p>

			<h5>1. Contact details</h5>

			<Row title="Creditor." {...props}>
				<p>Clydesdale Bank PLC.</p>
			</Row>

			<Row title="Address." {...props}>
				<p>30 St Vincent Place, Glasgow, G1 2HL.</p>
			</Row>

			<hr/>
			<h5>2. Key features of the credit product</h5>
			<Row title="The type of credit." {...props}>
				<p>Credit Card.</p>
			</Row>
			<Row title="The total amount of credit.<br/>This means the amount of credit to be provided under the proposed credit agreement or the credit limit." {...props}>
				<p>We will tell you your credit limit after the agreement has been made. The amount of the credit limit will be determined by our assessment of your financial circumstances and needs.</p>
			</Row>

			<Row title="How and when credit would be provided." {...props}>
				<p>Once you receive your card you can use it (or the card details) to make purchases and obtain cash. You can ask us for balance transfers subject to the terms and conditions of your agreement.</p>
			</Row>

			<Row title="The duration of the credit agreement." {...props}>
				<p>The agreement will have no fixed or minimum duration: it will continue until either you or we choose to end it.</p>
			</Row>

			<Row title="Repayments." {...props}>
				<p>You must make the minimum payment every month. This will be an amount equal to the greater of:</p>
				<ul>
					<li>All interest and default fees added to your account that month together with 1% of the remaining balance on your account, or</li>
					<li>£5 (or the statement balance if less than £5).</li>
				</ul>
			</Row>

			<Row title="Your repayments will pay off what you owe in the following order." {...props}>
				<p>If you do not repay the entire balance on your account we will apply the amount you pay to the outstanding balance starting with those items to which the highest interest rate applies. We will pay off statemented transactions before we pay off more recent transactions.</p>
			</Row>

			<Row title="The total amount you will have to pay.<br/>This means the amount you have borrowed plus interest and other costs." {...props}>
				<p>If you use your card to make a purchase of £1200 and then repay the capital in 12 equal payments, paying off the interest each month the total amount payable would be £1313.33. This assumes that the purchase is made at our purchases rate and that no changes are made to the interest rate during that period.</p>
			</Row>

			<hr/>

			<h5>3. Cost of the credit</h5>
			<Row title="The rates of interest which apply to the credit agreement" {...props}>
				<ul>
					<li><strong>Introductory Purchases Rate</strong> 0% p.a (fixed). This rate applies for a promotional period of 26 months from the date your account is opened and then the purchases rate will apply.</li>

					<li><strong>Introductory Balance Transfer Rate</strong> 0% (fixed) for a promotional period of 12 months from the date your account is opened and then the purchases rate will apply.</li>
					<li><strong>Purchases Rate</strong> 1.453% monthly, 18.9% p.a. (variable).</li>
					<li><strong>Balance Transfer Rate</strong> for balance transfers other than introductory balance transfers is 0.945% monthly, 11.9% p.a (fixed) and this will apply for 6 months from the date the balance is transferred to your account and then the purchases rate will apply.</li>
					<li><strong>Cash Advance Rate</strong> 2.075% monthly, 27.9% p.a (variable). This rate applies to cash advances which includes transfers to other accounts which are not balance transfers, use of the card for gambling, the purchase of foreign currency or travellers cheques and interest and charges on those amounts.</li>
				</ul>

				<p>We add interest to your account on the date of your statement each month and then charge you interest on that interest (“compound interest”) until you have paid it. We will not however charge interest on interest for default charges.</p>
				<p>We will charge you interest on your daily account balance each day on all transactions from the date we add them to your account until repaid. If you repay in full on the date specified on your statement you will not have to pay interest on purchases.</p>
				<p>If you miss a minimum payment or if you exceed your credit limit or if you otherwise break this agreement, we may switch anything on an introductory rate or promotional rate to the rate which generally applies to that type of transaction before the end of the introductory or promotional period.</p>
				<p>We may change any interest rate unless it is a fixed rate. We may change our interest rates to reflect changes in the costs we incur, or because of a change in regulatory requirements or for any other valid reason. We will tell you at least 30 days before making the change, although we may make the change more quickly if it is to your advantage.</p>
				<p>All the interest rates shown are the effective annual rates. This means that we have shown the effect of compounding these rates.</p>
			</Row>

			<Row title="Annual Percentage Rate of Charge (APR).<br/>This is the total cost expressed as an annual percentage of the total amount of credit.<br/>The APR is there to help you compare different offers." {...props}>
				<p><strong>18.9%</strong> (variable) calculated on the basis set out in the section above entitled “The total amount you willhave to pay”. If this was calculated on a non-purchase rate it may result in a higher APR.</p>
			</Row>

			<Row title="Related costs<br/>Any other costs deriving from the credit agreement." {...props}>
				<ul>
					<li>For cash advances a Cash Fee of 3% of the amount (subject to a minimum of £3). We will also treat as cash advances, transfers to another account which are not balance transfers or if you buy foreign currency or travellers cheques or if you use your card for gambling. For foreign cash advances this Cash. Fee will be charged in addition to the Non-Sterling Transaction Fee.</li>
					<li>For foreign transactions a Non-Sterling Transaction Fee of 2.95% of the amount converted into sterling.</li>
					<li>For balance transfers a transfer fee of 3% of the amount (subject to a minimum of £3).</li>
					<li>£12 if you exceed your credit limit at any time.</li>
					<li>£5 for copy transactions, receipts and statements.</li>
					<li>Any other reasonable losses and costs we incur as a result of you breaking the agreement.</li>
				</ul>
			</Row>

			<Row title="Conditions under which the above charges can be changed." {...props}>
				<p>We may change or add to our charges for any reason if we tell you at least 30 days before making the change, although we may make the change more quickly if it is to your advantage.</p>
			</Row>

			<Row title="Costs in the case of late payments." {...props}>
				<p>You will have to pay a fee of £12 if you do not make at least the minimum payment by the payment due date.We will continue charging you interest at the applicable rate on the overdue amount.</p>
			</Row>

			<Row title="Consequences of missing payments." {...props}>
				<p>If you miss your minimum payments, please note that, as well as having to pay us the above charges, you may lose any introductory or promotional rates. We may use money in your other Clydesdale or Yorkshire Bank accounts to pay us and your credit records may be affected so that you find it harder and more
expensive to borrow again from us or another lender. Occasionally if you are a homeowner we may take legal action which means if your home is repossessed or you decide to sell your house any amounts you owe us will be paid out of the sale of the proceeds.</p>
			</Row>
			<hr/>

			<h5>4. Other important legal aspects</h5>
			<Row title="Right of withdrawal." {...props}>
				<p>You have the right to withdraw from the credit agreement within a period of 14 days starting with the day after the day on which the agreement is made.</p>
			</Row>

			<Row title="Early repayment." {...props}>
				<p>You have the right to repay the credit facility early at any time in full or partially.</p>
			</Row>

			<Row title="Consultation with a Credit Reference Agency." {...props}>
				<p>We must inform you immediately and without charge if we reject your application on the basis of information we receive about you from a credit reference agency. We will give you the details of the Credit Reference Agency consulted.</p>
			</Row>

			<Row title="Right to a draft credit agreement." {...props}>
				<p>You have the right, upon request, to a copy of the draft credit agreement free of charge unless we no longer wish to proceed with your application at the time of your request.</p>
			</Row>

			<Row title="The period of time during which the creditor is bound by the pre-contractual information." {...props}>
				<p>This information is valid on the day it has been provided to you.</p>
			</Row>

			<hr/>

			<h5>5. Additional information in the case of distance marketing of financial services</h5>

			<p>(a) concerning the creditor</p>

			<Row title="Registration Number." {...props}>
				<p>Clydesdale Bank PLC is registered in Scotland with Company Number SC001111. We are regulated by the Financial Conduct Authority. Our Firm Reference number is 121873.</p>
			</Row>

			<Row title="The supervisory authority." {...props}>
				<p>The Financial Conduct Authority, 25 The North Colonnade, Canary Wharf, London, E14 5HS.</p>
			</Row>

			<p>(b) concerning the credit agreement</p>

			<Row title="The law taken by the creditor as a basis for the establishment of relations with you before the conclusion of the credit agreement." {...props}>
				<p>If your address is in Scotland, Scots Law will apply. If your address is elsewhere, English Law will apply.</p>
			</Row>

			<Row title="The law applicable to the credit agreement and/or the competent court." {...props}>
				<p>If your address is in Scotland when you take out this agreement, Scots Law will apply. If your address is elsewhere, English Law will apply.</p>
			</Row>

			<Row title="Language to be used in connection with the credit agreement." {...props}>
				<p>We will only communicate with you in English.</p>
			</Row>

			<p>(c) concerning redress</p>

			<Row title="Access to out-of-court complaint and redress mechanism." {...props}>
				<p>If you ever have cause for complaint, please contact our Customer Services team. We will deal with your complaint promptly and a full investigation will be carried out. If after all our efforts your complaint is not resolved you can approach the Financial Ombudsman Service who will act as an independent arbiter.<br/>
				To get to this stage you will need a final response letter stating that we are unable to progress your complaint any further. Once the Financial Ombudsman Service has checked and accepted that the deadlock has been agreed, and your complaint dealt with, a totally impartial investigation will take place. If you need to take a complaint to the Financial Ombudsman Service you can contact them at The Financial Ombudsman Service, Exchange Tower, Harbour Exchange Square, London E14 9GE, telephone 0800 023 4567, www.financial-ombudsman.org.uk</p>
			</Row>


		</div>
	);
};

CybCreditPreContract.propTypes = {
	content: PropTypes.object.isRequired,
};

const DybCreditPreContract = props => {
	return (
		<div>
			<h4 className="h2 lead">PRE-CONTRACT CREDIT INFORMATION</h4>
			<p>(Standard European Consumer Credit Information)</p>

			<h5>1. Contact details</h5>

			<Row title="Creditor Address." {...props}>
				<p>Clydesdale Bank PLC.</p>
				<p>30 St Vincent Place, Glasgow, G1 2HL.</p>
			</Row>

			<hr/>
			<h5>2. Key features of the credit product</h5>
			<Row title="The type of credit." {...props}>
				<p>Credit Card.</p>
			</Row>
			<Row title="The total amount of credit.<br/>This means the amount of credit to be provided under the proposed credit agreement or the credit limit." {...props}>
				<p>We will tell you your credit limit after the agreement has been made.</p>
			</Row>

			<Row title="How and when credit would be provided." {...props}>
				<p>Once you receive your card you can use it (or the card details) to make purchases and obtain cash, and you can ask us for balance transfers subject to the terms and conditions of your agreement.</p>
			</Row>

			<Row title="The duration of the credit agreement." {...props}>
				<p>The agreement will have no fixed or minimum duration: it will continue until either you or we choose to end it.</p>
			</Row>

			<Row title="Repayments." {...props}>
				<p>You must make the minimum payment every month. This will be an amount equal to the greater of:</p>
				<ul>
					<li>All interest and default fees added to your account that month together with 1% of the remaining balance on your account, or </li>
					<li>£5 (or the statement balance if less than £5).</li>
				</ul>
			</Row>

			<Row title="Your repayments will pay off what you owe in the following order:" {...props}>
				<p>If you do not repay the entire balance on your account we will apply the amount you pay to the outstanding balance starting with those items to which the highest interest rate applies. We will pay off statemented transactions before we pay off more recent transactions.</p>
			</Row>

			<Row title="The total amount you will have to pay.<br/>This means the amount you have borrowed plus interest and other costs." {...props}>
				<p>If you use your card to make a purchase of £1200 and then repay the capital in 12 equal payments, paying off the interest each month the total amount payable would be £1262.52. This assumes that the purchase is made at our Purchase Rate and that no changes are made to the interest rate during that period.</p>
			</Row>

			<hr/>

			<h5>3. Cost of the credit</h5>
			<Row title="The rates of interest which apply to the credit agreement" {...props}>
				<ul>
					<li>Purchase Rate 0.790% monthly, 9.9% per annum (variable).</li>
					<li>Balance Transfer Rate 0.790% monthly, 9.9% per annum (variable).</li>
					<li>Cash Advance Rate 2.075% monthly, 27.9% per annum (variable). <br/>This rate applies to cash advances which includes transfers to other accounts which are not balance transfers, use of the card for gambling, the purchase of foreign currency or travellers cheques and interest and charges on those amounts. </li>
				</ul>

				<p>We add interest to your account on the date of your statement each month and then charge you interest on that interest (“compound interest”) until you have paid it. We will not however charge interest on interest for default charges.</p>

				<p>We will charge you interest on your daily account balance each day on all transactions from the date we add them to your account until repaid. If you repay in full on the date specified on your statement you will not have to pay interest on purchases.</p>

				<p>If you miss a minimum payment or if you exceed your credit limit or if you otherwise break this agreement, we may switch anything on a promotional rate to the rate which generally applies to that type of transaction before the end of the promotional period.</p>

				<p>We may change any interest rate unless it is a fixed rate. We may change our interest rates to reflect changes in the costs we incur, or because of a change in regulatory requirements or for any other valid reason. We will tell you at least 30 days before making the change, although we may make the change more quickly if it is to your advantage.</p>

				<p>All the interest rates shown are the effective annual rates. This means that we have shown the effect of compounding these rates.</p>
			</Row>

			<Row title="Annual Percentage Rate of Charge (APR). <br/>This is the total cost expressed as an annual percentage of the total amount of credit. The APR is there to help you compare different offers." {...props}>
				<p><strong>9.9%</strong> (variable) calculated on the basis set out in the section above entitled “The total amount you will have to pay”. If this was calculated using a non-purchase rate it may result in a higher APR.</p>
			</Row>

			<Row title="Related costs<br/>Any other costs deriving from the credit agreement." {...props}>
				<ul>
					<li>For cash advances a Cash Fee of 3% of the amount (subject to a minimum of £3). We will also treat as cash advances, transfers to another account which are not balance transfers or if you buy foreign currency or travellers cheques or if you use your card for gambling. For foreign cash advances this Cash Fee will be charged in addition to the Non-Sterling Transaction Fee.</li>
					<li>For foreign transactions a Non-Sterling Transaction Fee of 0.00% of the amount converted into sterling. </li>
					<li>For balance transfers a transfer fee of 0.00% of the amount. </li>
					<li>£12 if you exceed your credit limit at any time. </li>
					<li>£5 for copy transactions, receipts and statements. </li>
					<li>Any other reasonable losses and costs we incur as a result of you breaking the agreement.</li>
				</ul>
			</Row>

			<Row title="Conditions under which the above charges can be changed." {...props}>
				<p>We may change or add to our charges for any reason if we tell you at least 30 days before making the change, although we may make the change more quickly if it is to your advantage.</p>
			</Row>

			<Row title="Costs in the case of late payments." {...props}>
				<p>You will have to pay a fee of £12 if you do not make at least the minimum payment by the payment due date.
				<br/>We will continue charging you interest at the applicable rate on the overdue amount.</p>
			</Row>

			<Row title="Consequences of missing payments." {...props}>
				<p>If you miss your minimum payments, please note that, as well as having to pay us the above charges, you may lose any promotional rates. We may use money in your other Clydesdale Bank PLC accounts to pay us and your credit records may be affected so that you find it harder and more expensive to borrow again from us or another lender. Occasionally if you are a homeowner we may take legal action which means if your home is repossessed or you decide to sell your house any amounts you owe us will be paid out of the sale of the proceeds.</p>
			</Row>
			<hr/>

			<h5>4. Other important legal aspects</h5>
			<Row title="Right of withdrawal." {...props}>
				<p>You have the right to withdraw from the credit agreement within a period of 14 days starting with the day after the day on which the agreement is made.</p>
			</Row>

			<Row title="Early repayment." {...props}>
				<p>You have the right to repay the credit facility early at any time in full or partially.</p>
			</Row>

			<Row title="Consultation with a Credit Reference Agency." {...props}>
				<p>We must inform you immediately and without charge if we reject your application on the basis of information we receive about you from a credit reference agency. We will give you the details of the Credit Reference Agency consulted.</p>
			</Row>

			<Row title="Right to a draft credit agreement." {...props}>
				<p>You have the right, upon request, to a copy of the draft credit agreement free of charge unless we no longer wish to proceed with your application at the time of your request.</p>
			</Row>

			<Row title="The period of time during which the creditor is bound by the pre-contractual information." {...props}>
				<p>This information is valid on the day it has been provided to you.</p>
			</Row>

			<hr/>

			<h5>5. Additional information in the case of distance marketing of financial services</h5>

			<p>(a) concerning the creditor</p>

			<Row title="Registration Number." {...props}>
				<p>Clydesdale Bank PLC is registered in Scotland with Company Number SC001111.
				<br/>We are regulated by the Financial Conduct Authority. Our Financial Services Register number is 121873. </p>
			</Row>

			<Row title="The supervisory authority." {...props}>
				<p>The Financial Conduct Authority, 25 The North Colonnade, Canary Wharf, London, E14 5HS.</p>
			</Row>

			<p>(b) concerning the credit agreement</p>

			<Row title="The law taken by the creditor as a basis for the establishment of relations with you before the conclusion of the credit agreement." {...props}>
				<p>If your address is in Scotland, Scots Law will apply. If your address is elsewhere, English Law will apply.</p>
			</Row>

			<Row title="The law applicable to the credit agreement and/or the competent court." {...props}>
				<p>If your address is in Scotland when you take out this agreement, Scots Law will apply. If your address is elsewhere, English Law will apply.</p>
			</Row>

			<Row title="Language to be used in connection with the credit agreement." {...props}>
				<p>We will only communicate with you in English.</p>
			</Row>

			<p>(c) concerning redress</p>

			<Row title="Access to out-of-court complaint and redress mechanism." {...props}>
				<p>
					We are committed to providing our customers with the best possible service. However, if you are not happy with any product or service you have received from us, we would like the chance to put it right. Our internal complaint handling procedures are in place to deal with your concerns when things go wrong. There is no charge for raising a complaint.  You can contact your local branch or Relationship Manager in person, by writing or by phone. You can also get in touch with our central complaints team whose up to date details can be found on our website or in our complaints handling leaflet which is available on request in our branches.  If you are not satisfied with our response to your complaint, you can refer the matter to the Financial Ombudsman Service. The Financial Ombudsman Service is an independent organisation, which helps to resolve complaints that customers and financial institutions haven’t been able to resolve themselves.  Further details can be found on the Financial Ombudsman Service website: <NewWindowLink
						href={'http://www.financial-ombudsman.org.uk'}
						title="Financial Ombudsman Service website. This link will open in a new browser window"
						text={'www.financial-ombudsman.org.uk'}
						{...props}
					/>
				</p>
			</Row>


		</div>
	);
};

DybCreditPreContract.propTypes = {
	content: PropTypes.object.isRequired,
};


module.exports = {
	DybCreditPreContract,
	CybCreditPreContract,
};
