/**
 * @module PageValidator
 */

const React = require('react');
const { PropTypes } = React;
const _ = require('lodash');

const AccountOpeningActions = require('../../actions/AccountOpeningActions');
const AnalyticsActions = require('../../actions/AnalyticsActionCreator');
const ValidationUtils = require('../../utils/ValidationUtils');

const isCreditCard = props => props.data.product.productType.name === 'credit-card';

const PageValidator = WrappedComponent => React.createClass({

	propTypes: {
		validations: PropTypes.object,
		data: PropTypes.object,
		bankDetails: PropTypes.object,
	},

	componentWillReceiveProps(nextProps) {
		if (!_.isEqual(this.props.data, nextProps.data)) {
			this.setState({
				invalidOnSubmit: false,
			});
		}
	},

	updateGroupValidations(group) {
		const validations = this.props.validations[group];
		const invalidFields = {};

		_.keys(validations).forEach(key => {
			!validations[key].isEnabled && AccountOpeningActions.enableValidation(group, key);
			!validations[key].isValid && (invalidFields[`${key}Question`] = true) && AccountOpeningActions.updateValidation(group, key, false);
		});
		let isValid = ValidationUtils.isGroupValid(this.props.validations, group);

		if (isCreditCard(this.props)) {
			const bankDetails = this.props.bankDetails;
			const inValidBanks = _.filter(bankDetails, value => value && value.inValid).length;

			isValid = isValid && !inValidBanks;
		}

		this.setState({
			invalidOnSubmit: !isValid,
			submitButtonClick: true,
		});

		if (!isValid) {
			AnalyticsActions.recordError({
				message: _.keys(invalidFields),
				type: 'validation',
			});
		}

		return isValid;
	},

	render() {
		return (
			<WrappedComponent
				updateGroupValidations={this.updateGroupValidations}
				{...this.props}
				{...this.state}
			/>
		);
	},
});

module.exports = PageValidator;
