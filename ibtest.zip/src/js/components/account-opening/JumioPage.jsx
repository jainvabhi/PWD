/**
 * @module JumioPage
 */

const React = require('react');
const { PropTypes } = React;
const Helmet = require('react-helmet');

const AppLinks = require('../common/links/AppLinks');
const PageHeader = require('../common/PageHeader');
const ResultSection = require('../common/sections/ResultSection');
const PageColumnWrapper = require('../common/PageColumnWrapper');
const SectionCentered = require('../common/SectionCentered');
const CopyToClipBoard = require('../common/links/CopyToClipboard');

const times = ['MonToFri', 'Sat', 'Sun'];

const TimeTableRow = ({ days, openingHours }) => (<tr>
	<td className="time-table-cell__label">{ days }</td>
	<td className="time-table-cell__value"><strong>{ openingHours }</strong></td>
</tr>);

TimeTableRow.propTypes = {
	days: PropTypes.string,
	openingHours: PropTypes.string,
};

const FloatingHeader = ({ heading }) => (
	<div className="col-xs-12">
		<div className="row floating-page-header">
			<div className="col-xs-11 col-lg-6 col-lg-offset-3">
				<ResultSection title={ heading } />
			</div>
		</div>
	</div>
);

FloatingHeader.propTypes = {
	heading: PropTypes.string,
};

const JumioPage = React.createClass({
	propTypes: {
		data: PropTypes.object,
		validations: PropTypes.object,
		content: PropTypes.object,
	},
	render() {
		const refCode = this.props.data.caseId;
		return (
			<div className="account-opening jumio-page container-fluid">
				<Helmet title={ this.props.content.jumioPageHeader } />
				<PageHeader title={ this.props.content.jumioPageTitle } content={this.props.content} />
				<div className="row main-container">
					<FloatingHeader heading={ this.props.content.jumioPageFloatingHeader } />
					<PageColumnWrapper content={ this.props.content }>
						<h2>{ this.props.content.jumioPageTitle }</h2>
						<SectionCentered centredColumnSize={12}>
							<p dangerouslySetInnerHTML={{ __html: this.props.content.jumioPageDescription }} />
							<p className="reference reference__title">{ this.props.content.jumioPageReferenceNumber }</p>
							<h3 className="reference reference__code">{ refCode }</h3>
							<CopyToClipBoard stringToCopy={ refCode } />
							<h3 dangerouslySetInnerHTML={{ __html: this.props.content.jumioPageDownload }} />
							<AppLinks appName="jumioPhoneApp" feature="app-links" {...this.props} />
							<p>{ this.props.content.jumioPageNoBiDDescription }</p>
							<p dangerouslySetInnerHTML={{ __html: this.props.content.jumioPageNoBiDphone }} />
							<table className="time-table">
								<tbody>
									{ times.map((time, key) => (
										<TimeTableRow
											key={ key }
											days={ this.props.content[`jumioPagePhone${time}`] }
											openingHours={ this.props.content[`jumioPagePhone${time}Time`] }
										/>
									))}
								</tbody>
							</table>
						</SectionCentered>
					</PageColumnWrapper>
				</div>
			</div>
		);
	},
});

module.exports = JumioPage;
