/**
 * @module ReviewPage
 */

const _ = require('lodash');
const React = require('react');
const { PropTypes } = React;
const Helmet = require('react-helmet');
const moment = require('moment');

const config = require('../../config');
const envConfig = require('../../../static/config');

const AccountOpeningActions = require('../../actions/AccountOpeningActions');
const PageSessionActions = require('../../actions/PageSessionActions');
const AnalyticsActionCreator = require('../../actions/AnalyticsActionCreator');
const SessionActionCreator = require('../../actions/SessionActionCreator');
const AccountOpeningConstants = require('../../constants/AccountOpeningConstants');

const PageColumnWrapper = require('../common/PageColumnWrapper');
const SideBarColumnWrapper = require('../common/SideBarColumnWrapper');
const BottomNavigationBox = require('../common/BottomNavigationBox');
const PageHeader = require('../common/PageHeader');
const NewWindowLink = require('../common/links/NewWindowLink');
const FormRow = require('../common/FormRow');
const ErrorMessage = require('../common/ErrorMessage');

const ArrayUtils = require('../../utils/ArrayUtils');
const ScreenshotUtils = require('../../utils/ScreenshotUtils');
const MaskingUtils = require('../../utils/MaskingUtils');
const ContentUtils = require('../../utils/ContentUtils');
const BrandUtils = require('../../utils/BrandUtils');
const EncryptionUtils = require('../../utils/EncryptionUtils');
const CredentialsActions = require('../../actions/CredentialsActions');

const ReviewSection = require('./review/ReviewSection');
const ImportantInfoSection = require('./review/ImportantInfoSection');
const DeclarationAndAuth = require('./review/DeclarationAndAuthSection');

const PersonalDetailsFoundError = require('./findDetails/PersonalDetailsFoundError');
const CurrentAccountReviewSection = require('./review/CurrentAccountReviewSection');
const SavingsAccountReviewSection = require('./review/SavingsAccountReviewSection');
const CashISAReviewSection = require('./review/CashISAReviewSection');
const CreditCardAccountReviewSection = require('./review/CreditCardAccountReviewSection');
const BondAccountReviewSection = require('./review/BondAccountReviewSection');

const PageValidator = require('./PageValidator');

const accountToUiMap = {
	'current': CurrentAccountReviewSection,
	'savings': SavingsAccountReviewSection,
	'cashISA': CashISAReviewSection,
	'credit-card': CreditCardAccountReviewSection,
	'bond': BondAccountReviewSection,
};

const showFurtherProductInfo = props => {
	return props.data.product.productType.name !== 'credit-card';
};

const ReviewPage = React.createClass({
	propTypes: {
		appData: PropTypes.object.isRequired,
		data: PropTypes.object.isRequired,
		content: PropTypes.object.isRequired,
		validations: PropTypes.object.isRequired,
		updateGroupValidations: PropTypes.func,
		invalidOnSubmit: PropTypes.bool,
		session: PropTypes.object,
	},

	getInitialState() {
		return {
			isDeclarationOpen: false,
		};
	},

	componentWillMount() {
		if (this.props.session && this.props.session.accessToken && this.props.data.bankID) {
			this.setState({
				isLoadingCredentials: true,
			}, CredentialsActions.getCredentials);
		}
	},

	/**
	 * Track that user has visited Review page. Future edits to earlier pages should then
	 * revert the user straight back to Review.
	 */
	componentDidMount() {
		AccountOpeningActions.updateFormValue('isReviewing', true);

		// Record an analytics user event.
		AnalyticsActionCreator.track({
			path: '/user/experience/view',
			action: 'Appeared',
		}, {
			description: 'PageLoaded',
		});
	},

	/**
	 * Triggered each time contact prefs are updated.
	 *
	 * @param  {String} name  Which pref was changed?
	 * @param  {String} value Is it checked or not?
	 */
	onContactMethodsChange(name, value) {
		AnalyticsActionCreator.track({
			path: '/user/experience/activity',
			action: 'Interacted',
		}, {
			value,
			description: 'ContactMethodsSelected',
			event: (this.props.data[name] ? 'updated' : 'created'),
		});
		AccountOpeningActions.updateFormValue(name, value);
	},

	/**
	 * User has clicked an "Edit" link. Take them to the right part of that section.
	 *
	 * @param  {Event} e 		Click event.
	 */
	onEditLinkClick(e) {
		e.preventDefault();
		AccountOpeningActions.navigateToWebTask(e.target.dataset.taskId);
	},

	/** onClick handler for productTermsPDF. Record an analytics event. */
	onProductTermsPDFClick() {
		AnalyticsActionCreator.track({
			path: '/user/experience/activity',
			action: 'Interacted',
		}, {
			description: 'DownloadProductTermsPDF',
			event: 'click',
		});
	},

	onReviewAcceptTCs(name, value) {
		if (name === 'reviewAcceptTsAndCs') {
			AnalyticsActionCreator.track({
				path: '/user/experience/activity',
				action: 'Interacted',
			}, {
				value,
				description: 'ReviewAcceptTCs',
				event: 'click',
			});
		}
		AccountOpeningActions.updateFormValue(name, value);
	},

	onSubmitPage(e) {
		// Don't go anywhere until we've taken a screen shot.
		e.preventDefault();

		if (BrandUtils.isAbleToDisplay('defer-validation') && !this.props.updateGroupValidations(AccountOpeningConstants.GROUP_REVIEW)) {
			return;
		}

		// User has now seen updated legal docs.
		this.updateDocumentAuditInfo();

		this.setState({
			isDeclarationOpen: true,
		}, () => {
			SessionActionCreator.requestPublicKey((publicKey, publicKeyDateTime) => {
				this.updateEncryptedPassword(publicKey, publicKeyDateTime);
				AccountOpeningActions.sendFormData(true, () => {
					PageSessionActions.setPageSession({
						persisted: true,
					});
					ScreenshotUtils.takeScreenshot(() => {
						AccountOpeningActions.recordTaskComplete('WEB-REVIEW-DETAILS');
						AccountOpeningActions.navigateToWebTask('WEB-SUBMIT-FORM');
						// Now carry on
						AnalyticsActionCreator.track({
							path: '/user/experience/activity',
							action: 'Interacted',
						}, {
							description: 'ApplicationSubmit',
							event: 'click',
						});
						if (!this.props.session.authenticated) {
							setTimeout(() => {
								SessionActionCreator.logUserIn(this.props.data.username, this.props.data.password1);
							}, envConfig.autoLoginTimeout);
						}
					}, this.props.data.caseId, undefined, false, envConfig.standardApiDelay);
				});
			});
		});
	},

	/**
	 * Handles interaction with collapsable declaration section
	 *
	 */
	onDeclarationToggle() {
		this.setState({
			isDeclarationOpen: !this.state.isDeclarationOpen,
		});
	},

	/**
	 * Build a repeatable review section
	 *
	 * @param  {Object} data 	Specifics to put into this section.
	 * @return {JSX}
	 */
	getReviewSection(data) {
		return (
				<ReviewSection
					onEditLinkClick={this.onEditLinkClick}
					data={data}
				/>
		);
	},

	/**
	 * Return a string containing the Tax Obligations
	 *
	 * @param  {String} noObligations	'Yes' if there are no Tax Obligations to be listed.
	 * @param  {Array}  list 			the Tax Obligation JSON items
	 * @return {String} 				Either comma seperated Tax Obligations or 'No'.
	 */
	getTaxObligations(noObligations, list) {
		if (noObligations === 'Yes') {
			return 'No';
		}

		return ArrayUtils.getCommaString(_.map(list, item => `${item.taxCountry} ${(item.taxNumber) ? `(${item.taxNumber})` : ''}`));
	},


	/**
	 * Formats telephone number, based on if the the user is an existing customer.
	 * Number is masked for an existing user
	 *
	 * @param {String} phoneNumber Phone number to be formatted
	 *
	 * @returns {String} Masked telephone number if customer is exisitng, unmasked otherwise
	 *
	 */
	formatPhoneNumber(phoneNumber) {
		if (this.props.data.isExistingCustomer !== 'Yes') {
			return phoneNumber;
		}

		const mask = config.masks.phoneNumber;

		return MaskingUtils.applyMask(phoneNumber, mask.startPosition, mask.numberOfMasks);
	},

	isSubmitDisabled() {
		return this.props.appData.isApiCallInProgress || this.props.data.personalDetailsFound;
	},

	/**
	 * Stores the current version of each legal document, along with the current time.
	 */
	updateDocumentAuditInfo() {
		const productDocs = this.props.data.product.additionalDocumentItems;

		const timestamp = moment().format();

		const data = _.map(productDocs, docName => {
			return {
				key: docName,
				value: {
					version: this.props.content[`${docName}DocVersion`],
					consent: 'Y',
					timestamp,
				},
			};
		});

		AccountOpeningActions.updateFormValues(data);
	},

	updateEncryptedPassword(publicKey, datetime) {
		const formattedPassword = `${datetime}:${this.props.data.password1}`;
		const encPassword = EncryptionUtils.encrypt(publicKey, formattedPassword);
		AccountOpeningActions.updateFormValue('encryptedPassword', encPassword);
	},

	render() {
		const productData = this.props.data.product;
		const productName = this.props.data.product.name;
		const type = productData.productType ? productData.productType.name : '';
		const productTypeName = productData.amlQuestionSet && productData.amlQuestionSet !== 'default' ? productData.amlQuestionSet : type;
		const applyingFor = this.props.data.product.productLink && (
			<NewWindowLink
				href={this.props.data.product.productLinkOverride ? this.props.data.product.productLinkOverride : this.props.content[this.props.data.product.productLink]}
				title="Product Link. This link will open in a new browser window"
				text={productName}
				{...this.props}
			/>
		);

		const AccountTypeReview = accountToUiMap[productTypeName] || (() => (<noscript />));

		return (
			<div className="account-opening review-page container-fluid">
				<Helmet title={this.props.content.reviewPageHeader} />
				<PageHeader title={this.props.content.reviewPageTitle} content={this.props.content} />

				<div className="row main-container">
					<PageColumnWrapper step={3} content={this.props.content}>
					{/* Personal Details section */}
					<div className="paper margin-bottom">

						<PersonalDetailsFoundError
							content={this.props.content}
							data={this.props.data}
						/>

						<div className="review-top-section">
							<h1 className="icon-header product-details h2-style">{this.props.content.reviewTopTitle}</h1>
							<p className="h3-style">{this.props.content.reviewTopSubtitle}</p>
							<p>You are applying for a {applyingFor}</p>
							<p>{ContentUtils.getProductContent('reviewTopParagraph', this.props.content, this.props.data.productCode)}</p>
							{ContentUtils.getProductContent('reviewTopTermsParagraph', this.props.content, this.props.data.productCode) &&
								<p>{ContentUtils.getProductContent('reviewTopTermsParagraph', this.props.content, this.props.data.productCode)}</p>
							}
						</div>

						<AccountTypeReview
							getTaxObligations={this.getTaxObligations}
							formatPhoneNumber={this.formatPhoneNumber}
							onEditLinkClick={this.onEditLinkClick}
							group={AccountOpeningConstants.GROUP_REVIEW}
							onContactMethodsChange={this.onContactMethodsChange}
							onChange={AccountOpeningActions.updateFormValue}
							{...this.props}
						/>
					</div>
					<div className="review-product-summary white-board review-remove-keyline">
						{showFurtherProductInfo(this.props) &&
							<div className="review-section">
								<ImportantInfoSection
									applyingFor={applyingFor}
									onReviewAcceptTCs={this.onReviewAcceptTCs}
									onProductTermsPDFClick={this.onProductTermsPDFClick}
									group={AccountOpeningConstants.GROUP_REVIEW}
									onDeclarationToggle={this.onDeclarationToggle}
									isDeclarationOpen={this.state.isDeclarationOpen}
									{...this.props}
								/>
							</div>}

						<DeclarationAndAuth
							group={AccountOpeningConstants.GROUP_REVIEW}
							onChange={AccountOpeningActions.updateFormValue}
							name="declarationAccept"
							{...this.props}
						/>

						{this.props.invalidOnSubmit && <FormRow extraClasses="ja-existing-customer-error"><ErrorMessage text="Some of your details haven't been completed or have been entered incorrectly. Please complete all required fields and correct any errors before you continue." /></FormRow>}

						<BottomNavigationBox
							onClickNext={this.onSubmitPage}
							disabled={this.isSubmitDisabled()}
							nextButtonLabel="Submit"
							backTaskId="WEB-EMPLOYMENT-DETAILS"
							dataAnchorNext={'complete-application'}
						/>
					</div>
					</PageColumnWrapper>

					<SideBarColumnWrapper
						appData={this.props.appData}
						content={this.props.content}
						data={this.props.data}
					/>
				</div>
			</div>
		);
	},
});

module.exports = PageValidator(ReviewPage);
