/**
 * @module MultiCardDeferredPage
 */

const React = require('react');
const _ = require('lodash');
const { PropTypes } = React;
const Helmet = require('react-helmet');

// Components
const ResultSection = require('../common/sections/ResultSection');
const PageHeader = require('../common/PageHeader');

// Utils
const BrandUtils = require('../../utils/BrandUtils');
const ContentUtils = require('../../utils/ContentUtils');

const MultiCardDeferredPage = React.createClass({
	propTypes: {
		data: PropTypes.object,
		content: PropTypes.object,

	},

	render() {
		const listItems = _.map(ContentUtils.getContent('multiCardDeferredPageListItem', this.props.content), i => i && <li key={i}>{i}</li>);

		return (
			<div className="account-opening result-page-wrapper deferred-page-wrapper container-fluid">
				<Helmet title={this.props.content.deferredPageHeader} />
				<PageHeader visible={BrandUtils.isAbleToDisplay('result-pages-header')}
							title={`${this.props.content.landingPageTitle}${this.props.data.product.name}${this.props.data.product.nameSuffix}`}
							content={this.props.content}
				/>
				<div className="result-page multi-carddeferred-page" role="main">
					<div className="row text-center">
						<div className="col-xs-12">
							<ResultSection
								imgSrc={BrandUtils.getResultImage('deferred-page-with-image', 'time-illustration.png')}
								imgAlt="Deferred Result"
								title={this.props.content.multiCardDeferredPageTitle}
							/>
							<div className="white-board">
								<p>{this.props.content.multiCardDeferredPageIntro}</p>

								<p>{this.props.content.multiCardDeferredPageListIntro}</p>
								{listItems.length ? <ul className="list-unstyled">{listItems} </ul> : null}
							</div>
						</div>
					</div>
				</div>
			</div>
		);
	},
});

module.exports = MultiCardDeferredPage;
