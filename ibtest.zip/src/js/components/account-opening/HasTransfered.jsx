/**
 * @module HasTransfered
 */

const React = require('react');
const { PropTypes } = React;
const { locationShape } = require('react-router/lib/PropTypes');
const _ = require('lodash');
const Helmet = require('react-helmet');

const AccountOpeningActions = require('../../actions/AccountOpeningActions');
const SessionServerActionCreator = require('../../actions/SessionServerActionCreator');

const ResultSection = require('../common/sections/ResultSection');
const PageHeader = require('../common/PageHeader');
const LoadingSpinner = require('../LoadingSpinner');

const BrandUtils = require('../../utils/BrandUtils');
const ProductUtils = require('../../utils/ProductUtils');

const transition = _.once(props => {
	const taskKey = props.data.isExistingCustomer === 'Yes' ? 'existing' : 'ntb';
	AccountOpeningActions.navigateToWebTask(props.data.product.postTransferTask[taskKey]);
});

function parseHashValues(hash) {
	return _.chain(hash.slice(1).split('&'))
		.map(item => item && item.split('='))
		.compact()
		.fromPairs()
		.value();
}

const HasTransfered = React.createClass({

	propTypes: {
		data: PropTypes.object.isRequired,
		content: PropTypes.object.isRequired,
		location: locationShape,
	},

	componentWillMount() {
		AccountOpeningActions.updateFormValue('hasTransfered', true);
		AccountOpeningActions.setBankId(this.props.location.query.bankId);

		if (this.props.location.hash) {
			const { case_id, id_token } = parseHashValues(this.props.location.hash);

			AccountOpeningActions.updateFormValue('caseId', case_id);
			SessionServerActionCreator.setAccessToken({
				scope: 30,
				access_token: id_token,
			});
		}
	},

	componentWillReceiveProps(nextProps) {
		if (nextProps.session && nextProps.session.accessToken) {
			transition(nextProps);
		}
	},

	render() {
		return (
			<div className="account-opening result-page-wrapper submission-page-wrapper container-fluid">
				<Helmet title={this.props.content.submissionPageHeader} />
				<PageHeader visible={BrandUtils.isAbleToDisplay('result-pages-header')}
							title={this.props.content.landingPageTitle + ProductUtils.getName(this.props.data.productCode)}
							content={this.props.content}
				/>
				<div className="result-page submission-page" role="main">
					<div className="row text-center">
						<div className="col-xs-12">
							<ResultSection
								imgSrc={BrandUtils.getResultImage('submission-page-with-image', 'submission-illustration.png')}
								imgAlt="Loading"
								bodyClassName="text-center"
								title={this.props.content.submissionPageTitle}
							>
								<p>{this.props.content.submissionPageText}</p>
								<LoadingSpinner />
							</ResultSection>
						</div>
					</div>
				</div>
			</div>
		);
	},
});

module.exports = HasTransfered;
