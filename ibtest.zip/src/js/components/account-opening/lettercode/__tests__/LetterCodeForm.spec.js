jest.autoMockOff();

const React = require('react');
const ReactDOM = require('react-dom');
const TestUtils = require('react-addons-test-utils');
const shallowRenderer = TestUtils.createRenderer();

const BrandUtils = require('../../../../utils/BrandUtils');
const RegexUtils = require('../../../../utils/RegexUtils');
const AccountOpeningActions = require('../../../../actions/AccountOpeningActions');
const TextQuestion = require('../../../common/questionsets/TextQuestion');
const LetterCodeForm = require('../LetterCodeForm');
const BottomNavigationBox = require('../../../common/BottomNavigationBox');
const { buildContent } = require('../../../../__helpers__/TestHelpers');

const content = buildContent([
    'letterCodeErrorInvalid',
    'letterCodeInputHelpText',
    'letterCodeLabel',
    'letterCodeLimitError',
    'letterCodeSubmitBtn',
    'letterCodeValidationMessage',
    'lettercodeLimitError',
]);

const render = (data = {}) => {
    const props = {
        content,
        data,
        appData: {},
        onChange: () => {},
        validations: {},
    };
    const el = document.createElement('div');
    const component = <LetterCodeForm {...props} />;
    const instance = ReactDOM.render(component, el);
    shallowRenderer.render(component);
    return { props, instance, output: shallowRenderer.getRenderOutput() };
};

describe('LetterCodeForm', () => {
    describe('when initially loaded', () => {
        it('should render', () => {
            const { props, output } = render();
            expect(output).toEqualJSX(
                <div className="lettercode-form">
                    <fieldset className="lettercode-form__fieldset">
                        <TextQuestion
                            name="lettercode"
                            key="lettercode"
                            id="lettercode"
                            title="lettercode"
                            labelClassName="lettercode-form__label"
                            inputClassName={'lettercode-form__input'}
                            containerClassName="lettercode-form__input-wrapper"
                            defaultValue={undefined}
                            group={'GROUP_LETTER_CODE'}
                            label="letterCodeLabel"
                            onChange={() => {}}
                            dataAnchor="letter-code"
                            validateType="letterCode"
                            validateRegex={RegexUtils.regexes.letterCode}
                            validationText="letterCodeValidationMessage"
                            helpText="letterCodeInputHelpText"
                            required
                            {...props}
                        >
                            {'letterCodeLabel'}
                        </TextQuestion>
                    </fieldset>
                    <BottomNavigationBox
                        dataAnchorNext="lettercode-submit-btn"
                        disabled={false}
                        isLoading={undefined}
                        nextButtonLabel="letterCodeSubmitBtn"
                        onClickNext={function noRefCheck() {}}
                    />
                </div>
            );
        });

        it('should enable proceed button', () => {
            const { props, instance } = render();
            TestUtils.Simulate.change(
                TestUtils.findRenderedDOMComponentWithClass(
                    instance,
                    'lettercode-form__input'
                ),
                { target: { value: '0123456789' } }
            );
            expect(
                ReactDOM.findDOMNode(
                    TestUtils.findRenderedDOMComponentWithClass(instance, 'btn')
                ).className
            ).not.toContain('lettercode-form__btn--disabled');
        });
    });

    describe('when submitted', () => {
        it('should set the letter code to action', () => {
            const submitLetterCodeMock = jest.fn();
            AccountOpeningActions.submitLetterCode = submitLetterCodeMock;
            const { props, instance } = render();
            instance.onChange('lettercode', '0123456789');
            TestUtils.Simulate.click(
                TestUtils.findRenderedDOMComponentWithClass(instance, 'btn')
            );
            expect(submitLetterCodeMock.mock.calls[0][0]).toBe('0123456789');
        });
    });

    describe('when error', () => {
        it('should enable proceed button', () => {
            const { props, instance } = render();
            instance.onChange('lettercode', '0123456789');
            TestUtils.Simulate.click(
                TestUtils.findRenderedDOMComponentWithClass(instance, 'btn')
            );
            TestUtils.Simulate.change(
                TestUtils.findRenderedDOMComponentWithClass(
                    instance,
                    'lettercode-form__input'
                ),
                { target: { value: 'fdsfdsfds' } }
            );
            expect(
                ReactDOM.findDOMNode(
                    TestUtils.findRenderedDOMComponentWithClass(
                        instance,
                        'lettercode-form__input'
                    )
                ).className
            ).not.toContain('lettercode-form__input--error');
        });
    });

    describe('when API limit is reached', () => {
        it('should display the error', () => {
            const { props, output } = render({
                letterCodeAPIErrorLimit: true,
            });
            expect(output).toIncludeJSX(
                <p className="error" className="lettercode-form__error error">
                    {props.content.letterCodeLimitError}
                </p>
            );
        });
    });

    describe('when letter is invalid', () => {
        it('should display the error', () => {
            const { props, output } = render({
                letterCodeAPIErrorInvalid: true,
            });
            expect(output).toIncludeJSX(
                <p className="error" className="lettercode-form__error error">
                    {props.content.letterCodeErrorInvalid}
                </p>
            );
        });
    });
});
