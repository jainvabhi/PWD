/**
 * @module LetterCodeForm
 */

const React = require('react');
const { PropTypes } = React;

const RegexUtils = require('../../../utils/RegexUtils');
const ValidationUtils = require('../../../utils/ValidationUtils');
const TextQuestion = require('../../common/questionsets/TextQuestion');
const BottomNavigationBox = require('../../common/BottomNavigationBox');

const AccountOpeningActions = require('../../../actions/AccountOpeningActions');
const AccountOpeningConstants = require('../../../constants/AccountOpeningConstants');

const LetterCodeForm = React.createClass({
	propTypes: {
		appData: PropTypes.object,
		validations: PropTypes.object.isRequired,
		data: PropTypes.shape({
			letterCodeAPIErrorInvalid: PropTypes.boolean,
			letterCodeAPIErrorLimit: PropTypes.boolean,
			lettercode: PropTypes.string,
		}),
		content: PropTypes.shape({
			letterCodeLabel: PropTypes.string.isRequired,
			letterCodeErrorInvalid: PropTypes.string.isRequired,
			letterCodeLimitError: PropTypes.string.isRequired,
			letterCodeSubmitBtn: PropTypes.string.isRequired,
			letterCodeValidationMessage: PropTypes.string.isRequired,
			letterCodeInputHelpText: PropTypes.string.isRequired,
		}),
	},

	getInitialState() {
		return {
			value: undefined,
		};
	},

	onChange(name, value) {
		this.setState({
			value: value,
		}, () => {
			AccountOpeningActions.updateFormValue(name, this.state.value);
		});
	},

	onSubmit(event) {
		event.preventDefault();
		AccountOpeningActions.submitLetterCode(this.state.value);
	},

	render() {
		const isValid = ValidationUtils.isGroupValid(this.props.validations, AccountOpeningConstants.GROUP_LETTER_CODE);

		return (
			<div className="lettercode-form">
				<fieldset className="lettercode-form__fieldset">
					<TextQuestion
						name="lettercode"
						key="lettercode"
						id="lettercode"
						title="lettercode"
						labelClassName="lettercode-form__label"
						inputClassName="lettercode-form__input"
						containerClassName="lettercode-form__input-wrapper"
						defaultValue={this.props.data.lettercode}
						group={AccountOpeningConstants.GROUP_LETTER_CODE}
						label={this.props.content.letterCodeLabel}
						onChange={this.onChange}
						dataAnchor="letter-code"
						validateType="letterCode"
						validateRegex={RegexUtils.regexes.letterCode}
						validationText={this.props.content.letterCodeValidationMessage}
						helpText={this.props.content.letterCodeInputHelpText}
						required
						{...this.props}
					>
						{this.props.content.letterCodeLabel}
					</TextQuestion>
					{this.props.data.letterCodeAPIErrorInvalid && <p className="lettercode-form__error error">{this.props.content.letterCodeErrorInvalid}</p>}
					{this.props.data.letterCodeAPIErrorLimit && <p className="lettercode-form__error error">{this.props.content.letterCodeLimitError}</p>}
				</fieldset>
				<BottomNavigationBox
					onClickNext={this.onSubmit}
					nextButtonLabel={this.props.content.letterCodeSubmitBtn}
					disabled={!isValid}
					isLoading={this.props.appData.isApiCallInProgress}
					dataAnchorNext="lettercode-submit-btn"
				/>
			</div>
		);
	},
});


module.exports = LetterCodeForm;
