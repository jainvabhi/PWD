const React = require('react');
const ComponentHeader = require('../../common/ComponentHeader');
const CreditExpenditure = require('../../account-opening/accounts/CreditExpenditure');
const { IncomeReduction } = require('../../account-opening/accounts/IncomeDetails');

const ChangeOfCircumstances = props => (
	<ComponentHeader
		title="Change of Circumstances"
		titleLevel={2}
	>
		<CreditExpenditure {...props} />
		<IncomeReduction {...props} />
	</ComponentHeader>
);

module.exports = ChangeOfCircumstances;
