jest.unmock('../Overdrafts');

const React = require('react');
const TestUtils = require('react-addons-test-utils');

const shallowRenderer = TestUtils.createRenderer();

const Overdrafts = require('../Overdrafts');
const OverdraftDetails = require('../OverdraftDetails');
const { OverdraftLimitQuestion, OverdraftLimitAnswer } = require('../OverdraftLimitQuestion');

describe('Overdrafts data capture', () => {
	let component;

	const getProps = props => ({
		group: '',
		data: {},
		onChange: jest.fn(),
		...props,
	});

	describe('WHEN a user is not interested in an overdraft', () => {
		beforeEach(() => {
			const props = getProps({ data: { requiresOverdraft: 'No' }})
			component = shallowRenderer.render(<Overdrafts {...props} />)
		});

		it('should not have overdraft details present', () => {
			expect(component).not.toIncludeJSX(
				<OverdraftDetails
					data={{requiresOverdraft: 'No'}}
					group=""
					onChange={function noRefCheck() {}}
				/>
			)
		});
	});

	describe('WHEN a user is interested in an overdraft', () => {
		beforeEach(() => {
			const props = getProps({ data: { requiresOverdraft: 'Yes' }})
			component = shallowRenderer.render(<Overdrafts {...props} />)
		});

		it('should have overdraft details present', () => {
			expect(component).toIncludeJSX(
				<OverdraftDetails
					data={{requiresOverdraft: 'Yes'}}
					group=""
					onChange={function noRefCheck() {}}
				/>
			)
		});
	});

	describe('WHEN a user does want to apply overdraft to account', () => {
		beforeEach(() => {
			const props = getProps({ data: { requiresOverdraft: 'Yes', applyingForOverdraft: 'Yes' }})
			component = shallowRenderer.render(<Overdrafts {...props} />)
		});

		it('should not have overdraft questions present', () => {
			expect(component).toIncludeJSX(
				<OverdraftLimitAnswer
					data={{applyingForOverdraft: 'Yes', requiresOverdraft: 'Yes'}}
					group=""
					onChange={function noRefCheck() {}}
				/>
			)
		});
	});

	describe('WHEN a user does not want to apply overdraft to account', () => {
		beforeEach(() => {
			const props = getProps({ data: { requiresOverdraft: 'Yes', applyingForOverdraft: 'No' }})
			component = shallowRenderer.render(<Overdrafts {...props} />)
		});

		it('should not have overdraft questions present', () => {
			expect(component).not.toIncludeJSX(
				<OverdraftLimitAnswer
					data={{applyingForOverdraft: 'Yes', requiresOverdraft: 'No'}}
					group=""
					onChange={function noRefCheck() {}}
				/>
			)
		});
	});
});
