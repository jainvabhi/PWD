const React = require('react');
const { PropTypes } = React;

const { RadioQuestion, TextQuestion } = require('../../common/questionsets');

const isValid = props => {
	const limit = parseInt(props.data.overdraftLimit);
	return !(limit % 50) && limit >= 50 && limit <= 5000;
};

const OverdraftLimitAnswer = props => (
	<TextQuestion
		name="overdraftLimit"
		group={props.group}
		defaultValue={props.data.overdraftLimit}
		onChange={props.onChange}
		validateType="number"
		customValidator={() => isValid(props)}
		valueFormatter={e => {
			const val = parseInt(e, 10);
			return isNaN(val) ? '' : val;
		}}
		required
	>
		{props.content.overdraftLimit}
	</TextQuestion>
);

OverdraftLimitAnswer.propTypes = {
	group: PropTypes.string.isRequired,
	content: PropTypes.shape({
		applyingForOverdraft: PropTypes.string,
		overdraftLimit: PropTypes.string.isRequired,
	}),
	data: PropTypes.shape({
		applyingForOverdraft: PropTypes.string,
		overdraftLimit: PropTypes.number,
	}),
	onChange: PropTypes.func.isRequired,
};

const isOverdraftBeingApplied = props => props.data.overdraftLimit ? 'Yes' : props.data.applyingForOverdraft;

const OverdraftLimitQuestion = props => (
	<RadioQuestion
		name="applyingForOverdraft"
		labelText={props.content.applyingForOverdraft}
		group={props.group}
		onChange={props.onChange}
		defaultValue={isOverdraftBeingApplied(props)}
		options={[{
			label: 'No',
			value: 'No',
		}, {
			label: 'Yes',
			value: 'Yes',
		}]}
		required
	/>
);

OverdraftLimitQuestion.propTypes = {
	group: PropTypes.string.isRequired,
	content: PropTypes.shape({
		applyingForOverdraft: PropTypes.string.isRequired,
	}).isRequired,
	data: PropTypes.shape({
		applyingForOverdraft: PropTypes.string,
		overdraftLimit: PropTypes.number,
	}).isRequired,
	onChange: PropTypes.func.isRequired,
};

module.exports = {
	OverdraftLimitQuestion,
	OverdraftLimitAnswer,
};
