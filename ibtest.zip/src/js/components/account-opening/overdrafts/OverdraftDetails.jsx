const React = require('react');

const OverdraftInformation = require('./OverdraftInformation');
const { OverdraftLimitQuestion } = require('./OverdraftLimitQuestion');
const OverdraftThingsToKnow = require('./OverdraftThingsToKnow');

const OverdraftDetails = props => (
	<span>
		<OverdraftInformation {...props} />
		<OverdraftThingsToKnow {...props} />
		<OverdraftLimitQuestion {...props} />
	</span>
);

module.exports = OverdraftDetails;
