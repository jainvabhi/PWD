const React = require('react');
const { PropTypes } = React;
const ComponentHeader = require('../../common/ComponentHeader');

const { RadioQuestion } = require('../../common/questionsets');
const AccountOpeningActions = require('../../../actions/AccountOpeningActions');

const ChangeOfCircumstances = require('./ChangeOfCircumstances');
const OverdraftDetails = require('./OverdraftDetails');
const { OverdraftLimitAnswer } = require('./OverdraftLimitQuestion');

const isRequiresSelected = data => data.overdraftLimit ? 'Yes' : data.requiresOverdraft;

const RequireOverdraftQuestion = props => (
	<RadioQuestion
		name="requiresOverdraft"
		group={props.group}
		onChange={props.onChange}
		labelText={props.content.requiresOverdraft}
		defaultValue={isRequiresSelected(props.data)}
		options={[{
			label: 'No',
			value: 'No',
		}, {
			label: 'Yes',
			value: 'Yes',
		}]}
		required
	/>
);

RequireOverdraftQuestion.propTypes = {
	group: PropTypes.string.isRequired,
	onChange: PropTypes.func.isRequired,
	content: PropTypes.shape({
		requiresOverdraft: PropTypes.string.isRequired,
	}),
	data: PropTypes.shape({
		overdraftLimit: PropTypes.number,
	}).isRequired,
};

const Overdrafts = React.createClass({
	propTypes: {
		data: PropTypes.shape({
			requiresOverdraft: PropTypes.string,
			applyingForOverdraft: PropTypes.string,
			overdraftLimit: PropTypes.number,
		}),
		onChange: PropTypes.func.isRequired,
	},

	onOverdraftChange(key, value, onChange) {
		if (value === 'No') {
			AccountOpeningActions.updateFormValues([
				{ key: 'applyingForOverdraft', value: undefined },
				{ key: 'overdraftLimit', value: undefined },
				{ key: 'changeOfCircumstances', value: undefined },
				{ key: 'hasIncomeReduction', value: undefined },
				{ key: 'revisedMortgageOrRentExpenditure', value: undefined },
				{ key: 'revisedExpenditureOther', value: undefined },
				{ key: 'revisedGrossAnnualIncome', value: undefined },
				{ key: 'revisedNetMonthlyIncome', value: undefined },
			]);
		}

		onChange(key, value);
	},

	render() {
		const requiresOverdraft = this.props.data.requiresOverdraft === 'Yes' || this.props.data.overdraftLimit;
		const applyingForOverdraft = (this.props.data.applyingForOverdraft === 'Yes' && requiresOverdraft) || this.props.data.overdraftLimit;

		return (
			<span>
				<ComponentHeader
					title="Overdrafts"
					titleLevel={2}
					hasSeparator
					id="overdrafts"
				>
					<RequireOverdraftQuestion
						{...this.props}
						onChange={(key, val) => this.onOverdraftChange(key, val, this.props.onChange)}
					/>
					{requiresOverdraft && <OverdraftDetails
						{...this.props}
						onChange={(key, val) => this.onOverdraftChange(key, val, this.props.onChange)}
					/>}
					{applyingForOverdraft && <OverdraftLimitAnswer {...this.props} />}
				</ComponentHeader>
				{applyingForOverdraft && <ChangeOfCircumstances {...this.props} />}
			</span>
		);
	},
});

module.exports = Overdrafts;
