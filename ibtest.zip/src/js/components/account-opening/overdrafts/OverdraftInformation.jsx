const React = require('react');
const { PropTypes } = React;
const SectionFullWidth = require('../../common/SectionFullWidth');
const ComponentHeader = require('../../common/ComponentHeader');

const OverdraftInformation = props => (
	<SectionFullWidth>
		<div className="agreewrapper">
			<div className="agreewrapper__content agreewrapper__content-expanded">
				<p>{props.content.overdraftInformationIntro}</p>
				<ComponentHeader
					title={props.content.overdraftInformationInterestSectionTitle}
					titleLevel={3}
				/>
				<p>{props.content.overdraftInformationInterestSectionIntro}</p>
				<ul>
					<li>{props.content.overdraftInformationInterestSectionBullet1.replace('{earOverdraft}', props.data.product.earOverdraft)}</li>
					<li>{props.content.overdraftInformationInterestSectionBullet2.replace('{monthlyPlannedBorrowingFee}', props.data.product.monthlyPlannedBorrowingFee)}</li>
				</ul>
				<p>{props.content.overdraftInformationInterestSectionParagraph1}</p>
				<p>{props.content.overdraftInformationInterestSectionParagraph2}</p>
				<p dangerouslySetInnerHTML={{ __html: props.content.overdraftInformationInterestSectionParagraph3 }} />
				<p>{props.content.overdraftInformationInterestSectionParagraph4}</p>
				<p><strong>{props.content.overdraftInformationExampleTitle}</strong></p>
				<p>{props.content.overdraftInformationExampleIntro.replace('{earOverdraft}', props.data.product.earOverdraft)}</p>
				<p><i>{props.content.overdraftInformationExampleSubscript}</i></p>
				<p>{props.content.overdraftInformationExampleFooter}</p>
			</div>
		</div>
	</SectionFullWidth>
);

OverdraftInformation.propTypes = {
	data: PropTypes.shape({
		product: PropTypes.shape({
			name: PropTypes.string.isRequired,
			earOverdraft: PropTypes.string.isRequired,
			monthlyPlannedBorrowingFee: PropTypes.string.isRequired,
		}).isRequired,
	}).isRequired,
	content: PropTypes.shape({
		overdraftInformationIntro: PropTypes.string.isRequired,
		overdraftInformationInterestSectionTitle: PropTypes.string.isRequired,
		overdraftInformationInterestSectionIntro: PropTypes.string.isRequired,
		overdraftInformationExampleTitle: PropTypes.string.isRequired,
		overdraftInformationInterestSectionBullet1: PropTypes.string.isRequired,
		overdraftInformationInterestSectionBullet2: PropTypes.string.isRequired,
		overdraftInformationInterestSectionParagraph1: PropTypes.string,
		overdraftInformationInterestSectionParagraph2: PropTypes.string,
		overdraftInformationInterestSectionParagraph3: PropTypes.string,
		overdraftInformationInterestSectionParagraph4: PropTypes.string,
		overdraftInformationInterestSectionParagraph5: PropTypes.string,
		overdraftInformationExampleIntro: PropTypes.string,
		overdraftInformationExampleSubscript: PropTypes.string,
		overdraftInformationExampleFooter: PropTypes.string,
	}),
};

module.exports = OverdraftInformation;
