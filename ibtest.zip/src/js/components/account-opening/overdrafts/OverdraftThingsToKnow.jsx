const React = require('react');
const { PropTypes } = React;
const ComponentHeader = require('../../common/ComponentHeader');
const ContentUtils = require('../../../utils/ContentUtils');

const OverdraftThingsToKnow = props => (
	<ComponentHeader
		title="Things to consider when taking out an overdraft"
		titleLevel={3}
	>
		<ul>
			{ContentUtils.getContentListElements('overdraftInformationNeedToKnowSectionBullet', props.content)}
		</ul>
	</ComponentHeader>
);

OverdraftThingsToKnow.propTypes = {
	content: PropTypes.shape({}).isRequired,
};

module.exports = OverdraftThingsToKnow;
