const { OverdraftLimitQuestion, OverdraftLimitAnswer } = require('./OverdraftLimitQuestion');

module.exports = {
	Overdrafts: require('./Overdrafts'),
	ChangeOfCircumstances: require('./ChangeOfCircumstances'),
	OverdraftDetails: require('./OverdraftDetails'),
	OverdraftInformation: require('./OverdraftInformation'),
	OverdraftLimitQuestion,
	OverdraftLimitAnswer,
	OverdraftThingsToKnow: require('./OverdraftThingsToKnow'),
};
