/**
 * @module PersonalDetailsPage
 */

const _ = require('lodash');
const React = require('react');
const { PropTypes } = React;
const Helmet = require('react-helmet');
const config = require('../../config');
const cx = require('classnames');

// Actions
const AccountOpeningActions = require('../../actions/AccountOpeningActions');
const AnalyticsActionCreator = require('../../actions/AnalyticsActionCreator');
const AnalyticsActions = require('../../actions/AnalyticsActionCreator');

// Constants
const AccountOpeningConstants = require('../../constants/AccountOpeningConstants');

// Utils
const EncryptionUtils = require('../../utils/EncryptionUtils');
const BrandUtils = require('../../utils/BrandUtils');
const PathUtils = require('../../utils/PathUtils');
const RegexUtils = require('../../utils/RegexUtils');
const ContentUtils = require('../../utils/ContentUtils');
const ValidationUtils = require('../../utils/ValidationUtils');

// Components
const AddressSection = require('../account-opening/sections/AddressSection');
const MaritalStatus = require('../account-opening/sections/MaritalStatus');
const BottomNavigationBox = require('../common/BottomNavigationBox');
const ComponentHeader = require('../common/ComponentHeader');
const DropdownQuestion = require('../common/questionsets/DropdownQuestion');
const ErrorMessage = require('../common/ErrorMessage');
const ProgressBar = require('./ProgressBar');
const PageHeader = require('../common/PageHeader');
const RadioQuestion = require('../common/questionsets/RadioQuestion');
const ReadOnlyMessage = require('./ReadOnlyMessage');
const SectionFullWidth = require('../common/SectionFullWidth.jsx');
const FormRow = require('../common/FormRow');

const {
	Title,
	FirstName,
	LastName,
	MiddleName,
	DateOfBirth,
	PhoneNumber,
	EmailAddress,
	Gender,
	AdditionalCardHolder,
	NumberOfDependants,
} = require('./personalDetails');
const LinkCodeModal = require('./joint/LinkCodeModal');

const PageColumnWrapper = require('../common/PageColumnWrapper');
const SideBarColumnWrapper = require('../common/SideBarColumnWrapper');

const PersonalDetailsFoundError = require('./findDetails/PersonalDetailsFoundError');

const PageValidator = require('./PageValidator');

const getDefaultValue = (title = '', options) => {
	const selected = options.filter(opt => opt.label.toLowerCase() === title.toLowerCase());
	return selected.length > 0 ? title : undefined;
};

const isTitleReadOnly = (props, state, config) => props.data.isExistingCustomer && getDefaultValue(props.data.title, config.validTitles) && !state.existingCanEdit ? props.data.isExistingCustomer : undefined;

function getReadOnlyErrors(props, existingCustomerReadOnlyFields) {
	if (!props.validations) {
		return [];
	}

	return _(props.validations.GROUP_PAGE_1)
		.pick(existingCustomerReadOnlyFields)
		.pickBy(x => !x.isValid)
		.keys()
		.filter(key => key !== 'title')
		.map(key => props.content[`${key}Question`] || key)
		.value();
}

const replaceBankName = (bankID, content) => {
	if (bankID === 'CB') {
		return content.replace('{bankName}', 'Yorkshire');
	}

	return content.replace('{bankName}', 'Clydesdale');
};

const PersonalDetailsPage = React.createClass({
	propTypes: {
		envConfig: PropTypes.shape({
			bankId: PropTypes.string,
		}),
		appData: PropTypes.object,
		content: PropTypes.object.isRequired,
		data: PropTypes.object.isRequired,
		postcodeData: PropTypes.object,
		validations: PropTypes.object,
		updateGroupValidations: PropTypes.func,
		invalidOnSubmit: PropTypes.bool,
		submitButtonClick: PropTypes.bool,
	},

	getInitialState() {
		return {
			isLoadingCredentials: false,
			existingCanEdit: false,
		};
	},

	componentWillMount() {
		AccountOpeningActions.resetFormErrors();
	},

	componentDidMount() {
		// Record an analytics user event.
		AnalyticsActionCreator.track({
			path: '/user/experience/view',
			action: 'Appeared',
		}, {
			description: 'PageLoaded',
		});

		// Is the user resuming a case? Save their work as they go.
		if (this.props.data.caseId) {
			AccountOpeningActions.startAutosaveTimer();
		}
	},

	/**
	 * Stores have changed. Is the user waiting on a submission to complete?
	 *
	 * @param  {Object} nextProps
	 */
	componentWillReceiveProps(nextProps) {
		if (nextProps.data.productInvalid) {
			AccountOpeningActions.navigateToWebTask('WEB-ERROR');
		}

			// Have we fetched credentials now?
		if (this.state.isLoadingCredentials && !_.isUndefined(nextProps.data.credentials)) {
			this.setState({
				isLoadingCredentials: false,
			});
		}

			// Has the user just created a case successfully? Navigate them on.
		if (nextProps.data.caseId && !this.props.data.caseId) {
			// TODO: Don't think this is the best place for this, will review.
			// We want to alert other parts of the app we now have a caseId,
			// mainly for analytics currently
			AccountOpeningActions.setCaseId(nextProps.data.caseId);
			AccountOpeningActions.navigateToWebTask('WEB-EMPLOYMENT-DETAILS');
		}

		const readonlyErrors = this.getInvalidFieldLabels();
		if (this.props.data.isExistingCustomer === 'Yes' && readonlyErrors && readonlyErrors.length && !this.state.trackedErrors) {
			this.setState({
				trackedErrors: true,
			}, () => {
				AnalyticsActions.recordError({
					message: readonlyErrors,
					type: 'validation',
				});
			});
		}
	},

	onChange(name, value) {
		// @ticket DGW2-1748
		AccountOpeningActions.resetFormErrors();
		AccountOpeningActions.updateFormValue(name, value);
	},

	onDOBChange(name, value) {
		AnalyticsActionCreator.track({
			path: '/user/experience/activity',
			action: 'Interacted',
		}, {
			value,
			description: 'DOBSelected',
			event: (this.props.data[name] ? 'updated' : 'created'),
		});
		AccountOpeningActions.updateFormValue(name, value);
	},

	onEmailChange(name, value) {
		AnalyticsActionCreator.track({
			path: '/user/experience/activity',
			action: 'Interacted',
		}, {
			value,
			description: 'EmailAddressEntered',
			event: (this.props.data[name] ? 'updated' : 'created'),
		});
		AccountOpeningActions.updateFormValue(name, value);
	},

	onGenderChange(name, value) {
		if (!this.props.data.title) {
			return;
		}
		const isTitleGenderValid = this.isTitleGenderValid(this.props.data.title, value);
		const isTitleGenderNeutral = this.isTitleGenderNeutral(this.props.data.title);
		const isGenderValid = value && (isTitleGenderNeutral || isTitleGenderValid);
		AccountOpeningActions.updateFormValue(name, value);
		AccountOpeningActions.updateValidation(AccountOpeningConstants.GROUP_PAGE_1, 'gender', isGenderValid);
	},

	/**
	 * Set the appropriate dependents number value
	 * (undefined if No, default 1 if Yes)
	 *
	 * @param  {String} name  Key of the "has dependents?" question
	 * @param  {String} value Yes/No
	 */
	onHasDependantsChange(key, value) {
		AccountOpeningActions.updateFormValues([
			{
				key,
				value,
			}, {
				key: 'dependants',
				value: (value === 'Yes') ? '1' : undefined,
			},
		]);
	},

	onHasMiddleNameChange(name, value) {
		const data = [{ key: name, value }];

		let analyticsEvent;

		// Clear the saved list if user now says they don't have one.
		if (value === 'No') {
			data.push({ key: 'middleName', value: undefined });
			analyticsEvent = 'deleted';
		} else {
			analyticsEvent = 'created';
		}

		AnalyticsActionCreator.track({
			path: '/user/experience/activity',
			action: 'Interacted',
		}, {
			value,
			description: 'MiddleNameSelected',
			event: analyticsEvent,
		});

		AccountOpeningActions.updateFormValues(data);
	},

	/**
	 * Onchange handler for phoneNumber
	 * This function will update the store value.
	 */
	onPhoneNumberChange(name, value) {
		const isValid = RegexUtils.isValid(value, RegexUtils.regexes.phone);
		if (isValid) {
			AnalyticsActionCreator.track({
				path: '/user/experience/activity',
				action: 'Interacted',
			}, {
				type: RegexUtils.isValid(value, RegexUtils.regexes.mobilePhone) ? 'MobilePhone' : 'HomePhone',
				value,
				description: 'PhoneNumberEntered',
				event: (this.props.data[name] ? 'updated' : 'created'),
			});
		}

		AccountOpeningActions.updateFormValue(name, value);
	},

	/**
	 * Onchange handler for preferredContactMethod
	 * This function will record analytics as well as update the store value.
	 */
	onPreferredContactMethodChange(name, value) {
		AnalyticsActionCreator.track({
			path: '/user/experience/activity',
			action: 'Interacted',
		}, {
			type: RegexUtils.isValid(value, RegexUtils.regexes.mobilePhone) ? 'MobilePhone' : 'HomePhone',
			value,
			description: 'ContactMethodsSelected',
			event: 'click',
		});
		AccountOpeningActions.updateFormValue(name, value);
	},

	/**
	 * User has decided to submit the page.
	 *
	 * @param  {Event} e 		Stop user from navigating until we find out if the submission
	 *					 		was successful or not.
	 */
	onSubmitPage(e) {
		e.preventDefault();

		// @ticket DGW2-1749
		if (BrandUtils.isAbleToDisplay('defer-validation') && (!this.props.updateGroupValidations(AccountOpeningConstants.GROUP_PAGE_1) || this.props.data.jointMismatchBankId)) {
			return;
		}

		AccountOpeningActions.recordTaskComplete('WEB-PERSONAL-DETAILS');

		if (this.props.data.isReviewing) {
			AccountOpeningActions.navigateToWebTask('WEB-REVIEW-DETAILS');
		} else if (this.props.data.caseId) {
			AccountOpeningActions.navigateToWebTask('WEB-EMPLOYMENT-DETAILS');
		} else {
			AccountOpeningActions.sendFormData();
		}
	},

	onClickBack(e) {
		e.preventDefault();

		if (BrandUtils.isAbleToDisplay('defer-validation') && !this.props.updateGroupValidations(AccountOpeningConstants.GROUP_PAGE_1) && this.props.data.isReviewing) {
			return;
		}

		AccountOpeningActions.navigateToWebTask('WEB-ELIGIBILITY-PAGE');
	},

	onTitleChange(name, value) {
		AccountOpeningActions.updateFormValue(name, value);
		this.selectGenderFromTitle(value, config.validTitles);

		this.setState({
			existingCanEdit: true,
		});

		AnalyticsActionCreator.track({
			path: '/user/experience/activity',
			action: 'Interacted',
		}, {
			value,
			description: 'TitleEntered',
			event: (this.props.data[name] ? 'updated' : 'created'),
		});
	},

	/**
	 * show form guidance for existing customers
	 * @return {ReactElement}
	 */
	getGuidanceForExistingCustomers() {
		const readonlyErrors = this.getInvalidFieldLabels();

		if (!readonlyErrors || !readonlyErrors.length) {
			return (
					ContentUtils.getContentParagraphs('personalDetailsGuidance', this.props.content, 'padding-bottom')
				);
		}
	},

	/**
	 * fetch invalid field labels
	 * @return {array} List of invalid field labels
	 */
	getInvalidFieldLabels() {
		return getReadOnlyErrors(this.props, config.existingCustomerReadOnlyFields);
	},

	/**
	 * Label for the action button
	 * @param  {Boolean} isReviewing 			Is the customer reviewing?
	 * @param  {Boolean} isApiCallInProgress 	Any API calls happening?
	 * @param  {Boolean} isLoadingCredentials 	Are we fetching credentials for existing customers?
	 * @return {String} Button label
	 */
	getNextButtonLabel(isReviewing, isApiCallInProgress, isLoadingCredentials) {
		const labelText = (isReviewing) ? 'Review' : 'Continue';
		return (isApiCallInProgress && !isLoadingCredentials) ? 'Submitting...' : labelText;
	},

	getPersonaDetailsFoundError() {
		return (
			<PersonalDetailsFoundError
			{...this.props}
			/>
		);
	},

	/**
	 * Bank selection question
	 * @return {ReactElement}
	 */
	getSelectYourBankQuestion(shouldShow) {
		if (BrandUtils.isAbleToDisplay('select-your-bank-section')) {
			const shouldShowClass = cx({
				'show': shouldShow,
				'hide': !shouldShow,
			});

			return (
				<div className={shouldShowClass}>
					<SectionFullWidth>
						<ComponentHeader
							title={this.props.content.selectBankTitle}
							titleLevel={2}
							hasSeparator
							id="bank-question-title"
						>

							<p className="intro-paragraph">{this.props.content.selectBankSubtitle}
							</p>

							<p>
								<a href={this.props.content.selectBankHelpLinkCb} target="_blank" title={this.props.content.selectBankHelpLinkCbTitle}>{this.props.content.selectBankHelpLinkCbText} <span className="screenreader">{this.props.content.newBrowserWindowTitle}</span></a><br />
								<a href={this.props.content.selectBankHelpLinkYb} target="_blank" title={this.props.content.selectBankHelpLinkYbTitle}>{this.props.content.selectBankHelpLinkYbText} <span className="screenreader">{this.props.content.newBrowserWindowTitle}</span></a>
							</p>

							<RadioQuestion
								defaultValue={this.props.data.bankID}
								group={AccountOpeningConstants.GROUP_PAGE_1}
								name="bankID"
								labelText={this.props.content.selectBankQuestion}
								labelledBy="bank-question-title"
								helpText={this.props.content.selectBankHelpText}
								onChange={this.onChange}
								options={[{
									anchor: 'select-bank-cb',
									checkedImage: PathUtils.getPath('images/cb/bank-logo.png'),
									label: 'Clydesdale Bank',
									image: PathUtils.getPath('images/cb/bank-logo-grey.png'),
									value: 'CB',
								}, {
									anchor: 'select-bank-yb',
									checkedImage: PathUtils.getPath('images/yb/bank-logo.png'),
									label: 'Yorkshire Bank',
									image: PathUtils.getPath('images/yb/bank-logo-grey.png'),
									value: 'YB',
								}]}
								required
							/>
							{this.props.data.jointMismatchBankId && <FormRow><ErrorMessage text={replaceBankName(this.props.data.bankID, this.props.content.jointAccountIncorrectBankId)} /></FormRow>}
						</ComponentHeader>
					</SectionFullWidth>
				</div>
			);
		}
	},

	/**
	 * Responsible for deciding if the bank selection can be edited
	 *
	 * @return {Boolean} True if bank selection can be edited
	 */
	canEditBankSelection() {
		return !(this.props.data.completedTasks['SAVE_AND_RESUME'] || this.props.data.caseId);
	},

	isTitleGenderNeutral(title) {
		const t = title || '';
		return _.some(config.validTitles, l => l.label.toUpperCase() === t.toUpperCase() && l.gender === null);
	},

	isTitleGenderValid(title, gender) {
		if (!title || !gender) {
			return false;
		}
		const key = _.findKey(config.validTitles, l => {
			return l.label.toUpperCase() === title.toUpperCase() && (l.gender === gender || gender === null);
		});

		return key ? true : false;
	},

	selectGenderFromTitle(value, data) {
		const gender = _.result(_.find(data, { value }), 'gender');

		if (gender) {
			AccountOpeningActions.updateFormValue('gender', gender);
			AccountOpeningActions.updateValidation(AccountOpeningConstants.GROUP_PAGE_1, 'gender', true);
		} else if (!gender && this.props.data.gender) {
			AccountOpeningActions.updateFormValue('gender', gender);
			AccountOpeningActions.disableValidation(AccountOpeningConstants.GROUP_PAGE_1, 'gender');
		}
	},

	/**
	 * Take the current plaintext password and store the encrypted (and formatted) variant.
	 */
	updateEncryptedPassword(publicKey, datetime) {
		const formattedPassword = `${datetime}:${this.props.data.password1}`;
		const encPassword = EncryptionUtils.encrypt(publicKey, formattedPassword);
		AccountOpeningActions.updateFormValue('encryptedPassword', encPassword);
	},

	// Track when the user is ready to submit, but we needed to wait for a
	waitingToSendEncryptedData: false,

	render() {
		const isValid = BrandUtils.isAbleToDisplay('defer-validation') ? true : ValidationUtils.isGroupValid(this.props.validations, AccountOpeningConstants.GROUP_PAGE_1) && !this.props.data.jointMismatchBankId;

		const isExistingCustomer = (this.props.data.isExistingCustomer === 'Yes') ? true : false;

		return (
			<div className="account-opening personal-details-page container-fluid">
				<Helmet title={this.props.content.personalDetailsPageHeader} />

				<PageHeader title={this.props.content.personalDetailsPageHeader} content={this.props.content} />

				<div className="row main-container">
					<PageColumnWrapper step={1} content={this.props.content}>
						{/* Progress Bar */}
						<SectionFullWidth>
							<ProgressBar step={0} timeRemaining={10} />
						</SectionFullWidth>

						{/* Personal Details */}
						<SectionFullWidth id="personal-details">
							<ComponentHeader
								title={this.props.content.personalDetailsTitle}
								titleLevel={2}
								subTitle={this.props.content.personalDetailsSubtitle}
								hasSeparator
							>

								{isExistingCustomer && this.getGuidanceForExistingCustomers()}

								{isExistingCustomer && <ReadOnlyMessage
									content={this.props.content}
									bulletPoints={this.getInvalidFieldLabels()}
									group={AccountOpeningConstants.GROUP_PAGE_1}
								/>}

								<Title
									name="title"
									group={AccountOpeningConstants.GROUP_PAGE_1}
									onChange={this.onTitleChange}
									dataAnchor="title"
									defaultValue={getDefaultValue(this.props.data.title, config.validTitles)}
									label={this.props.content.titleQuestion}
									data={config.validTitles}
									readOnly={isTitleReadOnly(this.props, this.state, config)}
									required
								/>

								<FirstName
									group={AccountOpeningConstants.GROUP_PAGE_1}
									onChange={this.onChange}
									defaultValue={this.props.data.firstName}
									label={this.props.content.firstNameQuestion}
									readOnly={this.props.data.isExistingCustomer}
									required
								/>

								<MiddleName
									group={AccountOpeningConstants.GROUP_PAGE_1}
									onChange={AccountOpeningActions.updateFormValue}
									onHasMiddleNameChange={this.onHasMiddleNameChange}
									{...this.props}
								/>

								<LastName
									group={AccountOpeningConstants.GROUP_PAGE_1}
									onChange={this.onChange}
									defaultValue={this.props.data.lastName}
									label={this.props.content.lastNameQuestion}
									readOnly={this.props.data.isExistingCustomer}
									required
								/>

								<DateOfBirth
									group={AccountOpeningConstants.GROUP_PAGE_1}
									onChange={this.onDOBChange}
									defaultValue={this.props.data.dateOfBirth}
									label={this.props.content.dateOfBirthQuestion}
									readOnly={this.props.data.isExistingCustomer}
									required
									{...this.props}
								/>

								<Gender
									name="gender"
									group={AccountOpeningConstants.GROUP_PAGE_1}
									onChange={this.onGenderChange}
									dataAnchor="gender"
									defaultValue={this.props.data.gender}
									label={this.props.content.genderQuestion}
									data={['Male', 'Female']}
									onBlur={() => {
										// @ticket DGW2-3888
										const isTitleGenderValid = this.isTitleGenderValid(this.props.data.title, this.props.data.gender);
										const isTitleGenderNeutral = this.isTitleGenderNeutral(this.props.data.title);
										const isGenderValid = this.props.data.gender && (isTitleGenderNeutral || isTitleGenderValid);
										AccountOpeningActions.enableValidation(AccountOpeningConstants.GROUP_PAGE_1, 'gender');
										AccountOpeningActions.updateValidation(AccountOpeningConstants.GROUP_PAGE_1, 'gender', isGenderValid);
									}}
									readOnly={this.props.data.isExistingCustomer}
									required
								/>

								<MaritalStatus
									data={this.props.data}
									content={this.props.content}
								/>

								<NumberOfDependants
									group={AccountOpeningConstants.GROUP_PAGE_1}
									onHasDependantsChange={this.onHasDependantsChange}
									onChange={AccountOpeningActions.updateFormValue}
									{...this.props}
								/>


							</ComponentHeader>
						</SectionFullWidth>

						{/* Current Address */}
						<SectionFullWidth>
								<AddressSection
									appData={this.props.appData}
									name="addresses"
									arrayName={'addresses'}
									group={AccountOpeningConstants.GROUP_PAGE_1}
									content={this.props.content}
									addressList={this.props.data.addresses}
									residentialStatus={this.props.data.residentialStatus}
									postcodeData={this.props.postcodeData}
									validations={this.props.validations}
									isExistingCustomer={this.props.data.isExistingCustomer === 'Yes'}
									validateSameOrAfterDate={this.props.data.dateOfBirth}
									validateEqualToThese={this.props.data.product.allowedResidentialStatus}
									validationText={this.props.content[this.props.data.product.allowedResidentialStatusContentKey]}
									submitButtonClick={this.props.submitButtonClick}
									findAddressButtonClick={this.props.data.findAddressButtonClick}
								/>
						</SectionFullWidth>

						{/* Contact Details */}
						<SectionFullWidth id="contact-details">
							<ComponentHeader
								title={this.props.content.contactDetailsTitle}
								titleLevel={2}
								hasSeparator
							>

								<p className="intro-paragraph">{this.props.content.contactDetailsIntro}</p>

								<PhoneNumber
									group={AccountOpeningConstants.GROUP_PAGE_1}
									onChange={this.onPhoneNumberChange}
									defaultValue={this.props.data.phoneNumber}
									label={this.props.content.phoneNumberQuestion}
									readOnly={this.props.data.isExistingCustomer}
									required
								/>

								<EmailAddress
									group={AccountOpeningConstants.GROUP_PAGE_1}
									onChange={this.onEmailChange}
									defaultValue={this.props.data.emailAddress}
									label={this.props.content.emailAddressQuestion}
									readOnly={this.props.data.isExistingCustomer}
									required
								/>

								<EmailAddress
									name="emailAddressConfirmation"
									group={AccountOpeningConstants.GROUP_PAGE_1}
									onChange={this.onChange}
									defaultValue={this.props.data.emailAddressConfirmation}
									label={this.props.content.emailAddressConfirmationQuestion}
									readOnly={this.props.data.isExistingCustomer}
									dataAnchor="confirm-email-address"
									validateEqualTo={this.props.data.emailAddress}
									required
								/>

							</ComponentHeader>
						</SectionFullWidth>

						{/* Preferred Contact Method */}
						<SectionFullWidth>
							<ComponentHeader
								title={this.props.content.contactMethodTitle}
								titleLevel={2}
								hasSeparator
							>

								<p className="intro-paragraph">{this.props.content.contactMethodIntro}</p>

								<DropdownQuestion
									name="preferredContactMethod"
									group={AccountOpeningConstants.GROUP_PAGE_1}
									data={config.formOptionsPreferredContactMethod}
									onChange={this.onPreferredContactMethodChange}
									defaultValue={this.props.data.preferredContactMethod}
									dataAnchor="preferred-contact-method"
									required
								>
									{this.props.content.preferredContactMethodQuestion}
								</DropdownQuestion>
							</ComponentHeader>
						</SectionFullWidth>

						{/* Select Your Bank */}
						{!isExistingCustomer && this.getSelectYourBankQuestion(this.canEditBankSelection())}

						<AdditionalCardHolder
							group={AccountOpeningConstants.GROUP_PAGE_1}
							titleLevel={2}
							onChange={AccountOpeningActions.updateFormValue}
							{...this.props}
						/>

						{this.getPersonaDetailsFoundError()}

						{/* @ticket DGW2-1751 */}
						{(this.props.envConfig.bankId !== 'DYB' || isExistingCustomer) && this.props.data.jointMismatchBankId && <FormRow extraClasses="ja-existing-customer-error"><ErrorMessage text={replaceBankName(this.props.data.bankID, this.props.content.jointAccountIncorrectBankIdExisting)} /></FormRow>}

						{this.props.invalidOnSubmit && <FormRow extraClasses="ja-existing-customer-error"><ErrorMessage text="Some of your details haven't been completed or have been entered incorrectly. Please complete all required fields and correct any errors before you continue." /></FormRow>}

						{/* Continue Application */}
						<SectionFullWidth>
							<BottomNavigationBox
								onClickNext={this.onSubmitPage}
								disabled={!isValid || this.props.appData.isApiCallInProgress}
								nextButtonLabel={this.getNextButtonLabel(this.props.data.isReviewing, this.props.appData.isApiCallInProgress, this.state.isLoadingCredentials)}
								onClickBack={this.onClickBack}
								dataAnchorNext="personal-details-next"
							/>
						</SectionFullWidth>
					</PageColumnWrapper>

					<SideBarColumnWrapper
						appData={this.props.appData}
						content={this.props.content}
						data={this.props.data}
					/>
				</div>
				<LinkCodeModal
					{...this.props}
					onClickNext={this.onSubmitPage}
					getNextButtonLabel={this.getNextButtonLabel}
				/>
			</div>
		);
	},
});

module.exports = PageValidator(PersonalDetailsPage);
