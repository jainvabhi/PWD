'use strict';

window.appContent = (function() {

	var brands = {
		CB: {
			bankName: 'Clydesdale',
			bankCode: 'cb',
			bankWebsite: 'http://www.cbonline.co.uk',
			phoneNumber: '0800 028 3632',
			appendBank: true,
			faqsLink: 'https://help.cybonline.co.uk/system/selfservice.controller?CONFIGURATION=1125&PARTITION_ID=1&CMD=STARTPAGE&USERTYPE=1&isSecure=true&isSecure=true&LANGUAGE=en&COUNTRY=us',
			monetiseLink: 'http://www.cbonline.co.uk/personal/current-accounts/nextsteps/'
		},
		DYB: {
			bankName: 'B',
			bankCode: 'dyb',
			bankWebsite: 'http://www.cbonline.co.uk',
			phoneNumber: '0800 678 3654',
			phoneNumberCC: '0800 678 3320',
			appendBank: true
		},
		YB: {
			bankName: 'Yorkshire',
			bankCode: 'yb',
			bankWebsite: 'http://www.ybonline.co.uk',
			phoneNumber: '0800 028 3632',
			appendBank: false,
			faqsLink: 'https://help.cybonline.co.uk/system/selfservice.controller?CONFIGURATION=1131&PARTITION_ID=1&CMD=STARTPAGE&USERTYPE=1&isSecure=true&isSecure=true&LANGUAGE=en&COUNTRY=us',
			monetiseLink: 'http://www.ybonline.co.uk/personal/current-accounts/nextsteps/'
		}
	};

	var appLinks = {
		ios: {
			link: 'http://itunes.apple.com/app/id1051351437',
			title: 'Get B on the App Store',
		},
		android: {
			link: 'https://play.google.com/store/apps/details?id=co.uk.youandb.android.b',
			title: 'Get B on Google Play',
		},
		amazon: {
			link: 'http://www.amazon.co.uk/gp/mas/dl/android?p=co.uk.youandb.android.b',
			title: 'Amazon App Store',
		},
	}

	var brand = brands.DYB;

	var result = {
		bankName: brand.bankName,
		bankNames: {
			CB: brands.CB.bankName,
			YB: brands.YB.bankName,
			DYB: brands.DYB.bankName,
		},
		bankNameDD: {
			CB: 'Clydesdale Bank PLC',
			YB: 'Yorkshire Bank',
		},
		appLinks: appLinks,
		bankWebsite: brand.bankWebsite,
		phoneNumber: brand.phoneNumber,

		// Product Links
		productLinkIM540: brand.bankWebsite + '/personal/current-accounts/direct/',
		productLinkIM135: brand.bankWebsite + '/personal/current-accounts/current-account-plus/',
		productLinkIM125: brand.bankWebsite + '/personal/current-accounts/current-account-control/',
		productLinkIM800: brand.bankWebsite + '/personal/current-accounts/standard-current-account/',
		productLinkIM136: 'http://www.youandb.co.uk/get-b',
		productLinkCreditCard: 'https://www.youandb.co.uk/credit-card/get-b-credit-card/',

		// Document
		documentTitle: brand.bankName + ' Bank',
		navigationWarning: 'If you refresh or leave this page, you\'ll lose any unsaved progress. Are you sure you want to leave?',

		// Header Logo
		headerLogoAlt: brand.bankName + ' Bank Logo',

		// Side Progress Bar
		sidebarStep1: 'About you',
		sidebarStep2: 'Your money',
		sidebarStep3: 'All systems go',

		// Key Features
		noMonthlyFee: 'There is no monthly fee for this account.',
		noMonthlyFeeOrCharges: 'There are no fees or charges for this account.',
		monthlyFee: 'A Monthly Maintenance Fee of £2 applies to the B banking service and will be applied following a 12 month free period. Full details can be found in your Terms & Conditions and Tariff.',
		variableCreditInterest: 'Variable credit interest is payable on this account on credit balances.',
		noCreditInterest: 'This account doesn\'t pay credit interest.',
		interestUpTo3000: 'Interest is payable on this account on credit balances up to £3000.',
		noUnplannedBorrowing: 'Borrowing is not available on this account. Requests for unplanned borrowing will usually be declined. An item returned unpaid costs £15. Full details can be found in the Borrowing section of your Terms & Conditions and in your Tariff.',
		plannedBorrowing125: 'Planned borrowing is available on this account, subject to eligibility. The cost of this is £6 per month plus interest. Requests for unplanned borrowing will usually be declined. Full details can be found in the Borrowing section of your Terms & Conditions and in your Tariff.',
		plannedBorrowing: 'Borrowing is available on this account, subject to eligibility, and is usually more expensive if not agreed in advance. Planned borrowing costs £6 per month plus interest. Unplanned borrowing costs £6 per day. An item returned unpaid costs £15. Full details can be found in the Borrowing section of your Terms & Conditions and in your Tariff.',
		fscsCovered: 'Your eligible deposits with Clydesdale Bank PLC are protected up to a total of £85,000 per depositor by the Financial Services Compensation Scheme, the UK\'s deposit guarantee scheme. This limit is applied to the total of any deposits you have with Clydesdale Bank, Yorkshire Bank and B. Any total deposits you hold above the limit between these brands are unlikely to be covered. Please see <a href="https://www.youandb.co.uk/resources/b82e172a-b00f-4783-973b-e4399da349e4/201610-fscs_awareness_jan2017_web-int.pdf" target="_blank" title="www.fscs.org.uk. This link will open in a new browser window">FSCS leaflet<span class="screenreader"> This link will open in a new browser window</span></a> for further information or visit <a href="http://www.fscs.org.uk" target="_blank" title="www.fscs.org.uk. This link will open in a new browser window">www.fscs.org.uk<span class="screenreader"> This link will open in a new browser window</span></a>',
		defaultCancellationPolicy: 'You can cancel your agreement with us within 14 days of opening the account, or from the day you receive the Terms & Conditions, if later, by contacting us in branch, by phone or in writing.  You will need to repay any debit balance, interest and fees incurred within 30 days of the date you tell us you want to cancel it.',
		mortgageSaver: 'Both B Current and B Instant Savings accounts are eligible for inclusion in mortgage offsetting arrangements. Any credit balance can be used to set against the debit balance on your Offset Mortgage held with us and so reduce the interest payable on your mortgage. Full details can be found in the Offsetting section of your Terms & Conditions',
		accountClosureInfo: 'If you close all of your B Current accounts, you\'ll no longer have access to the B app (unless you hold another account that the team at B agree can be used to access the app) and your B Instant Savings accounts will be closed or transferred to another instant savings account.',
		caDirectKeyFeature: 'This account requires a minimum deposit of £1000 per month (excluding transfers from other accounts held with us), and that you must register for telephone and internet services and use these for day-to-day banking. Please note, if you fail to meet these criteria, we may change your account to a Current Account Plus which has different interest rates.',
		caDirectKeyFeature2: 'You can have a maximum of 2 Current Account Direct accounts, of which only one may be a sole account.',

		// Key Features B
		keyFeatureRequirements: 'You are applying for both a B Current account and a B Instant Savings account. Both are required to take full advantage of all the features of B.',
		keyFeatureRequirementsB:'You will need both a compatible tablet and compatible mobile phone to access the full range of services available in the B app, though other mobile phones can still be used to receive SMS alerts',
		keyFeatureCreditIterest: 'Credit interest is payable on both the current and the savings account; please refer to your Tariff for rates.',
		keyFeatureTransfer: 'If you want to take money out of your B Instant Savings account, you need to transfer the money into your B Current account first and make your payment from there. You will be able to make transfers from your B Instant Savings account to some other accounts you hold with us',
		keyFeatureNoDirectDebitSavings: 'No standing orders or Direct Debits can be set up on your B Instant Savings account',
		keyFeaturesComplaints: 'We are committed to providing our customers with the best possible service but more information can be found in the Terms & Conditions about what to do if you have a complaint.',
		serviceCommitmentB: 'We are committed to providing our customers with the best possible service but more information can be found in the Terms & Conditions about what to do if you have a complaint. ',
		overdraftFacilityB: 'Borrowing is available on the B Current account, subject to eligibility.  Going overdrawn is usually more expensive if not arranged in advance. Planned borrowing costs £6 per month plus interest. Unplanned borrowing costs £6 per day. An item returned unpaid costs £15. Full details can be found in your Terms & Conditions and in your Tariff. Borrowing is not allowed on the B Instant Savings account.</br>The monthly cap on unarranged* overdraft charges for your B Current account is £100. Further details can be found online at <a href="https://www.youandb.co.uk/the-account/your-overdraft/" target="_blank">https://www.youandb.co.uk/the-account/your-overdraft/</a> </br>*The term \'unarranged\' has the same meaning as \'unplanned\' as explained in your Terms & Conditions and Tariff.',
		packagedAccountOpening: 'Both a current account and a savings account will be opened at the same time so you can take full advantage of all the features of the B app.',
		creditInterestPaid: 'Credit interest is payable on both the current and the savings account; please refer to your Tariff for rates.',
		savingsWithdrawals: 'You can’t make withdrawals directly from your B Instant Savings; you need to first transfer money into your B Current account and make the payment from there. You can transfer money from your B Instant Savings account to your B Current account, or any other account that we allow you to make a transfer into using one of our services. Apart from these transfers, you won’t be able to make payments directly to other accounts from B Instant Savings. No standing orders or Direct Debits can be set up on your B Instant Savings account.',
		creditBalanceMortgage: 'Any credit balance in this account may be used to reduce the debit interest calculated on your mortgage account with us.',
		noticeOfChanges: 'We will usually give you two months’ notice of any changes. The Terms & Conditions detail any that we may make sooner.',

		downgradedOfferPageKeyFeaturesTitle: 'Key features for the',
		downgradedOfferKeyFeaturesParagraph: 'This section contains certain key information relating to this alternative offer of a Readycash Account. Full details are contained in your terms & conditions and tariff attached below which you should read.',

		// Offer Restrictions ReadyCash
		noCheckbook: 'Chequebook facilities.',
		noMortgageOffset: 'The ability to offset against a mortgage product.',
		noLinkedSavings: 'Linked savings account.',
		noBapp: 'The B app.',

		// SideBar
		sideBarTitle: 'Need help?',
		sideBarContentLine1: 'Call us on:',
		sideBarContentLine2: brand.phoneNumber + ',',
		sideBarContentLine3: 'Or if you\'re abroad:',
		sideBarContentLine4: '+44 141 221 7300',
		sideBarContentLine5: 'Monday to Friday 8am - 8pm,',
		sideBarContentLine6: 'Saturday 9am - 5pm, Sunday 10am - 5pm.',

		// Footer
		footerLinkText1: 'Footer Link 1',
		footerLinkUrl1: '/',
		footerLinkText2: 'Footer Link 2',
		footerLinkUrl2: '/',
		footerLinkText3: 'Footer Link 3',
		footerLinkUrl3: '/',
		footerLinkText4: 'Footer Link 4',
		footerLinkUrl4: '/',

		// Landing Page
		landingPagePageHeader: 'Account Opening',
		landingPageTitle: 'You\'re applying for a ',
		'landingPageIntro-current': 'By the time you\'re finished, if all goes to plan, you should be all set up with a B Current account, B Instant Savings account and B Debit Card. You\'ll need to register for Internet and Telephone banking and will also have the option to use the Current Account Switch Service.',
		'landingPageIntro-current-joint': 'By the time you\'re finished, if all goes to plan, you should be all set up with a B Current account, B Instant Savings account and B Debit Card. You\'ll need to register for Internet and Telephone banking and will also have the option to use the Current Account Switch Service.',
		'landingPageIntro1-current': undefined,
		'landingPageIntro1-current-joint': 'Please be aware our online application does not currently offer the ability to arrange an overdraft. If you require an overdraft and are planning to use the Current Account Switch Service, please call us or go into a branch.',
		'landingPageIntro-credit-card': 'Our simple online application includes everything you need to open a B credit card. If everything goes to plan, you should be all set up with B Credit by the time you’re finished.',
		'landingPageIntro1-credit-card': '',
		landingPageQuestionsNote: 'If you’re experiencing difficulties or there are other special circumstances related to your application, then it may be that our Basic Banking Account Readycash may suit your needs better than B. If you think this is the case, please call the team at B on ' + brand.phoneNumber + ' or if you\'re abroad: +44 141 221 7300 or call into one of our branches.',
		'landingPageQuestionsNote-credit-card': '',
		existingCustomerTitle: 'Existing customer?',
		initialQuestionsTitle: 'First, a few questions.',
		initialQuestionsSubtitle: undefined,
		infoToApplyTitle: 'Apply for B',
		'infoToApplyTitle-credit-card': 'Apply for a B credit card ',
		infoToApplyIntro: 'Before you start you\'ll need about 15 minutes and a few facts at your fingertips:',
		infoToApply1: 'Where you\'ve lived',
		'infoToApply1-credit-card': 'Where you\'ve lived for the past three years',
		infoToApply2: 'What you do for a living',
		'infoToApply2-credit-card': 'The name of your employer, how much you get paid and when you started work',
		infoToApply3: 'General information about your income and expenditure',
		'infoToApply3-credit-card': 'How much you usually spend each month',
		infoToApply4: 'General information about your financial history',
		'infoToApply4-credit-card': '',
		isExistingCustomer: 'Have you ever held an account with ' + brand.bankName + ' Bank?',
		isExistingCustomerHelpMessage: 'Even if you held this account in the past, please select Yes.',
		isExistingCustomerValidationMessage: 'Sorry, you can\'t apply online, so please call us instead and apply over the phone. Or, if you prefer, go into a branch and ask for help there.',

		infoToApplyFooter1: 'Great. Let\'s go.',

		// Eligibility Questions
		eligibilityAge18Question: 'Are you 18 or over?',
		eligibilityAge18QuestionValidationMessage: 'You need to be 18 or over to open an account online or apply for a credit card. If you want to sign up for a B account other than a credit card, pop into your local branch of Clydesdale or Yorkshire Bank for a chat.',
		eligibilityAge18QuestionHelpMessage: 'You need to be 18 or over to sign up for a B account online or apply for a credit card. So if you\'re 16 or 17 and want to open an account (other than a credit card) you\'ll need to pop into your local branch of Clydesdale or Yorkshire Bank.',
		eligibilityAge16Question: 'Are you 16 or over?',
		eligibilityAge16QuestionValidationMessage: 'Sorry, but if you\'re under 16 we can\'t offer you this account at the moment. But we do have some other products that might be of interest. Click on the link to find out more: <a href="#">CA Plus</a> &amp; <a href="#">Jumpstart</a>',
		eligibilityAge16QuestionHelpMessage: 'You need to be 16 or over to have a bank account.',

		eligibilityUKResidentQuestion: 'Do you live in the UK?',
		eligibilityUKResidentQuestionValidationMessage: 'We need to ask you a few questions we can\'t cover online. Please give us a call and we\'ll explain what\'s involved.',
		eligibilityUKResidentQuestionHelpMessage: 'You can answer yes if you live in the UK, even if you were born in another country or used to live abroad. Feel free to call us if you\'re unsure about anything.',
		eligibilityDeviceQuestion: 'Got the right device? Are you sure B will work on both your tablet and mobile phone?',
		eligibilityDeviceQuestionValidationMessage: 'You will need both a compatible tablet and a compatible mobile phone to take full advantage of all the features of the B app, though other mobile phones can still be used to receive SMS alerts',
		eligibilityDeviceQuestionHelpMessage: 'For details of the operating systems and example mobile and tablet devices supported by the B app, please visit: <a href="http://www.youandb.co.uk/devices" target="_blank" title="www.youandb.co.uk/devices. This link will open in a new browser window">www.youandb.co.uk/devices <span class="screenreader">This link will open in a new browser window</span></a>.',
		eligibilityHomeownerQuestion: 'Are you a first-time buyer?',
		eligibilityHomeownerQuestionValidationMessage: 'We need to ask you a few questions we can\'t cover online. Please call us and we\'ll talk you through it.',
		eligibilityHomeownerQuestionHelpMessage: 'You can answer ‘Yes’ if you have never owned a property in the UK',
		eligibilityNINOQuestion: 'Do you have a National Insurance Number?',
		eligibilityNINOQuestionValidationMessage: 'We need to ask you a few questions we can\'t cover online. Please call us and we\'ll talk you through it.',
		eligibilityNINOQuestionHelpMessage: 'You can answer ‘Yes’ if you have been issued a National Insurance number',

		// CC
		eligibilityCCJQuestion: 'Have you had a county court judgement or decree in the last three years?',
		eligibilityCCJQuestionValidationMessage: 'Sorry, you can’t apply for a credit card online. Please give us a call for more information.',
		eligibilityCCJQuestionHelpMessage: 'A county court judgement (or decree in Scotland) can be issued if someone takes court action against you because you owe them money. If you’ve had one in the last three years, you can’t apply for a credit card.',
		eligibilityBankruptQuestion: 'Are you currently bankrupt?',
		eligibilityBankruptQuestionValidationMessage: 'Sorry, you can’t apply for a credit card if you’re currently bankrupt.',
		eligibilityBankruptQuestionHelpMessage: 'You won’t be able to apply for a credit card if you’re currently bankrupt.',


		// Terms & Conditions
		eligibilityTermsTitle: 'Using your personal information',
		eligibilityTerms1: 'The information you provide will be used to assess your application and set up and manage your account',
		eligibilityTerms2: 'We\'ll share your information with credit reference agencies to help determine what credit products and services we can provide you – these agencies will use the information for assessing credit applications, debt tracing and prevention of money laundering',
		eligibilityTerms3: 'If false or inaccurate information is provided and fraud is identified, details will be passed to fraud prevention agencies to prevent fraud and money laundering',
		eligibilityTermsClosingText: 'A full description of how and for what purposes your information may be processed, plus further details of how your information is held by fraud prevention agencies, can be found in our {dataProtectionDocLink}. <br><br> Please read and save a copy of this statement for your reference and records. This will also be emailed to you.',
		acceptTsAndCs: 'I agree to the use of the personal information above.',


		// CSAP Error code content
		loginCSAPErrorMessage: 'Hmm. You look familiar. Already started to apply? <a href="https://www.youandb.co.uk/continue-application">Pick up where you left off</a>.',
		authCSAPErrorMessage: 'Hmm. You look familiar. Already got another account with us? <a href="{websiteBaseDirectory}account-opening/authentication?applyFor={productCode}{productVariant}">Verify your details</a> to get started.',
		contactBankCSAPErrorMessage: 'Hmm. You look familiar. Already got another account with us? Get in touch with the team at B and they’ll help get you started.',


		// Step 1 - Your Details
		personalDetailsPageHeader: 'Personal details',
		personalDetailsTitle: 'Now for some form filling',
		personalDetailsGuidance: 'As part of B\'s security measures you aren\'t able to change your details at this stage. But don\'t worry, if anything needs updating please call the team at B on ' + brand.phoneNumber + '.',
		personalDetailsSubtitle: undefined,

		titleQuestion: 'Title',
		titleHelpMessage: 'Please select from the given list.',
		titleValidationMessage: 'Please select from the given list.',
		firstNameQuestion: 'First name',
		firstNameValidationMessage: 'Please use letters and spaces only.',
		firstNameHelpMessage: 'Just using letters and spaces as it appears on your passport or driving licence.',
		hasMiddleNameQuestion: 'Do you have a middle name?',
		hasMiddleNameHelpMessage: 'Just using letters and spaces as it appears on your passport or driving licence.',
		hasMiddleNameValidationMessage: 'Please select an option.',
		middleNameQuestion: 'Middle name',
		middleNameValidationMessage: 'Please use letters and spaces only.',
		lastNameQuestion: 'Last name',
		lastNameValidationMessage: 'Please use letters and spaces only.',
		lastNameHelpMessage: 'Please use your last name as it appears in your passport or driving licence.',
		dateOfBirthQuestion: 'Date of birth',
		dateOfBirthValidationMessage: 'Please enter a valid date using the format DD-MM-YYYY. You need to be 18 or over to open an account online or apply for a credit card.',
		dateOfBirthHelpMessage: 'Click on the calendar icon to select a date or enter it in the format DD-MM-YYYY. You need to be 18 or over to sign up for a B account online or apply for a credit card. If you\'re 16 or 17 and want to open an account (other than a credit card) you\'ll need to pop into a local branch of Clydesdale or Yorkshire Bank to go through your options.',
		genderQuestion: 'Gender',
		genderHelpMessage: 'This is just to help identify you.',
		genderValidationMessage: 'Please confirm if your title and gender are both correct on ' + brand.phoneNumber,
		maritalStatusQuestion: 'Marital status',
		maritalStatusHelpMessage: 'This is just to help identify you.',
		maritalStatusValidationMessage: 'Please select from the given list.',
		hasDependantsQuestion: 'Do you have any dependants?',
		hasDependantsHelpMessage: 'A dependant is anyone who relies on your help and support - a child for instance.',
		hasDependantsValidationMessage: 'Please select an option.',
		personalDetailsFoundValidationMessage: 'It appears you are already a customer. <a href="{websiteBaseDirectory}account-opening/authentication?applyFor={productCode}{productVariant}">Please login to continue</a>.',

		// Step 1 - Addresses
		addressTitle: 'Where do you live?',
		addressContainerErrorMessage: 'We\'ll need your house number too, please tap on \'Find Address\' and select your house from the list',
		addressSubtitle: 'If you\'ve lived at this address for less than three years, you\'ll need to add your other previous addresses too.',
		postcodeQuestion: 'Postcode',
		addressLookupError: 'We were unable to look up your postcode. Please try again or contact us to proceed.',
		addressNoExactMatch: 'Don\'t see your exact address? Contact us to proceed.',
		previousAddressTitle: 'Previous address',
		previousAddressSubtitle: 'We need to know where you\'ve been living for the last 3 years.',
		residentialStatusHelpMessage: 'Choose the option that best describes your situation. For instance, if you pay a mortgage, choose owner.',
		residentialStatusValidationMessage: 'Please select an option from the dropdown list.',
		residentialStatusQuestion: 'Living arrangement',
		dateMovedQuestion: 'When you moved here',
		removeAddressButtonLabel: 'Remove Address',
		postcodeSearchButtonLabel: 'Find address',
		postcodeSearchLegend: 'Postcode',
		selectAddressPlaceholder: 'Please select your address...',
		selectAddressLabel: 'Select your address',
		selectAddressSelectButtonText: 'Select',
		addressesQuestion: 'Postcode',
		addressTypeQuestion: 'Did you live in the UK?',
		addressInvalidMessage: 'Something isn\'t right with your postcode, please contact the team at ' + brand.bankName + ' on ' + brand.phoneNumber,

		// Step 1 - Contact Details
		contactDetailsTitle: 'Now for your contact details',
		contactDetailsIntro: 'Please give the mobile phone number and email address you want to be used in future.',
		phoneNumberQuestion: 'Mobile number',
		phoneNumberValidationMessage: 'This should be 11 characters long and numbers only. No spaces or symbols.',
		phoneNumberHelpMessage: 'This should be 11 numbers long with no spaces or symbols. You must give a mobile number to be able to use the B app in full.',
		emailAddressQuestion: 'Email address',
		emailAddressValidationMessage: 'Hmm. Can you check your email address please? Looks like there\'s a typo in there somewhere.',
		emailAddressHelpMessage: 'We\'ll need your email address to send you important documents like your terms and conditions. If you don\'t want us to contact you by email in the future, just tell us below.',
		emailAddressConfirmationQuestion: 'Confirm email address',
		emailAddressConfirmationValidationMessage: 'Oops. Your email address doesn\'t match what you’ve entered above. Give it another go.',
		emailAddressConfirmationHelpMessage: 'Please type your email address again.',
		contactMethodTitle: 'How would you like to be contacted?',
		contactMethodIntro: 'Tell us how we can get in touch with you. When it comes to security, the team at B will always try to contact you on your mobile. You\'ll never get a request for your login details by email or text.',
		preferredContactMethodQuestion: 'I\'d prefer to be contacted by',
		preferredContactMethodValidationMessage: 'Please select at least one contact method.',
		contactMethodsValidationMessage: 'Please select at least one contact method.',

		// Step 1 - Select Your Bank
		selectBankTitle: 'If you ever need to see us',
		selectBankQuestion: 'Which bank is handy for you?',
		selectBankSubtitle: 'You’ll be able to manage your account online and you can call us too, but we need to know which bank is handy for you in case you ever need to see us in person. Use the links below to find your nearest branch now.',
		bankIDHelpMessage: 'Please select one of the banks, which seems the best fit for your location. Please call us if you\'re not sure.',
		bankIDValidationMessage: 'This is required.',
		selectBankHelpText: 'Let us know whether Clydesdale Bank or Yorkshire Bank is handier for you. You’ll have to visit your local branch to make certain types of transactions, including CHAPS and international payments, or if you want to see us in person.',

		selectBankHelpLinkCb: 'http://www.cbonline.co.uk/personal/online-locator/',
		selectBankHelpLinkCbText: 'Clydesdale Bank Branch Locator',
		selectBankHelpLinkCbTitle: 'Clydesdale Bank Branch Locator link. This link will open in a new browser window',
		selectBankHelpLinkYb: 'http://www.ybonline.co.uk/personal/online-locator/',
		selectBankHelpLinkYbText: 'Yorkshire Bank Branch Locator',
		selectBankHelpLinkYbTitle: 'Yorkshire Bank Branch Locator link. This link will open in a new browser window',

		additionalCardTitle: 'Share the benefits of B Credit',
		additionalCardHolderLabel: 'Would you like to add an additional cardholder to your B Credit account?',
		additionalCardHolderValidationMessage: 'Please select an option.',
		additionalCardHolderIntro: 'With B Credit, you have the option of adding additional cardholders to your credit card account. That means you can authorise someone else, like your partner, to have their own card and buy stuff on your account.',
		additionalCardHolderInfo: 'Great. We’ll send you a form in the post to fill in and send back to us.',

		// Step 1 - Username and Password
		setPasswordTitle: 'Your username and password',
		usernameInfo: 'Make sure your username and password are memorable, as you\'ll need them for internet banking, signing up to the B app and logging on in future. Once you’ve set them, you\'ll also be able to save your application and log back in if you need a break.',
		usernameAdditionalInfo: 'Remember to make a note of your username, as it can\'t be changed and the team at B won\'t be able to remind you of it if you forget it.',
		additionalUsernameInfo: 'Once you\'ve set them you\'ll be able to save your application form and log back in if you need to take a break.',
		usernameQuestion: 'Username (6–16 characters, using letters and numbers only)',
		usernameQuestionExisting: 'Username',
		unsavedUsernameHelpMessage: 'Your username must be 6–16 characters in length, using only letters and numbers. It\'s also case sensitive.',
		unsavedUsernameValidationMessage: ' Your username must be 6–16 characters in length, using only letters and numbers. It\'s also case sensitive.',
		usernameAlreadyInUseValidationMessage: 'Sorry, that username’s already in use. Please try another one.',
		password1Question: 'Password (8–16 characters, with at least one letter, number and symbol)',
		password1QuestionExisting: 'Password',
		password2Question: 'Confirm your password',
		passwordRequirements: 'Your password should be 8-16 characters long with at least one letter, number and symbol. It\'s case sensitive too.',
		password1HelpMessage: 'Your password should be 8–16 characters long with at least one letter, number and symbol. It\'s case sensitive too.',
		password1ValidationMessage: 'It needs to be tougher than that. Your password should be 8–16 characters long with at least one letter, number and symbol. It\'s case sensitive too.',
		password2HelpMessage: 'Your password should be 8-16 characters long with at least one letter, number and symbol. It\'s case sensitive too.',
		password2ValidationMessage: 'Oops. Your passwords don\'t match. Please have another go.',
		passwordDisclaimer: 'If you have to leave the application for any reason and want to save and log back in later, you can use the same password to login. This password will also be the one you use to sign up to the B app.',
		passwordLastWarning: 'Never give your security details to anyone either in person, by email or by text. Clydesdale or Yorkshire Bank will never email or text you asking for username or password, or for details of your accounts or cards.',

		// Employment Details
		employmentDetailsHeader: 'Employment details',
		employmentDetailsTitle: 'Employment details',
		employmentSectionTitle: 'You and your money',
		employmentSectionSubtitle: undefined,

		employmentStatusQuestion: 'Job status',
		employmentStatusHelpMessage: 'Choose an option that best describes your job.',
		employmentStatusValidationMessage: 'Please select from the given list.',
		employmentOccupationHelpMessage: 'Which occupation is closest to yours?',
		employmentOccupationValidationMessage: 'Please select from the given list.',
		employmentStartDateQuestion: 'When did you start work there?',
		employmentStartDateValidationMessage: 'Sorry, that date doesn’t seem right. Please check it and try again.',
		employmentStartDateHelpMessage: 'Click on the calendar icon to select a date or enter it in the format DD-MM-YYYY',
		employmentEmployerNameQuestion: 'Employer\'s name',
		employerNameValidationMessage: 'Oops. You missed one. Please fill this in to keep going.',
		employerNameHelpMessage: 'This should be the same as it appears on your payslip. If you work for yourself, just put your own name here.',

		// Employment Details - Nationality
		nationalityTitle: 'Where are you from?',
		nationalityQuestion: 'Your nationality',
		nationalityHelpMessage: 'Please select your country of nationality.',
		nationalityValidationMessage: 'Please select from the given list.',
		cityBorn: 'City or town where you were born?',
		cityBornValidationMessage: 'Letters and spaces only. No numbers or characters.',
		cityBornHelpMessage: 'As it\'s written on your birth certificate or passport.',
		countryBorn: 'Country where you were born?',
		countryBornHelpMessage: 'As it\'s written on your birth certificate or passport.',
		countryBornValidationMessage: 'Please select from the given list.',
		ukCitizen: 'Are you a UK citizen?',
		ukCitizenHelpMessage: 'If you have a UK passport you definitely have UK citizenship. If you have a visa and you’re not sure if it covers citizenship, call the team at B on ' + brand.phoneNumber + '.',
		ukCitizenValidationMessage: 'Please select an option.',

		hasAdditionalCitizenships: 'Are you a citizen of any other countries?',
		hasAdditionalCitizenshipsValidationMessage: 'If you\'re not a UK citizen, please tell us where you\'re from.',
		hasAdditionalCitizenshipsHelpMessage: 'If you\'re a legally registered citizen of another country please tell us below.',
		citizenshipListQuestion: 'What country or countries?',
		citizenshipListValidationMessage: 'Please select a country from each of the additional citizenship options you\'ve selected.',

		// Employment Details - Tax
		taxObligationsTitle: 'Now for your tax status',
		taxStatusIntro: 'Don\'t worry, this information won\'t be shared. If you\'re not sure about anything call the team at B on ' + brand.phoneNumber + '.',
		hasNoTaxOligations: 'Are you a UK tax resident only?',
		hasNoTaxOligationsHelpMessage: 'Choose "no" if you are not a UK tax resident OR if you have tax obligations in any country in addition to the UK.',
		hasNoTaxOligationsValidationMessage: 'Please select an option.',
		taxCountryHelpMessage: 'Which country(ies) do you have a tax obligation in? Please ensure you include details of all countries of tax residency, including the UK',
		taxNumberHelpMessage: 'This is a code or number that is associated with your tax obligation, usually issued by the tax authority of your country of tax residence. It is mandatory that, if your country of tax residency does issue a tax ID number or equivalent, you must provide this for the country entered. If you do not know what this is, or do not have a tax ID for other reasons,  please call us.',
		allTaxObligationsListed: 'I confirm that I have no tax obligations other than in the countries listed above.',
		allTaxObligationsListedValidationMessage: 'Please list all the ways you\'re liable for tax.',
		allTaxObligationsListedHelpMessage: 'If you\'ve got a tax obligation that doesn\'t fit these options, please call us.',
		taxObligationListValidationMessage: 'Please list all the ways you\'re liable for tax.',
		taxNumberNA: 'Country of Tax Residency does not issue a Tax ID number',
		taxNumberMissing: 'I do not have my Tax ID Number here',
		taxObligationsListCountryFieldName: 'Country of tax residency',
		taxObligationsListHasTaxNumberFieldName: 'Does your country of tax residency issue a tax ID number?',
		taxObligationsListTaxNumberName: 'Tax ID',
		taxNumber0ValidationMessage: 'Letters and numbers only (no symbols or punctuation)',
		taxNumber1ValidationMessage: 'Letters and numbers only (no symbols or punctuation)',
		taxNumber2ValidationMessage: 'Letters and numbers only (no symbols or punctuation)',
		taxNumber3ValidationMessage: 'Letters and numbers only (no symbols or punctuation)',
		taxNumber4ValidationMessage: 'Letters and numbers only (no symbols or punctuation)',

		// Employment Details- Income
		incomeSectionTitle: 'Money coming in',
		incomeIntro: 'We use this information to work out your credit limit so make sure it’s as accurate as possible.',
		grossAnnualIncome: 'Roughly how much do you earn a year before tax?',
		grossAnnualIncomeValidationMessage: 'Keep it simple please. No dots, commas or even a £.',
		grossAnnualIncomeHelpMessage: 'If you\'re working, enter your annual salary before tax. Otherwise, just enter zero.',
		netMonthlyIncome: 'Approximately how much goes into your bank account a month after tax?',
		incomeSectionCurrentAccountSubtitle: 'Current Account Details',
		incomeSectionSavingsAccountSubtitle: 'Saving up',
		incomeSectionSavingsAccountIntro: 'Imagine you could put some money aside to do more of the things you\'ve always wanted to do.',
		netMonthlyIncomeValidationMessage: 'Keep it simple please. No dots, commas or even a £. Your monthly income shouldn’t be more than your annual income divided by 12.',
		netMonthlyIncomeHelpMessage: 'This is the amount you receive each month after tax and deductions. It can include your salary, pension and any state benefits (such as Disability Living Allowance, Personal Independence Payment, Carer’s Allowance and Reduced Earnings Allowance). If your income goes up and down, just type in an average.',
		hasAdditionalIncome: 'Aside from the above, do you bring in extra income from anything else?',
		hasAdditionalIncomeValidationMessage: 'Please select an answer.',
		hasAdditionalIncomeHelpMessage: 'You might get rent in from somewhere or maybe you get interest from investments? If it\'s something that you declare on your tax returns, you should add it here.',
		incomeOtherAmount: 'What does that extra income add up to over a year?',
		incomeOtherAmountValidationMessage: 'Please estimate how much extra income you earn a year, not including your salary.',
		incomeOtherAmountHelpMessage: 'Try to come up with a rough estimate that doesn\'t include your salary.',
		incomeOtherFrequency: 'That money tends to come in',
		incomeOtherFrequencyOptionsValidationMessage: 'Please select one of the options.',
		incomeOtherFrequencyOptionsHelpMessage: 'It\'s possible that income might come unpredictably or at different times. If there is an option that makes sense for the majority of your payments, please choose it. Otherwise, please call us.',

		incomeOtherSavingsAmount: 'How much might you be able to put away a year?',
		incomeOtherSavingsAmountValidationMessage: 'Put in a whole number please, without spaces or commas. For example 5000.',
		incomeOtherSavingsAmountHelpMessage: 'Tell us an overall amount you hope to save annually. If you\'re not sure, add in a realistic number, perhaps based on previous savings habits.',
		incomeOtherSavingsFrequency: 'How often would you like to put money aside?',
		incomeOtherSavingsFrequencyHelpMessage: 'If you\'re not sure, pick an interval that seems most likely. This is just to get you started.',
		incomeOtherSavingsFrequencyValidationMessage: 'Please select from given list.',

		incomeOtherPaymentAmount: 'How much will you pay in each month?',
		incomeOtherPaymentAmountValidationMessage: 'Put in a whole number please, without spaces or commas. For example 3000.',
		incomeOtherPaymentAmountHelpMessage: 'This is an overall monthly figure which indicates how much income you plan to pay into your new account.',
		incomeOtherAccountPurpose: 'What is your main reason for having an account with B?',
		incomeOtherAccountPurposeHelpMessage: 'Please select the main reason for having this account. If there are a few reasons there that make sense to you, just pick one you know is important.',
		incomeOtherAccountPurposeValidationMessage: 'Please select an answer.',
		incomeOtherPaymentType: 'What will you pay into B? Will it be your salary or another source of income?',
		incomeOtherPaymentTypeOptionsHelpMessage: 'Choose the option that feels the most relevant one to you. This should incorporate all your income sources.',
		incomeOtherPaymentTypeOptionsValidationMessage: 'Please select one of the options.',

		'hasIncomeReduction-current': 'As far as you’re aware, is your income likely to go down in the future?',
		'hasIncomeReduction-credit-card': 'As far as you’re aware, is your income likely to go down in the future?',
		hasIncomeReductionHelpMessage: 'We need to make sure you can still afford your credit card payments if your income goes down. So let us know if you’re aware of anything that could reduce your income, such as going part-time or getting your state benefits reduced.',
		hasIncomeReductionValidationMessage: 'Please select an option.',
		revisedGrossAnnualIncome: 'How much will you earn a year if your income goes down?',
 		revisedGrossAnnualIncomeHelpMessage: 'This would be your annual salary before tax.',
		revisedGrossAnnualIncomeValidationMessage: 'Keep it simple please. No dots, commas or even a £.',
		revisedNetMonthlyIncome: 'How much will go into your bank account a month if your income goes down?',
		revisedNetMonthlyIncomeValidationMessage: 'Keep it simple please. No dots, commas or even a £. Your monthly income shouldn’t be more than your annual income divided by 12.',
		revisedNetMonthlyIncomeHelpMessage: 'This would be the amount you’d receive each month after taxes and other deductions.',

		// Employment Details - Expenses
		expenditureSectionTitle: 'And money going out',
		mortgageOrRentExpenditure: 'How much do you pay a month on the mortgage or rent?',
		mortgageOrRentExpenditureValidationMessage: 'Type in a whole number, for example 1200. And keep it simple please. No dots, commas or even a £.',
		mortgageOrRentExpenditureHelpMessage: 'Just the basic figure, not extras like council tax, heating bills or service charges.',
		expenditureOther: 'Roughly how much do you pay out a month on personal loans, credit cards and hire purchase agreements?',
		expenditureOtherValidationMessage: 'Keep it simple please. No dots, commas or even a £.',
		expenditureOtherHelpMessage: 'The amount you enter here should be the total monthly amount you pay on any personal loans, credit cards and hire purchase agreements.',

		'changeOfCircumstances-current': 'As far as you’re aware, is the money you pay out likely to go up in the future?',
		'changeOfCircumstances-credit-card': 'As far as you’re aware, is the money you pay out likely to go up in the future?',

		changeOfCircumstancesHelpMessage: 'We need to make sure you can still afford your credit card payments if your other bills go up. So let us know if you’re aware of anything that could increase your outgoings, like your mortgage or rent payments going up.',
		changeOfCircumstancesValidationMessage: 'Please select an option.',
		'revisedMortgageOrRentExpenditure-current': 'How much will you pay a month on the mortgage or rent if your payments go up?',
		'revisedMortgageOrRentExpenditure-credit-card': 'How much will you pay a month on the mortgage or rent if your payments go up?',
		revisedMortgageOrRentExpenditureHelpMessage: 'If your mortgage or rent is going to increase, let us know what the new payment will be.',
		revisedMortgageOrRentExpenditureValidationMessage: 'Type in a whole number, for example 1200. And keep it simple please. No dots, commas or even a £.',
		'revisedExpenditureOther-current': 'How much will you pay out a month on personal loans, credit cards and hire purchase agreements if your payments go up?',
		'revisedExpenditureOther-credit-card': 'How much will you pay out a month on personal loans, credit cards and hire purchase agreements if your payments go up?',
		revisedExpenditureOtherHelpMessage: 'If your other payments are going to increase, let us know what the new amount will be.',
		revisedExpenditureOtherValidationMessage: 'Keep it simple please. No dots, commas or even a £.',

		// Bank details
		bankDetailsTitle: 'Your bank details',
		bankDetailsIntro: 'Tell us about your main bank account. Don’t worry, this information won’t be shared. It’s just so we can complete our credit checks.',
		bankDetailsAccountNumber: 'Account number',
		bankDetailsAccountNumberHelpMessage: 'Enter the eight-digit account number of the bank account your salary, pension or benefits are paid into.',
		bankDetailsAccountNumberValidationMessage: 'Oops, something’s not right there. Check your account number and try again.',
		bankDetailsSortCode: 'Sort code',
		bankDetailsSortCodeHelpMessage: 'Enter the six-digit sort code of the bank account your salary, pension or benefits are paid into.',
		bankDetailsSortCodeValidationMessage: 'Oops, something’s not right there. Check your sort code and try again.',
		lengthOfTimeAtBank: 'How long have you had this account?',
		lengthOfTimeAtBankValidationMessage: 'Please select from the given list.',
		lengthOfTimeBankMonthsValidationMessage: 'Please select from the given list.',
		lengthOfTimeBankYearsValidationMessage: 'Please select from the given list.',
		bankDetailsLookupError: 'Hmm. We can’t find a bank account matching those details. Make sure you’ve entered your sort code and account number correctly then try again. If it still doesn’t work, give us a call on  ' + brand.phoneNumber + '.	',

		// Direct debit
		directDebitTitle: 'Set up a Direct Debit',
		setUpDirectDebitIntro: 'You can set up a Direct Debit now so your credit card payments are made automatically each month and you’ll never forget to pay. We’ll still let you know how much you owe and when it’s due on your monthly statement.',
		setUpDirectDebit: 'Do you want to set up a Direct Debit?',
		setUpDirectDebitHelpMessage: 'If you set up a Direct Debit, your credit card payments will be made automatically every month.',
		setUpDirectDebitValidationMessage: 'Please select an option.',
		useBankDetails: 'Do you want to use the bank details you just told us about for your Direct Debit?',
		useBankDetailsHelpMessage: 'We can use the bank details you’ve given us for your main bank account or you can give us the details for another account.',
		useBankDetailsValidationMessage: 'Please select an option.',
		directDebitAccountName: 'Account holder name',
		directDebitAccountNameHelpMessage:'This is the name that’s shown on your bank statements or debit cards for the bank account you\'re using to set up your Direct Debit, for example Mr and Mrs Smith or John Brown.',
		directDebitAccountNameValidationMessage: 'Oops, something\'s not right there. Give it another try, using letters, spaces and hyphens only. If the name on your account\'s longer than 18 characters, try using a shortened version with initials or abbreviations.',
		directDebitAccountNumber: 'Account number',
		directDebitAccountNumberHelpMessage: 'Enter the eight-digit account number of the bank account you want your Direct Debit to come out of.',
		directDebitAccountNumberValidationMessage: 'Oops, something’s not right there. Check your account number and try again.',
		directDebitSortCode: 'Sort code',
		directDebitSortCodeHelpMessage: 'Enter the six-digit sort code of the bank account you want your Direct Debit to come out of.',
		directDebitSortCodeValidationMessage: 'Oops, something’s not right there. Check your sort code and try again. ',

		howToPay: 'How would you like to pay?',
		howToPayHelpMessage: 'This is the amount that the Direct Debit will take from your account. You can pay the full balance or minimum payment, or you can enter a fixed amount on your own.',
		howToPayValidationMessage: 'Please select an option.',
		directDebitPaymentAmount: 'Fixed amount',
		directDebitPaymentAmountHelpMessage: 'Enter the fixed amount you’d like to pay in full pounds, without any dots, commas or even a £ (for example, 25 not £25.00). If your minimum payment is ever more than your fixed amount, we’ll collect the minimum payment that month.',
		directDebitPaymentAmountValidationMessage: 'Oops, something’s not right there. Enter a whole number greater than zero, without any dots, commas or even a £.',
		directDebitPaymentDates: 'When would you like to make your credit card payment each month?',
		paymentDateHelpMessage: 'When you have a balance on your B credit card, you’ll have to make payments by a certain date – this is called your ‘payment due date’. Let us know roughly when you’d like your payment due date to be each month.',
		paymentDateValidationMessage: 'Please select from the given list.',
		directDebitAcceptTsAndCs: 'By agreeing to make payments by Direct Debit, I confirm I’ve got the authority to set up Direct Debits for the above account and the details I’ve provided are correct',
		directDebitAcceptTsAndCsValidationMessage: 'Before you continue, please confirm you have the authority to set up Direct Debits for the above accounts and that the details you\'ve provided are correct.',

		// Review Page
		reviewPageHeader: 'Review',
		reviewTopTitle: 'Review and submit your application',
		reviewTopSubtitle: 'Almost there. Now for a quick review.',
		reviewTopParagraph: 'Please double-check your details are all correct in the summary below. You’ll be able to edit some yourself but if anything’s not quite right, call the team at B on ' + brand.phoneNumber + ' and ask them to make changes for you.',

		reviewTopTermsParagraph: 'Please read all the important information below. It includes Key Features, Terms & Conditions and Tariff details.',
		'reviewTopTermsParagraph-credit-card': 'When you’re ready, accept the declaration and authorisation then submit your application. We’ll take care of the rest.',
		reviewPageTitle: 'Review and submit your application',

		reviewPersonalDetailsTitle: 'Your details',
		reviewSectionPersonalTitle: 'About you',
		reviewSectionContactTitle: 'Contact details',
		reviewSectionNationalityTitle: 'Where you are from',
		reviewEmploymentDetailsTitle: 'Employment details',
		reviewSectionEmploymentTitle: 'Employment details',
		reviewSectionIncomeTitle: 'Your money',
		reviewSectionOutgoingsTitle: 'Money out',
		reviewTermsDocumentsTitle: 'Documents for you to read and save',
		reviewTermsDocumentsParagraph: 'We will also email you these documents after you have opened a ',
		reviewImportantInformationTitle: 'Important information',


		reviewKeyFeaturesTitle: 'Key features for the',
		reviewOfferRestrictionsTitle: 'This offer doesn\'t include:',
		reviewAcceptTsAndCs: 'By ticking this box and clicking "Submit" this represents my signature confirming that:',

		//  Overdrafts
		requiresOverdraft: 'Are you thinking about taking out an overdraft?',
		requiresOverdraftHelpMessage: 'An overdraft lets you borrow money through your account to help with day-to-day costs – and that can come in handy every now and then. Thinking about taking one out? Choose yes to get more info about rates and charges plus other things you should consider. Once you’ve read this, you can decide if you want to apply for an overdraft online now. ',
		requiresOverdraftValidationMessage: 'Please select an option.',
		applyingForOverdraft: 'Want to apply for an overdraft now?',
		applyingForOverdraftHelpMessage: 'Want to apply for an overdraft? You can do it right now as part of this application. When you apply, you’ll get more details plus the overdraft facility agreement you’ll need to agree to.',
		applyingForOverdraftValidationMessage: 'Please select an option',
		overdraftLimit: 'How much of an overdraft would you like (in multiples of £50)?',
		overdraftLimitHelpMessage: 'This is the overdraft limit you want to arrange with the team at B. Enter a whole number (in multiples of 50) without spaces or commas (for example, 250 or 500).',
		overdraftLimitValidationMessage: 'Oops, something’s not right there. Please enter a valid overdraft limit. This should be 5000 or less and in multiples of 50. It also has to be a whole number, without spaces, commas or even a pound sign.',
		overdraftInformationIntro: 'You can apply for an Overdraft facility with your current account. This type of overdraft is called Planned Borrowing. An overdraft provides you with immediate funds to assist with day to day operating costs and allows you to borrow up to an agreed limit when there is no money left in your account. There is no fixed end date however we can withdraw this at anytime but  we wouldn’t cancel this without letting you know.',
		overdraftInformationInterestSectionTitle: 'Interest Rates & Charges',
		overdraftInformationInterestSectionIntro: 'If you use your overdraft at anytime during the month, the following charges will apply:',
		overdraftInformationInterestSectionBullet1: 'Planned Borrowing Debit interest {earOverdraft}% EAR',
		overdraftInformationInterestSectionBullet2: 'Monthly Planned Usage Fee of £{monthlyPlannedBorrowingFee}',
		overdraftInformationInterestSectionParagraph1: 'The monthly planned usage fee will be charged once every calendar month if you end any business day in Planned Borrowing by more than the £25.00 Planned Borrowing Buffer Amount (unless you’re over that amount because of fees or interest that have been added by us) and you’ve gone over the Monthly Planned Usage Fee Grace Period.',
		overdraftInformationInterestSectionParagraph2: 'The total cost of the Overdraft will depend on how much you use, and for how long. We will notify you in advance of the charges that will be applied.',
		overdraftInformationInterestSectionParagraph3: 'For more information on our interest rates and charges (<a href="https://www.youandb.co.uk/the-account/your-overdraft/" target="_blank" title="www.youandb.co.uk/the-account/your-overdraft/. This link will open in a new browser window">link to the tariff<span class="screenreader"> This link will open in a new browser window</span></a>)',
		overdraftInformationInterestSectionParagraph4: 'We may ask you to provide evidence of your income',
		overdraftInformationExampleTitle: 'Representative example:',
		overdraftInformationExampleIntro: 'If you have an overdraft facility with a limit of £1,200 and you use all of this, you will be charged interest at {earOverdraft}% EAR* (Variable) and a monthly planned usage fee of £6.00.',
		overdraftInformationExampleSubscript: '*The Effective Annual Rate is used to express the cost of borrowing on current accounts. The EAR takes account of the rate of interest charged, the frequency it is levied to accounts and compounding of interest. It does not include overdraft fees and is variable.',
		overdraftInformationExampleFooter: 'If you choose to apply for an overdraft, you will be provided with further details and the overdraft facility agreement that you will need to agree to.',
		overdraftInformationNeedToKnowSectionBullet1: 'You may be charged if you go over your overdraft limit',
		overdraftInformationNeedToKnowSectionBullet2: 'We can ask for the money back at any time',
		overdraftOfferAcknowledge: 'To proceed you will need to read and acknowledge the Overdraft Key Features and  read and agree to the Overdraft Facility Agreement on screen. We have emailed you copies too.',

		overdraftConditionalParagraph1: 'You can open the account today without the overdraft facility in place by selecting <strong>\"Open account without overdraft\"</strong> or you can go ahead and upload your <a class="document-upload-link" href="https://send.cbonline.co.uk" target="_blank" title="send.cbonline.co.uk. This link will open in a new browser window">documents online<span class="screenreader"> This link will open in a new browser window</span></a> now or take them along to your nearest branch.',
		overdraftConditionalParagraph2: 'You will get an email that explains how to do this. After we\'ve verified your income (we\'ll need two working days to do this) we\'ll send you an email or text to log in and see your decision.',
		overdraftConditionalParagraph3: 'I confirm that by clicking the <strong>“Open account without overdraft”</strong> button this represents my signature and that I am opening an account and reconfirm my authority previously provided.',
		overdraftConditionalParagraph4: 'Need any help?<br />We are open monday to Sunday, 8am to 10pm, and calls from mobiles and landlines are free. Call us on 0800 678 3654. If you wish an overdraft a later date give us a call 0800 678 3654 when you wish to arrange it.',

		overdraftOpenAccountOnly: 'Open account without overdraft',
		overdraftOpenAccountWithOverdraft: 'Yes, open my account and apply overdraft',
		overdraftOpenAccountWithoutOverdraft: 'Open my account only',
		overdraftsSuccessfulOffer: 'You can open B with an overdraft of:<br />{amount}',
		overdraftsConditionalOfferSuffix: '<br />However, we need your proof of income',
		overdraftsFullOffer: 'The overdraft limit we can offer you:<br />{amount}',
		overdraftsReducedOffer: 'The maximum overdraft limit we can offer you is:<br />{amount}',
		overdraftsDeclinedOffer: 'We can offer you B',
		overdraftsDeclineCreditAgency: 'We use a Credit Scoring System and information from credit reference agencies, Experian and Callcredit, to ensure we assess all credit applications fairly and consistently. You can request a copy of your report from the credit reference agencies by clicking on the link below. If you think there are special circumstances related to your application, you can call us to discuss it on' + brand.phoneNumber + '. Lines are open Monday to Friday 08:00 to 20:00, closed on Saturday and Sunday.',

		// Review page labels - capital LABEL so last section can match up to name of the form element
		reviewLabelsectionPersonalDetails: 'Personal details',

		reviewLabeltitle: 'Title',
		reviewLabelfirstName: 'First name',
		reviewLabelmiddleName: 'Middle name',
		reviewLabellastName: 'Last name',
		reviewLabeldateOfBirth: 'Date of birth',
		reviewLabelgender: 'Gender',
		reviewLabelmaritalStatus: 'Marital status',
		reviewLabeldependants: 'No. of dependants',
		reviewLabeladdresses: 'Address',
		reviewLabelresidentialStatus: 'Residential status',
		reviewLabeldateMoved: 'Date moved',
		reviewLabelPreviousaddresses: 'Previous address',

		reviewLabelsectionContactDetails: 'Contact details',

		reviewLabelemailAddress: 'Email address',
		reviewLabelpreferredContactMethod: 'Preferred contact method',
		reviewLabelphoneNumber: 'Mobile number',

		reviewLabelsectionCardDetails: 'Share the benefits of B Credit',
		reviewLabelAdditionalCard: 'Would you like to add an additional cardholder?',

		reviewLabelsectionNationality: 'Nationality',

		reviewLabelnationality: 'Nationality',
		reviewLabelcountryBorn: 'Country of birth',
		reviewLabelcityBorn: 'City of birth',
		reviewLabelukCitizen: 'UK citizen',
		reviewLabelAdditionalCitizenship: 'Citizen of any other countries',
		reviewLabelcitizenshipList: 'Other countries you’re a citizen of',
		reviewLabeltaxObligations: 'Additional tax obligations',
		reviewLabelallTaxObligationsListed: 'All tax obligations listed',


		reviewLabelsectionEmployment: 'Employment details',

		reviewLabelemploymentStatus: 'Employment status',
		reviewLabelemploymentOccupation: 'Occupation',
		reviewLabelemployerName: 'Employer name',
		reviewLabelemploymentStartDate: 'Start date',

		reviewLabelsectionIncome: 'Income',

		reviewLabelgrossAnnualIncome: 'Gross annual income',
		reviewLabelnetMonthlyIncome: 'Net monthly income',
		reviewLabelincomeOtherAmount: 'Additional income',
		reviewLabelincomeOtherFrequencyOptions: 'Frequency',

		reviewLabelsectionCA: 'Current Account',

		reviewLabelincomeOtherAccountPurpose: 'Account purpose',
		reviewLabelincomeOtherPaymentTypeOptions: 'Account use for',
		reviewLabelincomeOtherPaymentAmount: 'Monthly pay in',

		reviewLabelsectionSA: 'Savings Account',

		reviewLabelincomeOtherSavingsAmount: 'Pay in amount',
		reviewLabelincomeOtherSavingsFrequency: 'Frequency',

		reviewLabelsectionOutgoings: 'Outgoings',

		reviewLabelmortgageOrRentExpenditure: 'Mortgage or rent',
		reviewLabelexpenditureOther: 'Other payments',

		reviewLabelRevisedMortgageOrRentExpenditure: 'Revised mortgage or rent',
		reviewLabelRevisedExpenditureOther: 'Revised other payments',
		reviewLabelRevisedNetMonthlyIncome: 'Revised monthly income',
		reviewLabelRevisedGrossAnnualIncome: 'Revised annual income',

		reviewLabelsectionBankDetails: 'Bank details',

		reviewLabelMainBankAcNo: 'Account number',
		reviewLabelMainBankSortCode: 'Sort code',
		reviewLabelMainBankLengthAtBank: 'How long you\'ve had this account ',
		reviewLabelMainBankPaymentDate: 'Payment due date',

		reviewLabelsectionDirectDebit: 'Direct Debit instruction',

		reviewLabelDDSetup: 'Do you want to set up a Direct Debit?',

		reviewLabelDDName: 'Name(s) of account holder(s)',
		reviewLabelDDAccountNo: 'Bank/building society account number',
		reviewLabelDSortCode: 'Sort code',
		reviewLabelDDBankName: 'Bank/building society name',
		reviewLabelDDBankAddress: 'Bank/building society address',
		reviewLabelDDBankPostCode: 'Bank/building society postcode',

		// Review DD section
		debitReviewCheckBoxLabel: 'By ticking this box you confirm that the account details shown above are correct and that you have authority to set up Direct Debits',
		debitReviewParagraph2: 'A Direct Debit for the {paymentAmount} payment will be collected each month from the bank account detailed below. We will inform you of the payment amount and date to be collected by Direct Debit on your monthly statement',
		debitReviewParagraph3: 'If you would prefer to make payments from a different bank account, you can change this later by giving us a call on ' + brand.phoneNumberCC + '.',
		debitReviewSubTitle: 'Instruction to your bank or building society to pay by Direct Debit',
		debitReviewParagraph4: 'Please pay {bankName} Direct Debits from the account detailed in this instruction, subject to the safeguards assured by the Direct Debit Guarantee.',
		debitReviewParagraph5: 'I understand that this instruction may remain with {bankName} and, if so, details will be passed electronically to my bank/building society.',
		debitReviewParagraph6: 'You will receive confirmation of the Direct Debit set up by email within three working days.',
		debitReviewParagraph7: 'Your Direct Debit will show on your statement as B credit card.',
		debitReviewParagraph8: 'Need help? Contact us 24 hours a day, seven days a week on ' + brand.phoneNumberCC + '. Or write to us at:',
		debitReviewAddress: 'Clydesdale Bank<br>PO Box 4509<br>Leeds<br>LS2 8NP',

		debitGuaranteeHeader: 'The Direct Debit Guarantee',
		debitGuaranteeItem1: 'This Guarantee is offered by all banks and building societies that accept instructions to pay Direct Debits.',
		debitGuaranteeItem2: 'If there are any changes to the amount, date or frequency of your Direct Debit {bankName} will notify you 10 working days in advance of your account being debited or as otherwise agreed. If you request {bankName} to collect a payment, confirmation of the amount and date will be given to you at the time of the request.',
		debitGuaranteeItem3: 'If an error is made in the payment of your Direct Debit, by {bankName} or your bank or building society, you are entitled to a full and immediate refund of the amount paid from your bank or building society',
		debitGuaranteeItem3b: 'If you receive a refund you are not entitled to, you must pay it back when {bankName} asks you to.',
		debitGuaranteeItem4: 'You can cancel a Direct Debit at any time by simply contacting your bank or building society. Written confirmation may be required. Please also notify us.',

		// DGS Documents
		reviewAcceptSaDgs: 'Yes, I agree to the Savings Account Deposit Guarantee Scheme',
		reviewAcceptCaDgs: 'Yes, I agree to the Current Account Deposit Guarantee Scheme',


		// Marketing Prefs
		marketingPrefsTitle: 'Marketing stuff',
		marketingPrefsText: 'When we have new stuff we think you’d find useful, we’d like to tell you about it. If that’s okay with you, let us know the best way to do that here. We should say, whatever you choose will replace anything you’ve already told us about this (like if you said phone before but say email now).',
		marketingPrefsSmsDYB: '',

		// declaration and auth
		declarationAndAuthTitle: 'Declaration and authorisation',
		declarationAndAuthText: 'By ticking this box and clicking submit, I confirm that this represents my signature and confirm that:',
		declarationAndAuthBullet1: 'I wish to apply for this credit card',
		declarationAndAuthBullet2: 'I authorise you to undertake any necessary searches and credit checks required to validate this application',
		declarationAndAuthBullet3: 'I agree to you sending me documentation by email (which may incorporate a PDF or other attachment) to the address I provided',

		// Letter Code
		letterCodePageTitle: 'Authorisation Code',
		letterCodePageHeader: 'Enter your 10-digit authorisation code to complete your application',
		letterCodePageUnhappyHeader: 'Sorry, but we couldn’t confirm all your details',
		letterCodePageUnhappyExplaination: 'Just to be extra secure, we’ve sent a letter with an authorisation code to your home address. When you get it, you’ll be able to use the code to continue your application.',
		letterCodeLabel: 'Authorisation Code',
		letterCodeValidationMessage: 'This code should be 10 digits long and should only contain numbers.',
		letterCodeInputHelpText: 'You should have received a letter from us with your 10-digit code. Didn’t get the letter? Give us a call on ' + brand.phoneNumber,
		letterCodeErrorInvalid: 'Oops, that’s the wrong code. The code should be 10 digits long and should only contain numbers. Please try again.',
		letterCodeLimitError: 'Oops, it looks like this authorisation code isn’t working. Give us a call on ' + brand.phoneNumber + ' and we’ll get things moving again.',
		lettercodeError: 'You have entered the wrong authorisation code. Please try again.',
		letterCodeSubmitBtn: 'Resume your application',
		lettercodeFooter: 'Need any help? Give us a call on ' + brand.phoneNumber + '. We’re open Monday to Friday 8am - 8pm, Saturday 9am - 5pm, Sunday 10am - 5pm, and calls from mobiles and landlines are free.',

		// Offer Page
		offerItemCurrentAndSavingsAccounts: 'Both a B Current Account and a B Instant Savings account.',
		offerItemSelfService: 'Access to the B app',
		offerItemWithInterest: 'Ongoing 2% AER (variable) interest on balances up to £3000',
		offerItemDebitContactless: 'A Debit Mastercard for your B Current account with contactless functionality as well as allowing you to withdraw cash at any UK ATM, subject to available funds. We will tell you your daily withdrawal limit when we send you your B debit card.',
		offerItemDebitContactlessOverdraft: 'A Debit Mastercard for your B Current account with contactless functionality as well as allowing you to withdraw cash at any UK ATM. We will tell you your daily withdrawal limit when we send you your B debit card.',
		offerItemDebitContactlessLimited: 'A Debit Mastercard Online Only card for your B Current Account with Contactless functionality allowing you to withdraw up to £350 a day at any UK ATM, subject to available funds.',
		offerItemDebitContactlessLimitedOverdraft: 'A Debit Mastercard Online Only card for your B Current Account with Contactless functionality allowing you to withdraw up to £350 a day at any UK ATM.',
		offerItemOverdraft: 'An overdraft facility for the sum above with the following key features and subject to the terms set out below in the Overdraft Facility Agreement.',

		offerItemCaControl: 'A Debit Mastercard Online Only card with Contactless functionality allowing you to withdraw up to £350 a day at any UK ATM, subject to available funds.',
		offerItemCaControlOverdraft: 'A Debit Mastercard Online Only card with Contactless functionality allowing you to withdraw up to £350 a day at any Clydesdale ATM or UK ATM.',
		// ready cash offers
		offerItemReadyCash: 'A Debit Mastercard Online Only card with Non contactless functionality allowing you to withdraw up to £350 a day at any UK ATM, subject to available funds.',
		offerItemNoFees: 'There are no fees or charges for this account.',
		offerItemNoCreditInterest: 'This account doesn\'t pay credit interest.',
		offerItemNoOverdrafts: 'Overdrafts are not permitted.',
		offerItemNoBorrowing: 'Borrowing is not available on this account. Requests for unplanned borrowing will usually be declined. {termsAndConditionsDoc}',
		offerItemDebitCard: 'You will receive a Debit Mastercard Online Only card with non contactless functionality allowing you to withdraw up to £350 a day at any Clydesdale ATM or UK ATM, subject to available funds.',
		offerItemDeposits: 'Your eligible deposits with Clydesdale Bank PLC are protected up to a total of £85,000 per depositor by the Financial Services Compensation Scheme, the UK’s deposit guarantee scheme. This limit is applied to the total of any deposits you have with Clydesdale Bank, Yorkshire Bank and B. Any total deposits you hold above the limit between these brands are unlikely to be covered. Please see <a href="http://www.cbonline.co.uk/resources/b82e172a-b00f-4783-973b-e4399da349e4/fscs_2015_online-leaflet.pdf" target="_blank" title="www.fscs.org.uk. This link will open in a new browser window">FSCS leaflet<span class="screenreader"> This link will open in a new browser window</span></a> for further information or visit <a href="http://www.fscs.org.uk" target="_blank" title="www.fscs.org.uk. This link will open in a new browser window">www.fscs.org.uk<span class="screenreader"> This link will open in a new browser window</span></a>',
		offerItemCancelation: 'You can cancel your agreement with us within 14 days of opening the account, or from the day you receive the Terms & Conditions, if later, by contacting us in branch, by phone or in writing. You will need to repay any debit balance, interest and fees incurred within 30 days of the date you tell us you want to cancel it.',

		offerItemCaDirectCaPlus: 'A Debit Mastercard with Contactless functionality as well as allowing you to withdraw cash at any UK ATM, subject to available funds. We will tell you your daily withdrawal limit when we send you your Debit Mastercard.',
		offerItemCaDirectCaPlusOverdraft: 'A Debit Mastercard with Contactless functionality as well as allowing you to withdraw cash at any Clydesdale ATM or UK ATM. We will tell you your daily ATM withdrawal limit when we send you your Debit Mastercard.',
		offerPageUnsuccessfulTitle: 'We are sorry, it appears that you are not eligible for the {productTitle} as you don’t hold the appropriate current account',
		offerPageDowngradeTitle: 'Unfortunately you have been unsuccessful for the {productTitle}',
		offerPageAlternativeOfferTitle: 'However we can offer you our ',
		offerPageHeader: 'Offer',
		offerPageTitle: 'Happy days. You can open B.',
		offerPageAltTitle: 'We are please to offer you a ',
		offerPageSubTitle: 'This offer includes:',
		offerPageIntroTitle: 'This section contains certain key information relating to the Readycash Account. Full details are contained in your Terms & Conditions and Tariff attached below which you should read.',

		offerPageKeyFeaturesTitle: 'Key features for',
		offerPageofferRestrictionsTitle: 'This offer doesn\'t include:',
		offerPageDocumentToReadSectionTitle: 'Documents for you to read and save:',
		offerPageDeclineOffer: 'If there\'s something you\'re undecided about, please call us on ' + brand.phoneNumber + ' or go into a branch.',
		offerConditionsIntro: 'You will receive these by email after you have opened the account.',
		offerTandCQuestion: 'By ticking this box and clicking "Yes Open my account" this represents my signature confirming that:',
		offerPageContinue: 'Do you wish to continue with the offer of a ',
		openAccountButton: 'Yes, open my account',
		declineAccountButton: 'No, do not proceed',
		downgradedOfferPageEmail: 'We will also email you these four documents after you have opened the account',

		// CC offer
		creditOfferPageTitle: 'Happy days. You’ve been approved for a {productName}',
		creditOfferPageSubTitle: 'You’ve requested a credit limit of',
		creditOfferPageMinSubTitle: 'We could give you a credit limit of',

		creditOfferPagePara1: 'We’ll consider your request (subject to our terms and conditions) and will let you know your credit limit in your welcome email.',
		creditOfferPagePara2: 'Please make sure you read and complete the sections below. We’ve also emailed you this information for you to read and consider.',
		creditOfferPagePara3: 'If anything’s not clear, just give the team at B a call on ' + brand.phoneNumber + '. We’re open Monday to Friday 8am - 8pm, Saturday 9am - 5pm, Sunday 10am - 5pm, and calls from mobiles and landlines are free.',

		creditLimitInputIntro: 'Now use the slider below to tell us what you’d like your credit limit to be (just round it up to the nearest £100).',
		creditLimitInputLabel: 'I’d like like a credit limit up to',
		creditLimitValidationMsg: 'Oops, something’s not right there. Put in a whole number of at least 500, to the nearest 100, without spaces or commas.',
		creditLimitConfirmation: 'Happy with the limit you’ve requested? Go ahead and continue.',
		creditLimitBtn: 'Continue',

		creditOfferKeyFeaturesTitle: '1. Key features',
		creditOfferKeyFeaturesIntro: 'Please read and consider the key features then tick the box before moving onto the pre-contract information.',
		creditOfferPreContractTitle: '2. Pre-contract credit information',
		creditOfferPreContractIntro: 'Please read and consider the pre-contract information then tick the box before moving onto the credit agreement.',
		creditOfferCreditAgreementTitle: '3. Credit agreement and general card conditions',
		creditOfferCreditAgreementIntro: 'Please read and consider the credit agreement below, tick the box to sign the agreement and then click the ‘Open my account’ button to agree to the terms and conditions.',

		// Offer Page Mandate
		mandateTitle: '',
		mandateParagraph: 'By clicking the \'Yes, open my account\' button, this confirms my signature and authority, and that I am opening an account.',

		// Savings Account Information
		savingsAccountInformation1: 'For more information regarding the savings account, please see the Terms & Conditions',

		// Mutli Offer & Modal
		altOpenAccountButton: 'Accept offer',
		altDeclineAccountButton: 'Decline offer',
		offerCancelApplicationBtn: 'Cancel application',
		offerCancelApplicationModalTitle: 'Are you sure you want to cancel this application?',
		offerCancelApplicationConfirm: 'Yes',
		offerCancelApplicationDecline: 'No',
		offerCancelIntro: 'If you do not wish to proceed with your application you can cancel below',



		// Mandate items
		mandateBullet1: 'I wish to apply for the B accounts and B App',
		mandateBullet2: 'I have read and accept the Terms & Conditions and Tariff for B accounts and B App. And I have also saved or printed a copy of the Terms & Conditions and Tariff',
		mandateBullet3: 'I acknowledge receipt of the Financial Services Compensation Scheme Information Sheet for both B Current account and B Instant Savings account',
		mandateBullet4: 'I authorise you to undertake any necessary searches and credit checks required to validate my identity and address, and',
		mandateBullet5: 'If my application is accepted and I proceed to open the B accounts, I authorise you to debit to the accounts all cheques, orders, payments and withdrawals signed or otherwise authorised by me. I also authorise you to debit to the B Current account all transactions made by using any debit cards that you may issue to me.',
		mandateBullet6: undefined,
		mandateBullet7: undefined,
		mandateBullet8: undefined,
		mandateBullet9: 'I wish to apply for the account',
		mandateBullet10: 'I have read and accept the Terms & Conditions and Tariff. And I have also saved or printed a copy of the Terms & Conditions and Tariff',
		mandateBullet11: 'I acknowledge receipt of the Financial Services Compensation Scheme Information Sheet',
		mandateBullet12: 'I authorise you to undertake any necessary searches and credit checks required to validate my identity and address, and',
		mandateBullet13: 'If my application is accepted and I proceed to open the account, I authorise you to debit to the account all cheques, orders, payments and withdrawals signed or otherwise authorised by me. I also authorise you to debit to the account all transactions made by using any debit cards that you may issue to me',

		jointMandateBullet1: 'I acknowledge that either party can authorise payments, cheques, orders, withdrawals and transactions made using a debit card.',
		jointMandateBullet2: 'I acknowledge that the other account holder may request an overdraft facility on the account without my consent and that both parties are liable for all debts, including any fees and interest, on the account, and not just a share.',
		jointMandateBullet3: 'I agree that the Pre-contract Information the Bank is obliged to provide before the completion of a planned overdraft agreement does not have to be disclosed to me if I am not the account holder who requests the facility.',
		jointMandateBullet4: 'I acknowledge that one statement for the account will be issued jointly to the address provided by party 1, unless any one of us advise you to the contrary.',

		jointAcceptTsAndCsIntro: 'If my Joint Account application is accepted and I proceed to open the account:',
		jointAcceptTsAndCsFooter: 'If you wish your account to operate only on the authority of both account holders, or you want Pre-contract Information for a planned overdraft agreement to be given to both parties, please contact us on ' + brand.phoneNumber + ' before continuing with the application.',
		jointAcceptTsAndCs: 'By ticking this box and clicking "Submit" this represents my signature confirming the above',

		// Deferred Page
		// FYI title used below also used for multi card Deferred Page
		deferredPageHeader: 'Deferred',
		deferredPageTitle: 'We need more time to look at your application',
		deferredPageExplanation: 'The team at B need to go over your application in more detail. We’ll do this within two working days then send you an email or text to log in and see our decision.',

		// Multi Card Deferred Page
		multiCardDeferredPageTitle: 'We need more time to look at your application',
		multiCardDeferredPageIntro: 'The team at B need to go over your application in more detail. Don’t worry – we just need a few more details.',
		multiCardDeferredPageListIntro: 'We’ll give you a call within two working days or you can get in touch on ' + brand.phoneNumber + ' if you’d prefer. We’re open Monday to Friday 8am - 8pm, Saturday 9am - 5pm, Sunday 10am - 5pm, and calls from mobiles and landlines are free.',

		// ID Deferred Page
		idDeferredPageHeader: 'Verify your identity',
		idDeferredPageTitle: 'We need to see your ID',
		idDeferredPageExplanation: 'We’ve not been able to verify your identity using the details you’ve given us so we’ll need to see your ID in person. ',
		idDeferredLinkTitle: 'Download ID Requirements Factsheet PDF. This link will open in a new browser window.',
		idDeferredLinkText: '<a href="http://www.cbonline.co.uk/wcm-media/CYB-Identificatio-Requirements.pdf" aria-label="Download ID Requirements Factsheet PDF. This link will open in a new browser window." target="_blank" title="Download ID Requirements Factsheet PDF. This link will open in a new browser window.">For details on what ID to bring with you please click here. Cheers.<span class="screenreader">This link will open in a new browser window.</span></a>',
		'idDeferredLinkText-credit-card': '<a href="http://www.cbonline.co.uk/wcm-media/CYB-Identificatio-Requirements.pdf" aria-label="Download ID Requirements Factsheet PDF. This link will open in a new browser window." target="_blank" title="Download ID Requirements Factsheet PDF. This link will open in a new browser window.">Find out what ID to bring with you<span class="screenreader">This link will open in a new browser window.</span></a> and pop into your local branch of Clydesdale or Yorkshire Bank to apply for your B Credit account.',
		'idDeferredPageFooter-credit-card': 'Need any help? Give us a call on ' + brand.phoneNumber + '. We’re open Monday to Friday 8am - 8pm, Saturday 9am - 5pm, Sunday 10am - 5pm, and calls from mobiles and landlines are free.',

		// Jumio Page
		jumioPageHeader: 'Jumio',
		jumioPageFloatingHeader: 'We couldn\'t confirm some of your details',
		jumioPageTitle: 'What happens next',
		jumioPageDescription: 'The quickest way to continue your application is to download <strong>B iD</strong> app on your smartphone or tablet and verify your details there.</p><p>You\'ll need a passport, ID card or driving licence, plus the reference number below.',
		jumioPageReferenceNumber: 'Reference number',
		jumioPageDownload: 'Download the <strong>B iD</strong> app to get started',
		jumioPageNoBiDDescription: 'Don\'t want to confirm your details using B iD? You can get an authorisation code sent to your home address instead.',
		jumioPageNoBiDphone: 'To get this, <strong>call the team at B on <u>0800 678 3654</u></strong> or <u><strong>+44 141 221 7300</u></strong> if abroad.',
		jumioPagePhoneMonToFri: 'Monday to Friday',
		jumioPagePhoneMonToFriTime: '8am - 8pm',
		jumioPagePhoneSat: 'Saturday',
		jumioPagePhoneSatTime: '9am - 5pm',
		jumioPagePhoneSun: 'Sunday',
		jumioPagePhoneSunTime: '10am - 5pm',
		jumioPhoneApp: {
			ios: {
				link: 'https://itunes.apple.com/us/app/b-id/id1270637923',
				title: 'Get Jumio on the App Store',
			},
			android: {
				link: 'https://play.google.com/store/apps/details?id=co.uk.youandb.android.bid',
				title: 'Get Jumio on Google Play',
			},
			amazon: {
				link: 'http://www.amazon.co.uk',
				title: 'Get Jumio on Amazon',
			},
		},
		// Contact Bank Page
		contactBankPageHeader: 'We need your number',
		contactBankPageTitle: 'We need your number',
		contactBankPageExplanation: 'To continue your application the team at B need you to update your mobile details. Please give them a call on ' + brand.phoneNumber + '.',

		//proof of income
		tacReferredPageHeader: 'We need some more info',
		tacReferredPageTitle: 'We need some more info',
		tacReferredParagragh1: 'We need to see proof of your income before we can process your application. ',
		tacReferredParagragh2: 'You’ll get an email that explains how to do this but you can go ahead and <a href="https://send.cbonline.co.uk" target="_blank" title="upload your documents online. This link will open in a new browser window">upload your documents online</a> now or take them along to your <a href="' + brand.bankWebsite + '/personal/online-locator/" target="_blank" title="nearest branch. This link will open in a new browser window">nearest branch<span class="screenreader">nearest branch. This link will open in a new browser window</span></a>.',
		tacReferredParagragh3: 'After we’ve verified your income (we’ll need two working days to do this) we’ll send you an email or text to log in and see our decision.',
		tacReferredFooter: 'Need any help? Give us a call on ' + brand.phoneNumber + '. We’re open Monday to Friday 8am - 8pm, Saturday 9am - 5pm, Sunday 10am - 5pm, and calls from mobiles and landlines are free.',

		// Sorry Page
		sorryPageHeader: 'Sorry',
		sorryPageTitle: 'Sorry, but after careful consideration, we’ve declined your application',
		sorryPageExplanation1: 'We use a credit scoring system and information from our credit reference agencies, Experian and Callcredit, to ensure we assess all credit applications fairly and consistently.',
		sorryPageExplanation2: '{findOutMore}',
		'sorryPageExplanation2-current': 'You can request a copy of your report from the credit reference agencies by clicking on the links below.',
		'sorryPageExplanation2-credit-card': 'You can request a copy of your report from the credit reference agencies by clicking on the links below.',
		sorryPageExplanation3DYB: 'If you think there are special circumstances related to your application, you can call us to discuss it on ' + brand.phoneNumber + '. Lines are open Monday to Friday 8am - 8pm, Saturday 9am - 5pm, Sunday 10am - 5pm, closed on Saturday and Sunday.',
		'sorryPageExplanation3DYB-credit-card': 'If you think there are special circumstances related to your application, you can call us to discuss it on ' + brand.phoneNumber + '. We’re open Monday to Friday 8am - 8pm, Saturday 9am - 5pm, Sunday 10am - 5pm, and calls from mobiles and landlines are free.',
		'sorryPageExplanation3DYB-current': 'If you think there are special circumstances related to your application, you can call us to discuss it on ' + brand.phoneNumber + '. We’re open Monday to Friday 8am - 8pm, Saturday 9am - 5pm, Sunday 10am - 5pm, and calls from mobiles and landlines are free.',
		'sorryPageExplanation4DYB-credit-card': 'We’ll send you a letter in the post to confirm this decision.',
		sorryFindOutMore: '',
		sorryPageFormLink: 'http://www.experian.co.uk/consumer/statutory-report.html',
		sorryPageFormLink2: 'http://www.callcredit.co.uk',
		sorryPageFormLinkText: 'Visit the Experian website',
		sorryPageFormLinkText2: 'Visit the Callcredit website',
		sorryPageFormLinkTitle: 'This link will open in a new window',
		sorryPageFormLinkTitle2: 'This link will open in a new window',

		// Decline Page
		declinePageTitle: 'We are sorry but after careful consideration we declined your application for {productName}. We note you did not proceed with our offer of an alternative product.',
		declinePageParagraph1: 'We use a Credit Scoring System and information from credit reference agencies, Experian and Callcredit, to ensure we assess all credit applications fairly and consistently. You can request a copy of your report from the credit reference agencies by clicking on the link below.',
		'declinePageParagraph1-credit-card': 'We use a credit scoring system and information from our credit reference agencies, Experian and Callcredit, to ensure we assess all credit applications fairly and consistently.',
		declinePageParagraph2: 'If you think there are special circumstances related to your application, you can call us to discuss it on ' + brand.phoneNumber + '. Lines are open Monday to Friday 08:00 to 20:00, closed on Saturday and Sunday. We will send you a letter in the post to confirm this decision.',
		'declinePageParagraph2-credit-card': 'You can request a copy of your report from the credit reference agencies by clicking on the links below.',
		declinePageParagraph3: '',
		'declinePageParagraph3-credit-card': 'If you think there are special circumstances related to your application, you can call us to discuss it on 0800 678 3654. We’re open Monday to Friday 8am - 8pm, Saturday 9am - 5pm, Sunday 10am - 5pm, and calls from mobiles and landlines are free.',
		declinePageParagraph4: '',
		'declinePageParagraph4-credit-card': 'We’ll send you a letter in the post to confirm this decision.',
		declinePageLink1: '<a href="http://www.experian.co.uk/consumer/statutory-report.html" target="_blank" title="www.experian.co.uk/consumer/statutory-report.html This link will open in a new browser window">Visit the Experian website <span class="screenreader"> This link will open in a new browser window.</span></a>',
		declinePageLink2: '<a href="http://www.callcredit.co.uk" target="_blank" title="www.callcredit.co.uk This link will open in a new browser window">Visit the Callcredit website <span class="screenreader"> This link will open in a new browser window.</span></a>',

		declinePageCurrentAccountTitle: 'We are sorry but after careful consideration we declined your application for {productName}. We note you did not proceed with our offer of an alternative product.',
		declinePageCreditAccountTitle: 'Sorry, but after careful consideration, we’ve declined your application',

		// Registration Page
		registrationPageHeader: 'Registration',
		registrationPageTitle: 'Congratulations, your account’s open. Almost done now.',
		registrationPageSubTitle: 'You’ll be needing this information. Got a pencil?',

		registrationPageRibHeader: 'Internet and telephone banking',
		registrationPageParagraph1: 'To give you a backup in case you ever lose your phone or tablet, we recommend you register for internet and telephone banking now.',
		registrationPageParagraph2: 'You’ll need your customer number (up there). Take a note of this as you’ll also need it to download the app. You’ll also need the password you created at the start of this form and a telephone access code (that bit comes later).',
		registrationPageBulletParagraph: 'For internet banking you\'ll need the following details to log in:',
		registrationPageBullet1: undefined,
		registrationPageBullet2: undefined,
		registrationPageBullet3: undefined,
		registrationPageErrorMessage: 'There has been a problem registering your {0} credentials. The reason is {1}.',
		registrationTransferSubmit: 'Continue',
		registrationSubmit: 'Proceed',
		registrationPageCustNoTitle: 'Customer information',
		registrationPageCustNoPara1: 'Customer number:',
		registrationPageCustNoPara2: undefined,

		wantToTransferHelpMessage: 'With B Credit, you can transfer balances from other credit cards, store cards and even overdrafts without paying a balance transfer fee. You can make up to three balance transfers online but the total amount you transfer can\’t be more than your credit limit.',

		transferHeader: 'Transfer your balance to your B credit card',
		'transferQuestion-credit-card': 'Do you want to make a balance transfer?',

		// Alternative YB/CB rgistration content
		registrationPageHeaderCYB: 'Registration',
		registrationPageTitleCYB: 'Congratulations, your account has been opened',
		registrationPageSubTitleCYB: 'Your account details and information you\'ll need to make a note of',
		registrationPageParagraph1CYB: 'Now that your account is opened, let\'s register you for Internet and Telephone Banking services so that you can use your account straight away.',
		registrationPageParagraph2CYB: 'For Telephone Banking you\'ll need your customer number – again it\'s above, and your telephone PIN – which you can set up below.',
		registrationPageBulletParagraphCYB: 'For Internet Banking you\'ll need the following details to log in:',
		registrationPageBullet1CYB: 'your customer number - which is above',
		registrationPageBullet2CYB: 'your password - which you created at the start of this application',
		registrationPageBullet3CYB: 'your security questions for Internet Banking - which you can set up below',
		registrationPageErrorMessageCYB: 'There has been a problem registering your {0} credentials. The reason is {1}.',

		securityQuestionsTitle: 'Set up your internet banking',
		securityQuestionsSubTitle: 'Please choose some security questions and answers. These will be used when you log in to internet banking.',

		securityPageLoadingMessage: 'Loading...',
		securityPageSubmissionMessage: 'Submitting answers...',

		securityQuestionDropdownValidationMessage: 'Sorry, you can\'t select the same question twice.',
		securityQuestionInputValidationMessage: 'Your answer must be 6-20 characters long, and only contain letters and numbers.',
		securityQuestionDropdownHelpText: 'These questions are a safeguard against the risk of fraud and make your log in to internet banking more secure.',
		securityQuestionInputHelpText: 'Type in a simple answer that you can easily remember for each question. Your answer must be 6-20 characters long, and only contain letters and numbers.',
		telephonePinTitle: 'Set up telephone banking',
		telephonePinSubTitle: 'To use telephone banking, you need to set up a four-digit access code.',
		telephonePinHelpMessage: 'Your telephone access code is a special code you\'ll use to identify yourself when you phone up to use telephone banking. It\'s an important security measure. It needs to be a 4 digit number which you can easily remember. Don\'t use the same number more than three times, or have any sequential numbers in there like 1234.',
		telephonePinValidationMessage: 'Pick a 4 digit number, with no consecutive numbers, and without using the same number four times.',
		telephonePin2HelpMessage: 'This needs to be exactly the same as the access code entered in the box above.',
		telephonePin2ValidationMessage: 'Try again? The access code didn\'t match.',
		registrationTCsTitle: 'Download and save the terms and conditions for telephone and internet banking for your records. These will also be emailed to you.',

		registrationAcceptTCs: 'I confirm by ticking this box that I agree to the terms and conditions above',
		registrationAcceptTCsValidationMessage: 'You need to agree in order to carry on.',

		registrationPasswordTitle: 'Create your internet banking password',
		registrationPasswordSubTitle: 'Please create a strong, memorable password that you\’ll use to login to internet banking for your account.',
		registrationPassword1Question: 'Password (8–16 characters, using at least one letter, number and symbol)',
		registrationPassword1QuestionExisting: 'Password (8–16 characters, using at least one letter, number and symbol)',
		registrationPassword2Question: 'Confirm your password',
		registrationPasswordRequirements: 'Your password should be 8-16 characters long with at least one letter, number and symbol. It\'s case sensitive too.',
		registrationPassword1HelpMessage: 'Your password should be 8–16 characters long and should include at least one letter, number and symbol. It’s case sensitive too.',
		registrationPassword1ValidationMessage: 'Please enter a valid password. It should be 8–16 characters long, with at least one letter, number and symbol.',
		registrationPassword2HelpMessage: 'Your password should be 8-16 characters long with at least one letter, number and symbol. It\'s case sensitive too.',
		registrationPassword2ValidationMessage: 'Oops. Your passwords don\'t match. Please have another go.',

		alreadyRibRegistered: 'It looks like you\'re already signed up for internet banking, you don\'t need to do anything more here.',
		alreadyTBRegistered: 'It looks like you\'re already signed up for telephone banking, you don\'t need to do anything more here.',

		// Submission Page
		submissionPageHeader: 'Submission',
		submissionPageTitle: 'Thanks for sending your application',
		submissionPageText: 'Please wait while your details are checked.',

		// Security Page
		securityPageTitle: 'Nearly there',
		timerSectionTitle: 'Just tell us a bit more about yourself',
		timerSectionTimeUnitDescription: 'mins',
		timerSectionTimeUnitExpiredDescription: 'Sorry, but you\'ve run out of time.',

		// Account Opened Page
		accountOpenedPageHeader: 'Account Opened',
		accountOpenedPageTitle: 'You\'re good to go',
		accountOpenedAppDownloadTitle: 'Now you can download the B app',
		accountOpenedAppDownloadBullet1: 'You can download B right away but you’ll have to wait till your B credit card arrives to get full access to the app and all its clever tools.',

		accountOpenedSection1Title: 'What\'s next?',
		accountOpenedSection1Bullet1: 'The team at B have sent you an email with important documents to read and save. If you can’t see it in your inbox, check your junk and spam in case it’s landed there.',
		accountOpenedSection1Bullet2: 'You’re all registered for internet and telephone banking too. You can use internet banking straight away by going to the login button on the <a href="' + brands.CB.bankWebsite + '" target="_blank" title="www.cbonline.co.uk. This link will open in a new browser window">Clydesdale Bank website<span class="screenreader"> This link will open in a new browser window</span></a> or <a href="' + brands.YB.bankWebsite + '" target="_blank" title="www.ybonline.co.uk. This link will open in a new browser window">Yorkshire Bank website<span class="screenreader"> This link will open in a new browser window</span></a>. You’ll need your customer number, password and security details.',
		accountOpenedSection1Bullet3: 'This email includes more info on how to register for internet and telephone banking. You’ll be able to register as soon as you get your B credit card.',
		accountOpenedSection2Title: 'Look out for the post too:',
		accountOpenedSection2Bullet1: 'Your B Debit Mastercard and PIN will arrive separately in around 3-5 days.',
		accountOpenedSection2Bullet2: 'If you\'d like a cheque book as well please call the team at B on ' + brand.phoneNumber,
		accountOpenedSection2Bullet3: 'Your B credit card and PIN will arrive separately in around 3–5 days.',
		accountOpenedSection3Title: 'With B, you can also:',
		accountOpenedSection3Bullet1: 'Arrange to include your B accounts in mortgage offsetting arrangements (this won\’t be done automatically)',
		accountOpenedSection3Bullet2: 'Apply for an overdraft (subject to eligibility)',
		accountOpenedSection3Bullet3: 'Apply for a credit card or a personal loan (subject to eligibility)',
		accountOpenedSection3Bullet4: 'For any of these, please get in touch with the team at B on ' + brand.phoneNumber,
		accountOpenedSection4Title: 'P.S. Here are some useful links:',
		accountOpenedSection4Bullet1: 'Any questions? Find out the answers <a href="https://www.youandb.co.uk/faq/tablet" target="_blank" title="Tablet FAQs. This link will open in a new browser window">in our FAQs<span class="screenreader"> This link will open in a new browser window</span></a>',
		accountOpenedSection5Title: 'Balance transfers',
		accountOpenedSection5Bullet1: 'Transferred your balance to B? Give it up to ten working days to reach your account.',
		accountOpenedSection5Bullet2: 'Not taken us up on our balance transfer offer yet? Or want to set up another one? Give us a call on ' + brand.phoneNumber + '.',
		accountOpenedSection6Title: 'Share the benefits of B Credit',
		accountOpenedSection6Bullet1: 'Adding an additional cardholder to your account? You’ll get a form in the post within five working days that we need you both to complete and send back to us.',
		accountOpenedSection6Bullet2: 'Want to set up an additional cardholder? Give us a call on ' + brand.phoneNumber + '.',
		accountOpenedSection7Title: 'Any more questions?',
		accountOpenedSection7Bullet1: 'Give us a call on 0800 678 3654 to chat to us about your new credit card. ',

		// Alt CYB content for account opened
		accountOpenedPageTitleCYB: 'Good news, you\'re all done',
		accountOpenedSection1TitleCYB: 'Check your email',
		accountOpenedSection1Bullet1CYB: 'In the next few days we will send you an email with important information for you to read and save. Check your email filters in case it\'s gone straight to your junk/spam folder and you can\'t see it in your inbox',
		accountOpenedSection1Bullet2CYB: 'You’re all registered for internet banking too. You can use this straight away by going to the login button at the top right of any page on <a href="' + brands.CB.bankWebsite + '" target="_blank" title="www.cbonline.co.uk This link will open in a new browser window">www.cbonline.co.uk <span class="screenreader">This link will open in a new browser window</span></a> or <a href="' + brands.YB.bankWebsite + '" target="_blank" title="www.ybonline.co.uk This link will open in a new browser window">www.ybonline.co.uk <span class="screenreader">This link will open in a new browser window</span></a>. You\'ll need your customer number, password and security details.',
		accountOpenedSection2TitleCYB: 'Look out for your post',
		accountOpenedSection2Bullet1CYB: 'You will receive a welcome letter which will confirm the details of your new account, please read through and send us back your specimen signature, as we’ll need this so you can make certain transactions on your account',
		accountOpenedSection2Bullet2CYB: 'Your Debit Mastercard and PIN are on their way. These will come separately and will be with you within 3-5 working days',
		accountOpenedSection3TitleCYB: 'Useful links',
		accountOpenedSection3Bullet1CYB: 'Download our mobile banking app <a href="' + brand.monetiseLink + '" target="_blank" title="Click here to download our mobile banking app. This link will open in a new browser window">here <span class="screenreader">Click here to download our mobile banking app. This link will open in a new browser window</span></a>',
		accountOpenedSection3Bullet2CYB: '<a href="' + brand.faqsLink + '" target="_blank" title="FAQs. This link will open in a new browser window">FAQs <span class="screenreader">This link will open in a new browser window</span></a> to help answer any queries you may have',
		accountOpenedSection3Bullet3CYB: '',
		accountOpenedSection4TitleCYB: 'Contact us',
		accountOpenedSection4Bullet1CYB: 'If you have any queries about your new account',
		accountOpenedSection8TitleCYB: 'Ways to contact us',
		accountOpenedSection8Bullet1CYB: 'Call us on ' + brands.YB.phoneNumber + ' or pop in to your local branch',

		// Portal Page
		portalPageHeader: 'Portal',
		portalPageTitle: 'Your saved applications',
		portalPageSubTitle: 'Pick an application to carry on with',

		// Login Page
		loginPageHeader: 'Login',
		loginPageTitle: 'Your saved application',
		loginPageNextButtonLabel: 'Please log in to carry on',
		usernameLabel: 'Customer number/username',
		usernameValidationMessage: 'Oops, that doesn’t seem right. Please enter a valid customer number or username. Your customer number should be 10 digits long starting with 10 and your username should be 6–16 characters long. Your username can include letters and numbers and it\'s also case sensitive. Can’t remember them? Get in touch with the team at B.  ',
		usernameHelpMessage: 'Enter your customer number or the username you created at the start of your application. Your customer number’s a 10-digit number beginning with 10 and your username’s 6–16 characters long. Need any help? Get in touch with the team at B.',
		passwordLabel: 'Please type the characters we\'ve requested from your password. The password characters are case sensitive.',
		passwordValidationMessage: 'Type the characters we\'ve requested from your password.',
		passwordHelpMessage: 'This is the password you created when you registered for Internet Banking earlier. Please call us if you need help.',
		passwordCharacterPrefix: 'Character ',
		goneWrongMessage: 'Can you check your details and try again please? Something went wrong but it might work if you try again.',
		tooManyRetries: 'You have exceeded the maximum number of login attempts. Please try again later.',
		cannotBeLoggedIn: 'Sorry we cannot log you in at this time. Please contact us for support.',
		passwordForgotten: 'Please call us on ' + brand.phoneNumber,

		// Joint Account
		jointAccountPageHeader: 'Joint Account',
		jointAccountLinkCodeValidationMessage: 'This code should be 6 digits long and should only contain numbers',
		jointAccountButtonLabel: 'Proceed',
		jointAccountInvalidResponse: 'Oops! Something has gone worng. We can fix it though. Just call us on ' + brand.phoneNumber,
		jointAccountInputHelpText: 'You should have been sent an email containing this 6 digit link code from the person you’re applying for the account with',
		jointAccountModalTitle: 'Unfortunately that code doesn’t seem to be working',

		jointAccountMultiPartyPageHeader: 'Joint Account',
		jointAccountMultiPageTitle: 'Thanks, that’s all we need from you for now',
		jointAccountPartyTwoAbsentTitle: 'Okay doke. We’ve sent you an email and text explaining how the other person can join the application. Please forward it to them so they can get started. Thanks!',
		jointAccountPartyOneWaiting: 'Next, the other person needs to fill in their part of the application.',
		jointAccountMultiPartyRadioQuestionTitle: 'Is the other person with you and ready to start their application?',
		jointAccountPartyTwoPresentTitle: 'The other person has to be available before you can complete the application',
		jointAccountPartyPresentNextLabel: 'Proceed to application',
		jointAccountIsSecondPartyPresent: 'If the other person opening the account with you is there, click ‘Yes’ and they can start their application now',

		// Joint Account Join View
		jointAccountLinkCodeViewTitle: 'Confirming your 6-digit code will let you join the application',
		jointAccountLinkCodeTextQuestionLabel: 'Link code',
		jointAccountLinkCodeViewNextLabel: 'Confirm code',

		// Joint Account Existing Customer
		jointAccountExistingCustomerTitle: 'Are you an existing customer?',
		jointAccountExistingCustomerTextQuestion: 'Do you already have an account with us?',
		jointAccountExistingCustomerTextQuestionHelp: 'B is brought to you by Clydesdale Bank and Yorkshire Bank. If you are an existing current account customer of either bank, telling us now will help us process your application.',

		// Joint Account Switch Page
		jointAccountSwitchPageTitle: 'Switch to B. It’s easy and there’s a guarantee',
		jointAccountSwitchPageIntro: 'First of all the team at B will do everything for you, you won’t even have to get in touch with your old bank.',
		jointAccountSwitchPageSubheader: 'Choose from 2 types of Switch',
		jointAccountSwitchPageP1: 'Switching your current account to us from another bank is straightforward with the current account switching service, we’ll do everything for you. We’ll contact your old bank so you don’t have to worry about letting them know. The current account switching service is free to use and once you have chosen and agreed your switch date with us, we guarantee it will only take 7 days, backed by the current account switching guarantee. On your switch date, your old account will be closed and all your payments and credit balance will be transferred to your new Clydesdale account.',
		jointAccountSwitchPageP2: 'If you’re not eligible for current account switching or you don’t want to use it, the payment transfer service lets you transfer your direct debits and standing orders from your old account to your new account over a 3 month period',
		jointAccountSwitchPageFooter1: 'Call us on ' + brand.phoneNumber,
		jointAccountSwitchPageFooter2: 'Or visit your local branch',

		// Joint Account Offer
		jointAccountOfferKeyFeature1: 'I agree to open the account on behalf of myself and the other person named on the joint account',

		// Joint Account Expenditure
		jointAccountExpenditureHelp: 'Got some joint commitments with the other person? Just tell us how much your <strong>share</strong> is. This bit is pretty important so be careful and make sure you enter the right amount.',

		// Joint Account Bank selection
		jointAccountIncorrectBankId: 'Oops! It looks like you’ve chosen a different bank to the other person.  You’ll need to change this to {bankName} Bank before we can get you moving.',
		jointAccountIncorrectBankIdExisting: 'Oops!  It looks like your bank is different to the one chosen by the other person on the application.  Give us a call on ' + brand.phoneNumber + ' and we’ll sort this for you.',

		jointAccountLetterCodeIntro: 'In the meantime, the other person you’re applying with can get started, if they like.',

		// CashISA
		niNumberTitle: 'National Insurance Number',
		niNumberSubtitle: 'Number',
		niNumberMissingSubtitle: 'Reason',
		niNumberMissingQuestion: 'Please select the reason why you don’t have a National Insurance Number?',
		niNumberQuestion: 'Do you have a National Insurance Number?',
		niNumberValidationText: '[VALIDATION NI NUMBER]',
		niNumberQuestionHelpText: '[HELP TEXT]',
		niNumberQuestionInputHelpText: '[HELP TEXT]',
		niNumberMissingHelpText: '[HELP TEXT]',
		niNumberMissingValidText: '[INVALID TEXT]',
		niNumerMissingReasonError: 'If you don’t have a National Insurance number you’ll find instructions on getting one on the Gov.uk website',
		niNumberRequiredValidationMessage: 'You can not proceed with your application until you have a National Insurance number. If you don’t have a National Insurance number you’ll find instructions on getting one on the Gov.uk website.',

		cashISAOfferDeclarationTitle: 'Declaration and Authorisation',
		cashISAOfferDeclarationSubTitle: 'I declare that:',
		cashISAInterestRatesPolicy: 'For interest rates, please refer to the Cash ISA tariff for personal customers, our <a href="' + brand.bankWebsite + '" target="_blank" title="' + brand.bankWebsite + ' This link will open in a new browser window">website <span class="screenreader">This link will open in a new browser window</span></a> or the notice displayed in branch.',
		csshISAAcceptDecleration: 'By ticking this box I agree to and accept the ISA Declaration and Authorisation statements above',
		cashISARegistrationTitle: 'Check your ISA balance, earned interest and more!',
		cashISARegistrationIntro: 'Now that your account has been opened, register for Internet Banking to access your account anytime.',
		cashISAHowToRegisterTitle: 'To register and log into Internet Banking you’ll need:',
		cashISARequirements1: 'your customer number: <strong>{customerNumber}</strong> (make a note of this)',
		cashISARequirements2: 'your password - which you created at the start of your application',
		cashISARequirements3: 'your security questions and answers - which you can set up below',
		cashISARegistrationFooter1: 'When registering for Internet Banking we also automatically register you for Telephone Banking as well.',
		cashISARegistrationFooter2: 'To use our Telephone Banking service you’ll need your customer number (shown above) and a telephone banking PIN - which you can set up below.',
		cashISAHelpToBuyInvalidResidentialStatus: 'You must be a first-time buyer to open a Help To Buy: ISA',

		cashISAOfferFootNotes1: 'I declare that the information completed in this application form is correct to the best of my knowledge and belief. I understand that for my benefit and protection, I should read the terms & conditions and the Key Features within the enclosed ’Your Cash ISA. Important information about your account’ leaflet (copies of which I have received). If you do not understand any point please ask for further information.',
		cashISAOfferFootNotes2: 'I agree to be bound by the terms & conditions applicable to the ISA and to inform Clydesdale Bank PLC immediately of any changes in my circumstances.',
		cashISAOfferFootNotes3: 'I have saved and/or printed a copy of the Financial Services Compensation Scheme (FSCS) information sheet.',
		cashISAOfferFootNotes4: 'I understand that this application is subject to acceptance by Clydesdale Bank PLC and a completed copy of it is available on request.',

		// Cash ISA Declaration Items
		additionalDeclarationsTitle: 'I authorise Clydesdale Bank PLC:',
		cashISADeclareItem1: 'All subscriptions made, and to be made, belong to me',
		cashISADeclareItem2: 'I am 16 years of age or over',
		cashISADeclareItem3: 'I have not subscribed and will not subscribe more than the overall subscription limit in total to a Cash ISA, a stocks and shares ISA, and an Innovative Finance ISA in the same tax year;',
		cashISADeclareItem4: 'I have not subscribed and will not subscribe more than the Cash ISA subscription limit to one Cash ISA',
		cashISADeclareItem5: 'I have not subscribed and will not subscribe to another Cash ISA in the same year that I subscribe to this {productName}',
		cashISADeclareItem6: 'I am resident in the United Kingdom for tax purposes or, if not so resident, either perform duties, which, by virtue of Section 28 of the Income Tax (Earnings & Pensions) Act 2003 (Crown employees serving overseas), are treated as being performed in the United Kingdom, or I am married to, or in a civil partnership with, a person who performs such duties. I will inform Clydesdale Bank PLC if I cease to be so resident or to perform such duties or to be married to, or in a civil partnership with, a person who performs such duties',
		cashISADeclareItem7: 'No advice has been sought or provided relating to this {productName} application',

		cashISAAuthoriseItem1: 'To hold my cash subscription, ISA investments, interest and any other rights or proceeds in respect of those investments and any other cash',
		cashISAAuthoriseItem2: 'To make on my behalf any claims to relief from tax in respect of ISA investments',
		cashISAAuthoriseItem3: 'To undertake any necessary searches and checks required to validate my identity and address',

		// Flexi Cash ISA Key Features
		flexiISAKeyFeature1: 'Interest is earned tax free. Interest is paid annually on 31 December or the first business day thereafter.',
		flexiISAKeyFeature2: 'The overall ISA limit for 2016/17 is £15,240',
		flexiISAKeyFeature3: 'The minimum monthly deposit is £10.',
		flexiISAKeyFeature4: 'Funds can be withdrawn at any time without losing any tax benefits',
		flexiISAKeyFeature5: 'Any subscriptions you make in the current tax year can be withdrawn and replaced without the replacement funds affecting your annual subscription limit. The replacement funds have to be paid back into your ISA in the same tax year they are withdrawn or you will lose the ability to replace them. Interest is earned tax free. Interest is paid annually on 31 December or the first business day thereafter.',

		// Flexi Cash Offer Items
		flexiCashOfferItem1: 'This is a Cash ISA. You can take your money out at anytime, immediately, without any charges.',
		flexiCashOfferItem2: 'If you take money out, you can pay it back in during the same tax year without it counting towards your annual subscription limit',
		flexiCashOfferItem3: 'If you don’t pay any withdrawals back in during the same tax year, they can’t be carried forward to the next tax year.',
		flexiCashOfferItem4: 'The minimum amount you can pay into this ISA is £10 a month',

		// Help To Buy Key Features
		helpBuyKeyFeature1: 'Each tax year, you can split your £15,240 ISA subscription allowance across a Help to Buy: ISA and a stocks and shares ISA - providing you don\'t go over the Help to Buy: ISA monthly subscription allowance.',
		helpBuyKeyFeature2: 'There is no minimum monthly deposit.',
		helpBuyKeyFeature3: 'The maximum amount you can subscribe is £200 each calendar month; if you miss a month you cannot make up these funds any other calendar month.',
		helpBuyKeyFeature4: 'At account opening you can subscribe an additional £1,000 provided it is deposited within the same calendar month. This is in addition to your monthly £200.',
		helpBuyKeyFeature5: 'The government will pay a bonus of 25% on account balances between £1,600 and £12,000 when you purchase your first home in the UK under £250,000 (under £450,000 in London).',
		helpBuyKeyFeature6: 'The bonus is paid directly to the conveyancer and is only released if the house purchase is completed.',
		helpBuyKeyFeature7: 'Funds can be withdrawn at any time without charge. Withdrawing from your ISA will affect the bonus the government will pay. Please refer to the Help to Buy: ISA scheme rules which can be found at: <a href="www.helptobuy.gov.uk/help-to-buy-isa/furtherinformation" target="_blank" title="www.helptobuy.gov.uk/help-to-buy-isa/furtherinformation This link will open in a new browser window">www.helptobuy.gov.uk/help-to-buy-isa/furtherinformation <span class="screenreader">This link will open in a new browser window</span></a>',
		helpBuyKeyFeature8: 'Interest is paid annually on 31 December or the first business day thereafter.',

		// Help To Buy Offer Items
		helpBuyOfferItem1: 'The Clydesdale Bank Help to Buy: ISA Account helps you save your deposit for your first home.',
		helpBuyOfferItem2: 'The maximum amount you can subscribe is £200 each calendar month',
		helpBuyOfferItem3: 'At account opening you can subscribe an additional £1,000 provided it is deposited in the same calendar month',
		helpBuyOfferItem4: 'The government will pay a bonus of 25% on account balances between £1,600 and £12,000 when you buy your first home in the UK under £250,000 (Under £450,000 in London)',
		helpBuyOfferItem5: 'Funds can be withdrawn at any time without charge. Withdrawing from your ISA will affect the bonus the government will pay.',

		// Help To Buy Declaration Items
		helpBuyDeclareItem1: 'I do not own, and never have owned, any interest in land, whether in the United Kingdom or elsewhere, which:',
		helpBuyDeclareItem2: 'I have not previously received payment of a Bonus under the Help to Buy: ISA Scheme Rules (unless the full amount of such Bonus has subsequently been repaid to the Administrator in accordance with the Scheme Rules)',
		helpBuyDeclareItem3: 'I have not paid, and will not pay, into this Help to Buy: ISA more than the applicable monthly allowance, as set out in the Scheme Rules.',
		helpBuyDeclareItem4: 'I understand I can only hold one Help to Buy: ISA at any time',
		helpBuyDeclareItem5: 'I have been supplied with, or have had made available to me, a copy of the Scheme Rules, or have been provided with, or had made available to me, a linkto a website where the Scheme Rules can be accessed, and I agree to be bound from the date of this agreement as an Eligible Customer by the Scheme',
		helpBuyDeclareItem6: 'Rules, as such may be amended and/or restated from time to time.',
		helpBuyDeclareItem7: 'I have not subscribed and will not subscribe to another Cash ISA in the same tax year that I subscribe to this Help to Buy: ISA and I acknowledge that any current year transfers from a Help to Buy: ISA to a Stocks and Shares ISA have the effect of the original cash subscription no longer counting as a Cash ISA subscription but instead as a subscription to a Stocks and Shares ISA; and',

		helpBuyLegal1: '',
		helpBuyLegal2: '',
		helpBuyLegal3: '',
		helpBuyLegal4: '',
		helpBuyLegal5: '',
		helpBuyLegal6: '',
		helpBuyLegal7: '',
		helpBuyLegal8: '',
		helpBuyLegal9: '',
		helpBuyLegal10: '',
		helpBuyLegal11: '',
		helpBuyLegal12: '',
		helpBuyLegal13: '',

		helpBuySavingUpAssistance: 'The maximum amount you can subscribe to a Help to Buy: ISA is £200 per calendar month (£2,400 per year).',

		// OTP Authentication Overlay
		OTPTitle: 'We\'ve sent a passcode to your mobile',
		OTPAuthenticationTitle: 'We\'ve sent a passcode to your mobile ending {partial-phone-number}',
		OTPAuthenticationAltTitle: 'We\'ve sent a passcode to your mobile',
		OTPAuthenticationSubTitle: 'You should have received a text on your mobile ending {partial-phone-number} You can\'t proceed past this point unless we have a mobile number saved for you. If you need help call us on ' + brand.phoneNumber + '.',
		OTPAuthenticationAltSubTitle: 'You should have received a text on your mobile. You can\'t proceed past this point unless we have a mobile number saved for you. If you need help call us on ' + brand.phoneNumber + '.',

		OTPAuthenticationTitleResent: 'We\'ve sent you another passcode.',
		OTPAuthenticationSubTitleResent: 'Check your mobile ending {partial-phone-number}',
		passcodeValidationMessage: 'This passcode is required and should be a number of exactly 10 characters.',
		OTPAuthenticationTitleNoOTP: 'Something went wrong',
		OTPAuthenticationSubTitleNoOTP: 'Please try that again.',
		OTPAuthenticationTitleInvalidOTP: 'That\'s not the right passcode.',
		OTPAuthenticationSubTitleInvalidOTP: 'Try again please. The passcode you entered isn\'t the same as the one we texted you.',
		OTPAuthenticationLimitError: 'Sorry – it looks like this passcode isn\'t working. Give us a call on ' + brand.phoneNumber + ' and we\'ll get things moving again.',

		// Switch Page
		switchPageHeader: 'Switch',
		switchPageTitle: 'Switch to B. It\'s easy and there\'s a guarantee',
		switchPageHeadingOptional1: 'The switch guarantee means it\'s really straightforward',
		switchPageText1: 'First of all the team at B will do everything for you, you won\'t even have to get in touch with your old bank.',
		switchPageHeadingOptional2: 'Make sure you arrange an overdraft first',
		switchPageText2: 'In your overdraft on your old account? Before you switch, make sure you’ve paid this off or have got one with B that covers the amount you’re overdrawn by – or your old account won’t be closed. Not arranged an overdraft with B yet? Give the team at B a call on 0800 678 3654 or pop into a branch of Clydesdale or Yorkshire Bank. If you\'re eligible, your balance will be carried across, even if it\'s in debit (subject to checks of course).',
		switchPageHeadingOptional3: '',
		switchPageText3: '',
		switchPageHeadingOptional4: 'A word in your ear',
		switchPageText4: 'Once switching has started it can\'t be stopped, but the guarantee means that if anything goes wrong, tell B and you\'ll get a refund of any interest or charges made on either your old account or the new one as a result. If, for any reason, you don\'t qualify for the Current Account Switch Service, or you don\'t want to use it, you can use the Payment Transfer Service. This enables you to transfer all your Direct Debits and standing orders from your old account to B over 3 months. Please note that the 7 working day switch guarantee does not apply to this service.',
		switchPageText5: '',
		switchPageText6: '',

		wantsToSwitch: 'Want to switch from your current account to B?',
		wantsToSwitchValidationMessage: 'This is required.',
		switchDetailsTitle: 'Your old current account details',
		switchAccountNameValidationMessage: 'Your account name must be no more than 18 characters long.',
		switchAccountNameHelpMessage: 'This is the name shown on your account statement.',
		switchAccountNumberValidationMessage: 'This must be 8 numbers long.',
		switchAccountNumberHelpMessage: 'The account number will appear on your account statements.',
		switchSortCodeValidationMessage: 'This is 6 numbers long.',
		switchSortCodeHelpMessage: 'You will see your sort code on your account statements, usually next to the account number.',
		switchHasDebitCardValidationMessage: 'Your 16-digit Card Number',
		switchDebitCardPanLabel: 'Your 16-digit Card Number',
		switchDebitCardPanValidationMessage: 'Your 16-digit Card Number',
		switchDebitCardPanHelpMessage: 'This is the main number across the front of the card, typically printed in bigger characters and usually 16 numbers long.',
		switchDebitCardExpirationValidationMessage: 'Please use numbers without any extra characters, so for example January 2017 should be written like this: 0117. The card must not have expired.',
		switchDebitCardExpirationHelpMessage: 'This will be shown on the card as a month and year, typically next to a statement such as \'Expires end\'.',
		switchTypeValidationMessage: 'This is required.',
		switchTypeTitle: 'Choose from two types of switch',
		switchTypeFullSwitch: 'A full switch using the Current Account Switch Service will guarantee that once you have chosen and agreed the switch date with us the full balance and regular payments associated with your old account at your old bank will be switched to your new account and your old account will be closed. You will be advised of regular payments that cannot be automatically transferred and any payments made to your old account will be redirected to your new account.',
		switchTypePaymentSwitch: 'The Payment Transfer Service allows you to choose which payments you would like to transfer across to your new account and your old account will not be closed. Please note that the 7 working day switch guarantee does not apply to this service.',
		switchDateValidationMessage: 'The date cannot be in the past. Please remeber to select a date at least 7 working days from now, which is not a weekend or Bank Holiday.',
		switchDateHelpMessage: 'This is the date you would like the switch to take place.',
		switchDateGuidance: 'Please select a date at least 7 working days from now, which is not a weekend or Bank Holiday.',
		switchCloseOldAccount: 'Yes, I agree to you closing my old current account when the switch to my new one is complete.',
		switchCloseOldAccountValidationMessage: 'Please confirm your consent to continue.',
		switchCloseOldAccountHelpMessage: 'This means that we\'ll transfer your balance, direct debits and standing orders before closing the account.',

		switchAcceptFullTCs: 'Yes, I agree to the Terms & Conditions above',
		switchAcceptFullTCsValidationMessage: 'Please agree in order to continue.',

		switchAcceptPaymentsTCs: 'Yes, I agree to the Terms & Conditions above',
		switchAcceptPaymentsTCsValidationMessage: 'Please agree in order to continue.',
		// Switch page alt CYB content
		switchPageHeaderCYB: 'Switch',
		switchPageTitleCYB: 'Switch to us with the Current Account Switch Service',
		switchPageText1CYB: 'If you have an agreed overdraft facility on your old account you will need to arrange a planned borrowing limit with us prior to switching your account to ensure that you can fully transfer any debit balance as part of your switch. You can arrange planned borrowing, subject to eligibility, just pop into your nearest branch or call us on 0800 678 3350.',
		switchPageText2CYB: 'Switching your current account to us from another bank is straightforward with the Current Account Switch Service, we\'ll do everything for you. We\'ll contact your old bank so you don\'t have to worry about letting them know. The Current Account Switch Service is free to use and once you have chosen and agreed your switch date with us, we guarantee it will only take 7 working days, backed by the Current Account Switch Guarantee. On your switch date, your old account will be closed and all your payments and credit balance will be transferred to your new {bankName} account.',
		switchPageText3CYB: '<strong>Once your switch has started it cannot be stopped</strong>, but the guarantee means that if anything goes wrong we’ll refund any interest or charges made on either your old account or the new one as a result.',
		switchPageText4CYB: 'If you\'re not eligible for the Current Account Switch Service, or you don\'t want to use it, the Payment Transfer Service lets you transfer your Direct Debits and standing orders from your old account to your new account over a 3 month period.',

		wantsToSwitchCYB: 'If you want to use either of these switching services, please click on the \'Yes\' button.',
		wantsToSwitchValidationMessageCYB: 'This is required.',
		switchDetailsTitleCYB: 'Please fill in the following details. Use the details from the old account you’re switching from, and not the new one you’ve just opened.',
		switchAccountNameValidationMessageCYB: 'Your account name must be no more than 18 characters long.',
		switchAccountNameHelpMessageCYB: 'This is the name shown on your account statement.',
		switchAccountNumberValidationMessageCYB: 'This must be 8 numbers long.',
		switchAccountNumberHelpMessageCYB: 'The account number will appear on your account statements.',
		switchSortCodeValidationMessageCYB: 'This is 6 numbers long.',
		switchSortCodeHelpMessageCYB: 'You will see your sort code on your account statements, usually next to the account number.',
		switchHasDebitCardValidationMessageCYB: 'This is required.',
		switchDebitCardPanLabelCYB: 'Your 16-digit Card Number',
		switchDebitCardPanValidationMessageCYB: 'This is the long number on the front of the card.',
		switchDebitCardPanHelpMessageCYB: 'This is the main number across the front of the card, typically printed in bigger characters and usually 16-19 numbers long.',
		switchDebitCardExpirationValidationMessageCYB: 'Please use numbers without any extra characters, so for example January 2017 should be written like this: 0117. The card must not have expired.',
		switchDebitCardExpirationHelpMessageCYB: 'This will be shown on the card as a month and year, typically next to a statement such as \'Expires end\'.',
		switchTypeValidationMessageCYB: 'This is required.',
		switchTypeTitleCYB: 'Please choose a switch option.',
		switchTypeFullSwitchCYB: 'A full switch using the Current Account Switch Service will guarantee that once you have chosen and agreed the switch date with us that the full balance and regular payments associated with your old account will be switched to your new account and your old account will be closed. You will be advised of regular payments that cannot be automatically transferred and any payments made to your old account will be redirected to your new account.',
		switchTypePaymentSwitchCYB: 'The Payment Transfer Service allows you to choose which payments you would like to transfer across to your new account, your old account will not be closed.',

		// Map Switch Response Codes to Messages
		switchCode000: 'Your switch has been successful',
		switchCode340: 'Sorry. This account doesn\'t allow switching. But you can transfer your details from your old bank to B. Please call the team at B on ' + brand.phoneNumber + ' for help.',
		switchCode365: 'Sorry. This account doesn\'t allow switching. Please call the team at B on ' + brand.phoneNumber + ' for help.',
		switchCode366: 'The sort code, account number or 16-digit card number you’ve entered aren’t quite right. Please give them a double-check and try again.',
		switchCode364: 'Sorry. You can\'t switch to this account at the moment. Please get in touch with the team at B.',
		switchCode367: 'Sorry. You can\'t carry out a switch to B on this account.',
		switchCode345: 'Switches can\'t go ahead on weekends and bank holidays. Please choose another date for your switch.',
		switchCode346: 'Please pick a switch date that\'s at least 7 working days from now.',
		switchCode347: 'Please pick a switch date that\'s less than 90 days from today, and more than 7 working days in the future.',
		switchCode393: 'There’s been a problem with B, please try again later or call the team on ' + brand.phoneNumber + ' to get this sorted.',
		switchCode394: 'Sorry. You can\'t switch to this account at the moment. Please get in touch with the team at B.',
		switchCode395: 'There\'s been a problem with B, please try again later or call the team on ' + brand.phoneNumber + ' to get this sorted.',
		switchCode349: 'There\'s been a problem with B, please try again later or call the team on ' + brand.phoneNumber + ' to get this sorted.',
		switchCode350: 'Please check that the day, month and year you\'ve given for your date of birth are correct. If they are then please get in touch with the team at B.',
		switchCode353: 'Please pick a switch date that\'s at least 7 working days in the future.',
		switchCode380: 'Sorry. You can\'t switch to B from this type of account. Please call the team at B on ' + brand.phoneNumber + ' for help.',
		switchCode402: 'Sorry. You can\'t switch to B from this type of account. Please call the team at B on ' + brand.phoneNumber + ' for help.',
		switchCode403: 'Sorry. You can\'t switch to B from this type of account. To switch you need an account that\'s backed by the Current Account Switch Service. Please call the team at B on ' + brand.phoneNumber + ' to get something sorted.',
		switchCode398: 'There\'s been a problem with B, please try again later or call the team on ' + brand.phoneNumber + ' to get this sorted.',
		switchCode801: 'There\'s been a problem with B, please try again later or call the team on ' + brand.phoneNumber + ' to get this sorted.',
		switchCode355: 'There\'s been a problem with B, please try again later or call the team on ' + brand.phoneNumber + ' to get this sorted.',
		switchCode358: 'There\'s been a problem with B, please try again later or call the team on ' + brand.phoneNumber + ' to get this sorted.',
		switchCode359: 'There\'s been a problem with B, please try again later or call the team on ' + brand.phoneNumber + ' to get this sorted.',
		switchCode348: 'Hold your horses - there\'s already a switch going on for this account.',
		switchCode861: 'There\'s been a problem with B, please try again later or call the team on ' + brand.phoneNumber + ' to get this sorted.',
		switchCode362: 'There\'s been a problem with B, please try again later or call the team on ' + brand.phoneNumber + ' to get this sorted.',
		switchCode363: 'There\'s been a problem with B, please try again later or call the team on ' + brand.phoneNumber + ' to get this sorted.',
		switchCode389: 'B needs your postal address to continue, please call ' + brand.phoneNumber + '.',
		switchCodeDefault: 'Sorry, something has gone wrong creating your switch application',

		// Authentication Page
		authPageHeader: 'Application',
		authPageSubtitle: 'Please login to continue',
		authPageTitle: 'Authentication',
		authFormTitle: undefined,
		authFormSubTitle: undefined,
		hasCustomerName: 'Do you have a customer number/username?',
		authChallengeSecurityQuestionValidationMessage: 'This is the answer to the internet banking security question you selected at the time of registration. Please call us if you need help.',
		authPageContact: 'If you need help with your application, or if any of your details aren\'t up-to-date, please call the team at B on ' + brand.phoneNumber + '.',
		loginPageContact: 'If you need help with your application please call us on ' + brand.phoneNumber,

		authBankQuestion: 'Please let us know where you have an account',
		authBankIdHelpMessage: 'Please indicate the bank with which you hold an account',
		authFirstNameQuestion: 'First Name',
		authFirstNameHelpMessage: 'Just using letters and spaces as it appears on your passport or driving licence.',
		authLastNameQuestion: 'Last Name',
		authLastNameHelpMessage: 'Please use your last name as it appears in your passport or driving licence.',
		authGenderQuestion: 'Gender',
		authGenderHelpMessage: 'This is just to help identify you.',
		authDateOfBirthQuestion: 'Date Of Birth',
		authDateOfBirthHelpMessage: 'Click on the month/year to start entering your dates. There’s no need to scroll. The date entered should be formatted DD-MM-YYYY.',
		authHouseNumberQuestion: 'House Number',
		authHouseNumberHelpMessage: 'This is the number of your house or apartment.',
		authStreetQuestion: 'Street',
		authStreetHelpMessage: 'Your street name should be written using number and letters only.',
		authPostcodeQuestion: 'Postcode',
		authPostcodeHelpMessage: 'You need to supply a valid postcode for any UK address you add. These are normally formatted like this: A12 3BC.',
		authCheckDetailsError: 'Can you check your details and try again please? Something went wrong but it might work if you try again.',
		authNextButtonText: 'Proceed',
		authFirstNameValidationMessage: 'Please use letters and spaces only.',
		authLastNameValidationMessage: 'Please use letters and spaces only.',
		authDateOfBirthValidationMessage: 'Please enter a valid date in the following format DD-MM-YYYY.',
		authHouseNumberValidationMessage: 'Sorry, your house number must be written using numbers and letters only and no longer than 40 characters.',
		authStreetValidationMessage: 'Your street should be written using numbers and letters only and be no longer than 40 characters.',
		authPostcodeValidationMessage: 'Please enter a valid postcode.  Postcodes are normally formatted like this - A12 3BC',
		authGenderValidationMessage: 'Please select a gender.',
		authPageLoadingMessage: 'Please wait while we load your details...',

		// Authentication Component
		authChallengeTitle: 'Verify your details',
		authChallengeSubtitle: '',
		telephoneAuthAccessCode: 'Telephone Access Code',
		telephoneAuthAccessCodeValidationMessage: 'This is the 4-digit number you chose for Telephone Banking',
		telephoneAuthAccessCodeHelpMessage: 'This is 4 numbers long.',
		telephoneAuthSortCode: 'Sort code',
		telephoneAuthAccountNumber: 'Account number',
		debitCardAuthPan: 'Your 16-digit Card Number',
		debitCardAuthSortCode: 'Sort code',
		debitCardAuthAccountNumber: 'Account number',
		panHelpMessage: 'This is the 16-digit card number that runs across the middle of the front of your card.',
		accessCodeHelpMessage: 'This is your four-digit Access Account Number. It’s set during the registration process to allow you to access telephone banking and internet banking.',
		sortCodeHelpMessage: 'You\'ll spot your 6-digit sort code on your bank statements and debit card.',
		accountNumberHelpMessage: '8-digit account number appears on your bank statements and debit card.',
		panValidationMessage: 'This is 16 numbers long.',
		accessCodeValidationMessage: 'This is 4 numbers long.',
		sortCodeValidationMessage: 'This is 6 numbers long without spaces.',
		accountNumberValidationMessage: 'This is 8 numbers long.',
		dobChallengeQuestion: 'Please enter your date of birth',
		dobChallengeValidationMessage: 'Please enter a valid date of birth using the format DD-MM-YYYY.',
		dobChallengeHelpMessage: 'Click on the calendar icon to select your date of birth or enter it in the format DD-MM-YYYY.',
		ccPanChallengeQuestion: '16-digit credit card number',
		ccPanChallengeValidationMessage: 'Please enter a valid 16-digit credit card number.',
		ccPanChallengeHelpMessage: 'This is the 16-digit number that runs across the front of your card.',
		creditLimitChallengeQuestion: 'Credit limit',
		creditLimitChallengeValidationMessage: 'Please enter whole numbers, without spaces, commas or currency symbols (for example 1000).',
		creditLimitChallengeHelpMessage: 'Your credit limit is the agreed maximum amount you can borrow on your credit card. You can find this on your latest statement.',


		// Error Page
		errorPageHeader: 'Error',
		upgradeBrowserMessage: '<div id="browserhappy" class="account-opening container" style="display: none;" role="dialog" aria-live="polite" aria-atomic="true"><div class="alert alert-warning text-center"><p >Sorry, our online application does not support your browser. Please <a role=button href="http://browsehappy.com/" target="_blank" title="www.browsehappy.com This link will open in a new browser window.">update your browser <span class="screenreader">www.browsehappy.com This link will open in a new browser window.</span></a> to a newer version or try again with a different browser.</p> <p>You can close this window to return to the site to see other ways to apply.</p></div></div>',
		errorPageTitle: 'Something’s gone wrong',
		errorPageText1: 'Sorry, it looks like there’s been a technical problem. While we’re sorting it out, please call us instead on ' + brand.phoneNumber + '. ',
		errorPageText2: 'We’re open Monday to Friday 8am - 8pm, Saturday 9am - 5pm, Sunday 10am - 5pm, and calls from mobiles and landlines are free.',

		// Setup in Progress Page
		setupInProgressHeader: 'Setup',
		setupInProgressTitle: 'Sorry, there\'s been a slight technical hitch',
		'setupInProgressTitle-credit-card': 'We can’t open your account just yet but don’t worry',
		setupInProgressText1: 'Your account will be open and ready the next working day.',
		'setupInProgressText1-credit-card': 'We’re sorry, but our service is temporarily down for maintenance so we can’t open your account right now.',
		setupInProgressText2: 'We\'ll let you know as soon as it\'s available so you can register for online banking, telephone banking and account switching.',
		'setupInProgressText2-credit-card': 'Don’t worry though, your agreement has been completed and your account will be opened tomorrow morning. We’ll send you a welcome email as soon as we’ve opened it.',
		setupInProgressText3: 'We look forward to being in touch very soon.',
		'setupInProgressText3-credit-card': 'Any questions? Give us a call on ' + brand.phoneNumber + '. We’re open Monday to Friday 8am - 8pm, Saturday 9am - 5pm, Sunday 10am - 5pm, and calls from mobiles and landlines are free.',

		// Any page
		missingRequiredFields: 'Please contact the team at B on ' + brand.phoneNumber + ' to add the information below and carry on with your application:',
		newBrowserWindowTitle: 'This link will open in a new browser window.',
	};

	// Address validations. There is a max of 15 so create 15 of these.
	for (var i = 0; i < 15; i++) {
		result['addressPrefix_' + i + 'ValidationMessage'] = 'Sorry, your flat number must be written using numbers and letters only and no longer than 40 characters.';
		result['addressPrefix_' + i + 'HelpMessage'] = 'This is the flat number of your house or apartment.';
		result['houseNumber_' + i + 'ValidationMessage'] = 'Sorry, your house number must be written using numbers and letters only and no longer than 40 characters.';
		result['houseNumber_' + i + 'HelpMessage'] = 'This is the number of your house or apartment.';
		result['houseName_' + i + 'ValidationMessage'] = 'Sorry, your house name must be written using numbers and letters only.';
		result['houseName_' + i + 'HelpMessage'] = 'This is the name of your house or apartment.';
		result['streetName_' + i + 'ValidationMessage'] = 'Your street name should be written using numbers and letters only and be no longer than 40 characters.';
		result['streetName_' + i + 'HelpMessage'] = 'Your street name should be written using number and letters only.';

		for (var j = 1; j < 5; j++) {
			result[['addressLine', j, '_', i, 'ValidationMessage'].join('')] = 'Your address line ' + j + ' should be written using numbers and letters only and be no longer than 40 characters.';
			result[['addressLine', j, '_', i, 'HelpMessage'].join('')] = 'Your address line ' + j + ' should be written using number and letters only.';
		}

		result['city_' + i + 'ValidationMessage'] = 'Your town should be written using numbers and letters only and no longer than 40 characters.';
		result['city_' + i + 'HelpMessage'] = 'Please tell us which town or city this address is in.';
		result['county_' + i + 'ValidationMessage'] = 'Your county should be written using numbers and letters only and no longer than 40 characters.';
		result['county_' + i + 'HelpMessage'] = 'Please tell us which county this address is in.';
		result['country_' + i + 'ValidationMessage'] = 'Please select a valid option from the dropdown.';
		result['country_' + i + 'HelpMessage'] = 'Your current address must be in the UK, but for previous addresses, please tell us which country you lived in.';
		result['dateMoved_' + i + 'ValidationMessage'] = 'Please enter a valid date. For current addresses, the date you moved in needs to be before today. If it\'s a previous address, it should be an earlier date than any addresses listed above it.';
		result['dateMoved_' + i + 'HelpMessage'] = 'Click on the calendar icon to select a date or enter it in the format DD-MM-YYYY.';
		result['postcode_' + i + 'ValidationMessage'] = 'This postcode can\'t be found, please check it and try again. Postcodes are normally formatted like this: A12 3BC. Please ensure you have pressed the search button. If yours still can\'t be found, please call the team at B on  ' + brand.phoneNumber + '.';
		result['postcode_' + i + 'HelpMessage'] = 'You need to supply a valid postcode for any UK address you add. These are normally formatted like this: A12 3BC. If you live at a BFPO address, give us a call.';
	}

	return Object.freeze(result);
})();
