window.envConfig = {
	apiBaseUrl: 'https://my-dev.cybservices.co.uk/bpiInt3',
	appsBaseUrl: 'https://apps-np.cybonline.co.uk/int3',
	AOBaseUrl: 'https://yb.dybapplications.co.uk/int3/account-opening',
	bankId: 'YB',
	callValidate3DTimelimit: 300000,
	disableAnalytics: false,
	disableNavigationWarning: false,
	enableWindowStubs: true,
	requireMobileNumber: true,
	stubApiData: false,
	targetScope: {
		unknown: -1,
		notAuthed: 0,
		authentication: 30,
		login: 20,
	},
	websiteBaseDirectory: '/int3/',
	websiteAssetBaseDirectory: 'account-opening',

	// Timers
	autoLoginTimeout: 9500,			// How long after registering a user for the first time should we wait before logging them in?
	nextTaskCheckInterval: 5000,		// How often should a loading page call getNextTask after the last call?
	defaultAutoSaveInterval: 0,			// milliseconds, 0 = disabled
	shortAutoSaveInterval: 600000,		// After an error occurs, how long before we try an autosave again?
	publicKeyExpiry: 29000,				// How long do public keys from RAM last before becoming invalid?
	tokenInactivityTimeout: 300000,	// How long to wait after a user's last action before expiring their session?
	getCompletedCaseInterval: 5000,
	getCompletedCaseMaxAttempts: 10,
	standardApiDelay: 5000,
};
