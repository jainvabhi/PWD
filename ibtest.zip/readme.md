# Web Coding Standards & Setup

Please see [this wiki page](https://abouthere.atlassian.net/wiki/pages/viewpage.action?pageId=9863980) for setup instructions.

## Setup

```sh
export JENKINS_USERNAME=***
export JENKINS_PASSWORD=***
```

```sh
export DEV1_USERNAME=***
export DEV1_PASSWORD=***
```
