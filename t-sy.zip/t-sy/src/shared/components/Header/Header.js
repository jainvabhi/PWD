import React from 'react';

const Header = () => (
  <header className="header">
    <div className="header--container d-flex justify-content-between">
      <div className="site-logo">
        <button className="site-logo--link">
          <span className="sr-only">Cell Point Mobile</span>
          <span className="site-logo--image">cell point image</span>
        </button>
      </div>
      <div className="site-nav d-flex justify-content-between flex-direcction-reverse">
        <div className="nav--settings">
          <ul className="nav--list d-flex">
            <li className="nav--item">
              <div className="dropdown">
                <button className="nav--link">
                  Currency
                  <span className="dropdown--selecction">Currency</span>
                </button>
                <div className="dropdown--item">
                  <ul className="dropdown--list">
                    <li className="dropdown--list--item">
                      <button className="dropdown--link">INR</button>
                    </li>
                    <li className="dropdown--list--item">
                      <button className="dropdown--link">Dollar</button>
                    </li>
                    <li className="dropdown--list--item">
                      <button className="dropdown--link">EUR</button>
                    </li>
                  </ul>
                </div>
              </div>
            </li>
            <li className="nav--item">
              <div className="dropdown">
                <button className="nav--link">
                  <span className="sr-only">Country</span>
                  <span className="dropdown--selecction">
                    india
                  </span>
                </button>
                <div className="dropdown--item">
                  <ul className="dropdown--list">
                    <li className="dropdown--list--item">
                      <button className="dropdown--link">India</button>
                    </li>
                    <li className="dropdown--list--item">
                      <button className="dropdown--link">US</button>
                    </li>
                    <li className="dropdown--list--item">
                      <button className="dropdown--link">UK</button>
                    </li>
                  </ul>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <div className="site--search">
          <form className="form">
            <div className="form-group">
              <label htmlFor="siteSearch" className="sr-only">Search</label>
              <input type="search" className="form-control" placeholder="Search..." id="siteSearch" name="siteSearch" />
            </div>
          </form>
        </div>
      </div>
    </div>
  </header>
);

export default Header;
