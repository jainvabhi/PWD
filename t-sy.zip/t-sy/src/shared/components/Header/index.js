import React from 'react';
// import PropTypes from 'prop-types';
import Box from '../Box/';
import Dropdown from '../Dropdown/';
import Image from '../Image/';
import logo from '../../../static/images/logo.jpg';
import search from '../../../static/images/search.png';
import india from '../../../static/images/india.png';


const Header = () => (
  <header>
    <Box display="display-flex" justify="justify-between" className="bg-primary px-5">
      <Box>
        <Image src={logo} alt="log" className="display_image_flex header__image--width" />
      </Box>
      <Box className="text-white ibe-header-fontsize" display="display-flex" justify="justify-end" align="align-center">
        <a className="p-3" href="#">
          <Image src={search} alt="log" className="display_image_flex" />
        </a>
        <Dropdown
          label="Currency"
        />
        <Dropdown
          showIcon
          src={india}
          label="Country"
        />
        <a className="p-3">
          <span className="header__pic--background-text-color">YS</span>
          <span> Yashwant Singh</span>
        </a>
      </Box>
    </Box>
  </header>
);


export default Header;
