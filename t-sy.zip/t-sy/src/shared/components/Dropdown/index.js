import React from 'react';
import onClickOutside from 'react-onclickoutside';
import _ from 'lodash';
import PropTypes from 'prop-types';
import Box from '../Box/';
import Image from '../Image/';
import CSSClassnames from '../../utils/CSSClassnames';


const CLASS_ROOT = CSSClassnames.DROPDOWN;

const currency = [
  {
    name: 'india-Rs',
    value: 1972,
  },
  {
    name: 'Doller',
    value: 2000,
  },
  {
    name: 'Euro',
    value: 1983,
  },
];

const Country = [
  {
    name: 'India',
    value: 1972,
  },
  {
    name: 'US',
    value: 2000,
  },
  {
    name: 'UK',
    value: 1983,
  },
];

const Profile = [
  {
    name: 'My Profile',
    value: 1972,
  },
  {
    name: 'Manage Booking',
    value: 2000,
  },
  {
    name: 'Sign Out',
    value: 1983,
  },
];

class Dropdown extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dropdownCss: `${CLASS_ROOT}__content`,
      dropdownoptions: [],
    };
    this.dropdownClick = this.dropdownClick.bind(this);
  }


  componentWillMount() {
    switch (this.props.label) {
    case 'Currency': {
      this.state.dropdownoptions = currency;
      break;
    }
    case 'Country': {
      this.state.dropdownoptions = Country;
      break;
    }
    case 'Profile': {
      this.state.dropdownoptions = Profile;
      break;
    }
    default: {
      console.log('SDF');
      break;
    }
    }
  }

  handleClickOutside= () => {
    this.setState({
      dropdownCss: 'dropdown__content',
    });
  }

  dropdownClick() {
    this.setState({
      dropdownCss: 'dropdown__content dropdown__content--show',
    });
  }
  render() {
    const renderA = _.map(this.state.dropdownoptions, option => (
      <a className="p-2" href="#home">{option.name}</a>
    ));
    return (
      <Box className={CLASS_ROOT} display="display-flex" align="align-center">
        <a href="#" onClick={this.dropdownClick}>
          <Box display="display-flex" className="p-3" align="align-center">
            {this.props.showIcon ?
              (<Image src={this.props.src} alt="log" className="display_image_flex" />
              ) :
              (
                <span >{this.props.label}</span>
              )
            }
            <span className={`${CLASS_ROOT}__triangle--color`} />
          </Box>
        </a>
        <Box id="myDropdown" className={this.state.dropdownCss} >
          {renderA}
        </Box>
      </Box>
    );
  }
}

Dropdown.propTypes = {
  label: PropTypes.string,
  src: PropTypes.string,
  showIcon: PropTypes.bool,
};

export default onClickOutside(Dropdown);
