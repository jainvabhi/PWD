import React from 'react';
import ReactDatePicker from 'react-datepicker';
import moment from 'moment';
import 'react-datepicker/dist/react-datepicker.css';
import PropTypes from 'prop-types';
import Image from '../Image/';
import Box from '../Box/';
import CSSClassnames from '../../utils/CSSClassnames';

const CLASS_ROOT = CSSClassnames.AUTOSUGGEST;

class DatePicker extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      startDate: '',
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleChangeRaw = this.handleChangeRaw.bind(this);
  }

  handleChange(date) {
    this.setState({
      startDate: date,
    });
  }

  handleChangeRaw(value) {
    if (value === 'tomorrow') {
      const tomorrow = moment().add(1, 'day');
      this.handleChange(tomorrow);
    }
  }

  render() {
    return (
      <Box className={this.props.hideBottomMargin ? '' : 'mb-3'}>
        <label className={`${CLASS_ROOT}__label`} htmlFor="inlineFormInputGroup">{this.props.label}</label>
        <Box diplay="display-flex">
          <Box className={`${CLASS_ROOT}__box--background p-2`} >
            <Image src={this.props.icon} alt="log" className="display_image_flex" />
          </Box>
          <ReactDatePicker
            placeholderText={this.props.subLabel}
            selected={this.state.startDate}
            onChange={this.handleChange}
            monthsShown={2}
            onChangeRaw={event =>
              this.handleChangeRaw(event.target.value)}
            className="custom-date-picker"
          />
        </Box>
      </Box>
    );
  }
}

DatePicker.propTypes = {
  label: PropTypes.string,
  icon: PropTypes.string,
  subLabel: PropTypes.string,
  hideBottomMargin: PropTypes.bool,
};
export default DatePicker;
