import React from 'react';
import PropTypes from 'prop-types';

const Notification = ({ type, text, hide }) => (
  <div className={`c-notification c-notification--${type}`}>
    <div className="c-notification-text">{text}</div>
    <button className="c-notification--close" onClick={hide}>
      <svg width="11" height="11" viewBox="0 0 11 11" xmlns="http://www.w3.org/2000/svg"><title>dismiss-cross</title><path d="M4.185 5.5L.658 1.973 0 1.315 1.315 0l.658.658L5.5 4.185 9.027.658 9.685 0 11 1.315l-.658.658L6.815 5.5l3.527 3.527.658.658L9.685 11l-.658-.658L5.5 6.815l-3.527 3.527-.658.658L0 9.685l.658-.658L4.185 5.5z" fill="#fff" fillRule="evenodd" /></svg>
    </button>
  </div>
);

Notification.propTypes = {
  type: PropTypes.string,
  text: PropTypes.string,
  hide: PropTypes.func,
};

export default Notification;
