import React from 'react';
import PropTypes from 'prop-types';
import Image from '../Image/';
import Box from '../Box/';
import CSSClassnames from '../../utils/CSSClassnames';

const CLASS_ROOT = CSSClassnames.FORM_ELEMEMT;

const FormField = ({ ...prps }) => {
  let formField = (<input value={prps.value} onBlur={prps.onUnFocus} onFocus={prps.onFocus} className={`${CLASS_ROOT}__textarea--positon`} placeholder={prps.subLabel} id={name} name={name} type={prps.type} />);
  if (prps.type === 'textarea') {
    formField = (<textarea value={prps.value} className={`${CLASS_ROOT}__textarea--positon`} id={prps.name} name={prps.name} />);
  }
  return (
    <Box className={prps.hideBottomMargin ? '' : 'mb-3'}>
      <label className={`${CLASS_ROOT}__label`} htmlFor="inlineFormInputGroup">{prps.label}</label>
      <Box diplay="display-flex">
        {prps.icon ?
          <Box className={`${CLASS_ROOT}__box--background p-2`} >
            <Image src={prps.icon} alt="log" className="display_image_flex" />
          </Box> : null
        }
        {formField}
      </Box>
    </Box>
  );
};

FormField.propTypes = {
  type: PropTypes.string,
  name: PropTypes.string,
  label: PropTypes.string,
  subLabel: PropTypes.string,
  icon: PropTypes.string,
  value: PropTypes.string,
  onUnFocus: PropTypes.func,
  onFocus: PropTypes.func,
  hideBottomMargin: PropTypes.bool,
};

export default FormField;
