import React from 'react';
import PropTypes from 'prop-types';
import Box from '../../../../shared/components/Box/';
import FormField from '../../../../shared/components/FormField/';
import NumberBox from '../../../../shared/components/NumberBox/';
import passenger from '../../../../static/images/passenger.png';


class PassengerType extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isShow: props.isShow,
    };
    this.showBox = this.showBox.bind(this);
    this.hideBox = this.hideBox.bind(this);
  }

  showBox() {
    this.setState({
      isShow: true,
    });
  }

  hideBox() {
    this.setState({
      isShow: false,
    });
  }

  render() {
    return (
      <Box className="holder" onClick={this.showBox}>
        <FormField
          onClick={this.handleAllClickEvents}
          type="text"
          name="text"
          label="password"
          subLabel="Prom Code"
          error="error message"
          icon={passenger}
          hideBottomMargin
        />
        {
          this.state.isShow
            ? <Box className="bg-white p-2 dropdownr" display="display-inline-flex">
              <Box>
                <NumberBox
                  label="ADULT(+12yrs)"
                />
                <NumberBox
                  label="Child(2-12yrs)"
                />
                <NumberBox
                  label="INFANTS(0-2yrs)"
                />
              </Box>
            </Box>
            : null
        }
      </Box>
    );
  }
}

PassengerType.propTypes = {
  isShow: PropTypes.bool,
};

export default PassengerType;
