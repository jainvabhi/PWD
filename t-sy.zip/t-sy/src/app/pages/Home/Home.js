import React from 'react';

const Home = () => (
  <div className="f-search--container">
    <section className="carousel carousel--large">
      <div className="carousel--container">
        <div className="carousel--item">
          <div className="carousel--body">
            <div className="carousel--image">
              carousel image 1
            </div>
          </div>
        </div>
        <div className="carousel--item">
          <div className="carousel--body">
            <div className="carousel--image">
              carousel image 2
            </div>
          </div>
        </div>
      </div>
    </section>
    <section className="section f-search">
      <div className="section--title">
        <h2>Book a Flight</h2>
        <p>Discover a better way to fly</p>
      </div>
      <div className="f-search--box card">
        <div className="card--body">
          <div className="f-search--tab tab d-flex">
            <button className="btn tab--link tab--active">Round Trip</button>
            <button className="btn tab--link">One Way</button>
          </div>
          <div className="tab--body">
            <form className="form">
              <div className="form-group">
                <label className="sr-only" htmlFor="inlineFormInputGroupUsername">Search Origin</label>
                <div className="input-group mb-2 mb-sm-0">
                  <div className="input-group-addon">@</div>
                  <input type="text" className="form-control" id="inlineFormInputGroupUsername" placeholder="Search Origin" />
                </div>
              </div>
              <div className="form-group">
                <label className="sr-only" htmlFor="serchDest">Search Destination</label>
                <div className="input-group mb-2 mb-sm-0">
                  <div className="input-group-addon">@</div>
                  <input type="text" className="form-control" id="serchDest" placeholder="Search Destination" />
                </div>
              </div>
              <div className="d-flex justify-content-between">
                <div className="form-group">
                  <label className="sr-only" htmlFor="deDate">Depart Date</label>
                  <div className="input-group mb-2 mb-sm-0">
                    <div className="input-group-addon">@</div>
                    <input type="date" className="form-control" id="deDate" placeholder="Departure Date" />
                  </div>
                </div>
                <div className="form-group ml-2">
                  <label className="sr-only" htmlFor="reDate">Return Date</label>
                  <div className="input-group mb-2 mb-sm-0">
                    <div className="input-group-addon">@</div>
                    <input type="date" className="form-control" id="inlineFormInputGroupUsername" placeholder="Return Date" />
                  </div>
                </div>
              </div>
              <div className="d-flex justify-content-between">
                <div className="form-group">
                  <label className="sr-only" htmlFor="pCode">Promo Code</label>
                  <div className="input-group mb-2 mb-sm-0">
                    <div className="input-group-addon">@</div>
                    <input type="date" className="form-control" id="deDate" placeholder="Promo Code" />
                  </div>
                </div>
                <div className="form-group ml-2">
                  <label className="sr-only" htmlFor="fClass">Class</label>
                  <div className="input-group mb-2 mb-sm-0">
                    <div className="input-group-addon">@</div>
                    <select id="fClass" className="form-control">
                      <option value="economy">Economy</option>
                      <option value="first">First</option>
                    </select>
                  </div>
                </div>
              </div>
              <div className="form-footer">
                <button className="btn btn-primary">Search Flight</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  </div>
);

export default Home;
