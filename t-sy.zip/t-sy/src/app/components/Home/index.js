import React from 'react';

const Home = () => (
  <div className="home">
    <section className="container">
      <div className="section--title">
        <h2>Book a flight</h2>
        <p>Discover a better way to fly</p>
      </div>
      <div className="card">
        <div className="card--header d--flex">
          <button className="col btn btn--light active">Round Trip</button>
          <button className="col btn btn--light">One Way</button>
        </div>
        <div className="card--body">
          <form classNames="form">
            <div className="input--group">
              <label htmlFor="origin" className="sr-only">Select Origin</label>
              <div className="input--group-addon">@</div>
              <input type="text" id="origin" name="origin" className="form--control" />
            </div>
            <div className="input--group">
              <label htmlFor="destination" className="sr-only">Select Destination</label>
              <div className="input--group-addon">@</div>
              <input type="text" id="destination" name="destination" className="form--control" />
            </div>
            <div className="form--row flex--align-items--center">
              <div className="col">
                <div className="input--group">
                  <label htmlFor="origin" className="sr-only">Select Origin</label>
                  <div className="input--group-addon">@</div>
                  <input type="text" id="origin" name="origin" className="form--control" />
                </div>
              </div>
              <div className="col">
                <div className="input--group">
                  <label htmlFor="destination" className="sr-only">Select Destination</label>
                  <div className="input--group-addon">@</div>
                  <input type="text" id="destination" name="destination" className="form--control" />
                </div>
              </div>
            </div>
            <div className="form--row flex--align-items--center">
              <div className="col">
                <div className="input--group">
                  <label htmlFor="origin" className="sr-only">Select Origin</label>
                  <div className="input--group-addon">@</div>
                  <input type="text" id="origin" name="origin" className="form--control" />
                </div>
              </div>
              <div className="col">
                <div className="input--group">
                  <label htmlFor="destination" className="sr-only">Select Destination</label>
                  <div className="input--group-addon">@</div>
                  <input type="text" id="destination" name="destination" className="form--control" />
                </div>
              </div>
            </div>
            <div className="form--row flex--align-items--center">
              <div className="col">
                <div className="input--group">
                  <label htmlFor="origin" className="sr-only">Select Origin</label>
                  <div className="input--group-addon">@</div>
                  <input type="text" id="origin" name="origin" className="form--control" />
                </div>
              </div>
              <div className="col">
                <button className="btn btn--primary">Flight Search</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </section>
  </div>
);


export default Home;
