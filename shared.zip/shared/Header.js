import React from 'react';

const Header = () => (
  <header className="navbar navbar--dark flex--direction-row">
    <button className="navbar--brand btn--no-style" type="button">
      voyage
    </button>
    <div className="ml--auto navbar--search">
      <form className="form">
        <div className="form--group">
          <label htmlFor="ibe_search">Search</label>
          <input type="search" name="ibe_search" value="" id="ibe_search" placeholder="Search..." />
          <button className="btn btn--secondary">S</button>
        </div>
      </form>
    </div>
    <ul className="navbar--nav d--md-flex d--none">
      <li className="navbar--item dropdown">
        <button className="btn--no-style dropdown--link">Currency</button>
        <div className="dropdown--menu">
          <button className="btn--no-style dropdown--item active">INR</button>
          <button className="btn--no-style dropdown--item active">Dollar</button>
        </div>
      </li>
      <li className="navbar--item dropdown">
        <button className="btn--no-style dropdown--link">Language</button>
        <div className="dropdown--menu">
          <button className="btn--no-style dropdown--item active">INR</button>
          <button className="btn--no-style dropdown--item active">Dollar</button>
        </div>
      </li>
      <li className="navbar--item dropdown">
        <button className="btn--no-style dropdown--link">Welcome User</button>
        <div className="dropdown--menu">
          <button className="btn--no-style dropdown--item active">My Account</button>
          <button className="btn--no-style dropdown--item active">Logout</button>
        </div>
      </li>
    </ul>
  </header>
);


export default Header;
