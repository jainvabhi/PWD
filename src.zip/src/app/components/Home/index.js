import React from 'react';
import IconInbound from '../../../static/svg/IconInbound';
import IconOutbound from '../../../static/svg/IconOutbound';
import IconCalander from '../../../static/svg/IconCalander';
import IconClass from '../../../static/svg/IconClass';
import IconPassengers from '../../../static/svg/IconPassengers';

const Home = () => (
  <div className="home bg--dark">
    <section className="container px--6">
      <div className="section--title">
        <h2>Book a flight</h2>
        <p>Discover a better way to fly</p>
      </div>
      <div className="card bg--dark transparent col--md--6">
        <div className="p--4">
          <div className="card--header d--flex mb--3">
            <button className="col btn btn--light active">Round Trip</button>
            <button className="col btn btn--light">One Way</button>
          </div>
          <div className="card--body">
            <form className="form">
              <div className="input--group">
                <label htmlFor="origin" className="sr-only">Select Origin</label>
                <div className="input--group-addon">
                  <IconOutbound height="20" width="20" />
                </div>
                <input type="text" id="origin" name="origin" className="form--control" placeholder="Select Origin" />
              </div>
              <div className="input--group">
                <label htmlFor="destination" className="sr-only">Select Destination</label>
                <div className="input--group-addon">
                  <IconInbound height="20" width="20" />
                </div>
                <input type="text" id="destination" name="destination" className="form--control" placeholder="Select Destination" />
              </div>
              <div className="form--row flex--align-items--center">
                <div className="col">
                  <div className="input--group">
                    <label htmlFor="dDate" className="sr-only">Departure Date</label>
                    <div className="input--group-addon">
                      <IconCalander height="20" width="20" />
                    </div>
                    <input type="text" id="dDate" name="dDate" className="form--control" placeholder="Departure Date" />
                  </div>
                </div>
                <div className="col">
                  <div className="input--group">
                    <label htmlFor="rDate" className="sr-only">Return Date</label>
                    <div className="input--group-addon">
                      <IconCalander height="20" width="20" />
                    </div>
                    <input type="text" id="rDate" name="rDate" className="form--control" placeholder="Return Date" />
                  </div>
                </div>
              </div>
              <div className="form--row flex--align-items--center">
                <div className="col">
                  <div className="input--group">
                    <label htmlFor="passengers" className="sr-only">Passengers</label>
                    <div className="input--group-addon">
                      <IconPassengers height="20" width="20" />
                    </div>
                    <input type="text" id="passengers" name="passengers" className="form--control" placeholder="passengers" />
                  </div>
                </div>
                <div className="col">
                  <div className="input--group">
                    <label htmlFor="class" className="sr-only">Class</label>
                    <div className="input--group-addon">
                      <IconClass height="20" width="20" />
                    </div>
                    <input type="text" id="class" name="class" className="form--control" />
                  </div>
                </div>
              </div>
              <div className="form--row flex--align-items--center">
                <div className="col">
                  <div className="form--group">
                    <label htmlFor="origin" className="sr-only">Select Origin</label>
                    <input type="text" id="origin" name="origin" className="form--control" />
                  </div>
                </div>
                <div className="col">
                  <button className="btn btn--primary btn--block">Flight Search</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  </div>
);


export default Home;
