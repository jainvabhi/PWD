import React from 'react';
import VoyageLogo from '../../static/svg/VoyageLogo';
import IconSearch from '../../static/svg/IconSearch';
import DefaultUserIcon from '../../static/images/user.svg';

const Header = () => (
  <header className="navbar navbar--dark flex--direction-row">
    <button className="navbar--brand btn--no-style" type="button">
      <VoyageLogo className="navbar--brand-logo" />
    </button>
    <div className="ml--auto navbar--search">
      <form className="form">
        <div className="input--group m--0">
          <label className="sr-only" htmlFor="ibe_search">Search</label>
          <input className="form--control d--none" type="search" name="ibe_search" value="" id="ibe_search" placeholder="Search..." />
          <span className="input--group-btn">
            <button className="btn btn--secondary d--flex">
              <IconSearch />
            </button>
          </span>
        </div>
      </form>
    </div>
    <ul className="navbar--nav d--md-flex flex--align-items--center d--none m--0 p--0">
      <li className="navbar--item dropdown">
        <button className="btn--no-style dropdown--link">Currency</button>
        <div className="dropdown--menu">
          <button className="btn--no-style dropdown--menu-item active">INR</button>
          <button className="btn--no-style dropdown--menu-item">Dollar</button>
        </div>
      </li>
      <li className="navbar--item dropdown">
        <button className="btn--no-style dropdown--link">Language</button>
        <div className="dropdown--menu">
          <button className="btn--no-style dropdown--menu-item active">INR</button>
          <button className="btn--no-style dropdown--menu-item">Dollar</button>
        </div>
      </li>
      <li className="navbar--item dropdown">
        <button className="btn--no-style dropdown--link">
          <div className="d--flex flex--align-items--center">
            <span
              className="thumbnail"
              style={{
                backgroundImage: `url(${DefaultUserIcon})`,
              }}
            />
            <span className="ml--2">Tejpal Rajput</span>
          </div>
        </button>
        <div className="dropdown--menu">
          <button className="btn--no-style dropdown--menu-item">My Account</button>
          <button className="btn--no-style dropdown--menu-item">Logout</button>
        </div>
      </li>
    </ul>
  </header>
);


export default Header;
