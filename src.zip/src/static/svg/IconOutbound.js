import React from 'react';
import PropTypes from 'prop-types';

const IconOutbound = ({ ...props }) => (
  <svg width={props.width || '36'} height={props.height || '36'} viewBox="0 0 36 36">
    <path id="iconOutbound" data-name="Forma 1" fill={props.fill || '#262626'} d="M1.162,30.34H34.879v3.674H1.162V30.34Zm34.728-17.2a2.648,2.648,0,0,0-3.256-1.947L23.2,13.81,10.958,1.99l-3.424.956L14.88,16.124,6.059,18.567,2.574,15.729,0,16.445,3.229,22.24l1.358,2.434,2.849-.79,9.431-2.617,7.71-2.139,9.432-2.617A2.761,2.761,0,0,0,35.89,13.139Z" />
  </svg>
);

IconOutbound.propTypes = {
  width: PropTypes.string,
  height: PropTypes.string,
  fill: PropTypes.string,
};

export default IconOutbound;
