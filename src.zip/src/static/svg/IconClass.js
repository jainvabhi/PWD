import React from 'react';
import PropTypes from 'prop-types';

const IconClass = ({ ...props }) => (
  <svg width={props.width || '36'} height={props.height || '36'} viewBox="0 0 36 36">
    <path id="iconClass" data-name="Forma 1" fill={props.fill || '#262626'} d="M5.709,0.9A2.594,2.594,0,0,1,7.693-.01H9.8a3.567,3.567,0,0,1,3.31,2.988l0.134,0.815a2.777,2.777,0,0,1-.507,2.187,2.377,2.377,0,0,1-1.917.915H8.1a2.765,2.765,0,0,1-1.084-.225L7.3,9.332A2.2,2.2,0,0,1,8.21,9.138h3.111a3.18,3.18,0,0,1,2.92,2.542l2.752,13.944,12.982-1a1.784,1.784,0,0,1,1.65.7,2.144,2.144,0,0,1,.28,1.776L30.4,33.49a3.311,3.311,0,0,1-3,2.511H10.8a2.859,2.859,0,0,1-2.7-2.61L5.976,11.808a2.8,2.8,0,0,1-.009-0.365L5.238,4.75a3.315,3.315,0,0,1-.189-0.912L5,3.093A3.017,3.017,0,0,1,5.709.9Z" />
  </svg>
);

IconClass.propTypes = {
  width: PropTypes.string,
  height: PropTypes.string,
  fill: PropTypes.string,
};

export default IconClass;
