import React from 'react';
import PropTypes from 'prop-types';

const IconCalander = ({ ...props }) => (
  <svg width={props.width || '36'} height={props.height || '36'} viewBox="0 0 36 36">
    <path id="iconCalander" data-name="Forma 1" fill={props.fill || '#262626'} d="M32.33,3.186H27V1.062a1,1,0,1,0-2,0V3.186H19V1.062a1,1,0,1,0-2,0V3.186H11V1.062a1,1,0,1,0-2,0V3.186H3.667A2.752,2.752,0,0,0,1,6.018V33.153a2.752,2.752,0,0,0,2.667,2.833H32.33a2.751,2.751,0,0,0,2.664-2.833V6.018A2.75,2.75,0,0,0,32.33,3.186Zm0.665,29.967a0.688,0.688,0,0,1-.665.709H3.667A0.69,0.69,0,0,1,3,33.153V6.018A0.69,0.69,0,0,1,3.667,5.31H9V7.434a1,1,0,1,0,2,0V5.31h6V7.434a1,1,0,1,0,2,0V5.31h6V7.434a1,1,0,1,0,2,0V5.31H32.33a0.688,0.688,0,0,1,.665.708V33.153ZM9,13.745h4v3.186H9V13.745Zm0,5.31h4v3.186H9V19.056Zm0,5.31h4v3.186H9V24.366Zm7,0h4v3.186H16V24.366Zm0-5.31h4v3.186H16V19.056Zm0-5.31h4v3.186H16V13.745Zm7,10.62h4v3.186H23V24.366Zm0-5.31h4v3.186H23V19.056Zm0-5.31h4v3.186H23V13.745Z" />
  </svg>
);

IconCalander.propTypes = {
  width: PropTypes.string,
  height: PropTypes.string,
  fill: PropTypes.string,
};

export default IconCalander;
