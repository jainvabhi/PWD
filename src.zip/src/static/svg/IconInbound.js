import React from 'react';
import PropTypes from 'prop-types';

const IconInbound = ({ ...props }) => (
  <svg width={props.width || '36'} height={props.height || '36'} viewBox="0 0 36 36">
    <path id="iconInbound" data-name="Forma 1 copy 2" fill={props.fill || '#262626'} d="M1.162,30.34H34.879v3.674H1.162V30.34Z" />
    <path id="Forma_1_copy" data-name="Forma 1 copy" fill={props.fill || '#262626'} d="M33.688,23.285a2.641,2.641,0,0,0-1.855-3.3l-9.49-2.423L17.608,1.253,14.16,0.378,13.965,15.427l-8.874-2.27L3.481,8.97l-2.59-.659L0.8,14.927l-0.035,2.78L3.635,18.44l9.49,2.422,7.758,1.981,9.491,2.423A2.765,2.765,0,0,0,33.688,23.285Z" />
  </svg>
);

IconInbound.propTypes = {
  width: PropTypes.string,
  height: PropTypes.string,
  fill: PropTypes.string,
};

export default IconInbound;
