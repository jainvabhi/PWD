import React from 'react';
import PropTypes from 'prop-types';

const Form = ({ onSubmit }) => (
  <form onSubmit={onSubmit}>
    <input
      type="email"
      name="email"
      placeholder="Email address"
      title="Enter your email address"
      required
      className="form-control"
    />
    <input
      type="password"
      name="password"
      placeholder="Password"
      title="Type a strong password: aBC_123^"
      pattern="^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[^\w\s]).{8,}$"
      required
      className="form-control"
    />
    <button className="btn btn-primary" type="submit">Continue</button>
  </form>
);

Form.propTypes = {
  onSubmit: PropTypes.func.isRequired,
};

export default Form;
