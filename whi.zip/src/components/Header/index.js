import React from 'react';

const Header = () => (
  <div>
    <h1>Syntel - Whrolphool AI Demo</h1>
  </div>
);

export default Header;
