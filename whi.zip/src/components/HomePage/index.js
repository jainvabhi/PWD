import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Dropzone from 'react-dropzone';
import request from 'superagent';

const PREDICTION_KEY = '11abea3320d04833af3305ab902b93f6';
const CUSTOM_VISION_URL = 'https://southcentralus.api.cognitive.microsoft.com/customvision/v1.0/Prediction/6db2e8a3-3872-4847-bb93-5fb8e950d750/image?iterationId=006c4bb3-c8be-4fb2-83e5-f9d0c7612069';
// https://southcentralus.api.cognitive.microsoft.com/customvision/v1.0/Prediction/6db2e8a3-3872-4847-bb93-5fb8e950d750/image?iterationId=006c4bb3-c8be-4fb2-83e5-f9d0c7612069
// Set Prediction-Key Header to : 11abea3320d04833af3305ab902b93f6
// Set Content-Type Header to : application/octet-stream
// Set Body to : <image file>

export default class HomePage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      uploadedFile: '',
      tags: '',
    };
  }
  onImageDrop = files => {
    console.log(files);
    this.setState({ tags: '' });
    this.setState({
      uploadedFile: files[0],
    });
    this.handleImageUpload(files[0]);
  }

  handleImageUpload = file => {
    const upload = request.post(CUSTOM_VISION_URL)
    .set({ 'Prediction-Key': PREDICTION_KEY, Accept: 'application/json' })
    .field('file', file);
    upload.end((err, response) => {
      if (err) {
        console.error(err);
      }
      if (response.status === 200) {
        this.setState({
          tags: response.body.Predictions,
        });
      }
    });
  }

  render() {
    console.log(this.state.uploadedFile);
    let showImage;
    if (this.state.tags) {
      showImage = 'show image tags';
    }
    return (
      <div>
        <h2>Welcome to home page</h2>
        <Dropzone
          disablePreview
          multiple={false}
          accept="image/*"
          activeClassName="active-dropzone"
          onDrop={this.onImageDrop}
        >
          <p>Drop an image or click to select a file to upload.</p>
        </Dropzone>
        <img alt="as" src={this.state.uploadedFile.preview} />
        <button onClick={this.props.logout}>Logout</button>
        {showImage}
      </div>
    );
  }
}

HomePage.propTypes = {
  logout: PropTypes.func.isRequired,
};

