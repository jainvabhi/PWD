import React from 'react';

const Header = () => (
  <div>
    <h1 className="text-center mb-4 pt-4">SYNTEL - Whirlphool AI Demo</h1>
  </div>
);

export default Header;
