export const namespace = 'ibe--';

export default {
  BOX: 'box',
  BUTTON: 'button',
  DROPDOWN: 'dropdown',
  IMG: `${namespace}image`,
  AUTOSUGGEST: 'autosuggest',
  DATEPICKER: 'datepicker',
  HEADING: 'heading',
  HEADER: 'header',
  BACKGROUND_COLOR_INDEX: `${namespace}background-color-index`,
  SEARCH: `${namespace}search`,
  SEARCH_INPUT: `${namespace}search-input`,
  FORM_ELEMEMT: 'formelement',
  APP: `${namespace}app`,
};
