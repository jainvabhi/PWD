import React from 'react';

const TwitterLogo = () => (
  <svg className="logo-twitter" version="1.1" x="0px" y="0px" width="35px" height="57px" viewBox="0 0 35 57" enableBackground="new 0 0 35 57" xmlSpace="preserve">
    <path d="M20.9,0v15.6h14.2v9.1H20.9v16.4c0,0-0.6,6.1,6.2,5.5c3.2-0.3,6.1-1.8,8.1-4.4v10.4c0,0-2.4,2.8-8.6,3.8 c-3.1,0.4-6.3,0.5-9.4,0.2C12.6,56,6.5,53.8,6.5,41.9V24.7H0v-9.1c0,0,12.3-0.4,12.3-15.6H20.9z" />
  </svg>
);

export default TwitterLogo;
