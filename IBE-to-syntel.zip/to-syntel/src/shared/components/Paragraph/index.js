import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import CSSClassnames from '../../utils/CSSClassnames';

const CLASS_ROOT = CSSClassnames.Paragraph;


const Paragraph = ({ ...props }) => {
  const classes = classnames(
    CLASS_ROOT, {
      [`${CLASS_ROOT}--${props.align}`]: props.align,
    },
    props.className,
  );
  return (
    <p className={classes}>{props.children}</p>
  );
};
Paragraph.propTypes = {
  props: PropTypes.element.isRequired,
  children: PropTypes.any.isRequired,
  className: PropTypes.string,
  align: PropTypes.oneOf(['left', 'right', 'center ']),
};
export default Paragraph;

