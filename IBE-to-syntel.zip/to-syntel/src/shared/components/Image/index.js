import React from 'react';
import PropTypes from 'prop-types';
// import classnames from 'classnames';
// import Label from '../Label';
// import CSSClassnames from '../../utils/CSSClassnames';


// check for conditional attribute and its value. 
// const CLASS_ROOT = CSSClassnames.IMG;
// import TwitterLogo from '../../../shared/svg/TwitterLogo';

const Image = ({ ...props }) => (
  <img {...props} className={props.className} alt={props.alt} src={props.src} />
);

Image.propTypes = {
  className: PropTypes.string,
  alt: PropTypes.string,
  src: PropTypes.string,
};
export default Image;


// TODO
// 1) need to add full property
// ex. full: PropTypes.oneOf([true, 'horizontal', 'vertical', false])
