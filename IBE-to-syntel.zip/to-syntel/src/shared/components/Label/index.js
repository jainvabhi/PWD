import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import CSSClassnames from '../../utils/CSSClassnames';

const CLASS_ROOT = CSSClassnames.HEADING;
// import TwitterLogo from '../../../shared/svg/TwitterLogo';

const Label = ({ ...props }) => {
  const labelMargin = props.margin ? props.margin : 'medium';
  const classes = classnames(
    CLASS_ROOT,
    {
      [`${CLASS_ROOT}--truncate`]: props.truncate,
      [`${CLASS_ROOT}--uppercase`]: props.uppercase,
      [`${CLASS_ROOT}--margin-${labelMargin}`]: labelMargin,
      [`${CLASS_ROOT}--${props.size}`]: props.size,
      [`${CLASS_ROOT}--align-${props.align}`]: props.align,
    },
    props.className
  );
  return (
    <label {...props} className={classes} htmlFor={props.labelFor}>
      {props.children}
    </label>
  );
};


Label.propTypes = {
  props: PropTypes.element.isRequired,
  children: PropTypes.any.isRequired,
  align: PropTypes.oneOf(['start', 'center', 'end']),
  announce: PropTypes.bool,
  labelFor: PropTypes.string,
  margin: PropTypes.oneOf(['none', 'small', 'medium', 'large']),
  size: PropTypes.oneOf(['small', 'medium', 'large']),
  truncate: PropTypes.bool,
  uppercase: PropTypes.bool,
  className: PropTypes.string,
};

Label.defaultProps = {
  size: 'medium',
};
export default Label;
