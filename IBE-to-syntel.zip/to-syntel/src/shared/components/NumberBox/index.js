import React from 'react';
import PropTypes from 'prop-types';
import Box from '../Box/';
import Button from '../Button/';

class NumberBox extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 1,
    };
    this.increase = this.increase.bind(this);
    this.decrease = this.decrease.bind(this);
  }

  increase() {
    this.setState({
      count: this.state.count + 1,
    });
  }

  decrease() {
    this.setState({
      count: this.state.count - 1 < 0 ? 0 : this.state.count - 1,
    });
  }

  render() {
    return (
      <Box className="bg-white" >
        <Box className="my-2">
          {this.props.label}
        </Box>
        <Box display="display-inline-flex" className="ibe-border">
          <Button onClick={() => this.increase()} type="primary" size="small" title="+" />
          <Box className="px-4 bg-light" display="display-flex" align="align-center"> {this.state.count} </Box>
          <Button onClick={() => this.decrease()} type="primary" size="small" title="-" secondary />
        </Box>
      </Box>
    );
  }
}

NumberBox.propTypes = {
  label: PropTypes.string,
};

export default NumberBox;
