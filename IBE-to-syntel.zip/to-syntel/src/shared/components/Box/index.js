import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import CSSClassnames from '../../utils/CSSClassnames';


const CLASS_ROOT = CSSClassnames.BOX;

const Box = ({ ...props }) => {
  const css = [];
  if (props.className) {
    css.push(`${props.className}`);
  }
  const allValues = Object.values(_.omit(props, 'className'));
  // const allValues = Object.values(props);
  // const notStringArray = ['bgImage', 'col', 'responsive', 'children'];
  _.map(allValues, item => {
    if (item === 'row') {
      css.push('row');
    } else
    if (typeof item === 'string' && item !== 'children') {
      css.push(`${CLASS_ROOT}--${(item)}`);
    }
  });

  let bgStyles;
  if (props.bgImage) {
    bgStyles = {
      backgroundImage: `url(${props.bgImage})`,
    };
    css.push('boxDiv__image');
  }
  if (props.hide) {
    css.push(`${CLASS_ROOT}-hide`);
  }

  if (props.col) {
    if (props.responsive) {
      if (props.responsive.mobile) {
        css.push(`col-xs-${props.responsive.mobile}`);
      }
      if (props.responsive.tablet) {
        css.push(`col-sm-${props.responsive.tablet}`);
      }
      if (props.responsive.sDesktop) {
        css.push(`col-md-${props.responsive.sDesktop}`);
      }
      if (props.responsive.lDesktop) {
        css.push(`col-lg-${props.responsive.size}`);
      }
    }
    if (props.offset) {
      if (props.offset.mobile) {
        css.push(`col-xs-offset-${props.offset.mobile}`);
      }
      if (props.offset.tablet) {
        css.push(`col-sm-offset-${props.offset.tablet}`);
      }
      if (props.offset.sDesktop) {
        css.push(`col-md-offset-${props.offset.sDesktop}`);
      }
      if (props.offset.lDesktop) {
        css.push(`col-lg-offset-${props.offset.lDesktop}`);
      }
    }
  }

  const finalCss = _.join(css, ' ');
  const styleCSS = _.merge({}, bgStyles);

  return (
    <div className={finalCss} style={styleCSS}>
      {props.children}
    </div>
  );
};

Box.propTypes = {
  className: PropTypes.string,
  bgImage: PropTypes.string,
  children: PropTypes.any.isRequired,
  row: PropTypes.string,
  primary: PropTypes.string,
  col: PropTypes.bool,
  bgcolor1: PropTypes.bool,
  hide: PropTypes.bool,
  size: PropTypes.string,
  responsive: PropTypes.object,
  offset: PropTypes.object,
  display: PropTypes.oneOf(['display-flex', 'display-inline', 'display-block ', 'display-inline-flex']),
  direction: PropTypes.oneOf(['direction-row', 'direction-row-reverse', 'direction-column ', 'direction-column-reverse']),
  wrap: PropTypes.oneOf(['wrap ']),
  align: PropTypes.oneOf(['align-start', 'align-end', 'align-center', 'align-baseline', 'align-stretch']),
  justify: PropTypes.oneOf(['justify-start', 'justify-end', 'justify-center', 'justify-space-between', 'justify-space-around', 'justify-space-evenly ']),
  textAlign: PropTypes.oneOf(['text-align-left', 'text-align-center', 'text-align-right']),
  basis: PropTypes.oneOf(['basis-auto']),
};

export default Box;
