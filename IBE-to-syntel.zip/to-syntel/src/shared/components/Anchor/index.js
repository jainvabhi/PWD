import React from 'react';
import PropTypes from 'prop-types';

const Anchor = ({ href, size, icon, title, secondary }) => (
  <a href={href} className={secondary ? `c-btn c-btn--secondary c-btn--${size}` : `c-btn c-btn--primary c-btn--${size}`}>
    <span className="c-btn--flex">
      {icon ? <span className="c-btn--icon"><i className={`fa fa-${icon}`} /> </span> : ''} <span className="c-btn--title">{title}</span>
    </span>
  </a>
);

Anchor.propTypes = {
  title: PropTypes.string,
  icon: PropTypes.string,
  secondary: PropTypes.bool,
  href: PropTypes.string,
  size: PropTypes.string,
};

export default Anchor;
