import React from 'react';
import Autosuggest from 'react-autosuggest';
import PropTypes from 'prop-types';
import Image from '../Image/';
import Box from '../Box/';
import CSSClassnames from '../../utils/CSSClassnames';

const CLASS_ROOT = CSSClassnames.AUTOSUGGEST;

const types = [
  {
    name: 'Economy',
    year: 1972,
  },
  {
    name: 'Business',
    year: 2000,
  },
  {
    name: 'Prime Class',
    year: 1983,
  },
];

const languages = [
  {
    name: 'Pune',
    year: 1972,
  },
  {
    name: 'Mumbai',
    year: 2000,
  },
  {
    name: 'Jaipur',
    year: 1983,
  },
  {
    name: 'Delhi',
    year: 2007,
  },
  {
    name: 'Leh Ladak',
    year: 2012,
  },
  {
    name: 'Nagpur',
    year: 2009,
  },
  {
    name: 'Haridwar',
    year: 1990,
  },
  {
    name: 'Jodhpur',
    year: 1995,
  },
  {
    name: 'Nagpur',
    year: 1995,
  },
  {
    name: 'Nashik',
    year: 1987,
  },
];

function escapeRegexCharacters(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function getSuggestions(value, type) {
  const escapedValue = escapeRegexCharacters(value.trim());
  if (escapedValue === '') {
    return [];
  }

  const regex = new RegExp(`^${escapedValue}`, 'i');

  return type ? types.filter(types => regex.test(types.name)) :
    languages.filter(language => regex.test(language.name));
}

function getSuggestionValue(suggestion) {
  return suggestion.name;
}

function renderSuggestion(suggestion) {
  return (
    <span>{suggestion.name}</span>
  );
}

class AutosuggestBox extends React.Component {
  constructor() {
    super();

    this.state = {
      value: '',
      suggestions: [],
    };
  }

  onChange = (event, { newValue }) => {
    this.setState({
      value: newValue,
    });
  };

  onSuggestionsFetchRequested = ({ value }) => {
    this.setState({
      suggestions: getSuggestions(value, this.props.classType),
    });
  };

  onSuggestionsClearRequested = () => {
    this.setState({
      suggestions: [],
    });
  };

  render() {
    const { value, suggestions } = this.state;
    const inputProps = {
      placeholder: this.props.subLabel,
      value,
      onChange: this.onChange,
    };

    return (
      <Box className={this.props.hideBottomMargin ? '' : 'mb-3'}>
        <label className={`${CLASS_ROOT}__label`} htmlFor="inlineFormInputGroup">{this.props.label}</label>
        <Box diplay="display-flex">
          <Box className={`${CLASS_ROOT}__box--background p-2`} >
            <Image src={this.props.icon} alt="log" className="display_image_flex" />
          </Box>
          <Autosuggest
            suggestions={suggestions}
            onSuggestionsFetchRequested={this.onSuggestionsFetchRequested}
            onSuggestionsClearRequested={this.onSuggestionsClearRequested}
            getSuggestionValue={getSuggestionValue}
            renderSuggestion={renderSuggestion}
            inputProps={inputProps}
          />
        </Box>
      </Box>
    );
  }
}

AutosuggestBox.propTypes = {
  label: PropTypes.string,
  icon: PropTypes.string,
  subLabel: PropTypes.string,
  hideBottomMargin: PropTypes.bool,
  classType: PropTypes.bool,
};

export default AutosuggestBox;
