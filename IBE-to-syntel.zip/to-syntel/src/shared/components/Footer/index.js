import React from 'react';
// import PropTypes from 'prop-types';
import Box from '../Box/';
import Paragraph from '../Paragraph/';
// import TwitterLogo from '../../../shared/svg/TwitterLogo';

const Footer = () => (
  <footer>
    <Box className="m-auto py-3 bg-primary text-white">
      <Box justify="justify-center" display="display-flex">
        <Paragraph className="text-white ibe-footer_paraghrap" align="center">@ Cellpoint Mobile 2017 - All Right Reserved </Paragraph>
      </Box>
    </Box>
  </footer>
);

export default Footer;
