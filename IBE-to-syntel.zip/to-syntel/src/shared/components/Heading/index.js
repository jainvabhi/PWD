import React from 'react';
import classnames from 'classnames';
import PropTypes from 'prop-types';
import CSSClassnames from '../../utils/CSSClassnames';

const CLASS_ROOT = CSSClassnames.HEADING;

const Heading = ({ ...props }) => {
  const classes = classnames(
    CLASS_ROOT, {
      [`${CLASS_ROOT}--${props.size}`]: props.size,
      [`${CLASS_ROOT}--strong`]: props.strong,
      [`${CLASS_ROOT}--align-${props.align}`]: props.align,
      [`${CLASS_ROOT}--margin-${props.margin}`]: props.margin,
      [`${CLASS_ROOT}--truncate`]: props.truncate,
      [`${CLASS_ROOT}--uppercase`]: props.uppercase,
      [`${CLASS_ROOT}--bold`]: props.bold,
    },
    props.className,
  );
  return (
    <props.tag {...props} className={classes}>
      {props.children}
    </props.tag>
  );
};

Heading.propTypes = {
  align: PropTypes.oneOf(['start', 'center', 'end']),
  margin: PropTypes.oneOf(['none', 'small', 'medium', 'large']),
  size: PropTypes.oneOf(['small', 'medium', 'large']),
  strong: PropTypes.bool,
  tag: PropTypes.string,
  className: PropTypes.className,
  children: PropTypes.any.isRequired,
  truncate: PropTypes.bool,
  uppercase: PropTypes.bool,
  bold: PropTypes.bool,
};

Heading.defaultProps = {
  tag: 'h1',
};

export default Heading;
