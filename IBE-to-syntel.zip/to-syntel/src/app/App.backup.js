import React from 'react';
import { Carousel } from 'react-responsive-carousel';
// common components
import Footer from '../shared/components/Footer/';
import Box from '../shared/components/Box/';
import Header from '../shared/components/Header';
import HeaderNew from '../shared/components/Header/Header';
import bgslider1 from '../static/images/bgslider.jpg';
import bgslider2 from '../static/images/bgslider.png';

// custom Components
import Home from './pages/Home';
import HomeNew from './pages/Home/Home';


const App = () => (
  <section>
    <Header background="background-color-index-off-white" />
    <HeaderNew />
    <Box className="app__box--position-relative">
      <Carousel showArrow showThumbs={false} showStatus={false} >
        <div>
          <img src={bgslider1} alt="sd" />
        </div>
        <div>
          <img src={bgslider2} alt="sd" />
        </div>
      </Carousel>
    </Box>
    <Box className="app__box--position-absolute">
      <Home />
    </Box>
    <HomeNew />
    <Footer background="background-color-index-black" />
  </section>
);

export default App;

