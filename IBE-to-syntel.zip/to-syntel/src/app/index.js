import React from 'react';
// import PropTypes from 'prop-types';
// import { connect } from 'react-redux';
// import { Route, Redirect, withRouter, Switch } from 'react-router-dom';
import Async from 'react-code-splitting';


import Header from './shared/Header';
import Footer from './shared/Footer';

const Home = () => <Async load={import('./components/Home')} />;

const App = () => (
  <main className="app">
    <Header />
    <Home />
    <Footer />
  </main>
);


export default App;
