import React from 'react';
import _ from 'lodash';
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import { Carousel } from 'react-responsive-carousel';
// common components
import Box from '../../../../shared/components/Box/';


// Image path
import bgslider1 from '../../../../static/images/bgslider.jpg';
import bgslider2 from '../../../../static/images/bgslider.png';
// custom Components


const CarouselImg = () => (
  <Carousel showArrow >
    <div>
      <img src={bgslider1} alt="sd" />
      <p className="legend">Legend 1</p>
    </div>
    <div>
      <img src={bgslider2} alt="sd" />
      <p className="legend">Legend 2</p>
    </div>
  </Carousel>
);

export default CarouselImg;
