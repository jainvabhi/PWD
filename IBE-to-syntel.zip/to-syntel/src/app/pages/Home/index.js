import React from 'react';

// common components
import Box from '../../../shared/components/Box/';
import Button from '../../../shared/components/Button/';
import Heading from '../../../shared/components/Heading/';
import AutosuggestBox from '../../../shared/components/AutosuggestBox/';
import FormField from '../../../shared/components/FormField/';
import DatePicker from '../../../shared/components/Datepicker/';
// Image path
import calendar from '../../../static/images/calendar.png';
import arrival from '../../../static/images/arrival.png';
import departures from '../../../static/images/departures.png';
import pclass from '../../../static/images/class.png';
import PassengerType from './partial/PassengerType';

class Home extends React.Component {
  constructor(props) {
    console.log('sdf');
    super(props);
    this.state = {
      isRoundTrip: true,
    };
    this.onbuttonClick = this.onbuttonClick.bind(this);
  }

  onbuttonClick(isRoundTrip) {
    if (isRoundTrip !== this.state.isRoundTrip) {
      this.setState({
        isRoundTrip: !this.state.isRoundTrip,
      });
    }
  }

  render() {
    return (
      <Box>
        <Heading tag="h1" uppercase className="pb-2" bold>Boook A Flight</Heading>
        <Heading tag="h4" uppercase className="pb-3" bold>Discover a better way to fly</Heading>
        <Box row="row" className="mr-1">
          <Box col responsive={{ mobile: 5 }} >
            <Box className="bg-bark-trans">
              <Box padding="pad-md">
                <Box row="row" className="mb-3">
                  <Box col responsive={{ mobile: 12 }} >
                    <Box display="display-flex">
                      <Button title="Round Trip" onClick={() => this.onbuttonClick(true)} type={this.state.isRoundTrip ? 'primary' : 'secondary'} size="small" className="py-2" />
                      <Button title="One Way" type={!this.state.isRoundTrip ? 'primary' : 'secondary'} onClick={() => this.onbuttonClick(false)} size="small" />
                    </Box>
                  </Box>
                </Box>
                <Box row="row">
                  <Box col responsive={{ mobile: 12 }} >
                    <AutosuggestBox
                      label="From"
                      subLabel="Select Origin"
                      icon={departures}
                    />
                  </Box>
                </Box>
                <Box row="row">
                  <Box col responsive={{ mobile: 12 }} >
                    <AutosuggestBox
                      label="To"
                      subLabel="Select Destination"
                      icon={arrival}
                    />
                  </Box>
                </Box>
                {
                  this.state.isRoundTrip ?
                    <Box row="row" >
                      <Box col responsive={{ mobile: 6 }} >
                        <DatePicker
                          label="Depart Date"
                          subLabel="Depart Date"
                          icon={calendar}
                        />
                      </Box>
                      <Box col responsive={{ mobile: 6 }} >
                        <DatePicker
                          label="Return"
                          subLabel="Return Date"
                          icon={calendar}
                        />
                      </Box>
                    </Box> :
                    <Box row="row" >
                      <Box col responsive={{ mobile: 6 }} >
                        <DatePicker
                          label="Depart Date"
                          subLabel="Depart Date"
                          icon={calendar}
                        />
                      </Box>
                    </Box>}
                <Box row="row">
                  <Box col responsive={{ mobile: 6 }} >
                    <PassengerType />
                  </Box>
                  <Box col responsive={{ mobile: 6 }} >
                    <AutosuggestBox
                      label="Class"
                      subLabel="Class"
                      classType
                      icon={pclass}
                    />
                  </Box>
                </Box>
                <Box row="row">
                  <Box col responsive={{ mobile: 6 }} >
                    <FormField
                      type="text"
                      name="text"
                      label="password"
                      subLabel="Prom Code"
                      error="error message"
                      hideBottomMargin
                    />
                  </Box>
                  <Box col responsive={{ mobile: 6 }} >
                    <Button title="Search Flight" type="primary" size="small" className="py-2" />
                  </Box>
                </Box>
              </Box>
            </Box>
          </Box>
        </Box>
      </Box>
    );
  }
}

export default Home;

