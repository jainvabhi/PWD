import React from 'react';

const Header = () => (
  <header>Header Component</header>
);


export default Header;
