import React from 'react';

const Footer = () => (
  <footer>Header Component</footer>
);


export default Footer;
