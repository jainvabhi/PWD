import React from 'react';

const Home = () => (
  <div className="home">Home Page</div>
);


export default Home;
