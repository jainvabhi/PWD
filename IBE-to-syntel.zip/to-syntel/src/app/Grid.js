import React from 'react';

const Grid = () => (
  <main className="wrapper container-fluid">
    <section className="page-section">
      <h2>Responsive</h2>
      <p>Responsive modifiers enable specifying different column sizes, offsets, alignment and distribution at xs, sm, md &amp; lg viewport widths.</p>
      <div className="row">
        <div className="col-xs-12 col-sm-3 col-md-2 col-lg-1">
          <div className="box-row" />
        </div>
        <div className="col-xs-6 col-sm-6 col-md-8 col-lg-10">
          <div className="box-row" />
        </div>
        <div className="col-xs-6 col-sm-3 col-md-2 col-lg-1">
          <div className="box-row" />
        </div>
      </div>
      <div className="row">
        <div className="col-xs-12 col-sm-3 col-md-2 col-lg-1">
          <div className="box-row" />
        </div>
        <div className="col-xs-12 col-sm-9 col-md-10 col-lg-11">
          <div className="box-row" />
        </div>
      </div>
      <div className="row">
        <div className="col-xs-10 col-sm-6 col-md-8 col-lg-10">
          <div className="box-row" />
        </div>
        <div className="col-xs-2 col-sm-6 col-md-4 col-lg-2">
          <div className="box-row" />
        </div>
      </div>
    </section>
    <section className="page-section"><br />
      <h2>Fluid</h2>
      <p>Percent based widths allow fluid resizing of columns and rows.</p>
      <div className="row">
        <div className="col-xs-12">
          <div className="box-row" />
        </div>
      </div>
      <div className="row">
        <div className="col-xs-1">
          <div className="box-row" />
        </div>
        <div className="col-xs-11">
          <div className="box-row" />
        </div>
      </div>
      <div className="row">
        <div className="col-xs-2">
          <div className="box-row" />
        </div>
        <div className="col-xs-10">
          <div className="box-row" />
        </div>
      </div>
      <div className="row">
        <div className="col-xs-3">
          <div className="box-row" />
        </div>
        <div className="col-xs-9">
          <div className="box-row" />
        </div>
      </div>
      <div className="row">
        <div className="col-xs-4">
          <div className="box-row" />
        </div>
        <div className="col-xs-8">
          <div className="box-row" />
        </div>
      </div>
      <div className="row">
        <div className="col-xs-5">
          <div className="box-row" />
        </div>
        <div className="col-xs-7">
          <div className="box-row" />
        </div>
      </div>
      <div className="row">
        <div className="col-xs-6">
          <div className="box-row" />
        </div>
        <div className="col-xs-6">
          <div className="box-row" />
        </div>
      </div>
    </section>

    <section className="page-section">
      <h2>Offsets</h2>
      <p>Offset a column</p>
      <div className="row">
        <div className="col-xs-offset-11 col-xs-1">
          <div className="box-row" />
        </div>
      </div>
      <div className="row">
        <div className="col-xs-offset-10 col-xs-2">
          <div className="box-row" />
        </div>
      </div>
      <div className="row">
        <div className="col-xs-offset-9 col-xs-3">
          <div className="box-row" />
        </div>
      </div>
      <div className="row">
        <div className="col-xs-offset-8 col-xs-4">
          <div className="box-row" />
        </div>
      </div>
      <div className="row">
        <div className="col-xs-offset-7 col-xs-5">
          <div className="box-row" />
        </div>
      </div>
      <div className="row">
        <div className="col-xs-offset-6 col-xs-6">
          <div className="box-row" />
        </div>
      </div>
      <div className="row">
        <div className="col-xs-offset-5 col-xs-7">
          <div className="box-row" />
        </div>
      </div>
      <div className="row">
        <div className="col-xs-offset-4 col-xs-8">
          <div className="box-row" />
        </div>
      </div>
      <div className="row">
        <div className="col-xs-offset-3 col-xs-9">
          <div className="box-row" />
        </div>
      </div>
      <div className="row">
        <div className="col-xs-offset-2 col-xs-10">
          <div className="box-row" />
        </div>
      </div>
      <div className="row">
        <div className="col-xs-offset-1 col-xs-11">
          <div className="box-row" />
        </div>
      </div>

    </section>
    <section className="page-section">
      <h2>Auto Width</h2>
      <p>Add any number of auto sizing columns to a row. Let the grid figure it out.</p>
      <div className="row">
        <div className="col-xs">
          <div className="box-row" />
        </div>
        <div className="col-xs">
          <div className="box-row" />
        </div>
      </div>
      <div className="row">
        <div className="col-xs">
          <div className="box-row" />
        </div>
        <div className="col-xs">
          <div className="box-row" />
        </div>
        <div className="col-xs">
          <div className="box-row" />
        </div>
      </div>

    </section>
    <section className="page-section">
      <h2>Nested Grids</h2>
      <p>Nest grids inside grids inside grids.</p>
      <div className="row">
        <div className="col-xs-7">
          <div className="box box-container">
            <div className="row">
              <div className="col-xs-9">
                <div className="box-first box-container">
                  <div className="row">
                    <div className="col-xs-4">
                      <div className="box-nested" />
                    </div>
                    <div className="col-xs-8">
                      <div className="box-nested" />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xs-3">
                <div className="box-first box-container">
                  <div className="row">
                    <div className="col-xs">
                      <div className="box-nested" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-xs-5">
          <div className="box box-container">
            <div className="row">
              <div className="col-xs-12">
                <div className="box-first box-container">
                  <div className="row">
                    <div className="col-xs-6">
                      <div className="box-nested" />
                    </div>
                    <div className="col-xs-6">
                      <div className="box-nested" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </section>
    <section className="page-section">
      <h2>Alignment</h2>
      <p>Add classNamees to align elements to the start or end of a row as well as the top, bottom, or center of a column</p>
      <h3>.start-</h3>
      <div className="row">
        <div className="col-xs-12">
          <div className="box box-container">
            <div className="row start-xs">
              <div className="col-xs-6">
                <div className="box-nested" />
              </div>
            </div>
          </div>
        </div>
      </div>

      <h3>.center-</h3>
      <div className="row">
        <div className="col-xs-12">
          <div className="box box-container">
            <div className="row center-xs">
              <div className="col-xs-6">
                <div className="box-nested" />
              </div>
            </div>
          </div>
        </div>
      </div>

      <h3>.end-</h3>
      <div className="row">
        <div className="col-xs-12">
          <div className="box box-container">
            <div className="row end-xs">
              <div className="col-xs-6">
                <div className="box-nested" />
              </div>
            </div>
          </div>
        </div>
      </div>

      <p>Here is an example of using the modifiers in conjunction to acheive different alignment at different viewport sizes.</p>
      <div className="row">
        <div className="col-xs-12">
          <div className="box box-container">
            <div className="row center-xs end-sm start-lg">
              <div className="col-xs-6">
                <div className="box-nested" />
              </div>
            </div>
          </div>
        </div>
      </div>
      <h4>Example</h4>

      <h3>.top-</h3>
      <div className="row top-xs">
        <div className="col-xs-6">
          <div className="box-large" />
        </div>
        <div className="col-xs-6">
          <div className="box" />
        </div>
      </div>

      <h3>.middle-</h3>
      <div className="row middle-xs">
        <div className="col-xs-6">
          <div className="box-large" />
        </div>
        <div className="col-xs-6">
          <div className="box" />
        </div>
      </div>

      <h3>.bottom-</h3>
      <div className="row bottom-xs">
        <div className="col-xs-6">
          <div className="box-large" />
        </div>
        <div className="col-xs-6">
          <div className="box" />
        </div>
      </div>

    </section>
    <section className="page-section">
      <h2>Distribution</h2>
      <p>Add classNamees to distribute the contents of a row or column.</p>
      <h3>.around-</h3>
      <div className="row">
        <div className="col-xs-12">
          <div className="box box-container">
            <div className="row around-xs">
              <div className="col-xs-2">
                <div className="box-nested" />
              </div>
              <div className="col-xs-2">
                <div className="box-nested" />
              </div>
              <div className="col-xs-2">
                <div className="box-nested" />
              </div>
            </div>
          </div>
        </div>
      </div>

      <h3>.between-</h3>
      <div className="row">
        <div className="col-xs-12">
          <div className="box box-container">
            <div className="row between-xs">
              <div className="col-xs-2">
                <div className="box-nested" />
              </div>
              <div className="col-xs-2">
                <div className="box-nested" />
              </div>
              <div className="col-xs-2">
                <div className="box-nested" />
              </div>
            </div>
          </div>
        </div>
      </div>

    </section>
    <section className="page-section">
      <h2>Reordering</h2>
      <p>Add classNamees to reorder columns.</p>
      <h3>.first-</h3>
      <div className="row">
        <div className="col-xs-12">
          <div className="box box-container">
            <div className="row">
              <div className="col-xs-2">
                <div className="box-first">1</div>
              </div>
              <div className="col-xs-2">
                <div className="box-first">2</div>
              </div>
              <div className="col-xs-2">
                <div className="box-first">3</div>
              </div>
              <div className="col-xs-2">
                <div className="box-first">4</div>
              </div>
              <div className="col-xs-2">
                <div className="box-first">5</div>
              </div>
              <div className="col-xs-2 first-xs">
                <div className="box-nested">6</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <h3>.last-</h3>
      <div className="row">
        <div className="col-xs-12">
          <div className="box box-container">
            <div className="row">
              <div className="col-xs-2 last-xs">
                <div className="box-nested">1</div>
              </div>
              <div className="col-xs-2">
                <div className="box-first">2</div>
              </div>
              <div className="col-xs-2">
                <div className="box-first">3</div>
              </div>
              <div className="col-xs-2">
                <div className="box-first">4</div>
              </div>
              <div className="col-xs-2">
                <div className="box-first">5</div>
              </div>
              <div className="col-xs-2">
                <div className="box-first">6</div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </section>
    <section className="page-section">
      <h2>Reversing</h2>
      <h3>.reverse</h3>
      <div className="row">
        <div className="col-xs-12">
          <div className="box box-container">
            <div className="row reverse">
              <div className="col-xs-2">
                <div className="box-nested">1</div>
              </div>
              <div className="col-xs-2">
                <div className="box-nested">2</div>
              </div>
              <div className="col-xs-2">
                <div className="box-nested">3</div>
              </div>
              <div className="col-xs-2">
                <div className="box-nested">4</div>
              </div>
              <div className="col-xs-2">
                <div className="box-nested">5</div>
              </div>
              <div className="col-xs-2">
                <div className="box-nested">6</div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </section>
  </main>
);

export default Grid;
