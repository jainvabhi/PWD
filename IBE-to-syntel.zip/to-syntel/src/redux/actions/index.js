import { actionTypes as types, urls } from '../constants';
import { post } from '../helpers';

export const signup = ({ email, password }) => dispatch => {
  dispatch({ type: types.LOGIN_REQUEST });
  post({
    url: urls.LOGIN,
    body: { email, password },
    success: types.LOGIN_SUCCESS,
    failure: types.LOGIN_FAILURE,
    dispatch,
  });
};
